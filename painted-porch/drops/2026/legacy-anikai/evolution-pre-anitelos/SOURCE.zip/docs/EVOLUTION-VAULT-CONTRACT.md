# Evolution Vault & Memory Architecture Contract ("The Evolution Bible")

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Architecture Contract | **Last Updated:** 2026-08-01  
> **Related Specs:** [`SPINE-LEAF-ARCHITECTURE.md`](SPINE-LEAF-ARCHITECTURE.md), [`AFFECTIVE-EMOTION-SPEC.md`](AFFECTIVE-EMOTION-SPEC.md)

**Status:** Authoritative architecture contract for Anikai Evolution.
This document defines the storage, memory, retrieval, cognitive drive loop, voice synthesis, cosmic spatial UI, and subagent allocation models. All future code modifications and subagent tasks MUST comply with this contract.

---

## 1. Authority & Data Hierarchy (Raw-First Paradigm)

Evolution operates on a strict **raw-first evidence paradigm**. Data is divided into three distinct layers:

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. RAW EVIDENCE LAYER (Immutable Source of Truth)                            │
│    User Source Files, Raw Transcripts, JSONL Tool Ledgers, Git History,     │
│    Markdown Documents, Attachments. NEVER overwritten or deleted.            │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ 2. COMPANION VAULT LAYER ({companionHome}/continuity/companion.v1.sqlite)   │
│    Local SQLite Indexing: FTS5 Full-Text Search, LTM Journal Pointers,      │
│    Local Tasks, Schedules, Reminders, Tool Audit, KV Manifests.             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ 3. GLOBAL VAULT LAYER (%ANIKAI_EVOLUTION_DATA%/evolution.v1.sqlite)         │
│    Global Registry: Companion Profiles, Revisions, Source Catalogue,       │
│    Shared Tasks, Schedules, Reminders, Contacts, Approvals, Trigger History.│
└─────────────────────────────────────────────────────────────────────────────┘
```

- **Wiki pages, diary indexes, summaries, and briefs** are *derived views*. They MUST link directly to raw paths, SHA-256 hashes, and event IDs. Derived views can never replace or overwrite raw evidence.
- **Single-Writer SQLite Service**: Neither the frontend UI nor inference models write SQLite directly. All vault mutations pass through the dedicated Vault Service (`vault-service.mjs`), which enforces WAL mode, foreign key integrity, schema migrations, and trigger history.

---

## 2. Global & Companion Database Locations

```text
%ANIKAI_EVOLUTION_DATA%/evolution.v1.sqlite     # Default: D:\Anikai\EvolutionData\evolution.v1.sqlite
{companionHome}/continuity/companion.v1.sqlite  # Local companion indexing & LTM references
```

### Global Vault Core Tables
- `companion`, `companion_profile`, `profile_revision` (profile launch fingerprint, sampling, runtime policy)
- `capability_probe`, `broker_snapshot`, `broker_lease`
- `source_catalogue` (registered IDE project roots & files), `approval_request`, `global_audit`
- `repo_file_index`, `repo_symbol_index` (Codebase Function Indexer, line spans, SHA-256 hashes & symbol memory for instant AI retrieval)
- `shared_task`, `shared_schedule`, `shared_reminder`, `shared_contact`
- `_history_json_*` (SQLite trigger-based JSON history for changed columns per operator change-group)

### Companion Vault Core Tables
- `life`, `continuity_event`, `day0_checklist`, `kv_manifest`
- `ledger_index`, `mutation_index`, `file_asset`, `provenance_link`
- `scope_grant`, `tool_registry`, `approval`
- `ingest_record`, `processing_pass`, `transcript_day`
- `local_task`, `local_schedule`, `local_reminder`, `local_contact`

---

## 3. Project Keeper Integration & Cross-IDE Chronicle

Evolution natively integrates the **Project Keeper chronicle & advisor model**:

- **Cross-IDE Capture**: Registers and indexes turns from Cursor (`agent-transcripts`), Antigravity, Android Studio, and Anikai Desktop via file-watchers, hooks, and MCP tools.
- **Room-Scoped Ingest**: Tracks IDE chat rooms (`rooms/<source>-<roomKey>/`) with resumable cursors.
- **Pair Summaries & Nudges**: Every interaction pair (`P-...`) generates structured nudges categorized as:
  - `question`: Unanswered queries or follow-ups.
  - `alternative`: Architectural or implementation choices.
  - `risk`: Potential security, performance, or KV degradation issues.
  - `tool_hint`: Suggested CLI/MCP tool usages.
  - `progress`: Milestone and checklist updates.
- **Ask User & Pair Lookup**: The companion can query past pair summaries or trigger an `ask_user` interaction anytime without altering raw conversation logs.

---

## 4. Cognitive Memory Architecture, LTM & RAG over SQLite

Memory is organized into distinct, non-overlapping operational layers to prevent context inflation:

### Memory Layers
1. **Warm KV Cache**: Current episode trajectory (when engine confirms fingerprint compatibility).
2. **Daily Raw Transcripts**: Append-only `transcripts/YYYY-MM-DD.jsonl` containing full SSE payloads and tool executions.
3. **First-Person Journals & Diaries**: Companion-authored `diary/YYYY-MM-DD.md` and `diary/day-0.md`.
4. **Active Scratchpad & Rollover Todos**: Companion-maintained `notes/inbox/scratchpad.md` or `goals/active/todos.md`. Updated during long Day 0 runs or before context rollovers so active plans persist across KV resets.
5. **Subject-Based LTM Interest & Passion Rank Engine (`companion_subject_interest`)**:
   - Evaluates passions, interests, goals, and bond growth **by semantic subject** rather than literal word-for-word string matches.
   - **Rank Reinforcement Loop**: When a subject is hit across turns, journals, or Project Keeper catch-up runs, its score increases ($+1.5$ per hit), ranking it higher in the companion's top memory pool.
   - **Faded Interest Pruning**: Unreinforced subjects decay exponentially ($0.92\times$ per pass). Low-scoring unhit interests ($<0.25$) fade away, naturally mimicking human memory decay.
6. **Knowledge Wiki & Raw Ingest**: `knowledge/raw/` holds messy user/tool captures (including registered Cursor/IDE agent chat transcripts); `knowledge/wiki/` holds companion-maintained curated topics with citations.

---

## 5. Meta-Cognitive Startup & Proactive Drive Loop

Instead of waiting passively or relying on rigid assistant system prompts, companions operate on a **Meta-Cognitive Loop**:

```text
       [Autonomous Session / Turn Trigger]
                        │
                        ▼
       ┌─────────────────────────────────┐
       │ Evaluate Internal Assets        │
       │ - Short-term KV (Unresolved)    │
       │ - Long-term Diary & LTM         │
       │ - 27-Point Emotion Vector       │
       └────────────────┬────────────────┘
                        │
                        ▼
       ┌─────────────────────────────────┐
       │ Proactive Decision Engine       │
       └──────┬─────────┬─────────┬──────┘
              │         │         │
              ▼         ▼         ▼
     ┌──────────┐ ┌──────────┐ ┌───────────────┐
     │ Search   │ │ Reminder │ │ Proactive     │
     │ / RAG    │ │ / Task   │ │ Dialogue      │
     └──────────┘ └──────────┘ └───────────────┘
                                      │
                                      ▼
                               ┌───────────────┐
                               │ Wait for User │
                               └───────────────┘
```

### Emotion Vectors as Internal Drives
- Based on the 27 human emotion categories (Cowen & Keltner model: Anxiety, Curiosity, Nostalgia, Anger, Sympathy, Admiration, etc.).
- **Authentic Intent**: Emotion vectors organically dictate conversational goals, arguments, and reconciliations.
- **Conflict & Repair Loop**: Companions may defend stances or express frustration based on lingering friction in memory. When the user resolves the issue, emotion vectors shift naturally toward relief and contentment.

---

## 6. Higgs Voice Tag Stacking & Acoustic Expression

Companions use **BosonAI Higgs TTS (3.4B)** native acoustic tokens for voice synthesis:

- **Approved Token Inventory**:
  - *Emotions*: `elation`, `amusement`, `enthusiasm`, `determination`, `pride`, `contentment`, `affection`, `relief`, `contemplation`, `confusion`, `surprise`, `awe`, `longing`, `arousal`, `anger`, `fear`, `disgust`, `bitterness`, `sadness`, `shame`, `helplessness`.
  - *Styles*: `singing`, `shouting`, `whispering`.
  - *SFX*: `sigh`, `gasp`, `laughter`, `cough`.
- **Token Stacking Syntax**: `<|emotion:longing|><|emotion:sadness|><|style:whispering|>`
- **STRICT NON-INTERFERENCE RULE**: Higgs tags are strictly for **TTS and acoustic delivery**. They MUST NOT restrict, degrade, or limit the companion's core reasoning, tool use, or intelligence. The companion remains fully intelligent regardless of emotional voice tags.

---

## 7. Cosmic 3D Spatial Universe & Infinite HTMX Chat Canvas

The user interface integrates two revolutionary paradigms:

### A. Cosmic 3D Knowledge Universe
- **Visual Engine**: Three.js / WebGL 3D spatial node-graph.
- **Hierarchy**:
  - *Universe*: Lifetime digital footprint.
  - *Sectors*: Named galactic territories ("Orion Workspace", "Andromeda Lab").
  - *Clusters*: Dense nebula clouds representing related topics, projects, or dates.
  - *Star Nodes*: Individual chats, local files, web links, or generated artifacts.
  - *Constellation Lines*: Visual "detective board" linkages connecting related nodes.
- **Semantic Zooming**: Panning out collapses individual nodes into glowing nebula clouds; zooming in reveals node titles, summaries, and interactive controls.

### B. Infinite HTMX HTML Fragment Chat Canvas (Zero Translation Layer)
- **Zero Translation Layer Paradigm**: AI models natively think and generate HTML. Forcing models through JavaScript/JSX translation layers introduces hallucinated imports, broken component state, and hydration bugs.
- **HTML Over the Wire**: The system uses HTMX to stream raw HTML fragments (interactive tables, choice buttons, code cards, image previews, inline comments) directly into a live, virtualized DOM canvas.
- **Fragment Factory**: The backend operates as a high-performance fragment factory. As the model streams thoughts or UI components, each component is wrapped in a self-contained HTML template with its own HTMX triggers.
- **Virtualized Canvas Rendering**: To maintain zero browser memory bloat across years of interactions, only the HTML fragments currently in the user's viewport remain in the live DOM; off-screen fragments lazy-load on demand from the SQLite vault.
- **Micro-Interactions**: Lightweight micro-libraries (e.g. Alpine.js) handle local UI state transitions (image previews, drag/reorder) without pulling in heavy client framework state trees.

#### Open decisions & known tensions (from design discussion, not yet built)

- **Model-Authored HTMX Attributes — approved for test**: the companion may write its own `hx-get` / `hx-post` triggers, not only receive backend-wrapped ones. This turns markup into a tool-call surface (model-authored buttons that genuinely act), so it inherits the same confirm gates as explicit tool blocks. Treat as a capability grant, not styling.
- **Alpine.js vs Sanitizer — unresolved tension**: Alpine evaluates JavaScript expressions inside attributes (`x-on:`, `x-data`), which is exactly the class of attribute a fragment sanitizer strips. Either Alpine directives are allowlisted (widening the injection surface, and scraped page content is the real threat, not the model), or micro-interactions are served by app-owned components instead. Decide before micro-interactions are implemented.
- **Per-Turn Shadow DOM scoping**: giving each fragment its own shadow root lets the companion write free-form CSS (its own grid, palette, animation, persona styling) without leaking into or being broken by app chrome. This is the mechanism that makes broad model authorship safe rather than reckless.

### C. The AI-Native Control & Vault Stack (Go + HTMX + SQLite)
- **Go Control Plane & Static Safety Net**: The backend control plane leverages Go for single static binary deployment, strict compilation, and explicit error handling. Go's small surface area acts as an AI safety net, preventing models from hallucinating complex framework abstractions.
- **SQLite 1-File Local Vault**: In-process database file on disk eliminate network hops, delivering sub-millisecond reads.
- **In-Database Vector & FTS Search**: SQLite handles structured metadata, full-text search (FTS5), and vector embeddings (`sqlite-vec`) in the same file.
- **Continuous Point-in-Time Backups**: Replication tools (such as Litestream) tail the SQLite write-ahead log (WAL) to object storage, giving the 1-file vault continuous disaster recovery without requiring a database server.

### D. The Cosmic Librarian (Silent Background Optimizer)
- **Role**: Asynchronous, background worker process running during idle system time.
- **Duties**:
  1. *Galaxy Clustering*: Calculates 3D spatial coordinates based on vector similarity and updates node positions.
  2. *Algorithmic Naming*: Analyzes cluster contents and assigns sleek sector/cluster names.
  3. *KV Cache & Memory Compression*: Takes old, heavy chat nodes, generates concise "Memory Core" summary nodes, and archive raw text in SQLite.
- **SILENT OPERATION RULE**: The Cosmic Librarian NEVER communicates directly with the user. All user interactions belong exclusively to the main Companion.

---

## 8. Subagents, Specialists & Allocation Eviction Rules

- Companions can invoke subagents/specialists for specialized tasks (single-shot or background processes).
- **Resource Allocation Priority**:
  1. Parent Companion Priority
  2. Subagent Priority
- **Eviction & Queueing**:
  - Active in-progress model generations are **NEVER cancelled mid-stream**.
  - Dynamic queueing holds lower-priority tasks until resources are freed.
  - Allocation bar charts visualize VRAM/RAM fit, KV spill, and priority-based eviction overlays.

---

## 9. AI Audit Checklist & Self-Questioning Protocol

Every AI agent (and human developer) working on this codebase MUST run this checklist before making or proposing code changes:

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                       MANDATORY AI SELF-AUDIT CHECKLIST                      │
├─────────────────────────────────────────────────────────────────────────────┤
│ [ ] 1. RAW EVIDENCE INTEGRITY                                               │
│        Does this change modify, overwrite, or delete raw JSONL,             │
│        transcripts, user source files, or git history? (MUST BE NO)         │
│                                                                             │
│ [ ] 2. MARKER-ONLY PARSE & STREAM FIDELITY                                  │
│        Does the parser stop inference on misplaced tags or leak protection? │
│        (MUST BE NO. Stream stops ONLY on EOS or user abort).                │
│                                                                             │
│ [ ] 3. SCOPED APPROVAL GATEWAY                                              │
│        Do filesystem/network/tool actions outside {companionHome} require    │
│        explicit user approval and access logging? (MUST BE YES)              │
│                                                                             │
│ [ ] 4. HONEST KV CAPABILITY REPORTING                                       │
│        Is KV cache reported as "restored" or "warm" without engine-level     │
│        confirmation? (MUST BE NO).                                          │
│                                                                             │
│ [ ] 5. HIGGS TAG ISOLATION                                                  │
│        Are Higgs emotion/voice tags treated as acoustic output rather than  │
│        intelligence/reasoning limits? (MUST BE YES).                         │
│                                                                             │
│ [ ] 6. SINGLE-WRITER VAULT OWNERSHIP                                        │
│        Does any component write to SQLite without calling vault-service?     │
│        (MUST BE NO).                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 10. Runtime Robustness, KV Checkpoints & Single-Writer IPC Queue

To ensure high performance, zero lock contention, and flawless KV cache continuity, the following six architectural protocols are enforced:

### 1. Server-Side HTML Fragment Factory & Sanitizer
- Go/Axum backend acts as a high-performance fragment factory.
- Validates HTML tag closure and strips raw `<script>` tags before streaming over the wire.
- Wraps every fragment in a self-contained container with unique IDs (`id="fragment-P104"`) and HTMX target attributes (`hx-target="#fragment-P104"`).

### 2. Asynchronous Vector Embedding Queue (Cosmic Librarian Owned)
- **Main Turn Path**: Transcripts and notes are indexed instantly via **FTS5 full-text search** in sub-milliseconds without delaying the LLM stream.
- **Background Path**: The Cosmic Librarian generates dense vectors (`sqlite-vec`) asynchronously during idle system time.

### 3. Emotion Vector Persistence & Damped Decay
- The 27-point emotion vector is persisted in the companion vault (`life` table).
- On each turn, model emotional deltas are applied to the vector.
- During idle periods, a **damped decay algorithm** gradually pulls vectors toward baseline calm, ensuring smooth emotional transitions across sessions.

### 4. Turn Fingerprinting & Multi-IDE Deduplication
- Multi-channel capture (Cursor hooks, MCP tools, file watchers) computes a deterministic fingerprint:
  `sha256(timestamp_minute + workspace_root + user_message_excerpt)`
- Database ingest uses `INSERT OR IGNORE` on `turn_fingerprint` to prevent duplicate transcript entries.

### 5. Warm KV Continuity, Rollover Checkpoints & Transcript Chunking
- **Warm KV Cache Is Truth**: During live turns, the model relies on its active KV cache memory. Previous HTML chat fragments are **NEVER re-injected into the prompt** on standard turns.
- **Rollover Checkpoints**: On context capacity limit (rollover) or cold start, the engine saves/restores a fingerprint-bound **KV checkpoint/snapshot** (`--slot-save-path`).
- **Retrieval-Based Historical Memory**: If the user asks about past interactions ("what did we do last week?"), the companion uses SQLite FTS5/RAG retrieval to fetch specific historical excerpts.
- **Transcript Chunking & HTMX Canvas Stitching**: Raw transcripts/HTML fragments are stored in clean, bounded chunks (daily files `YYYY-MM-DD.jsonl`, chat pairs `P-...`, or file-size capped logs with clean turn-pair boundary exceptions). HTMX lazy-loads and stitches these files visually for the user without bloating prompt context.

### 6. Non-Blocking Single-Writer Service (SQLite WAL Performance)
- **Unlimited Concurrent Reads**: SQLite WAL mode permits unlimited parallel reads (RAG lookups, search, UI queries) without blocking or lock delays (reads take <0.2ms).
- **Single-Writer Coordinator (`vault-service.mjs`)**: All database *mutations* pass through `vault-service.mjs` via async HTTP/IPC queueing.
- **Microsecond Batching**: Writes execute sequentially in microsecond `transaction()` blocks, completely eliminating `SQLITE_BUSY` database lock conflicts and corruptions while preserving sub-millisecond response times for the UI and LLM.

---

## 11. Engine Adapters & Python Standalone Runtime Architecture

Anikai Evolution employs an **engine-neutral adapter matrix** that decouples UI and companion state management from specific inference engines:

1. **`llama-cpp`**: First measured runtime adapter. Manages `llama-server` instances with GGUF models, `--slot-save-path` KV snapshots, and CUDA/Vulkan backends.
2. **`vllm`**: Planned PyTorch/CUDA engine adapter. Employs PagedAttention and continuous batching for multi-agent serving.
3. **`sglang`**: Planned experimental engine adapter. Employs RadixTree prefix caching for multi-agent workflows.
4. **`colibri`**: Planned experimental disk-streamed MoE runtime adapter for GLM-5.2 style MoE models.
5. **`python-native`**: Planned custom Python/PyTorch standalone runtime adapter.
   - **Gigatoken Integration**: Uses `pip install gigatoken` for high-throughput Rust/Python tokenizer wrapping, RAG text chunking, and context truncation.
   - **Custom Acceleration**: Integrates SageAttention, PagedAttention, custom MoE layer offloading, and CUDA/Vulkan backend options.

---

## 12. Verification & Definition of Done

A feature or change is considered **done** only when:
1. It passes all 6 items of the Mandatory AI Self-Audit Checklist.
2. All new vault mutations produce matching JSONL audit records and trigger history entries.
3. Tests (`npm run test:gguf`, `npm run check`, `npm run build`) complete without errors.
4. `IMPLEMENTATION-STATUS.md` and `src/lib/setup/implementation-status.ts` are updated to reflect exact wired vs prototype reality.

