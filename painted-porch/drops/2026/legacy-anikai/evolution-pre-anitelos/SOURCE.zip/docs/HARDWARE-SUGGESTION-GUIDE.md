# Anikai Evolution - Hardware Suggestion & Acceleration Guide

This guide breaks down the hardware physics, memory bandwidth bottlenecks, GPU vs Unified Memory choices, engine backends (CUDA, Vulkan, ROCm), attention acceleration mechanisms (PagedAttention, SageAttention), hardware topology recommendations, and KV snapshot vs checkpoint mechanics for running high-parameter companion runtimes and sub-agents.

---

## 1. The Physics of Token Generation Speed (Tok/s)

In Large Language Model (LLM) inference, generation/decoding is almost entirely **memory-bandwidth bound**. Every single token generated requires reading model weights and KV cache tensors from memory into compute cores.

### The Decode Formula:
$$\text{Theoretical Speed (Tokens/s)} \approx \frac{\text{Memory Bandwidth (GB/s)}}{\text{Active Parameters / Weights Loaded Per Token (GB)}}$$

| Model Class | Active Model Size (Q4/FP4) | Memory Location | Memory Bandwidth | Estimated Decode Speed |
| :--- | :--- | :--- | :--- | :--- |
| **Gemma 4 12B / A4B** | ~7 - 9 GB | GPU VRAM (RTX 5080 GDDR7) | **~1,000 GB/s** | **60 – 110 tok/s** |
| **Gemma 4 12B / A4B** | ~7 - 9 GB | System RAM (DDR5 Dual Channel) | **~60 – 80 GB/s** | **8 – 12 tok/s** |
| **Laguna S 2.1 118B MoE** | ~71 GB (8.5B active = ~17 GB/token) | GPU VRAM (e.g. Dual 72GB) | **~1,000 GB/s** | **55 – 85 tok/s** |
| **Laguna S 2.1 118B MoE** | ~71 GB (8.5B active = ~17 GB/token) | System RAM Spill (PCIe Gen 5) | **~64 – 80 GB/s** | **10 – 16 tok/s** |

---

## 2. Hardware Investment Comparison & Strategy

When evaluating hardware choices for running 100B+ MoE companion runtimes and fast ephemeral sub-agents, consider the trade-offs between **Dedicated GDDR7/GDDR6 VRAM** vs. **Unified Memory Systems**.

### Comparison Matrix:

| Hardware Configuration | Total Memory | Memory Bandwidth | Estimated 118B MoE Speed | Key Strengths & Drawbacks |
| :--- | :--- | :--- | :--- | :--- |
| **1x PNY RTX PRO 5000 (72GB GDDR7)** | 72 GB VRAM | **~1,000 GB/s** | **45 - 65 tok/s** | **Best Single-GPU Value**: Entire 71GB FP4/Q4 MoE fits in 100% VRAM! Ultra-fast CUDA & vLLM/FlashInfer support. |
| **2x PNY RTX PRO 5000 (144GB VRAM Total)** | 144 GB VRAM | **~2,000 GB/s** (Tensor Parallel) | **80 - 120 tok/s** | **Ultimate Workstation Powerhouse**: Runs 118B MoE at maximum speed, plus leaves 70GB VRAM for 2-3 parallel sub-agents/familiars. |
| **4x Gigabyte Radeon Pro W7800 (192GB VRAM)** | 192 GB VRAM | **~864 GB/s per card** | **50 - 75 tok/s** | **Unbeatable VRAM per Dollar ($8k Total)**: 192GB VRAM supports 1M token contexts and 5+ parallel sub-agents. Uses Vulkan/HIP multi-GPU on llama.cpp. |
| **1x RTX PRO 6000 (Blackwell 96GB)** | 96 GB VRAM | **~1,200 GB/s** | **60 - 80 tok/s** | High cost ($10k+). Single card simplicity, but double RTX PRO 5000 or 4x W7800 offers better VRAM capacity per $. |
| **NVIDIA DGX Spark / GB10** | 128 GB Unified | **~270 GB/s** | **14 - 24 tok/s** (30+ w/ DFlash) | Compact, all-in-one box, low power. Capped by unified memory bandwidth. |
| **AMD Strix Halo (128GB LPDDR5X)** | 128 GB Unified | **~270 GB/s** | **12 - 18 tok/s** | Compact APU box. Limited by ROCm driver setup on Windows/Linux; Vulkan backend recommended for llama.cpp. |
| **Apple Mac Studio (M3/M4 Max 128-192GB)** | 128 - 192 GB | **~400 - 800 GB/s** | **18 - 32 tok/s** | Excellent Apple Metal support via MLX or llama.cpp. Higher bandwidth than PC DDR5, but slower than dedicated GDDR7 VRAM. |

---

## 3. Gigabyte Radeon Pro W7800 48GB Analysis

The **Gigabyte Radeon Pro W7800 AI TOP 48GB** ($2,000+ price point) is an exceptionally strong candidate for multi-GPU local AI rigs:
1. **Specs**: 48GB GDDR6 VRAM, 384-bit memory bus, **864 GB/s bandwidth**.
2. **4x Setup (192 GB VRAM Total)**: Costs ~$8,000–$9,000 for 192GB VRAM.
3. **1 Million Tokens + Parallel Familiars**: 192GB VRAM allows hosting a 100B+ MoE (70GB), a 1M token KV cache (~30–50GB in Q8/Q4 KV), and running 4–5 parallel sub-agents/familiars without ever offloading to slow system RAM.
4. **Driver Backend Recommendation**: On Windows, use `llama.cpp`'s **Vulkan AI** backend with `-sm row` or `-sm layer` multi-GPU split. On Linux, use **AMD ROCm / HIP** for native tensor parallelism.

---

## 4. Backends & Attention Mechanisms

### A. CUDA vs Vulkan vs ROCm
- **NVIDIA CUDA**: Gold standard for AI inference. Native support for FlashInfer, vLLM, TensorRT-LLM, DFlash speculative decoding, and FP4/FP8 quantization.
- **Vulkan AI**: Excellent cross-platform fallback for integrated/AMD graphics on llama.cpp. Avoids ROCm driver instability on Windows.
- **AMD ROCm**: Native Linux driver for AMD GPUs. Requires specific PyTorch/HIP builds.

### B. PagedAttention
- Organizes Key-Value (KV) cache memory into non-contiguous fixed-size blocks (like OS virtual memory paging).
- Prevents memory fragmentation and enables zero-copy prefix sharing (prompt caching across multiple turns and sub-agents).
- Standard in vLLM, SGLang, and supported/simulated in llama.cpp slot management.

### C. SageAttention & FlashAttention
- **FlashAttention-2 / FlashAttention-3**: Exact attention algorithms that compute softmax without writing intermediate $N \times N$ attention matrices to VRAM, yielding 2x-4x prefill speedups.
- **SageAttention**: Quantized $8$-bit/INT4 exact attention kernel optimized for ultra-fast prefill and decode on massive context lengths (100k+ tokens).

---

## 5. RAG Retrieval Architecture & Specialized Models

For high-precision, low-latency document and memory retrieval, generative LLMs are paired with dedicated RAG models in a 3-stage pipeline:

1. **Stage 1 (Dense Vector Embedding & Sparse BM25 Search)**:
   - **Embedding Models**: `bge-m3` (multilingual, 8k context) or `nomic-embed-text-v1.5` (8k context) generates 1024-dim vectors stored in `sqlite-vec`.
   - **Full-Text Search**: SQLite FTS5 index performs fast BM25 keyword matching across documents/transcripts.
   - **Latency**: 2 – 5 ms.
2. **Stage 2 (Cross-Encoder Reranking)**:
   - **Reranker Models**: `bge-reranker-v2-m3` or a fast Familiar sub-agent re-scores the top 20 candidate chunks down to the top 5 most relevant excerpts.
   - **Latency**: 15 – 30 ms.
3. **Stage 3 (Generative Synthesis)**:
   - The Companion or Familiar receives only the top 5 precise chunks in its context window.

---

## 6. Cosmic Librarian Model Selection

The **Cosmic Librarian** is the asynchronous background process responsible for:
- Log clustering, algorithmic naming, and knowledge graph extraction
- KV cache compression and eviction priorities
- Auto-chunking, vector embedding, and hybrid indexing (RAG)
- Journal and transcript summarization

### Recommended Models:
- **Embedding Component**: `bge-m3` (8k context, multi-stage retrieval).
- **Summarization & Clustering LLM**: **Qwen 2.5 7B / 14B (Q4_K_M)**, **Gemma 2 9B**, or **DeepSeek-R1-Distill-Qwen-14B**.
- **Execution Speed**: Generates clean structured JSON and summaries at 60–120 tok/s in VRAM.

---

## 7. KV Snapshot vs Context Checkpoint Mechanics

| Feature | KV Snapshot (`--slot-save-path`) | Context Checkpoint (Prefix Cache) |
| :--- | :--- | :--- |
| **Storage Location** | Binary file on disk (`.bin` in companion home) | Live GPU VRAM / System RAM |
| **Restore Speed** | **0 milliseconds** (instant reload without prefill) | Near-instant prefill bypass during runtime uptime |
| **Use Case** | Persistent session recovery, cold starts, and swapping model instances between Companion and Familiars | Live conversation turns sharing identical system instructions or Day 0 prompts |
| **Isolation Benefit** | Saving a Companion's slot state to a KV Snapshot allows sharing a 12B model instance with a Familiar sub-agent without dirtying or corrupting the Companion's warm conversation context! | Speeds up prompt prefill across multiple active slots. |

---

## 9. Gigatoken & Python Standalone Engine Architecture

### A. What Gigatoken Is (and What It Is Not)
- **What It Is**: A high-speed, Rust-backed Python tokenizer library (`pip install gigatoken`). It operates at the application/data preprocessing level, processing raw text into token IDs at 100x the speed of standard tokenizers (up to 30,000+ tokens/s).
- **What It Is Not**: Gigatoken is not a standalone LLM weights generation engine (like `llama.cpp` or `vLLM`). It accelerates the **tokenization and data preparation step**, not the matrix-multiplication decode loop.
- **Best Use Cases in Anikai Evolution**:
  1. **SQLite RAG Document Chunking**: Converts raw PDFs, markdown, and transcripts into precise token-bound chunks before inserting them into `sqlite-vec`.
  2. **Dynamic Context Truncation**: Instantly counts and trims old multi-turn chat logs on the CPU in < 1ms before handing the context over to the inference engine.

### B. Python Native Standalone Engine Profile (`python-native`)
To give users full flexibility without relying exclusively on fixed binary adapters, Anikai Evolution introduces the **Python Native Standalone Engine** (`python-native`):
- **Architecture**: A PyTorch-based standalone runtime server exposing an OpenAI-compatible REST/SSE API (`llama-dev-runtime.mjs` bridge).
- **Embedded Acceleration Stack**:
  - **Tokenizer**: Leverages **Gigatoken** as a drop-in replacement for HuggingFace `AutoTokenizer` or `tiktoken`.
  - **Attention Kernels**: Integrates **SageAttention** (8-bit quantized attention) and **PagedAttention** (non-contiguous KV paging).
  - **MoE & Memory Offloading**: Custom PyTorch expert routing between VRAM, RAM, and NVMe drives.
  - **Hardware Backends**: Explicit CUDA or Vulkan backend selection.

