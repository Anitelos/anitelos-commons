# Colibri experimental adapter note

Colibri is tracked as a future, experimental engine adapter because its
disk-streamed MoE design aligns with Evolution's resource-broker direction:
it stages model components across VRAM, RAM, and NVMe instead of requiring
all weights to remain resident.

Current boundary:

- The documented runtime targets converted GLM-5.2 int4 MoE data, not GGUF
  files or arbitrary 100-200B models.
- Its optional gateway is OpenAI-compatible, so a future adapter can use the
  same external chat contract after it verifies endpoints and telemetry.
- Its expert tier, disk reads, routing heat, and compressed MLA KV are
  engine-specific measurements. Evolution must not estimate or claim them
  until an adapter collects them.
- Colibri's cached/persisted KV is not interchangeable with llama.cpp slots
  or Evolution's generic recovery records.

Future work is an adapter probe, a Colibri model import path, and run-ledger
facts for NVMe throughput, tier residency, expert cache misses, and warm-KV
compatibility. No installer or runtime control is provided yet.
