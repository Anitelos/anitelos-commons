# Capability Test Matrix

- **wired**: GGUF/mmproj evidence inspector, per-profile cache and MoE launch
  policy, runtime fingerprint invalidation, and effective-argument/run-ledger
  evidence.
- **available after probe**: optional llama.cpp cache, Flash Attention,
  batching, checkpoint, cache-RAM, and CPU-MoE arguments. The managed runtime
  reads binary help/version before it emits these arguments.
- **experimental / not bundled**: TurboQuant quality comparisons,
  PagedAttention, Radix/prefix cache, vLLM/SGLang dynamic KV, tensor
  parallelism, and continuous batching. These remain visibly disabled.
# Implementation Status

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Active Ledger | **Last Updated:** 2026-08-01  
> **Related Specs:** [`SPINE-LEAF-ARCHITECTURE.md`](SPINE-LEAF-ARCHITECTURE.md), [`EVOLUTION-VAULT-CONTRACT.md`](EVOLUTION-VAULT-CONTRACT.md)

This is the source-of-truth checklist for what Setup displays and whether it is actually connected.

## State vocabulary

| State | Meaning |
|---|---|
| Wired | Works locally now, with direct evidence. |
| Prototype | UI/data contract exists; it does not yet invoke the underlying service. |
| Planned | Deliberately not implemented yet. |
| Blocked | Cannot be implemented honestly until an engine, operating-system, or hardware capability is probed. |

## Current checklist

| Area | Item | State | Reality now | Next | Constraint / conflict |
|---|---|---|---|---|---|
| Persona | Trait Sliders, Image Drop & Profile Cards | Wired | Persona tab includes 20 Writing Style & Persona State sliders, RP ↔ Romance dynamic slider, Day 0 Origin Image Drop & Preview, "Tiny ✕" field clear buttons, Persona Presets, and Saved Profile Vault Cards (Edit, Reset Day 0, Clear Home, Delete). | Wire dynamic emotion vector scaling during turns. | Sliders persist with profile draft without VRAM overhead. |
| Setup | Companion name, home, identity notes | Wired | Saved in a versioned browser-local draft with auto-slugified vault folder pathing and field clear buttons. | Replace browser storage with the Setup service. | Browser storage is not a companion vault. |
| Model | Primary GGUF & Control Vector Trait Dial | Wired | Native `--control-vector` and `--control-vector-scaled` support in `llama-server`. Control vector picker and scale dial directly on Subtab 01 (Persona & Identity) for Companions & Familiars. | Add multi-vector stacking. | Control vectors shift activation register without VRAM cost. |
| Navigation | Familiars Studio & Topbar Dev Ledger | Wired | 4th rail tab for niche Familiars with preset templates (`D:\Anikai\Familiars\`) and topbar `⚡ Dev Ledger & Logs` modal. | Connect live sub-agent parallel execution pool. | Familiars must remain unbiased single-shot utilities without Day 0 roleplay. |
| Cognition | Affective Emotion Subconscious Hive | Wired | Spec (`AFFECTIVE-EMOTION-SPEC.md`) defines Multi-LoRA 1st-person monologue hive, GoEmotions -> Higgs TTS translation layer, dynamic control vector trait steering, baseline anchoring ($w_{\text{task}}$ balance), overthinking circuit breaker, and capability gating with one-click `⚡ Install & Stage Emotion Classifier` (`Gemma-2B-e2b` / `D:\Anikai\models`). | Fine-tune 27 micro-LoRA adapters & wire dynamic vector slider maps. | Subconscious thoughts must never break 1st-person framing or corrupt Companion warm KV. |
| Runtime | Engine selector | Wired | Switches llama.cpp / vLLM capability profiles. | Read a live adapter probe. | Selection does not connect or launch. |
| Model | GGUF model + mmproj scan | Wired | A restricted local, header-only GGUF scan validates a selected file and reports context, architecture, tensor parameter count, MoE facts, and projector metadata where available. | Add a native picker and engine-level compatibility validation. | A scan cannot prove model/projector compatibility or live placement. |
| Continuity | Warm KV / rollover policy | Prototype | Lifecycle is described in UI. | Adapter session state and checkpoint evidence. | KV cannot remain warm through every restart, setting change, or capacity rollover. |
| Allocation | Local device map | Wired | Read-only Windows/NVIDIA probe supplies device names, CPU threads, RAM, VRAM and GPU utilization. | Broker-owned measured snapshot and per-process telemetry. | Hardware data does not create or manage leases. |
| Allocation | Planned companion reservations | Wired | Saved, scanned profiles expose editable context, vision, KV, placement, CPU/GPU share, eviction, and MoE policy; visuals are labelled planned. | Broker lease admission and atomic snapshot writer. | Companion apps must remain read-only consumers; profile plans are not live leases. |
| Allocation | Per-process VRAM, RAM, queue, KV and device telemetry | Blocked | The local probe only reports machine-wide facts. | Runtime telemetry contract + engine/broker process probes. | vLLM and llama.cpp do not expose identical data/control surfaces. |
| Runtime | llama.cpp endpoint probe | Wired | Read-only loopback probe calls `/health`, `/props`, `/slots`, and `/v1/models`. | Normalize endpoint facts into the adapter capability report. | Reachability does not establish a safe model/session/allocation configuration. |
| Test lab | Managed llama.cpp raw stream + benchmark ledger | Wired | Saved profiles can start registered loopback runtimes; Test Lab records outbound messages, raw SSE, session reuse attempts, timings, hardware baselines, and local comparison runs. | Run a selected real GGUF through cold/warm/mismatch probes and add engine-confirmed per-process telemetry. | Machine-wide VRAM/RAM is not per-companion telemetry; raw projections never control stream completion. |
| Parser UI | Thought/reply/tool projections | Planned | No live parser has been added. | Native family marker profiles downstream of raw ledger. | UI must not define inference completion. |
| Companion executable | Named tray/window/process | Planned | Setup profile concept only. | Build after reliable session/recovery tests. | Profiles must be shared-kernel launchers, not source forks. |

## UI implementation map

| Screen | Connected now | Intentional non-connection |
|---|---|---|
| Setup | Browser-local draft save/load; local GGUF/mmproj scan; scan-gated profile commit. | No native file picker, engine launch, or settings service. |
| Allocation | Refreshable local hardware facts; saved profiles render as planned reservations. | No allocation admission, process, queue, eviction enforcement, or per-process resource control is connected. |
| Test lab | Managed raw SSE test runs, persisted test transcript/ledgers, metrics, and comparison selection. | No attachment upload, Day 0 tool host, or verified per-process KV/VRAM telemetry. |
| Implementation status | Static checklist sourced from `src/lib/setup/implementation-status.ts`. | It is not yet generated from CI/probe results. |
| Profiles | Local stable ID registry with scanned model fingerprint and planned allocation policy. | No companion executable or launcher. |

The managed runtime now provisions the home-only Day 0 tree, append-only
access ledger, daily raw transcript ledger, tool permission file, and audit.
It can save text-only llama.cpp slot snapshots when the server supports
`--slot-save-path`; mmproj/multimodal companions use durable recovery instead.
Source document registration (reference/copy/move with SHA-256 provenance in SQLite vault),
on-demand tool inventory discovery, scoped grep pattern search, and Project Keeper
transcript catch-up are fully wired and functional.

Update this file and `src/lib/setup/implementation-status.ts` together whenever a UI item changes state.
