# Project Keeper Idea Audit

This records ideas carried into Evolution without importing Keeper's old
implementation.

## Adopt

- Append-only vault and global audit ledger.
- Room-scoped IDE transcript import with source/hash matching and resumable
  cursors.
- FTS-first index and citations linking summaries to pair/event/source IDs.
- Checkpoint-and-continue recovery with honest KV compatibility reporting.
- Tiered consent and worker/advisor tool separation.
- Source-root confirmation, staging-only code/tool changes, and explicit reset.

## Defer

- Embedding/vector index and knowledge-library ranking.
- Distributed authoritative home synchronization.
- Resource-broker admission and multi-node execution.
- Fast/deep model split, model training from knowledge, and autonomous tool
  promotion.
- Bulk transcript backfill and second-companion import UI.

## Reject

- Overwriting raw transcript or source bytes.
- Silent project/source-root creation and cross-companion writes.
- Persona re-injection on rollover.
- Shared inference context/KV across companions.
- Worker-side unrestricted shell, network, GPU, or repository writes.
- Treating classifier signals or summaries as authoritative personal facts.
