# CPU and memory observations

The probe now reports machine-wide physical-core count, logical processors,
CPU utilization, and RAM used/free alongside NVIDIA VRAM/utilization. These
are host observations, not per-companion attribution. P/E core topology is
currently reported unavailable: it requires a dedicated Windows
`GetLogicalProcessorInformationEx` implementation rather than inference from
a CPU model name.
# Local Probe Service

## Purpose

`scripts/local-probe-server.mjs` is a development-time, loopback-only service that lets the Setup UI read real local hardware facts and inspect an already-running local llama.cpp server.

It is not the future resource broker. It never allocates resources, launches engines, edits server settings, saves a profile, or executes user-provided shell commands.

It also does **not** own chat APIs, Jinja templates, or MCP — only read-only host/engine **observations** for Setup/Test Lab.

## Run

Start the probe service in one terminal:

```powershell
npm run probe-server
```

Start the Setup UI in another:

```powershell
npm run dev
```

The Vite development server proxies `/api/*` to `127.0.0.1:4318`.

## Fixed endpoints

| Endpoint | Read-only behavior |
|---|---|
| `GET /api/hardware` | Reads fixed Windows CIM facts and `nvidia-smi` telemetry. |
| `GET /api/llama-cpp?baseUrl=…` | Reads `/health`, `/props`, `/slots`, and `/v1/models` from a loopback-only HTTP llama.cpp endpoint. |
| `GET /api/gguf/scan?path=…` | Reads a canonical local `.gguf` header only; returns model/context/MoE/projector metadata without loading weights. |

The service rejects non-GET requests. It has no endpoint that accepts arbitrary commands, engine arguments, or allocation changes. The scan endpoint is the sole file-path exception: it resolves the selected path, requires a regular `.gguf` file, and reads no more than 48 MiB of header metadata.

## Managed runtime

`npm run dev-runtime` starts a separate development-only loopback service on
port `4319`. It is the only Evolution component that can launch a registered
llama.cpp child. Configure its executable with:

```powershell
$env:ANIKAI_LLAMA_SERVER_EXE = 'D:\path\to\llama-server.exe'
npm run dev-runtime
```

The runtime does not adopt, stop, or reconfigure external servers. The
read-only probe remains the correct tool for those endpoints.

## Hardware evidence

Windows CIM provides CPU identity/core counts, installed physical RAM, and display adapter facts. `nvidia-smi`, when present and functioning, provides NVIDIA GPU name, driver version, VRAM total/used, and current GPU utilization.

The UI labels this **Measured hardware** only when the probe successfully returns data. It reports CUDA as **ready**, not adapter-verified active: a successful NVIDIA driver probe does not prove that a selected llama.cpp/vLLM engine was launched with CUDA.

## llama.cpp endpoint scope

Only these local addresses are permitted:

- `http://127.0.0.1:<port>`
- `http://localhost:<port>`
- `http://[::1]:<port>`

An unreachable local URL returns a normal “no compatible endpoint responded” result with the individual endpoint facts. It is not treated as a malformed request.

## Known limits

- GGUF header evidence can report file size, architecture, context maximum, tensor-derived parameter total, and MoE count/default. It cannot establish live VRAM, KV, actual device placement, or a compatible chat-model/mmproj pair.
- CPU/RAM use by a companion process is not yet measured.
- GPU telemetry is machine-wide, not per-lease.
- No live KV/context/slot allocation is claimed.
- `/slots` and `/props` vary across llama.cpp versions; the future adapter must normalize them before enabling settings.
- The current service is for local Windows development. A Tauri-side implementation will replace it for packaging.
