# Managed llama.cpp Development Runtime

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Wired (Dev) | **Last Updated:** 2026-07-30  
> **Related Specs:** [`COMPANION-KNOWLEDGE-HOME-SPEC.md`](COMPANION-KNOWLEDGE-HOME-SPEC.md), [`ENGINE-CAPABILITY-CONTRACT.md`](ENGINE-CAPABILITY-CONTRACT.md)

## Launch-policy evidence

Per-profile runtime policy includes K/V cache types, Flash Attention, KV
offload, host cache RAM cap, idle slots, batch sizes, checkpoints, and CPU-MoE
policy. The runtime probes the bundled executable's help/version before adding
an optional argument. Every launch-affecting choice is part of the snapshot
fingerprint; a changed fingerprint is not warm-KV compatible.

TurboQuant cache types are experimental compression profiles, never labelled
lossless. The run ledger retains the chosen policy and effective launch
arguments so quality, memory, and speed can be compared together.

## Idle release

Profiles can request that the managed server stop after an idle timeout. This
releases loaded model memory and invalidates warm KV. It is intentionally not
described as throttling an idle resident model: a loaded model still owns its
weights and cache until the server exits.

## CPU and mapping controls

The managed runtime probes `--poll`, `--threads-batch`, `--prio`,
`--cpu-range`, `--mmap`, and `--mlock` before including their profile values.
The recommended idle baseline is poll `0`; mmap remains enabled by default.
Mlock is opt-in because it intentionally reduces available system RAM. The
current bundled binary does not advertise `GGML_SCHED_YIELD`, so Evolution
does not set that environment variable.
# Managed llama.cpp Development Runtime

`npm run dev-runtime` starts a development-only control plane on
`127.0.0.1:4319`. It is separate from the GET-only local probe service.

Set the executable before starting:

```powershell
$env:ANIKAI_LLAMA_SERVER_EXE = 'D:\llama\llama-server.exe'
npm run probe-server
npm run dev-runtime
npm run dev
```

The runtime starts one loopback `llama-server` per saved llama.cpp companion.
It assigns a private port, uses one parallel slot, and never adopts or changes
an externally started server.

## Warm-session rule

The launch fingerprint includes scanned model/projector identity, context,
device target, CPU thread policy, KV policy, and active MoE policy. Any change
restarts that companion server and marks the next request cold. Test Lab records
whether a warm cache attempt occurred; it does not claim warm KV without engine
timing/cache evidence.

For text-only servers the runtime creates `runtime/kv/` in the companion home,
launches with `--slot-save-path`, and saves/restores slot 0 as
`slot-0.bin`. Its manifest binds the file to the full Evolution launch
fingerprint and scanned GGUF fingerprint. llama.cpp save files do not fully
identify the model/configuration by themselves, so a matching architecture is
not enough to restore. mmproj/multimodal servers do not support the slot
save/restore path and are reported as durable-recovery only.

## Limits

- GPU percentage is an allocation intent, not a llama.cpp throttle flag.
- Machine-wide NVIDIA/RAM samples are not per-process telemetry.
- The runtime has no broker admission, session-file export, attachment host, or
  filesystem tool execution.
- Native GGUF selection is a user-invoked Windows dialog through the runtime;
  the selected path is scanned before it can be saved.

## Wire & template (local default)

- Prefer **OpenAI-compatible** streaming chat to the managed `llama-server` (Test Lab / companion surfaces).
- Launch with **`--jinja`** so the **GGUF-embedded** (or explicit override) chat template shapes prefill — thinking channels when the family supports them. See idea bible §5.3a.
- This runtime is the **home-native** engine adapter path, not a Claude/Anthropic client. Vendor-shaped APIs belong in other adapters under [`ENGINE-CAPABILITY-CONTRACT.md`](ENGINE-CAPABILITY-CONTRACT.md).
- Chat-template / tokenizer changes are **Hard** for warm KV (fingerprint), same as model path.
