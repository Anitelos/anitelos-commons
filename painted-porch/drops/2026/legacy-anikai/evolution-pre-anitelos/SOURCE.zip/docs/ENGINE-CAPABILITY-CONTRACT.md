# Capability experiment matrix

The Setup and Test Lab catalogue distinguishes `wired`, `available-after-probe`,
`experimental`, and `not-bundled`. A visible control is not an assertion that
the selected runtime implements it. The managed llama.cpp runtime records
`--help`, version, `/props`, slot facts, and effective arguments before it
enables optional cache, batching, Flash Attention, or CPU-MoE flags.

vLLM and SGLang remain disabled planned adapters until they produce equivalent
local evidence. PagedAttention, Radix/prefix caching, tensor parallelism, and
continuous batching are catalogue entries, not current llama.cpp toggles.
# Engine Capability Contract

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Active Contract | **Last Updated:** 2026-07-30  
> **Related Specs:** [`RESOURCE-BROKER-CONTRACT.md`](RESOURCE-BROKER-CONTRACT.md), [`LLAMA-DEV-RUNTIME.md`](LLAMA-DEV-RUNTIME.md)

## Purpose

Anikai Evolution presents settings only when the selected adapter reports that they are supported. The UI must not copy a setting from one engine to another by name or analogy.

The first real adapter is llama.cpp. vLLM is a planned adapter profile, not an assumed feature set.

## Control Vectors & Trait Dials (Plainspeak Dial)

Anikai Evolution natively supports **GGUF Control Vectors** (`--control-vector` and `--control-vector-scaled`) in `llama-server`. Control vectors allow shifting activation directions (such as prose register, tone, verbosity, or persona traits) at runtime:

- **Plainspeak Dial Example (`plainspeak-v2.gguf`):** Shifts Gemma 4 / Llama prose from ornate/purple register toward human-like plain style.
- **VRAM / Speed Impact:** Zero VRAM overhead and zero generation slowdown (unlike LoRA adapters or system prompt bloat).
- **Scale Range:** Scale dial from `-2.0` (opposite trait/purple) to `+1.0` (default plain/recommended) to `+2.0` (extreme).
- **Setup UI Integration:** Primary model `.gguf` and custom control vector `.gguf` paths are accessible directly on **Subtab 01 (Persona & Identity)** for both Companions and Familiars.

### Cross-Engine Vector & Trait Transferability
1. **File-Level GGUF Vectors (Model-Specific):** A specific `.gguf` control vector file contains directional tensors matching the exact hidden layer dimension $d_{\text{model}}$ of a model family (e.g. 8192-dim for Gemma 26B). Loading a 26B vector directly into an 8B model causes a tensor dimension mismatch error.
2. **Trait Sliders & Persona Role Packs (100% Transferable):** The high-level **Trait Sliders** (`Humanness`, `Formality`, `Sensuality`, `RP ↔ Romance Mode`) and **Persona Role Packs** (Demon / Demoness, Netrunner, Scholar, Android, Gothic, Cottagecore) are **100% engine-agnostic and model-agnostic**. They map to whatever steering mechanism the selected engine supports (`llama.cpp` CLI flags, `vLLM` PyTorch activation hooks, or system prompt/control vector overlays).

Before Setup enables a runtime feature, an adapter must return a versioned capability response:

```ts
type EngineCapabilityReport = {
  contractVersion: 1;
  engine: 'llama-cpp' | 'vllm' | string;
  adapterVersion: string;
  engineVersion: string | null;
  observedAt: string;
  connection: 'offline' | 'healthy' | 'incompatible';
  modelFormats: string[];
  supports: {
    openAiChat: boolean;
    streamingSse: boolean;
    modelScan: boolean;
    visionProjector: boolean;
    sessionState: boolean;
    sessionSnapshot: boolean;
    gpuPlacement: boolean;
    kvTelemetry: boolean;
    prefixCacheTelemetry: boolean;
    pagedAttentionTelemetry: boolean;
    tensorParallel: boolean;
  };
  telemetry: {
    vramBytes: 'measured' | 'unavailable';
    ramBytes: 'measured' | 'unavailable';
    kvBytes: 'measured' | 'unavailable';
    contextTokens: 'measured' | 'unavailable';
  };
  limits: Record<string, number | string | boolean | null>;
};
```

`healthy` only means the adapter can communicate with the engine. It does not mean a model, KV snapshot, media path, or allocation policy is validated.

## UI gating rules

| Setup control | Required evidence |
|---|---|
| Model picker | `modelScan` plus a successful scan result. |
| mmproj / encoder picker | `visionProjector` plus model compatibility evidence. |
| GPU layer / placement controls | `gpuPlacement`, with the adapter naming the exact available controls. |
| KV usage ring | `kvTelemetry` with measured context and KV values. |
| Session restore | `sessionState`; snapshot restore additionally requires `sessionSnapshot`. |
| PagedAttention display | `pagedAttentionTelemetry`; never inferred from engine name. |
| Tensor-parallel controls | `tensorParallel` and a probe that lists usable devices. |

## Current read-only llama.cpp probe

Setup can now inspect a user-supplied loopback HTTP endpoint without changing it. The development probe reads `/health`, `/props`, `/slots`, and `/v1/models`; endpoint responses are shown individually in Test Lab.

This is discovery evidence only. A successful endpoint probe must not enable session restore, allocation, model launch, or KV claims until the adapter converts the responses into a versioned `EngineCapabilityReport`.

## Local GGUF scan evidence

The development llama.cpp adapter now converts a successful header-only GGUF scan into `GgufScanResult` and a capability report. It can measure the file fingerprint, architecture, declared context maximum, tensor-derived total parameter count, and MoE expert/default-active count where those keys exist.

An optional mmproj scan can report `clip.vision.*` metadata. It grants a **vision metadata** capability only; it does not prove a projector is compatible with the selected chat model.

The scanner never reports live VRAM, KV bytes, GPU-layer placement, actual active experts, or a running context. Those remain unavailable until the launched engine reports them.

## Managed development runtime

The development runtime is a separate loopback service from the read-only probe.
It launches only registered companion profiles and owns one `llama-server` per
companion. It records a launch fingerprint covering model, projector, context,
device policy, KV policy, and MoE settings. A fingerprint mismatch restarts the
server and invalidates its warm-session claim.

Test Lab sends OpenAI-compatible streaming requests with a single managed slot.
Raw SSE lines and the outbound message body are retained as evidence. A server
timing field is engine evidence; wall-clock TTFT is client-clock evidence; GPU
and RAM samples from the hardware probe are machine-wide, never per-companion.

## Non-negotiable stream rule

Engine adapters emit append-only decoded stream events. A future parser may create `thinking`, `reply`, `tool`, or `media` projections, but cannot:

- call cancellation because a marker looks unexpected;
- hide or rewrite raw data;
- declare a server completion based only on a tag;
- claim tool execution when the tool host has not returned a verified result.

Server EOS, transport failure, or explicit user stop are the event sources that end a generation.

## Current known differences

- **llama.cpp:** first adapter target; GGUF, optional mmproj, GPU placement and any session/slot capability must be probed against the installed binary.
- **vLLM:** planned adapter target; PagedAttention, prefix caching, tensor parallelism, and cache telemetry must be discovered from the installed runtime and version.
- **Both:** OpenAI-compatible request shapes improve client interoperability but do not make KV, snapshots, memory allocation, tool loops, or metrics interchangeable.

## Home-native completion vs vendor wires (idea → contract)

**Continuity rule:** the companion’s *thinking shape* stays **home-native** — GGUF chat template / Jinja on the local engine, one Soft completion contract (raw stream truth; optional thought/reply/tool projections). Do **not** retrain the ego to “speak Claude” or “speak LM Studio v0” as its inner format.

**Adapters** (this doc’s job, per engine): map home turns ↔ vendor envelopes (OpenAI-compatible local, future cloud OpenAI / Anthropic / LM Studio v1, …). Surfaces and IDEs talk to **Evolution home**; home talks to adapters.

**MCP (later, not required for Day-0):** a host-facing tool bridge so other apps can call **familiars / home scripts** as named tools (e.g. friendly “ask companion / ask wiki familiar”). MCP does not replace the chat template or the resource broker. Idea bible: `ANIKAI-IDEA-COMPILATION.md` §5.3 / §5.3a.

**Not this contract:** GPU/VRAM leases → [`RESOURCE-BROKER-CONTRACT.md`](RESOURCE-BROKER-CONTRACT.md). Hardware SMI facts → [`LOCAL-PROBE-SERVICE.md`](LOCAL-PROBE-SERVICE.md). Launch fingerprint / `--jinja` / slot KV → [`LLAMA-DEV-RUNTIME.md`](LLAMA-DEV-RUNTIME.md).
