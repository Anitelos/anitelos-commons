# Pending vision origin

Before Day 0, a vision-capable profile may retain a selected local source image
in its saved setup record for synchronized Setup/Test Lab preview. Beginning
Day 0 copies that source into `identity/origin/` and writes provenance. After
Day 0, replacing the origin requires an explicit fresh-life reset so the
original evidence remains intact.
# Companion Knowledge Home and Day 0

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Wired (Dev) | **Last Updated:** 2026-07-30  
> **Related Specs:** [`EVOLUTION-VAULT-CONTRACT.md`](EVOLUTION-VAULT-CONTRACT.md), [`LLAMA-DEV-RUNTIME.md`](LLAMA-DEV-RUNTIME.md)

## Purpose

A companion home is a local, markdown-first life and knowledge workspace. It is
not a replacement for the append-only runtime transcript or a requirement for
vector search. It gives the companion a durable place to keep a first-person
diary, goals, passions, notes, raw captures, an organized wiki, and useful
outputs.

The model is the librarian, not an assistant acting out a library. It may make
connections and propose organization, but every filesystem action must be
performed by a verified tool and recorded in the access ledger.

## Storage boundaries

- `home/` contains editable life, knowledge, and companion-authored documents.
- `continuity/` contains runtime-owned life events, transcript records, and
  recovery checkpoints. Home edits emit a corresponding continuity event; they
  do not replace it.
- `runtime/kv/` is reserved for engine-supported KV/session artifacts. A file
  is never presented as a valid snapshot until the engine confirms it loaded.

## Home layout

```text
home/
  HOME.md
  README.md
  config/
    scopes.json
    permissions.json
    processing-state.json
  ledger/
    access.jsonl
    mutations.jsonl
    day-0-audit.md
    changelog.md
  transcripts/
    YYYY-MM-DD.jsonl
  diary/
    day-0.md
    YYYY-MM-DD.md
  goals/
    index.md
    active/
    archive/
  passions/
    index.md
    topics/
  notes/
    inbox/
    topics/
  knowledge/
    raw/
      ingest-registry.jsonl
    wiki/
      index.md
      topics/
    outputs/
  identity/
    persona.md
    origin/
    orientation.md
    revisions/
  projects/
  tools/
    inventory.json
    manifests/
  schedules/
    README.md
```

`HOME.md` is the companion's librarian contract. It states the read order,
source/provenance rules, write conventions, health-check cadence, and how the
wiki relates to raw capture. `knowledge/raw/` accepts messy capture.
`knowledge/wiki/` is the companion-maintained organized view. Answers,
briefings, and health reports go to `knowledge/outputs/` so useful work can
compound rather than disappear into chat.

Users may edit identity, notes, or raw capture directly. The companion records
wiki merges in `ledger/changelog.md` instead of silently overwriting a human
document.

## Day 0: home-only bootstrap

Day 0 is a deliberate initialization job, not an improvised opening prompt.
Before the companion greets the user, the tool host must:

1. create the home tree and an empty append-only ledger;
2. write `config/scopes.json` with `mode: "home_only"` and the canonical home
   path as its only root;
3. create `HOME.md`, `README.md`, `identity/orientation.md`, empty indexes,
   `tools/inventory.json`, and `schedules/README.md`;
4. let the companion author its first-person `diary/day-0.md`, goals/passions
   indexes, and Day 0 audit using home-scoped tools;
5. verify every expected file and ledger entry; and
6. record the verification in `ledger/day-0-audit.md`, then permit its
   introduction message.

The Day 0 audit names every created path, ledger event ID, scope status, any
initial sources, and failed or deferred actions. A model statement that a file
exists is never proof of a write.

For a scanned vision-capable companion, the operator may choose one origin
image before the Day 0 introduction. The runtime copies it into
`identity/origin/` with source/hash metadata, reserves vision tokens inside the
normal context window, and sends it with that Day 0 request. The companion then
writes a durable origin/visual-grounding note. The image embedding and hidden
reasoning are not restart-safe memory.

## Knowledge loop

1. Capture files, user notes, tool results, and source references in `raw/`.
2. Record source hash, origin, ingest time, and processing status in
   `raw/ingest-registry.jsonl`.
3. Build or update `wiki/index.md` and topic pages with links to source
   material.
4. Write responses and reports to `outputs/`.
5. Record each processing pass in `processing-state.json` and `changelog.md`.
6. Periodically run a health check that flags contradictions, orphaned pages,
   stale entries, unprocessed raw material, missing provenance, and useful new
   topic candidates.

The running model receives only the relevant orientation, diary/index, and
explicitly selected knowledge excerpts. It does not receive the entire home or
wiki on every turn.

## Access and mutation audit

Every list, read, write, rename, delete, denied action, scope grant, schedule
execution, and tool invocation appends an entry to `ledger/access.jsonl`.
Writes and destructive mutations also append before/after hashes to
`ledger/mutations.jsonl`.

```json
{
  "ts": "2026-07-28T12:00:00.000Z",
  "eventId": "uuid",
  "actor": "companion",
  "tool": "write_home_file",
  "op": "write",
  "path": "diary/day-0.md",
  "scopeGrantId": "home-only",
  "sha256": "optional-after-hash",
  "ok": true
}
```

A denied request is also recorded with `ok: false` and a reason such as
`scope_home_only`. Logs are evidence, not prompt text; they can be summarized
for the companion only when relevant.

## Daily raw transcript ledger

The runtime appends outbound request records, complete raw API SSE payloads,
KV/lifecycle state, and tool/lifecycle events to
`transcripts/YYYY-MM-DD.jsonl`. This is immutable evidence. Diary prose and
summaries are separate companion-authored artifacts and never replace it.

## Tools and future grants

Tools are listed by kind: `mcp`, `cli`, or `custom-script`. Each manifest
declares inputs, allowed operations, required scope, output paths, destructive
behavior, and whether an action needs confirmation.

Day 0 permits only `list_home_dir`, `read_home_file`, `write_home_file`, and
`ask_user`. It cannot run arbitrary shell commands or access a path outside the
home.

Later, the operator may grant any selected local root through a visible scope
record. There is no standing machine-wide write grant. Reads, lists, and writes
are still logged. Writes outside home, deletes, moves, executable/script
creation, and schedule changes require confirmation at the point of action.

`tools/inventory.json` begins empty. `schedules/` begins disabled. A later
autonomy policy may enable timers or health checks only after an operator
enables the schedule and its tools have valid scoped manifests. Every firing
creates a ledger and continuity event.

## Fresh life reset

The operator may explicitly clear a companion's life state by typing the
profile-specific confirmation shown in Test Lab. The runtime stops only its
registered server, requests slot erase when available, and removes the
companion home, KV snapshots, transcripts, tool grants, and browser-local test
records. The saved profile, scanned model/projector configuration, allocation
policy, and setup identity notes remain. The next run is `day0_pending`.

## Recovery

If warm KV is compatible, the runtime can continue its session. On restart it
first attempts a fingerprint-bound engine slot restore and only labels KV
restored after the engine confirms it. On rollover or a changed launch
fingerprint, recovery starts from durable facts: identity orientation, the
latest diary entry, goal index, knowledge wiki index, and any explicit task
handoff. The optional recovery hint is an explicit outbound event; ordinary
steady turns receive no system prompt. It must not claim a warm KV or
filesystem state without engine/tool evidence.

## Verification

- A Day 0 run fails if it writes outside the home root.
- Every successful file write has an access event and mutation hash.
- Every denied external access has a ledger event.
- Day 0 audit lists all required artifacts before the introduction is sent.
- A later tool/schedule is unavailable without a manifest, scope grant, and
  recorded operator approval.
