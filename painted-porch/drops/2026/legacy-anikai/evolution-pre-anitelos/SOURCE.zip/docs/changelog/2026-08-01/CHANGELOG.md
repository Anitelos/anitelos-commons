# Anikai Evolution - Change Log

**Date:** 2026-08-01  
**Timestamp:** 21:30 UTC  
**Session Goal:** Writing Style & Persona State Trait Sliders, Roleplay ↔ Romance Dynamic Trait, Day 0 Origin Image Drop Zone, Input Clear Buttons, Auto-Slug Home Vault Pathing, Auto-Shape Persona, Saved Profile Vault Cards Management, and Global Allocation UI Cleanup.

---

## 1. Architectural & UI Updates Summary

1. **Persona & Writing Style Trait Sliders (20 Sliders):**
   - Added Writing Style Sliders (`Human-ness`, `Formality`, `Playfulness`, `Narrative Intensity`, `Sensuality`, `Assertiveness`, `Spontaneity`, `Emotional Expressiveness`, `Roleplay ↔ Romance / Casual`, `Darkness / Edginess`, `Chaos / Order`, `Warmth`, `Vulnerability`) and Persona State Sliders (`Fiery ↔ Calm`, `Guarded ↔ Open`, `Dominant ↔ Submissive`, `Detached ↔ Attached`, `Stoic ↔ Dramatic`, `Logical ↔ Emotional`, `Mischievous ↔ Sincere`).
   - Placed the Trait Sliders Panel right above Continuity on Subtab 01 (`Persona & Identity Setup`).
   - Saved `traits: TraitSliders` into `SetupDraft` and `CompanionProfile` in `src/lib/setup/profile.ts` and `src/lib/setup/companion-registry.ts`.

2. **Roleplay ↔ Romance / Casual Dynamic Slider:**
   - Implemented a dynamic slider replacing static RP toggles, allowing companions to naturally evolve from scripted roleplay to casual intimacy and romantic devotion as interaction history progresses.

3. **Auto-Shape Persona & Traits:**
   - Added `✨ Auto-Shape Persona & Traits` buttons (`✨ Expressive & Intimate`, `✨ Analytical & Focused`, `✨ Roleplay & Romance`) that automatically configure all 20 trait sliders and persona notes based on the chosen disposition.

4. **Input Field Clear Buttons ("Tiny ✕"):**
   - Added a clear button (`✕`) for all input and textarea fields (`companionName`, `companionHome`, `identityNotes`, `initialInstruction`, `modelPath`, `mmprojPath`, `controlVectorPath`).

5. **Auto-Slugified Home Vault Pathing:**
   - Companion name changes automatically slugify and update the home vault path (e.g. `Elise` -> `D:\Anikai\Companions\elise`), unless the user has manually customized the home path.

6. **Day 0 Origin Image Drop Zone & Preview:**
   - Made the Day 0 Origin Image Drop Zone & Preview card always accessible on Subtab 01 (`Persona & Identity Setup`). Supports file browser button, drag-and-drop, image preview, and image removal.

7. **Saved Companion & Familiar Vault Cards Management:**
   - Rendered a grid of all saved companion and familiar profiles at the bottom of Subtab 01.
   - Provided action buttons for each profile card:
     - `⚙️ Edit Profile`: Loads profile into draft for editing and selects it.
     - `🔄 Reset Day 0`: Erases Day 0 life state and pre-Day-0 warm KV.
     - `📁 Clear Home`: Clears companion home vault directory contents.
     - `🗑️ Delete`: Deletes profile from local registry and SQLite vault.

8. **Cleaned Up Global Allocation UI:**
   - Removed the duplicate individual companion allocation policy editor from the bottom of `Global Allocation`.
   - Added an `⚙️ Edit in Model Setup` button on each lane card in Multi-Lane Global Reservation, jumping directly to `Model & Engine Setup` with that companion selected.

9. **GoEmotions Classifier Capability Gating & Install Staging:**
   - Added capability gating when the GoEmotions Classifier (`Gemma-2B-e2b` / `gemma-2b-e2b-goemotions.onnx`) is not installed:
     - Prominently displays `⚠️ Not Installed (Static Baseline Mode)`.
     - Gates real-time 27-emotion scoring and auto control-vector scaling (`evolveDynamicSteering`).
     - Preserves manual persona trait sliders for static baseline definition without pretending dynamic steering is active.
   - Added `⚡ Install & Stage Emotion Classifier` button that stages the small `Gemma-2B-e2b` / ONNX classifier into `D:\Anikai\models\goemotions\`, updating `emotionAgentStatus = 'staged'` and unlocking dynamic control vector steering.
   - Added a `Models Storage Directory` picker (`D:\Anikai\models`) for central staging of GGUF weights, ONNX classifiers, and mmproj projectors.
   - Documented architectural distinction between **Familiars** (unbiased sub-agent task runners) and **Companion Capabilities** (modular cognitive plugins like Emotion Classifier, Vision, TTS).

10. **Persona Archetypes & Role Packs Dropdown Selector (Anikai Desktop 23-Role Sync):**
    - Synced all 23 exact persona role packs from Anikai Desktop (`persona-defaults/roles`): `advocate`, `angel`, `anikai-base`, `archivist`, `broker`, `craftsman`, `curator`, `default`, `demon` (Demoness), `fixer`, `guide`, `iatros`, `mononofu`, `netrunner`, `onmitsu`, `operator`, `scholar`, `sentinel`, `spark-muse`, `steady-guardian`, `steward`, `strategist`, `western`.
    - Reframed initial instructions and identity notes into model-facing 1st-person / 2nd-person persona framing ("You are a...") rather than user-facing descriptions.
    - Updated GoEmotions staging to default to Google's `gemma-4-E2B-it-Q4_K_M.gguf` (~1.1 GB). Documented that legacy RotorQuant (`llama-cpp-turboquant`) fails on `gemma4`, whereas mainline `llama.cpp` (`-ctk q8_0 -ctv q8_0`) and `SGLang` (RadixCache sub-100ms prefix reuse) run Gemma 4 E2B natively at top speeds.
    - Documented cross-engine vector transferability in `docs/ENGINE-CAPABILITY-CONTRACT.md`: GGUF vector files require matching layer dimensions ($d_{\text{model}}$), but high-level Trait Sliders and Persona Role Packs are 100% engine-agnostic and transferable across `llama.cpp`, `vLLM`, `SGLang`, and `PyTorch` (`python-native`).

11. **IDE Agent Chat Transcript Discovery & Project Keeper Ingest:**
    - `catchupProjectKeeper()` now automatically discovers Cursor & IDE Agent Chat Transcripts (`.cursor/projects/*/agent-transcripts/*.jsonl`).
    - Test Lab UI displays discovered chats with turn counts, file sizes, and prompt titles.
    - One-click `+ Register Chat` button ingests transcripts into companion `knowledge/raw/` with SHA-256 provenance and records them in SQLite `source_catalogue`.

12. **Day 0 Scratchpad & Context Rollover Todos:**
    - Companion tool host (`exploreScopedPath`) enables writing and updating active scratchpad/todos in `notes/inbox/scratchpad.md` and `goals/active/todos.md`.
    - Preserves Day 0, Project Keeper, and raw document goals across context limit rollovers.

13. **Subject-Based LTM Passion Ranking & Fading Engine (`companion_subject_interest`):**
    - Added `companion_subject_interest` table and `/vault/subject-interests` / `/vault/log-subject-hit` endpoints in `vault-service.mjs`.
    - Evaluates passions, interests, goals, and bond growth by semantic subject.
    - Repeated subject hits increase rank score ($+1.5$), lifting top passions to the head of the companion's core memory.
    - Inactive subjects decay exponentially ($0.92\times$) and prune below $0.25$, naturally fading inactive interests.

14. **Gemma 4 E2B Abliterated & Disinhibited + MMProj Capability Staging with Download Telemetry:**
    - Updated staged classifier & audio target to `gemma4-E2B-it-Abliterated-AND-Disinhibited-USE-THIS.Q4_K_M.gguf` (~3.42 GB) and `gemma4-E2B-it-mmproj-f16.gguf` (~250 MB).
    - Added `/runtime/stage-emotion-model`, `/runtime/emotion-download-progress`, and `/runtime/uninstall-emotion-model` endpoints in `llama-dev-runtime.mjs`.
    - Added live download telemetry in `App.svelte` showing progress bar (`%`), current/total GB, speed (`MB/s`), and ETA (`s`).
    - Provided separate **Disable** (toggles off dynamic steering without deleting files) and **Uninstall** (removes staged files from disk) controls.

15. **3-Step Multimodal Audio & Steady Turn Ingestion Pipeline:**
    - Step 1: E2B sub-agent evaluates emotion intensity & dynamically scales control vectors (`--control-vector-scaled`) / trait dials.
    - Step 2: E2B processes attached audio clips via `mmproj` and generates a 1st-person acoustic perception review (`<internal_audio_perception>`).
    - Step 3: Primary Companion prefills the user's text message AND injects the E2B audio perception review directly inside its opening `<thought>` block at prefill stage before streaming verbal & Higgs voice responses.

16. **Multilingual GoEmotions V1.2 Safetensors Integration & Python Environment Setup:**
    - Included `AnasAlokla/multilingual_go_emotions_V1.2` (Safetensors multi-lingual BERT 27-emotion classifier, ~700 MB) in the unified emotion feature package (~4.37 GB total).
    - Created `scripts/goemotions_classifier.py` Python bridge for 27-label emotion classification with error handling for missing dependencies.
    - Added `/runtime/check-python-deps`, `/runtime/install-python-deps`, and `/runtime/classify-emotions` endpoints in `llama-dev-runtime.mjs`.
    - Added **`🔍 Check Python Env`** and **`📦 Install PyTorch & Transformers (pip)`** one-click setup controls in Subtab 01 (Persona Setup).

17. **Multi-File Staging Telemetry Status Line:**
    - Updated `stagedDownloadState` in `llama-dev-runtime.mjs` and `StagedDownloadProgress` type to report `currentFile`, `currentFileIndex`, `totalFiles`, `elapsedSeconds`, `etaSeconds`, `speedBytesPerSec`, and `percent`.
    - Updated download panel in `App.svelte` to display active file telemetry: `Downloading File [1/3]: gemma4-E2B-it-Abliterated-AND-Disinhibited-USE-THIS.Q4_K_M.gguf`, progress bar (`%`), current/total GB (`1.85 / 4.37 GB`), speed (`MB/s`), elapsed time (`Elapsed: 12s`), and remaining ETA (`ETA: 24s`).

18. **Multi-Turn Test Lab Messaging & Runtime Controls Fix:**
    - Updated `buildTestMessages` to preserve and send the full conversation history (`testHistory`) prior to the new user prompt, enabling continuous multi-turn messaging in Test Lab.
    - Clears `testPrompt = ''` when streaming finishes so the prompt box is ready for the next message.
    - Unlocked "Stop runtime" button (removed `disabled={runtimeStatus?.state !== 'running'}`) and updated `stopSelectedRuntime()` and `refreshRuntimeStatus()` to properly terminate processes and refresh runtime/hardware state.

19. **Visual Origin Image Anchor in Test Messages:**
    - Automatically injects a system visual origin anchor message whenever a vision origin image is present (`profile.draft.visionOriginPath` / `visionPreviewUrl`), enabling the companion to look up and reference its image anchor during test turns even before Day 0.

20. **Update Profile vs. Save New Companion & Duplicate Validation:**
    - Added `editingProfileId` state tracking. Editing an existing profile switches the button from "Save profile" to "Update profile", updating the existing profile ID instead of creating a duplicate.
    - Added `duplicateNameProfile` and `duplicateVaultProfile` validation. Shows warning notices under the inputs and disables saving if a duplicate name or vault path is entered.
    - Added `+ New Companion` button to clear editing state and start a clean draft.

21. **3-Column Studio Grid Layout (Tab 1 Persona & Identity):**
    - Reorganized Tab 1 into a 3-column responsive grid (`studio-3col-grid`):
      - **Column 1 (Identity & Model Setup)**: Role Packs, Name, Vault Home, Day 0 Origin Image Dropzone, Identity Notes, Initial Instructions, GGUF Primary Model & Vision Projector Pickers, and Full GGUF Metadata Summary Card.
      - **Column 2 (Emotions & Trait Steering)**: GoEmotions Classifier & Package Staging Card with Python Env Checker/Installer, Models Storage Directory, Control Vector GGUF File Picker & Scale Dial (-2.0x to +2.0x), Trait Sliders, Roleplay ↔ Romance Mode Slider, and Auto-Shape Persona.
      - **Column 3 (Hardware Placement & Inference Settings)**: Single Companion Hardware Placement Bar Chart Card (VRAM/RAM weights, KV, vision, and spill), Allocation Policy, Sampling Controls, and Runtime & Memory Policy.

22. **📥 Plainspeak Control Vector One-Click Staging & Download Button:**
    - Added `/runtime/stage-plainspeak-vector` endpoint in `llama-dev-runtime.mjs` and `stagePlainspeakVector` client helper in `companion-runtime-client.ts`.
    - Added **`📥 Plainspeak (~18.5 MB)`** action button in Subtab 01 (Column 2) with a hover explanation tooltip (`title` attribute) detailing file size (~18.5 MB) and real-time activation vector register shift functionality.

23. **Unified Draft Allocation/Sampling/Runtime Binding & Subtab 02 Cleanup:**
    - Replaced `{#if selectedProfile}` wrapper in Subtab 01 Column 3 with reactive `$state` variables (`draftAllocation`, `draftSampling`, `draftRuntime`) that bind directly to draft and editing state.
    - Context limit, placement, vision allowance, KV spill %, eviction priority, reasoning format, sampling controls, and runtime launch policies are now always visible and editable on Subtab 01 for both new companion drafts and existing profile edits.
    - Cleaned up duplicate `{:else if studioSubtab === 'model'}` block in `App.svelte` and added a prominent **`← Back to Persona & 3-Col Setup (Subtab 01)`** navigation button on Subtab 02.

24. **Unified 2-Subtab Setup & Comprehensive Column 3 Launch Policy (2026-08-02):**
    - Consolidated navigation into **2 clean subtabs**: `01 · Companion Persona & Model Setup` (full 3-column setup) and `02 · Test Run & Day 0 Lab`.
    - Moved ALL runtime & launch policy settings directly into Column 3 on Subtab 01 (`CPU MoE placement`, `CPU MoE layers`, `KV GPU offload`, `Retain idle slot cache`, `Engine auto-fit target`, `Release model when idle` + `Idle release minutes`, `Memory-map weights`, `Lock model pages in RAM`, `Idle polling level`, `Batch threads`, `CPU priority`, `CPU range`).
    - Removed duplicate `Update profile` / `Save draft` buttons from Column 3 to clean up layout.
    - Updated `.policy-grid` styling for select boxes and number inputs so dropdown boxes never overflow card boundaries.
    - Fixed multi-turn conversation handling in Test Lab so pressing "Send" continuously appends user and assistant messages to `testHistory`.
    - Confirmed `prepareDayZero` explicitly erases the KV slot and resets test history for a clean Day 0 start.
    - Reordered Test Lab layout: OpenAI Event Stream at top (collapsible, default collapsed via `<details>`), Model Output box in middle top, User Prompt textarea + Send/Stop buttons in middle bottom, and Audio Attachment card at bottom.
    - Reconstructed raw native markers (`<|channel|>thought` for Gemma or `<think>` for DeepSeek) in SSE stream output so "Full Model Raw Output" displays the authentic native token stream with tags intact.
    - Replaced the Test Lab static single bar with Live System Hardware VRAM & RAM Usage gauges stacked with the test companion's reservation.
    - Added `Emotion Agent Device` GPU vs CPU selector to Column 2 and included its footprint (~3.2 GiB) in reservation estimates, live system gauges, and global allocation maps with animated rainbow CSS gradient bars (`.rainbow-animated-bar`) and rainbow badges (`.badge-rainbow`).

25. **Plainspeak Model Gating, StyleGraft Warning & Affective Diagnostics Inspection Panel:**
    - Gated **`📥 Plainspeak (~18.5 MB)`** button to Gemma 4 26B A4B models (`modelScan.architecture === 'gemma4'`).
    - Added **StyleGraft (LM-Head Output Tensor Swapper)** info card with explicit warning tooltips explaining that physical tensor swaps require a **full KV cache reset**, and combining StyleGraft with Plainspeak vectors can cause chaotic prose generation.
    - Added **`⚡ Test Persona & Emotions (No Day 0 Writes)`** action in Test Lab that executes a full E2B 1st-person subconscious monologue & GoEmotions classification run without modifying Day 0 diary files.
    - Added **`🧠 Affective Cognition & Emotion Steering Diagnostics`** panel in Test Lab displaying top GoEmotions category score bubbles (>0.5), E2B subconscious internal monologue text, and turn-by-turn emotion drift charts with vector scales.

---

## 2. Updated File Paths & Verification

- **`src/lib/setup/profile.ts`**: Added `TraitSliders` type, `defaultTraitSliders`, and normalized `traits` in `loadDraft()` and `createDefaultDraft()`.
- **`src/lib/setup/companion-registry.ts`**: Updated `loadCompanionProfiles()` to normalize `draft.traits` with fallback defaults.
- **`src/App.svelte`**: Added `traits`, `homeCustomized`, `isDraggingImage` state, `handleCompanionNameInput`, `handleCompanionHomeInput`, `companionPresets`, `autoShapePersona`, `handleImageDrop`, Trait Sliders panel, Clear buttons, Day 0 Image Drop Zone, Saved Profile Vault Cards, and cleaned up Global Allocation tab.
- **`src/app.css`**: Added styles for `.input-clear-wrapper`, `.clear-btn`, `.image-drop-zone`, `.image-preview-container`, `.trait-sliders-grid`, `.trait-slider-item`, `.profile-cards-grid`, and `.profile-card`.
- **`docs/IMPLEMENTATION-STATUS.md`**: Updated checklist with Trait Sliders, Image Drop, and Profile Vault Cards.
- **`docs/INDEX.md`**: Updated master index.

---

## 3. Verification Evidence

`npm run build` executed successfully:
- 124 modules transformed.
- 0 errors, 0 warnings.
- Output bundle generated in `dist/`.
