# Anikai Evolution - Change Log

**Date:** 2026-07-30  
**Timestamp:** 11:56 PM UTC  
**Session Goal:** KV Mismatch Caution Indicators, Companion Studio Restructuring, Test Lab Model Updater, Codebase Symbol Indexer, Date-based Change Logging.

---

## 1. Architectural Summary

1. **KV Mismatch & Caution Indicators:**
   - Added yellow caution badges (`⚠️ KV reset`) and informative hover tooltips across all controls that alter the runtime fingerprint or cause warm KV tensor layout misalignment (Model path, mmproj path, Context limit, K/V cache precision, Flash Attention, Batch sizes, CPU MoE offload settings, reasoning format).
2. **Companion Studio Restructuring:**
   - Unified companion configuration and testing under **Companion Studio** with 3 intuitive sub-tabs:
     - `01 · Persona & Identity Setup`: Name, vault home, Day 0 origin image, identity notes, initial companion instructions.
     - `02 · Model & Engine Setup`: Engine selector, GGUF model picker/scanner, mmproj picker/scanner, allocation policy (placement, context, vision, KV spill %, eviction priority, reasoning format), per-companion sampling controls, and runtime launch policy.
     - `03 · Test Run & Day 0 Lab`: Live SSE event stream, prompt testing console, single-companion hardware reservation card, model/mmproj in-lab updater, raw docs dropper, tool catalog & grep search, fresh life reset, and external endpoint probe.
3. **Dedicated Workstation Hardware & Broker Allocation:**
   - Simplified **Global Allocation** to focus purely on workstation hardware devices (Windows CPU/RAM, NVIDIA GPUs), multi-lane stacked allocation bars across all companions, KV spill sliders, auto MoE setup, eviction priority stack, and broker lease rules.
4. **Test Lab Model & Encoder Updater:**
   - Enabled browsing, scanning, and saving updated GGUF model and mmproj projector paths directly within the Test Lab tab, immediately re-scanning and persisting changes to the companion profile.
5. **Codebase Function Indexer & Repo Memory:**
   - Created a standalone AST/regex symbol indexer (`scripts/repo-symbol-indexer.mjs`) that indexes every function, class, interface, and type across `src/`, `scripts/`, and `docs/` into SQLite (`evolution.v1.sqlite` in `repo_file_index` and `repo_symbol_index`).
   - Exposed `/vault/index-repo` and `/vault/repo-symbols` API endpoints in `vault-service.mjs` and a search UI panel in the Vault & Status tab.

6. **Familiars (Sub-Agent Dispatcher System):**
   - Added `profileKind: 'companion' | 'familiar'` support to `companion-registry.ts` and `App.svelte`.
   - Created a dedicated **Familiar Sub-Agent Task Dispatcher** in Test Lab that allows an Operator or Calling Companion to dispatch one-shot prompts to an unbiased sub-agent.
   - Added `familiar_task` SQLite table and `/vault/log-familiar-task` & `/vault/familiar-tasks` API endpoints in `vault-service.mjs` for task execution auditing.
7. **Hardware Acceleration & Investment Guide:**
   - Created `docs/HARDWARE-SUGGESTION-GUIDE.md` detailing memory bandwidth math, GDDR7 VRAM vs Unified Memory, GPU choices (PNY RTX PRO 5000, Blackwell, DGX Spark, Strix Halo, Mac Studio), and CUDA/Vulkan/PagedAttention mechanisms.

8. **Familiars Presets & Specialty Domain:**
   - Added `specialty` domain field to `SetupDraft` and `CompanionProfile`.
   - Exported static `familiarPresets` templates (`Tool Router & Classifier`, `Prompt Guard & Safety Classifier`, `RAG Retriever & Reranker`, `Code Refactorer & Syntax Checker`, `Fast Summarizer & Reporter`) in `catalog.ts`.
   - Exposed preset template quick-buttons and specialty focus inputs in Companion Studio for instant Familiar creation.
9. **RAG Models & KV Snapshot Mechanics:**
   - Documented 3-stage RAG retrieval pipeline (Embedding via `bge-m3` + `sqlite-vec` -> Sparse BM25 via FTS5 -> Re-ranking via `bge-reranker-v2-m3` -> Generative synthesis).
   - Documented exact distinction between KV Snapshot (`.bin` disk dump for 0ms slot reload) and Context Checkpoints (in-memory prefix cache), highlighting how KV Snapshots isolate Companion warm state from Familiar tool execution.
10. **Python Native Standalone Engine Adapter & Gigatoken Integration:**
    - Documented exact role of Gigatoken as a Rust-backed 100x data preprocessor / tokenizer (`pip install gigatoken`) rather than a standalone text weights decode engine.
    - Added `python-native` (Python Native Standalone Engine) profile to `catalog.ts` and `profile.ts` with capability matrix for Gigatoken fast tokenization, PyTorch MoE expert offloading, SageAttention, PagedAttention, and CUDA/Vulkan option.
11. **Affective Emotion Subconscious Hive Specification:**
    - Documented dynamic Multi-LoRA adapter scaling based on GoEmotions intensity (> 0.5).
    - Bounded recent feelings buffer (~800 lines / ~20k-64k tokens) with damped exponential decay.
    - 1st-person system framing ("You are I") to eliminate 3rd-person roleplay breaks.
    - Synthetic conversation pair generation pipeline and Unsloth/PEFT JSONL fine-tuning format.
    - GoEmotions -> Higgs TTS translation layer in `docs/AFFECTIVE-EMOTION-SPEC.md`.
12. **Familiars Studio 4th Rail Navigation & Dev Ledger Modal:**
    - Added 4th navigation rail tab for `Familiars Studio` with separate `D:\Anikai\Familiars\` home vault.
    - Moved Implementation Ledger out of Vault tab into topbar `⚡ Dev Ledger & Logs` modal overlay.
    - Added interactive SQLite `repo_symbol_index` table with clickable column sorting in Dev Ledger modal.
    - Capability-gated model setup controls based on selected engine profile (`llama-cpp` vs `python-native` vs `vLLM`).
13. **Strict Studio Separation & Complete Runtime Launch Policy Controls:**
    - Fully separated **Companion Studio** (`tab === 'companion'`) and **Familiars Studio** (`tab === 'familiars'`). Companion Studio lists and manages companion profiles ONLY; Familiars Studio manages familiar sub-agents ONLY.
    - Removed profile type switcher buttons inside cards; navigation rail tabs now explicitly dictate profile kind.
    - Added **Familiar Access & Companion Block List Panel** to configure global vs. custom companion access policies for familiars.
    - Restored 100% of runtime launch policy settings in `Model & Engine Setup` (subtab 02) matching Images 1 & 2: `Idle polling level`, `Batch threads`, `CPU priority`, `CPU range`, `Batch size`, `Micro-batch`, `Host cache RAM`, `Context checkpoints`, `Memory-map weights`, `Lock model pages in RAM`, `Release model when idle`.
    - Added auto-resolution for `llama-server.exe` candidates in `resources/llama-bin/` with clear guidance.

---

## 2. Files Changed & Line Details

### A. `src/App.svelte`
- **Paths:** `D:\Anikai\Anikai-Evolution\src\App.svelte`
- **Lines Changed:** ~350 lines modified/restructured.
- **Functions Added / Modified:**
  - `scanAndUpdateSelectedProfileModel()`: Scans target GGUF/mmproj and updates selected `CompanionProfile`.
  - `handleIndexRepoSymbols()`: Triggers `/vault/index-repo` and fetches indexed symbol count.
  - `handleSearchRepoSymbols()`: Filters indexed repo symbols by name or file path.
- **Key Changes:**
  - Updated `tab` type to `'companion' | 'allocation' | 'status'`.
  - Added `studioSubtab` state (`'persona' | 'model' | 'test-lab'`).
  - Rendered caution badges on KV invalidating controls with tooltip `kvCautionTip`.
  - Rendered Single Companion Hardware Reservation card in Test Lab.
  - Rendered Repo Symbol Library panel in Vault/Status tab.

### B. `src/app.css`
- **Paths:** `D:\Anikai\Anikai-Evolution\src\app.css`
- **Lines Added:** ~70 lines added.
- **Styles Added:**
  - `.studio-subtabs`, `.studio-subtab-btn`, `.studio-subtab-btn.active` for inner sub-navigation.
  - `.kv-caution-badge`, `.caution-icon` for KV mismatch warnings.
  - `.symbol-list`, `.symbol-item` for Codebase Function Indexer list display.

### C. `scripts/repo-symbol-indexer.mjs` (NEW)
- **Paths:** `D:\Anikai\Anikai-Evolution\scripts\repo-symbol-indexer.mjs`
- **Total Lines:** 125 lines.
- **Functions Defined:**
  - `collectFiles(dir, exts)`: Recursively collects code files excluding `node_modules`, `dist`, `.git`.
  - `parseSymbols(filePath, content)`: Parses export functions, const functions, types, interfaces, classes, and line numbers.
  - `runRepoIndexer()`: Initializes SQLite tables `repo_file_index` and `repo_symbol_index` and populates symbols.

### D. `scripts/vault-service.mjs`
- **Paths:** `D:\Anikai\Anikai-Evolution\scripts\vault-service.mjs`
- **Lines Changed:** ~30 lines modified.
- **Functions / Endpoints Modified:**
  - Imported `runRepoIndexer`.
  - Added `repo_file_index` and `repo_symbol_index` to database initialization script.
  - Added `safeCount(table)` helper.
  - Added `GET /vault/repo-symbols` endpoint.
  - Added `POST /vault/index-repo` endpoint.
  - Updated `status()` to include `repoFiles` and `repoSymbols` counts.

### E. `src/lib/vault/vault-client.ts`
- **Paths:** `D:\Anikai\Anikai-Evolution\src\lib\vault\vault-client.ts`
- **Lines Changed:** ~20 lines modified.
- **Types & Functions Added:**
  - Added `RepoSymbolItem` type.
  - Added `indexRepoSymbols()` API method.
  - Added `getRepoSymbols(q)` API method.

### F. `docs/EVOLUTION-VAULT-CONTRACT.md`
- **Paths:** `D:\Anikai\Anikai-Evolution\docs\EVOLUTION-VAULT-CONTRACT.md`
- **Lines Modified:** ~20 lines added.
- **Document Updates:** Documented Codebase Symbol Indexer schema and repo memory contract.

### G. `docs/IMPLEMENTATION-STATUS.md`
- **Paths:** `D:\Anikai\Anikai-Evolution\docs\IMPLEMENTATION-STATUS.md`
- **Lines Modified:** ~10 lines added.
- **Status Updates:** Added entry for Codebase Symbol Indexer as `wired`.

### H. `Test Lab Output, Per-Turn Telemetry & Pre-Day-0 Clean KV Reset`
- **Paths:** `D:\Anikai\Anikai-Evolution\src\App.svelte`, `src\app.css`, `src\lib\runtime\openai-sse.ts`, `src\lib\runtime\companion-runtime-client.ts`, `scripts\llama-dev-runtime.mjs`
- **Updates:**
  - **Assistant Output Mode Toggle:** Added `Full Model Raw Output` (unmodified truth) vs `Parsed Projection` (splits `<|channel|>thought`, `<thought>`, or planning bullets into separate Thought / Internal Planning and Final Response cards).
  - **Actual Per-Turn Telemetry Table:** Displays exact prompt tokens evaluated, cached tokens restored, hit %, output tokens generated, total accumulated context size, decode speed (tok/s), and prefill duration for every turn.
  - **Stream Container Height & Auto-Scroll:** Fixed max-height on assistant output boxes with smooth auto-scroll to prevent streaming text from pushing down the UI layout.
  - **`Send` Composer Button & Multi-Turn Chat:** Renamed composer button from `Run test` to `Send`. Enabled continuous multi-turn chat testing before Day 0.
  - **Clean Day 0 KV Reset:** Preparing Day 0 now erases pre-Day-0 warm slot KV on `llama-server` (`/slots/0?action=erase`) and resets test history, ensuring Day 0 starts on a clean slate.
  - **Cache Profile Caution Badge:** Added `⚠️` caution badge and tensor reset tooltip to `Cache profile` dropdown.

---

## 3. Verification & Evidence

- **Build Check:** Executed `npm run build` with Vite. Built cleanly in 269ms with 0 compiler errors or warnings.
- **Repo Indexer Test:** Executed `node scripts/repo-symbol-indexer.mjs`. Successfully indexed 39 files and 224 symbols into `evolution.v1.sqlite`.
