# Capability boundary

MoE top-k is a model metadata/launch policy, not a claim about individual
expert VRAM residency. The broker displays planned placement separately from
measured engine facts. CPU-MoE and auto-fit requests remain runtime launch
policies until the engine supplies measured placement telemetry.
# Resource Broker Contract

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Active Contract | **Last Updated:** 2026-07-30  
> **Related Specs:** [`ENGINE-CAPABILITY-CONTRACT.md`](ENGINE-CAPABILITY-CONTRACT.md), [`HARDWARE-SUGGESTION-GUIDE.md`](HARDWARE-SUGGESTION-GUIDE.md)

## Purpose

The resource broker is the sole authority for device allocation across Anikai Evolution companion processes and engine adapters.

Companion apps request a lease. They do not directly reserve CUDA, CPU threads, RAM, VRAM, server slots, or another companion's engine process.

## Authority boundaries

```text
Setup / Companion app
  → request or release a lease
Resource broker
  → admits, queues, rejects, or evicts
Engine adapter
  → launches and measures registered processes
Read-only resource snapshot
  → rendered by Setup and companion apps
```

The broker writes the snapshot atomically. Every other app is read-only. A future implementation may use SQLite or an atomic JSON snapshot; multiple independent app writes are prohibited.

**Out of scope for this contract:** chat templates, OpenAI vs Claude wire shapes, MCP familiar bridges, and stream parsing. Those live under [`ENGINE-CAPABILITY-CONTRACT.md`](ENGINE-CAPABILITY-CONTRACT.md) / companion home — the broker only **admits and measures** who may hold GPU/RAM/slots.

## Snapshot

The initial TypeScript contract is in `src/lib/allocation/resource-snapshot.ts`.

```ts
type ResourceBrokerSnapshot = {
  contractVersion: 1;
  evidence: 'simulated' | 'measured' | 'unavailable';
  generatedAt: string | null;
  writer: 'resource-broker';
  devices: LocalDevice[];
  leases: CompanionLease[];
};
```

`simulated` is visually useful but must never be presented as hardware telemetry. `measured` requires an adapter or OS probe with a timestamp. `unavailable` means the relevant runtime cannot report the figure.

## Lease admission

A lease request will include:

- companion/profile ID;
- selected engine and model profile;
- requested device placement;
- context and KV policy;
- CPU/GPU share;
- priority (`foreground`, `normal`, `background`);
- preemption/queue policy;
- compatibility fingerprint for shared server admission.

The broker evaluates weight residency, live KV, context limit, available RAM/VRAM, process/thread limits, existing priority leases, and the selected backend's actual capabilities.

## Setup allocation policy

Before a broker exists, Setup persists a **planned reservation** beside a committed, scanned companion profile. It may contain device intent, GPU share or CPU thread cap, context limit, vision allowance, KV location/strategy, eviction priority, and active-expert policy.

Vision allowance is part of the selected context window, never extra context. Full model weights and any MoE pool are residency/placement concerns; active experts are runtime-compute policy and not a promise that only those expert bytes occupy VRAM. Setup must render all of these as estimates/plans until the adapter measures a launched process.

The managed development runtime is intentionally one server per companion. It is
not broker admission and may duplicate model weights when multiple companions
run the same GGUF. Test Lab must warn through planned allocation UI rather than
pretend that per-server GPU admission is solved.

## llama.cpp rules

Multiple `llama-server` processes are valid when they have separate ports and broker leases.

A shared `llama-server` is only considered when model file/hash, model parameters, GPU placement, cache types, context policy, and relevant server configuration are compatible. Each companion still has a separate session/slot and KV budget.

`--parallel` is a concurrency/throughput control, not automatic speedup. Context/KV slot behavior varies by llama.cpp version and must be tested by the adapter before shared-server admission is enabled.

## CUDA state

| UI state | Meaning |
|---|---|
| Green / active | The selected adapter successfully used a compatible CUDA device in a current probe. |
| Orange / attention | CUDA-capable hardware may exist, but driver, backend, toolkit, or adapter probing needs attention. Show diagnostics and documentation; do not imply a toolkit download will always solve it. |
| Unlit / unavailable | No compatible CUDA path is available for this engine/device. |

## External engines

External processes may later be observed through OS/GPU process telemetry. Evolution must not alter an unregistered server. Only a process started and registered by the broker may be stopped, reconfigured, or evicted by Evolution.
