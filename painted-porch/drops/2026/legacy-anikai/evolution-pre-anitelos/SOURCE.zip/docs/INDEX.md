# Anikai Evolution — Master Documentation Index & Knowledge Map

> **Authoritative Specification Index**  
> **Repository Root:** `D:\Anikai\Anikai-Evolution\`  
> **Last Updated:** August 1, 2026  

---

## 1. Executive Purpose & Sub-Agent Knowledge Protocol

This document is the **single source of truth and master index** for all architectural contracts, technical specifications, hardware guides, and implementation ledgers in the Anikai Evolution project.

### Protocol for AI Coding Agents & Contributors

Before proposing new features, adding new documentation files, or refactoring existing logic:

1. **Consult the Index First:** Check this index to determine if an architectural contract or spec already exists for your feature (e.g., SQLite Vault, Resource Broker, Emotion Sub-Agents, Modular Code Architecture).
2. **Search SQLite Repo & Document Memory:** Query the SQLite symbol/document index (`evolution.v1.sqlite` via `getRepoSymbols()`) or `docs/INDEX.md` to locate relevant functions and designs.
3. **Avoid Duplicate Specifications:** Do not create duplicate spec files or re-implement existing features under a different name. Update existing docs or record new notes in the appropriate specification document.
4. **Maintain Cross-Links:** Every specification document in `docs/` must include a top navigation banner linking back to [`docs/INDEX.md`](INDEX.md) and related specifications.

---

## 2. Master Document Catalogue

| Document | Category / Domain | Status | Last Updated | Primary Purpose & Key Concepts |
| :--- | :--- | :--- | :--- | :--- |
| [`INDEX.md`](INDEX.md) | **Master Index** | **Active** | 2026-08-01 | Central repository knowledge map, document index, and sub-agent protocol. |
| [`IMPLEMENTATION-STATUS.md`](IMPLEMENTATION-STATUS.md) | **Status Ledger** | **Active** | 2026-08-01 | Detailed tracking of wired, prototype, planned, and blocked features. |
| [`EVOLUTION-VAULT-CONTRACT.md`](EVOLUTION-VAULT-CONTRACT.md) | **Vault & Memory** | **Architecture Contract** | 2026-08-01 | Global SQLite vault specification, litestream backups, Karpathy-style knowledge base, Project Keeper integration, and repo symbol indexer. |
| [`SPINE-LEAF-ARCHITECTURE.md`](SPINE-LEAF-ARCHITECTURE.md) | **Code Organization** | **Active Standard** | 2026-08-01 | Spine & Leaf modular code design policy for preventing giant files (`<250` line root spines, `<300` line single-responsibility leaf components). |
| [`AFFECTIVE-EMOTION-SPEC.md`](AFFECTIVE-EMOTION-SPEC.md) | **Cognition & Sub-Agents** | **Architecture Contract** | 2026-08-01 | Multi-LoRA Affective Sub-Agent Hive, GoEmotions dataset pipeline, 1st-person monologue, dynamic control vector trait steering, baseline anchoring, and overthinking circuit breaker. |
| [`ENGINE-CAPABILITY-CONTRACT.md`](ENGINE-CAPABILITY-CONTRACT.md) | **Inference Engines** | **Active Contract** | 2026-07-30 | Capability-gated UI specification. Settings only appear if the selected engine/adapter explicitly reports support. |
| [`RESOURCE-BROKER-CONTRACT.md`](RESOURCE-BROKER-CONTRACT.md) | **Hardware Allocation** | **Active Contract** | 2026-07-30 | Multi-companion hardware resource allocation, lease management, CUDA/VRAM/RAM reservation, MoE offloading, and eviction priorities. |
| [`LLAMA-DEV-RUNTIME.md`](LLAMA-DEV-RUNTIME.md) | **Runtime Service** | **Wired (Dev)** | 2026-07-30 | Development-time managed `llama-server` runtime process manager, SSE proxy streaming, slot save/restore KV snapshots, and Day 0 lifecycle orchestration. |
| [`COMPANION-KNOWLEDGE-HOME-SPEC.md`](COMPANION-KNOWLEDGE-HOME-SPEC.md) | **Companion Life & Day 0** | **Wired (Dev)** | 2026-07-30 | Companion home directory provisioning, Day 0 first-ever introduction, vision origin copying, raw knowledge ingestion, and tool permission ledgers. |
| [`LOCAL-PROBE-SERVICE.md`](LOCAL-PROBE-SERVICE.md) | **Hardware Probing** | **Wired (Dev)** | 2026-07-30 | Loopback hardware probe service fetching real Windows CPU, physical/logical core counts, total/free RAM, and NVIDIA GPU SMI VRAM telemetry. |
| [`HARDWARE-SUGGESTION-GUIDE.md`](HARDWARE-SUGGESTION-GUIDE.md) | **Hardware & Speeds** | **Reference Guide** | 2026-07-30 | Analysis of NVFP4 / Laguna S 2.1, RTX PRO 5000 72GB GDDR7, Halostrix, Vulkan vs CUDA, Gigatoken, and expected tok/s benchmarks. |
| [`PROJECT-KEEPER-IDEA-AUDIT.md`](PROJECT-KEEPER-IDEA-AUDIT.md) | **Legacy Audit** | **Archival Audit** | 2026-07-30 | Historical analysis of legacy Anikai Desktop and Project Keeper features for integration into Evolution. |
| [`COLIBRI-EXPERIMENT-NOTE.md`](COLIBRI-EXPERIMENT-NOTE.md) | **MoE Research** | **Backlog Note** | 2026-07-30 | Experimental disk-streamed MoE runtime notes for GLM-5.2 and large model offloading. |
| [`SETUP-DRAFT-STORAGE.md`](SETUP-DRAFT-STORAGE.md) | **Frontend State** | **Wired (Dev)** | 2026-07-30 | Browser local storage schema for setup draft profiles and Test Lab run ledgers. |
| [`changelog/2026-08-01/CHANGELOG.md`](changelog/2026-08-01/CHANGELOG.md) | **Changelog Ledger** | **Active Ledger** | 2026-08-01 | Dated changelog for Writing Style & Persona State Trait Sliders, Roleplay ↔ Romance dynamic slider, Day 0 Image Drop, Input Clear Buttons, Saved Profile Vault Cards, and Global Allocation UI cleanup. |
| [`changelog/2026-07-30/CHANGELOG.md`](changelog/2026-07-30/CHANGELOG.md) | **Changelog Ledger** | **Active Ledger** | 2026-07-30 | Dated changelog listing file paths, lines changed, functions added, and verification evidence. |

---

## 3. Feature Implementation & System Roadmap Matrix

### A. Wired & Fully Implemented
- [x] **Raw-First SSE Streaming Engine:** Direct, append-only stream capture from `llama-server`. No parser interference with inference.
- [x] **Thought / Reply Projection View:** Option to toggle between exact raw output and parsed Thought / Final Response cards.
- [x] **Actual Per-Turn Telemetry & Context Buildup Table:** Real-time and historical tracking of prompt tokens, cached tokens (KV hit %), output tokens, context buildup, decode tok/s, and prefill duration per turn.
- [x] **Clean Day 0 KV Reset:** Pre-Day-0 slot KV erasure (`/slots/0?action=erase`) ensuring Day 0 starts on a 100% clean KV state.
- [x] **Multi-Lane Global Reservation Preview:** Stacked color-coded bar chart showing VRAM and RAM allocation across all saved companions with eviction priorities.
- [x] **Single-Companion Hardware Reservation Card:** Individual memory/weights/KV/vision reservation preview in Test Lab.
- [x] **Familiars Studio (4th Rail Navigation):** Dedicated workspace for familiar sub-agents (`D:\Anikai\Familiars\`) with SQLite task logging.
- [x] **Codebase Symbol Indexer:** Node.js script (`scripts/repo-symbol-indexer.mjs`) scanning all repo symbols into `evolution.v1.sqlite`.
- [x] **Capability-Gated Controls:** Settings shown only if the selected engine adapter supports them.
- [x] **Caution Badges (`⚠️`):** Warning indicators and tooltips on settings that cause tensor misalignment and KV cache resets.
- [x] **One-Click Batch Launcher:** `start-evolution.bat` and `scripts/start-all.mjs` with automated Windows port cleanup.

### B. In Progress
- [ ] **Spine & Leaf Code Restructuring:** Splitting `App.svelte` and `llama-dev-runtime.mjs` into modular single-responsibility components per [`docs/SPINE-LEAF-ARCHITECTURE.md`](SPINE-LEAF-ARCHITECTURE.md).

### C. Planned Architecture & Research Backlog
- [ ] **Affective Emotion Sub-Agent Hive:** Multi-LoRA 27-emotion classifier and internal monologue generator with Higgs TTS translation layer ([`docs/AFFECTIVE-EMOTION-SPEC.md`](AFFECTIVE-EMOTION-SPEC.md)).
- [ ] **Vulkan + CUDA Dual Engine Adapter:** Dual compute backend support for NVIDIA, AMD, and Intel hardware ([`docs/HARDWARE-SUGGESTION-GUIDE.md`](HARDWARE-SUGGESTION-GUIDE.md)).
- [ ] **Gigatoken Application Tokenizer Integration:** Fast Rust-backed text chunking and pre-tokenization adapter ([`docs/HARDWARE-SUGGESTION-GUIDE.md`](HARDWARE-SUGGESTION-GUIDE.md)).
- [ ] **PagedAttention & Radix Prefix Caching Adapter:** `python-native` or advanced `vLLM` / `SGLang` runtime adapter integration ([`docs/ENGINE-CAPABILITY-CONTRACT.md`](ENGINE-CAPABILITY-CONTRACT.md)).
- [ ] **Colibri Disk-Streamed MoE Runtime:** Ultra-large model disk streaming experiment ([`docs/COLIBRI-EXPERIMENT-NOTE.md`](COLIBRI-EXPERIMENT-NOTE.md)).
- [x] **Staged engine resource folders:** `resources/engines/README.txt` + `resources/{vllm,sglang,python-native,colibri}/` (+ `llama-bin/staging.json`) so adapters are visible beside llama before launch wiring.

---

## 4. Documentation Standard & Banners

Every document created or updated in this repository must include the following top banner:

```markdown
# [Document Title]

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** [Wired / In Progress / Architecture Contract]  
> **Last Updated:** [YYYY-MM-DD]
```

---

*This index is updated whenever new architectural specifications, changelogs, or major implementation milestones are committed.*
