# Spine & Leaf Modular Code Architecture

> **Notice:** This document defines the architectural policy for preventing monolithic "god files" across Anikai Evolution. It is linked from [`docs/INDEX.md`](INDEX.md).

---

## 1. Executive Summary & Objective

In previous iterations (e.g., Anikai Desktop), codebases experienced maintainability friction due to monolithic files exceeding thousands of lines (such as `App.svelte` containing all UI tabs, modals, streaming parsing, and allocation state in a single file).

Anikai Evolution adopts a **Spine & Leaf Feature Tree Architecture**. Every module and component is organized by strict single-responsibility boundaries, preventing giant files and keeping code refactoring safe, fast, and local.

---

## 2. Architectural Structure: Spine, Branch & Leaf

```text
src/
├── App.svelte                          <-- Root Spine (Composition & Routing only, <250 lines)
├── components/                         <-- UI Feature Tree
│   ├── common/                         <-- Shared UI Leaves
│   │   ├── HeaderTopBar.svelte
│   │   ├── NavigationRail.svelte
│   │   └── DevLedgerModal.svelte
│   └── studio/                         <-- Studio Domain Branch
│       ├── PersonaSetupTab.svelte
│       ├── ModelSetupTab.svelte
│       ├── AllocationTab.svelte
│       ├── StatusVaultTab.svelte
│       └── test-lab/                   <-- Test Lab Sub-Branch Directory
│           ├── TestLabConsole.svelte
│           ├── TelemetryTable.svelte
│           ├── HardwareReservationCard.svelte
│           └── FamiliarDispatcher.svelte
└── lib/                                <-- Logic & Service Tree
    ├── runtime/
    │   ├── companion-runtime-client.ts <-- Sub-Spine API Client
    │   ├── openai-sse.ts               <-- Leaf: SSE Streaming Parser
    │   └── types.ts                    <-- Leaf: Data Contracts
    └── stores/                         <-- Reactive Svelte 5 Rune Stores
        └── studio-state.svelte.ts      <-- Decoupled Application State
```

### Component & Module Definitions

1. **Spine (Root Coordinator)**
   - **Role:** High-level composition, tab routing, and global state distribution.
   - **Rule:** Contains **NO** inline business logic, direct styling blocks, raw event parsing, or monolithic HTML blocks.
   - **Maximum Length:** **< 250 lines**.

2. **Branch (Domain Director)**
   - **Role:** A folder or container component managing a logical domain (e.g., `test-lab/`, `setup/`, `vault/`).
   - **Rule:** Coordinates interactions between sub-leaf components and exports a clean interface to the spine.

3. **Leaf (Feature-Specific Unit)**
   - **Role:** Single-responsibility, reusable component or utility file named strictly by function (e.g., `TelemetryTable.svelte`, `SlotProcessManager.mjs`).
   - **Rule:** Focuses on one specific visual or algorithmic task.
   - **Maximum Length:** **< 300 lines**.

---

## 3. The Tree Expansion Rule (Refactoring Trigger)

To prevent files from swelling over time:

1. **The 300-Line Soft Limit:**
   - If a single file exceeds 300 lines or starts handling more than one domain responsibility, it must be refactored.
2. **Directory Elevation:**
   - When a leaf file (e.g., `TestLab.svelte`) grows beyond the threshold, it is promoted to a directory (`components/studio/test-lab/`) containing a sub-spine (`TestLabView.svelte`) and smaller leaf components (`Console.svelte`, `TelemetryTable.svelte`, `HardwareReservationCard.svelte`).
3. **Decoupled Business Logic (Svelte 5 Runes):**
   - UI components should only declare visual markup and event bindings. Complex reactive state and API triggers are placed into headless Rune stores (`src/lib/stores/`).

---

## 4. Immediate Refactoring Targets for Anikai Evolution

To transition current monolithic development files into the Spine & Leaf architecture:

### A. Frontend (`src/App.svelte`)
- [ ] **Extract Navigation & Topbar:** Move topbar, brand rail, and Dev Ledger modal to `src/components/common/`.
- [ ] **Extract Persona Studio Subtab:** Move identity notes, origin image selector, and profile setup to `src/components/studio/PersonaSetupTab.svelte`.
- [ ] **Extract Model & Engine Setup Subtab:** Move capability-gated runtime policy controls to `src/components/studio/ModelSetupTab.svelte`.
- [ ] **Extract Test Lab Subtab:** Modularize into `src/components/studio/test-lab/`:
  - `TestLabConsole.svelte` (Event stream, raw output toggle, parsed thought/reply projection).
  - `PerTurnTelemetryTable.svelte` (Actual prompt tokens, cached tokens, context buildup, tok/s).
  - `HardwareReservationCard.svelte` (VRAM/RAM single-companion reservation bar).
  - `FamiliarDispatcher.svelte` (One-shot familiar sub-agent task form and SQLite history).
- [ ] **Extract Allocation & Placement Tab:** Move multi-lane global reservation bar chart and device allocation policy to `src/components/studio/AllocationTab.svelte`.

### B. Backend Runtime (`scripts/llama-dev-runtime.mjs`)
- [ ] **`scripts/runtime/slot-manager.mjs`**: Process spawning, health check, `/props` verification, and slot lifecycle.
- [ ] **`scripts/runtime/proxy-chat.mjs`**: SSE proxy stream handler, KV snapshot save/restore, and transcript logging.
- [ ] **`scripts/runtime/day0-service.mjs`**: Day 0 home provisioning, vision origin copying, and audit logging.
- [ ] **`scripts/runtime/tool-host.mjs`**: Scoped filesystem exploration, tool searching, and document registration.

---

## 5. Summary Matrix & Cross-References

| Tier | Purpose | Max Size | Examples |
| :--- | :--- | :--- | :--- |
| **Spine** | Root Composition & Routing | < 250 lines | `App.svelte`, `llama-dev-runtime.mjs` |
| **Branch** | Domain Container | < 400 lines | `components/studio/test-lab/`, `lib/vault/` |
| **Leaf** | Single-Responsibility Component/Unit | < 300 lines | `TelemetryTable.svelte`, `openai-sse.ts` |

- **Master Documentation Index:** [`docs/INDEX.md`](INDEX.md)
- **Implementation Ledger:** [`docs/IMPLEMENTATION-STATUS.md`](IMPLEMENTATION-STATUS.md)
- **Vault Contract:** [`docs/EVOLUTION-VAULT-CONTRACT.md`](EVOLUTION-VAULT-CONTRACT.md)
