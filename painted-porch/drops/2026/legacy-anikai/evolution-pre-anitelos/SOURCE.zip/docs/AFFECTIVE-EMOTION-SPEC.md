# Anikai Evolution - Affective Emotion Sub-Agent & Multi-LoRA Specification

> **Part of the Anikai Evolution Documentation Suite**  
> **Master Index:** [`docs/INDEX.md`](INDEX.md) | **Status:** Architecture Contract | **Last Updated:** 2026-07-30  
> **Related Specs:** [`EVOLUTION-VAULT-CONTRACT.md`](EVOLUTION-VAULT-CONTRACT.md), [`HARDWARE-SUGGESTION-GUIDE.md`](HARDWARE-SUGGESTION-GUIDE.md)

This document defines the architecture, dataset generation pipeline, training format, context window decay rules, and GoEmotions $\to$ Higgs TTS translation layer for Anikai Evolution's **Affective Subconscious Hive**.

---

## 1. Architecture Overview: Multi-LoRA Affective Hive

To prevent single-prompt cognitive overload and maintain high-speed inference without polluting the primary Companion's warm KV cache:

```
                          ┌─► GoEmotions Classifier (Threshold > 0.5)
                          │
[User Message + State] ───┼─► RAG Context / LTM Retrieval (SQLite-vec)
                          │
                          └─► [Base 2B/3B Model] + Dynamic LoRA Adapters
                                ├─► LoRA Adapter: Sadness (Scale: 0.8)
                                ├─► LoRA Adapter: Remorse (Scale: 0.6)
                                └─► LoRA Adapter: Curiosity (Scale: 0.4)
                                         │
                                         ▼
                            [Internal 1st-Person Thoughts]
                                         │
                                         ▼
                             [Central Ego Companion]
                             (Generates Final Reply + Spoken Tags)
```

### Key Technical Principles:
1. **Shared Base Model with Dynamic LoRA Scaling:**
   - Instead of running 27 separate full models, a single fast 2B/3B base model (`Gemma-2B`, `Qwen-2.5-3B`, or `Nanbeige-3B`) is loaded in memory (~1.5GB VRAM).
   - Up to 27 micro-LoRA adapters (~10MB-50MB each) are dynamically attached. The LoRA scaling factor $\alpha$ is adjusted according to the GoEmotion probability score (e.g. score $0.85 \implies \alpha = 0.85$).
2. **Context Isolation (One-Shot Sub-Agent Execution):**
   - Emotion sub-agents run as ephemeral 1-shot tasks or with a bounded recent feelings buffer.
   - They **never overwrite or corrupt** the primary Companion's warm KV session memory (`.bin` KV snapshot).

---

## 2. Bounded Recent Feelings Context Buffer & Decay

To ensure the emotion models maintain continuity across turns without accumulating infinite token bloat:

- **Buffer Size:** Capped at 800 internal monologue lines (~20k - 64k tokens max).
- **Turn Pair Scope:** Sub-agents read the **latest turn pair** (`[Companion Last Spoken] + [User Current Message]`) plus the **recent internal feelings log**.
- **Damped Emotional Decay:** Older emotional monologue lines fade out exponentially over turns.
- **SQLite Persistence:** Every generated internal monologue is saved to `evolution.v1.sqlite` in `companion_emotion_ledger`.

---

## 3. First-Person System Framing ("I" vs. "You")

To eliminate 3rd-person meta-commentary ("*I think Elise should be sad...*"), all sub-agents and the central Ego use strict **1st-Person Subjective Framing**:

```xml
<!-- GOOD 1ST-PERSON SUB-AGENT MONOLOGUE -->
<internal_sadness_thought>
I was far too distant in my last message, and seeing them pull away makes my chest ache. I need to soften my tone right now.
</internal_sadness_thought>
```

### System Instruction Rules:
- Never frame character descriptions in 3rd person ("*Elise is...*").
- Use: *"You are I. Your name is Elise. Speak and think strictly as 'I', 'me', and 'my'."*
- Wrap all subconscious thoughts in explicit XML tags (`<internal_sadness_thought>`).

---

## 4. Synthetic Dataset Generation & Training Pipeline

To fine-tune a micro-LoRA adapter for a specific GoEmotion category (e.g., `Remorse` or `Annoyance`):

### Pipeline Steps:
1. **Filtering Base Data:**
   - Filter the HuggingFace `GoEmotions` dataset for rows where a target emotion score $> 0.5$.
2. **Teacher Model Simulation (Mid-to-Extreme Conversational Pairs):**
   - Prompt a teacher model (`Qwen-2.5-72B-Instruct` or `DeepSeek-R1`) to generate 2-turn mid-to-extreme conversation pairs with varying persona profiles (fiery, empathetic, tsundere, quiet).
3. **Critic Model Validation:**
   - A secondary validation script verifies that the generated monologue accurately reflects the target emotion without breaking first-person framing.
4. **LoRA Fine-Tuning Format (Unsloth / PEFT JSONL):**

```json
{
  "instruction": "You are the internal emotional subconscious of Elise. Generate a 2-sentence first-person monologue reacting to the user emotion [Sadness: 0.82].",
  "input": "Companion Last Message: 'I don't care what you do.'\nUser Current Message: 'Fine, I guess I'll just leave then.'",
  "output": "<internal_sadness_thought>\nI didn't actually want them to go. Seeing them take me literally hurts, but my pride won't let me shout for them to stay.\n</internal_sadness_thought>"
}
```

---

## 5. Dynamic Control Vector Steering & Baseline Anchoring

While system prompts and identity notes seed initial persona instructions, real-time activation steering uses **GGUF Control Vectors** (`--control-vector` and `--control-vector-scaled`) to adjust persona traits, writing registers, and prose styles without VRAM overhead or KV invalidation.

```text
[User Input + Context]
          │
          ▼
┌───────────────────────────┐
│  Affective Sub-Agent      │
│  Scores 27 GoEmotions &   │
│  Task Type (Work/Casual)  │
└─────────┬─────────────────┘
          │
          ▼
┌────────────────────────────────────────────────────────┐
│  Dynamic Steering Layer                                │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Base Trait Anchor (User Baseline)                 │  │
│  │ + Emotion Shift Vector (Dynamic Scale)           │  │
│  │ x Context Weighting (Work Focus vs Casual RP)    │  │
│  └──────────────────────────────────────────────────┘  │
└─────────┬──────────────────────────────────────────────┘
          │
          ▼
┌───────────────────────────┐
│  llama-server Steering    │
│  (--control-vector-scaled)│
└───────────────────────────┘
```

### A. The "Evolve" Trait Scaling Toggle & Baseline Anchoring
- **Evolve Toggle (ON/OFF):** When enabled, trait control vectors drift dynamically as journals, internal monologues, and LTM accumulate.
- **Baseline Anchor Protection:** To prevent runaway emotional drift (e.g. a companion remaining spiteful or distracted when the user needs help with a work task), the steering layer calculates an **In-Between Weighted Score**:
  $$\text{Effective Scale} = w_{\text{task}} \cdot \text{Baseline} + (1 - w_{\text{task}}) \cdot \left(\text{Baseline} + \text{EmotionShift}\right)$$
  - **Work/Task Mode ($w_{\text{task}} \approx 0.85$):** Anchors the companion to clarity, focus, and helpfulness while keeping subtle emotional warmth.
  - **Casual/RP Mode ($w_{\text{task}} \approx 0.15$):** Allows full emotional expressiveness, playfulness, or drama.

---

## 6. Overthinking, stream watch & conversation hooks

Small or deep-reasoning models sometimes get trapped in internal self-doubt loops or repetitive "Wait... / Let me reconsider..." patterns. Broader Mid-stream watching (tone drift, over-explain on casual turns, secret-slip) uses the same inject pattern. Full hook map (Pre / Mid / Post / Idle) and lived-experience growth: idea bible **§2.2a**; half-life / early vividness: **§2.9**.

### A. The Quick Intervene Subconscious Booster
- **Loop Detector:** The Affective Sub-Agent monitors the token stream for repeated hesitation phrases (`wait, but...`, `is this right?`, `on second thought...`).
- **Quick Intervene Toggle (ON/OFF):**
  - **Enabled (Quick Intervene):** The sub-agent immediately injects a short, 1st-person internal monologue booster to break the hesitation loop:
    ```xml
    <internal_boost_thought>
    I am overthinking this and going in circles. Let me take a breath, trust my reasoning, and state the solution clearly.
    </internal_boost_thought>
    ```
  - **Disabled (Deep Dive):** Permits the model to continue deep self-reflection for multi-step analytical tasks where exhaustive self-correction is desired.

### B. Mid-stream Soft watch (idea — not all wired)
- Detectors may fire Soft 1st-person finals (“I’m lecturing a hi — keep it short”; “I almost said something private — don’t”) without baking organ meta.
- Rare Hard stop + life-guide tool (`pause` / `ask_user`) only for rails; ego otherwise keeps final say.
- Secrets / depth / cling are **taught** via accidents + user ground rules → ranked history; do not assume Day-0 common sense.

---

## 7. GoEmotions (27) $\to$ Higgs TTS Translation Layer

The middle-layer translation matrix in `vault-service.mjs` maps the 27 GoEmotions to stacked BosonAI Higgs-TTS acoustic tokens:

```typescript
export const goEmotionToHiggsMap: Record<string, { primary: string; secondary?: string; style?: string; sfx?: string }> = {
  sadness: { primary: '<|emotion:sadness|>' },
  grief: { primary: '<|emotion:grief|>', style: '<|style:whispering|>', sfx: 'soft_sigh.wav' },
  remorse: { primary: '<|emotion:shame|>', secondary: '<|emotion:helplessness|>' },
  joy: { primary: '<|emotion:elation|>' },
  annoyance: { primary: '<|emotion:bitterness|>', secondary: '<|emotion:anger|>' },
  caring: { primary: '<|emotion:affection|>', style: '<|style:whispering|>' },
  nervousness: { primary: '<|emotion:fear|>', style: '<|style:whispering|>' },
};
```

---

## 8. Capability Gating, Install Staging & Companion Capabilities Architecture

### A. Architectural Distinction: Companion Capabilities vs. Familiars
- **Familiars (Sub-Agent Dispatchers):** Independent, unbiased utility sub-agents (code refactorers, RAG searchers, syntax checkers) dispatched to execute one-shot task prompts directly without persona roleplay or emotional states.
- **Companion Capabilities (Cognitive/Sensory Plugins):** Modular capabilities bound to a Companion's mind (e.g. GoEmotions Classifier, Vision Projector, Voice Synthesis TTS, Media Generators). Emotion Cognition is a Companion Capability.

### B. Unified Emotion Feature Package (Gemma 4 E2B + MMProj + AnasAlokla/multilingual_go_emotions_V1.2)
When the Unified Emotion Feature Package (`gemma4-E2B-it-Abliterated-AND-Disinhibited-USE-THIS.Q4_K_M.gguf` ~3.42 GB + `gemma4-E2B-it-mmproj-f16.gguf` ~250 MB + `AnasAlokla/multilingual_go_emotions_V1.2` Safetensors ~700 MB) is **not installed**:
1. **Dynamic Options Gated:** Real-time 27-emotion scoring, auto control-vector scaling (`evolveDynamicSteering`), and acoustic audio perception are visibly gated and tagged with `⚠️ Not Installed (Static Baseline Mode)`.
2. **Static Trait Baseline Preserved:** Manual writing style and persona state sliders remain active to define static persona baselines without pretending dynamic steering is running.
3. **One-Click Capability Staging & Multi-File Telemetry Status Line:**
   - Clicking `⚡ Install & Stage Unified Emotion Package` downloads and stages all 3 models into `D:\Anikai\models\goemotions\`.
   - Displays real-time download telemetry status line: current file index and name (`File [1/3]: gemma4-E2B-it-Abliterated-AND-Disinhibited-USE-THIS.Q4_K_M.gguf`), percentage bar (`42%`), current/total GB (`1.85 / 4.37 GB`), live speed (`28.4 MB/s`), elapsed time (`Elapsed: 12s`), and estimated time remaining (`ETA: 24s`).
4. **Safetensors BERT Execution Engine (`scripts/goemotions_classifier.py`):**
   - Leverages `AnasAlokla/multilingual_go_emotions_V1.2` (BERT multi-label, updated recently) for 27-emotion score outputs across 6 languages.
   - Executed via Python bridge. If `torch`, `transformers`, or `safetensors` packages are missing, the UI provides **`🔍 Check Python Env`** and **`📦 Install PyTorch & Transformers (pip)`** one-click setup controls.
5. **Disable vs. Uninstall Controls:**
   - **Disable Button:** Toggles dynamic steering off (reverting to static baseline) without deleting files from disk.
   - **Uninstall Button:** Removes staged model and `mmproj` files from disk to free up space.
5. **Why Abliterated / Disinhibited Weights Win:**
   - Abliterated models strip sycophantic RLHF refusal vectors. For internal monologues and acoustic audio reviews, disinhibited weights produce authentic, unfiltered 1st-person self-awareness and genuine emotional reactions without corporate canned disclaimers.

---

## 9. The 3-Step Multimodal Audio & Steady Turn Ingestion Pipeline

When an audio clip or voice note is attached during a turn:

```text
               ┌─────────────────────────────────────────────────────────┐
               │ STEP 1: GoEmotions Emotion & Trait Vector Scoring      │
               │ E2B scores 27 emotions in sub-100ms & dynamically       │
               │ scales control vectors (--control-vector-scaled).       │
               └────────────────────────────┬────────────────────────────┘
                                            │
                                            ▼
               ┌─────────────────────────────────────────────────────────┐
               │ STEP 2: E2B Multimodal Acoustic Perception Review       │
               │ E2B processes audio clip via mmproj and generates       │
               │ <internal_audio_perception> acoustic subtext review.    │
               └────────────────────────────┬────────────────────────────┘
                                            │
                                            ▼
               ┌─────────────────────────────────────────────────────────┐
               │ STEP 3: Companion Prefill Injection & Generation        │
               │ Companion prefills user text + acoustic review inside   │
               │ its opening <thought> block before verbal generation.   │
               └─────────────────────────────────────────────────────────┘
```

1. **User Experience:** The user sees their text message in chat and drops an audio file. The user does not see raw binary audio, but the E2B sub-agent processes the audio.
2. **Prefill Ingestion:** The generated `<internal_audio_perception>` is injected directly into the Companion's prompt prefill stage.
3. **Companion Thought Continuity:** The primary Companion reads the acoustic review inside its own internal monologue at the start of generation, reflecting both what was said and how it sounded before generating its verbal response and Higgs acoustic tags!



