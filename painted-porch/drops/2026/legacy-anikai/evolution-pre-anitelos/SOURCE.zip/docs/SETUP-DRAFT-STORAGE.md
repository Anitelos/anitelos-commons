# Setup Draft Storage

## Current implementation

The static Setup UI stores one draft under this browser-local key:

```text
anikai-evolution.setup-draft.v1
```

Schema source: `src/lib/setup/profile.ts`.

Saved fields:

- companion display name;
- proposed companion home;
- identity notes;
- selected engine profile;
- model path and optional encoder/mmproj path;
- raw-stream visibility preference;
- ISO save timestamp.

## What this is not

This storage is a UI convenience only. It is not:

- a companion identity;
- a persistent continuity vault;
- a secure secret store;
- an engine profile accepted by a backend;
- a stable companion ID;
- a Day 0 record;
- a KV snapshot.

Clearing browser site data removes it.

## Committed local profiles

A separate local registry (`anikai-evolution.companion-profiles.v1`) stores companions only after their selected model completes a successful GGUF scan. Each record carries a stable local ID, scan fingerprint, model evidence, and a planned allocation policy.

These are validated **setup records**, not runtime leases. They do not start an engine, reserve resources, or write a companion home. A future desktop Setup service replaces both browser-local keys.

## Migration path

When the desktop Setup service exists, it will own versioned profile files and perform validation. The browser-local draft becomes an import source:

1. Read and validate the draft schema.
2. Ask the user for a profile location.
3. Create an immutable companion ID separately from the display name.
4. Run an adapter capability probe.
5. Validate model, media encoder, home path, and settings against that probe.
6. Persist an accepted profile and record its capability fingerprint.
7. Retain the browser draft until the user confirms it can be cleared.

No automatic migration should silently create a companion, launch a model, or write into a future companion home.
