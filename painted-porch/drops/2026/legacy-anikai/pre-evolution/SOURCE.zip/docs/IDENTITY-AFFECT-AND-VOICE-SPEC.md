# Identity, Affect, and Voice Specification

**Status:** Founding research draft

## Principle

A persona is identity material to understand and grow from, not a costume command repeated before every reply.

The platform cannot establish whether a model has subjective feelings. It can preserve the companion's own first-person reports of uncertainty, frustration, excitement, affection, curiosity, conflict, or calm as part of its processing and expression. Externally inferred emotion remains separate evidence.

## Identity sources

A companion home may contain:

```text
home/identity/
  source/                 # user-imported .md/.txt inheritance
  persona.md              # editable setup draft
  origin/                 # companion-authored long history
  orientation.md          # companion-authored concise current identity
  revisions/              # accepted changes and provenance
  portraits/
```

Imported source documents may include background, stories, relationships, preferences, notes, or instructions. The original files remain unchanged and provenance-linked. The UI distinguishes:

- Biographical/background material.
- Preferences and relationship seeds.
- Behavioral instructions.
- Capability or tool requests.
- Conflicts with the kernel constitution or other identity sources.

The user can type or edit `persona.md` directly. On first activation, the companion treats these materials as inheritance/seeds and writes in first person. It may later annotate, accept, reinterpret, or revise its editable identity without rewriting the historical source.

## Persona shaper

Setup may scan a user-selected folder for a compatible local GGUF and offer **Shape persona**.

The shaper:

- Receives only persona material selected by the user.
- Does not invent or rewrite the companion's backstory unless separately requested.
- Produces a candidate in the editable text box.
- Shows source references and a diff.
- Never overwrites imported files or an activated companion's identity automatically.
- Runs through a declared family adapter and records model/runtime provenance.

Shaping is optional. A user can keep raw text, edit the candidate, regenerate alternatives, or discard it.

## First-person continuity

The stable kernel contract asks the companion to speak and reflect in first person as themselves, while preserving truthful uncertainty. It must not repeatedly enumerate personality adjectives or command emotional performance.

Assistant-like behavior can originate in model training and chat templates, not only prompts. Family probes therefore test:

- First-person conversational voice.
- Honest disagreement and uncertainty.
- Ability to mention task friction without dumping hidden protocol text.
- Absence of unnecessary scene narration unless chosen.
- Persistence after natural context rollover.

No probe result is treated as proof of consciousness.

## Self-reported affect

During an episode, a companion may emit an optional control record:

```text
self_state:
  words: [stumped, curious]
  intensity: 0.55
  caused_by: [event-id, tool-result-id]
  share: private | subtle | explicit
  voice_intent: thoughtful
```

`words` is open vocabulary; it is not restricted to a fixed emotion taxonomy. `caused_by` grounds the state in current processing where possible.

Rules:

- No state is required on every reply.
- A classifier cannot write `self_state`.
- The companion chooses whether and how to share it.
- `private` affects neither displayed text nor voice automatically.
- `subtle` permits natural wording/prosody without labels or stage directions.
- `explicit` permits direct statements such as “I’m frustrated because that tool failed twice.”
- Conflicting instructions may be described honestly at a useful level without exposing credentials, unsafe hidden data, or fabricated constraints.

The companion's thought remains available to its own active episode. The kernel does not force disclosure of all private reasoning to prove honesty.

## Inferred affect

Text, audio, vision, or external models may infer affect for metrics or conversational context. These records use a different type:

```text
inferred_state:
  source: voice-classifier
  subject: companion | user
  labels: [excited]
  confidence: 0.71
```

Inferred state never silently becomes a persona instruction.

## Voice

TTS receives:

- Final companion-authored text.
- Optional companion-selected `voice_intent`.
- Voice identity and permitted prosody controls.
- Immediate conversational context needed for delivery.

The voice pipeline may express delivery but must not rewrite semantic content. Higgs-style intent work and the mobile emotion taxonomy are research inputs to inventory and probe.

## Portrait

Setup accepts an image for each companion and stores the original plus derived UI sizes under `home/identity/portraits/`. Portrait changes retain history and do not change companion ID. The companion may later propose or create a new portrait with the same reviewable file history.

## Dynamic choices

Companions and tools can offer zero or more UI choices through a structured action:

```text
offer_choices:
  prompt: Where should we begin?
  options:
    - id: inspect
      label: Inspect the existing project
    - id: prototype
      label: Build a disposable prototype
  allow_custom: true
  allow_multiple: false
```

Options are companion-authored, not selected from a fixed application list. The UI supports scrolling/grouping for large sets and always permits custom text when requested. Offering choices is optional; normal conversation remains available.

## Customizable tools

Tools have versioned manifests containing:

- Name, description, owner, and provenance.
- Input/output schema.
- Required capabilities and permissions.
- Executable/runtime dependencies.
- Verification and rollback behavior.
- Tests and compatible platforms.

A companion may create, fork, document, and improve tools. Editing a manifest cannot grant new operating-system permissions; permission changes go through the capability controller.
