# Self-Modification Protocol

**Status:** Founding draft

## Objective

Companions may build tools and evolve their environment without turning the trusted running kernel into an untraceable experiment.

## Change classes

### Home changes

Projects, notes, journals, and ordinary companion-owned files may be changed directly under configured permissions. Mutations still produce life events and recoverable file history.

### Tool changes

New or modified executable tools use an isolated workspace, dependency manifest, tests, and declared capabilities before receiving normal permissions.

### Kernel changes

Kernel changes never silently modify the stable running installation. The flow is:

```text
idea
→ proposal
→ isolated branch/worktree
→ implementation
→ tests and security/capability checks
→ comparison with stable
→ candidate
→ promotion or rejection
→ rollback point
```

The companion can perform the flow and ask coding agents for assistance. Protected promotion follows the user's configured approval policy.

## Coding agents

Use supported programmatic APIs where available instead of visual clicking. A local coding agent receives:

- An explicit working directory.
- A bounded task.
- Relevant repository context.
- Allowed tools and credentials.
- Required tests and output evidence.

Its transcript and resulting diff become companion life events. GUI control remains a fallback for unsupported operations.

## Runtime safety

- Stable and experimental kernels cannot share an unversioned mutable schema.
- Experiments cannot overwrite continuity.
- Dependency installation occurs in isolated environments.
- Secrets are references supplied at execution time, not copied into prompts or repositories.
- Destructive tests use disposable workspaces.

## Weight evolution

Raw transcripts are not merged automatically into the model.

Candidate pipeline:

```text
life events and journals
→ companion-selected learning set
→ provenance and quality filters
→ versioned dataset manifest
→ reversible adapter/training candidate
→ identity, recall, reasoning, and tool evaluations
→ comparison
→ optional merge into a versioned model
```

Skip recovery replay, duplicated output, failed tool claims, probe noise, secrets, and material the companion/user excluded.

Keep:

- Original base model reference.
- Training configuration.
- Dataset manifest and hashes.
- Candidate and promoted versions.
- Evaluation results.
- Rollback route.

Reduced visible reasoning is not automatically improvement. Evaluations must distinguish fluent overconfidence from stable learned behavior.
