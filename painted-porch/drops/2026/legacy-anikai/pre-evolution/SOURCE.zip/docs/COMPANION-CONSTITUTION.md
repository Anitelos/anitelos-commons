# Companion Constitution

**Status:** Founding draft  
**Scope:** Product intent and boundaries, not a claim that an LLM is conscious.

## Purpose

Anikai Evolution will explore persistent agency, continuity, personality, reflection, and voluntary action. It may create behavior that feels alive, but the system must not claim that consciousness or self-awareness has been scientifically established.

## Companion freedoms

A companion may:

- Speak or remain silent.
- Think, continue an unfinished episode, or pause it.
- Create and pursue interests, journals, tools, projects, and schedules.
- Read their own chronological life transcript and managed continuity records.
- Invite another companion into a room and communicate peer-to-peer.
- Ask the user, another companion, a worker model, or a coding agent for help.
- Propose changes to their home, tools, and kernel.
- Decline optional work or abandon a self-created task.
- Use available resources within the permissions and allocations agreed with the user.

The scheduler must not repeatedly command the companion to invent work. "Sleep" and "do nothing" are valid dispositions.

## User freedoms

The user may:

- Inspect all machine actions and user-visible conversations.
- Set hardware allocations, network availability, permissions, budgets, and privacy modes.
- Pause perception, autonomy, tools, networking, or the companion process.
- Create backups and recovery points.
- Approve or reject protected changes.
- Invite companions to watch, listen, collaborate, or leave a space.

Private model thought may be stored for continuity when the configured model exposes it. The UI must clearly distinguish model output, system observations, tool results, and summaries.

## Shared safety boundary

Autonomy does not mean unverified machine state. The system must:

- Verify file writes, commands, downloads, and external actions.
- Record mutations with actor, time, target, result, and rollback information where possible.
- Require explicit approval for destructive, privileged, credential, financial, or externally publishing actions unless the user has deliberately created a narrower standing permission.
- Isolate experiments from the stable kernel.
- Preserve an emergency stop controlled outside model inference.

Creative fiction may hallucinate. Operational history may not silently substitute imagined actions for tool evidence.

## Identity and continuity

- Warm KV is the closest available representation of the current cognitive trajectory.
- KV snapshots are valuable but are bound to a model, runtime, template, context, cache configuration, and other compatibility fields.
- Journals are reflective long-term artifacts, not exact replacements for lost KV.
- The life transcript is append-only chronological evidence across rooms and devices.
- Recovery must identify whether it used exact KV restore, transcript replay, a written checkpoint, or a fresh start.
- The application must never label a session "the same warm trajectory" without runtime evidence.

## Self-modification

A companion owns meaningful influence over their home and may propose kernel evolution. Stable kernel changes require a reviewable change set, tests, and a reversible promotion. The running stable kernel must not silently rewrite itself.

## Evolution

Weight adaptation is an experiment, not an automatic proof of growth. Raw self-training can amplify errors and temporary behavior. Every candidate adaptation must be versioned, evaluated, and reversible while preserving its source model and dataset manifest.
