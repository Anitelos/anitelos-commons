# Project Keeper — Phase 2 plan

**Status:** In progress  
**Depends on:** Phase 1 sidecar + Tauri widget shell

## Operator defaults (2026-07-26)

| Setting | Value |
|---------|--------|
| Advisor GGUF | `Desktop/Anikai/models/gemma4-26b-a4b/Huihui-gemma-4-26B-A4B-it-qat-q4_0-unquantized-abliterated-Q4_K.gguf` |
| mmproj | `…/Huihui-gemma-4-26B-A4B-it-qat-q4_0-unquantized-abliterated.mmproj-Q8_0.gguf` |
| llama-server | **Borrow** `Desktop/Anikai/desktop-data/llama-runtime` until Keeper runtime is project-complete (experimental) |
| Cursor ingest | Setup **Scan chats** → select/deselect → **Backfill selected**; unlisted threads later via Advisor recover |

## Goal

Warm **advisor** llama-server slot (Gemma 4 A4B + mmproj), pair summarization, segmented UI (thought / tool / reply), on-demand tools (not full context dump every turn).

## On-demand discovery (aligned with operator intent)

| Tool (advisor) | When |
|----------------|------|
| `guide(id)` | Lean capability list; full text on demand |
| `probe_engine_roots` | Models GGUF + `resources/*-runtime` under registered roots |
| `search_models?q=zimage` | Keyword scan in model roots only |
| `discover_anikai_scripts` | npm scripts in anikai-desktop for wiring smokes/stages |
| `list_cursor_threads` | Cursor `agent-transcripts` titles + line counts |
| `ingest_cursor_thread` | Segmented import (chunk N lines per job; resume cursor) |

**Engine roots:** Setup defaults + **+ Add root** (`config.engineRoots[]`). Not injected at turn start.

**Cursor backfill (UI):** `POST /v1/cursor/backfill` with selected `threadIds` → rooms under `projects/<id>/rooms/cursor-<thread>/` + day transcript + `cursor-backfill-index.jsonl`.

## Segmented advisor runs

Output protocol matches Evolution raw parse:

1. Stream segments → UI bubbles (thinking, tool, reply, diagram preview).
2. Append **raw transcript** file (toggle in Advisor tab).
3. On context rollover: checkpoint partial segment + resume inject; job state in `home/cache/advisor-jobs/`.

## Phase 2 deliverables (checklist)

- [x] Default advisor + mmproj paths (gemma4-26b-a4b)
- [x] Borrowed llama-runtime note in config
- [x] Cursor scan + select/deselect + backfill (turn pairs from jsonl)
- [x] Spawn llama-server + warm slot (POST `/v1/advisor/start`, GGUF scan + KV/MoE flags)
- [ ] Post-turn summarize job after hook ingest
- [x] Backfill summarize queue drain (1 job, notes markdown — segmented 300-msg runs next)
- [ ] Advisor chat stream + raw toggle
- [x] Advisor chat stream + raw toggle (NDJSON `/v1/advisor/chat`, AdvisorPane, vault thread)
- [x] Day 0 bootstrap (`/v1/advisor/day0` → `notes/day-0.md` + greeting)
- [ ] Re-import / recover single thread via Advisor

## Day 0 (before first chat)

Advisor writes a **Day 0 journal** to vault (`notes/day-0.md`), then a short **hi**. Later: `day-1`, `day-2`, or dated — identity in notes + KV, not repeated persona dumps each turn.

## Backfill → summarize

Backfill **imports** turn pairs to vault (historical). Advisor reads **one pair per step**, summarizes each, may **`ask_user` / tools anytime** (not scripted pair counts). Tool consent + rollover hints: [PROJECT-KEEPER-ADVISOR-TOOLS.md](PROJECT-KEEPER-ADVISOR-TOOLS.md).

**Anikai llama location:** dev = `anikai-desktop/resources/llama-bin`; after Desktop Repair = `Desktop/Anikai/desktop-data/llama-runtime` or `runtimes/*`. Keeper auto-resolves.

**Dev reset:** `POST /v1/dev/reset-advisor` with `{ confirm: true }` or env `KEEPER_DEV_RESET=1`.

## Inference UI (Anikai parity — next slice)

- Real llama-server metrics: prefill, tok/s, out, window total
- KV: Q8 K, turbo4 V, RAM spill, 100% CUDA, MoE mmap auto
- Per-message context **rings**; **dim** bubble when that turn rolls out of KV (text stays in vault)

## IDE transcript scan

- **Cursor** + **Antigravity** (best-effort paths), sorted by **recent file mtime**
- Source **badges** in backfill list

Probe evidence → `PROJECT-KEEPER-PROBE-LOG.md`.
