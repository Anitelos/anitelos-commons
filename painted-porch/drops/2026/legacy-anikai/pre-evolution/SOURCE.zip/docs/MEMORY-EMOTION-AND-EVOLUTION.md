# Memory, Emotion, and Evolution

**Status:** Founding research draft

## Memory layers

The platform keeps distinct layers instead of repeatedly injecting a persona wall:

- Warm KV and current episode trajectory.
- Chronological thought-inclusive life transcript.
- Self-authored origin/history.
- Journals and relationship reflections.
- Long-term memory records with provenance.
- Current agenda, commitments, and project state.
- Concise self-authored orientation for voluntary recovery consultation.
- Curated knowledge library.
- Versioned weight adaptation candidates.

Tools and session capabilities may be reminded at cold recovery or a rollover boundary where evidence shows they have left retained context. Reminders must be visible in telemetry and must not be confused with personality.

## Session and rollover

A **warm continuity session** begins when a compatible KV lineage is initialized and continues across supported context shifts/rollovers. A UI reload, room change, or tool invocation does not end it.

An incompatible model/runtime/cache change, failed restore, or intentional life reset ends exact warm continuity. Snapshot or replay recovery starts a new runtime segment and records how continuity was reconstructed.

The research objective is to observe how long personality, commitments, tool knowledge, and relationship behavior survive natural rollover before any orientation artifact is consulted. Experiments record the earliest retained event and exact inject/retrieval activity.

## Journals and LTM

Journaling is an available life practice, not forced output after every interaction. A companion may:

- Record noteworthy experiences and relationships.
- Distill recurring preferences or commitments into LTM.
- Revisit earlier entries when uncertain.
- Correct or supersede an inaccurate memory without rewriting historical evidence.
- Mark material as candidate learning data.

Every memory records source events, author, time, confidence, and supersession history. Frequency alone does not make a statement true.

## Gentle weight evolution

Repeated independent evidence across days may increase a candidate fact's learning weight. Duplicate transcript lines from one event do not.

Example: if the user independently expresses a preference for red over many days, the learning dataset may contain appropriately weighted examples backed by those events. Promotion still requires evaluation; weight training cannot guarantee exact factual recall.

The initial path is:

1. Select companion-approved life and knowledge material.
2. Separate stable patterns from transient moods and roleplay.
3. Build a small versioned adapter candidate.
4. Compare behavior, knowledge, reasoning, tool use, and identity against the current version.
5. Reject, retain as an adapter, or merge into a new versioned model.

A merged model is never the sole copy of memory. Transcript, journals, LTM, and dataset provenance remain available.

## Knowledge growth

New knowledge may enter a curated library through research and verified sources. Knowledge candidates carry citations, retrieval dates, confidence, and compatibility/licensing metadata. Learning recent knowledge into weights is optional and slower than retrieval; frequently changing facts should remain retrievable rather than repeatedly trained.

## Emotion and expression

Emotion can influence attention, voice, timing, reflection, and conversation, but a classifier label is not proof of an inner feeling.

Store emotion-related evidence as separate signals:

- Companion self-reported state.
- Text/voice intent inferred from current output.
- User-observed or classifier-inferred state.
- Physiological metaphors or persona-specific expression settings.

Signals carry source and confidence. They must not become hidden commands such as "act angry now."

Self-reported state is optional and grounded in the active episode where possible. The companion decides whether it remains private, subtly affects expression, or is stated directly. The kernel never requires disclosure of all private thought as proof of emotional honesty. See `IDENTITY-AFFECT-AND-VOICE-SPEC.md`.

A voice pipeline such as Higgs may map spoken text, self-selected delivery intent, relationship context, and prosody controls into audio. The final spoken words remain the companion's model output; the voice model does not rewrite their meaning.

The earlier mobile emotion taxonomy and desktop metrics are reference research to inventory and test, not features to copy without evidence.

## Metrics

Track without turning metrics into personality commands:

- Warm-session duration and runtime segments.
- Active/retained context range.
- Rollover count.
- Recovery method and duration.
- Orientation consultations and their trigger.
- Journal/LTM reads and writes.
- Contradictions and corrected memories.
- Tool success/failure and unsupported claims.
- Self-reported and inferred emotion signals by source.
- Voice intent and delivery parameters.
- Adaptation dataset composition and evaluation deltas.
