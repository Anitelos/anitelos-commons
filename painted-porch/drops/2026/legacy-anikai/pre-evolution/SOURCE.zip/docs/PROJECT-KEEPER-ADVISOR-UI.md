# Project Keeper — Advisor UI & Interaction Spec

**Status:** Founding draft  
**Parent:** [PROJECT-KEEPER-SPEC.md](PROJECT-KEEPER-SPEC.md)

This document defines the **Advisor chat surface**: raw stream fidelity, segmented rendering, dynamic options, voice (Higgs), and co-director identity—Tauri front-end consuming the Rust/Node sidecar inference bridge.

---

## Design goals

1. **Debug raw = truth** for model output (ANSI strip only on CLI mirror tab); UI parses but never discards source segments.
2. **Marker-native segments** where the family supports channels; preserve inline markup (`<p>`, `<li>`, lists, emphasis) in rendered reply—not stripped to plain text.
3. **Co-director**, not assistant: user-authored **identity notes** + optional **pulses** (Anikai desktop parity); passionate disagreement is in-bounds.
4. **Streaming blocks** for tools (grep/read/file preview) as results arrive.
5. **Model-designed questions** via `keeper_options`—not a fixed four-button cap.

---

## Shell: Tauri

- **Keeper v1:** Tauri 2 + web UI (Svelte or React—pick at Phase 1).
- **Sidecar:** llama-server + hook CLI + MCP (Node or Rust—Tauri commands invoke binary).
- **Future Evolution apps** may stay Electron where ecosystem reuse dominates; Keeper explicitly validates Tauri + GPU subprocess + file watchers.

---

## Identity & voice (Setup)

### Identity notes (replaces canned persona packs)

User maintains `projects/<id>/advisor-identity-notes.md` (and global default in config):

- Who the advisor **is** (user-written; not a stock “assistant” persona).
- Relationship frame: **building with you**, not **for** you—co-director / co-founder energy.
- Permission to argue, push back, get heated; not discouraged from relationship depth.
- **Performance rule:** *Be* the notes—feel and speak from them; do not meta “think like the character.” Imperfection is fine. Purpose: avoid generic model voice; this life is **continuous** (KV + vault), remembering as far as context and retrieval allow.

Optional fields in Setup (stored in config, not injected as roleplay commands every turn):

| Field | Purpose |
|-------|---------|
| `pulseIds[]` | Same id set as Anikai desktop characteristic pulses—light bias/spin on project tone |
| `voiceGender` | `male \| female \| neutral` — preset/cloning hint for TTS, not a personality stereotype block |
| `anamCaraDrift`-style toggle | Allow gentle proactive check-ins when idle (see Session reminders) |

On **first KV init only**, seed a short orientation from identity notes + system capability digest. Steady turns rely on **warm KV**, not repeated persona walls ([INJECT-RULES](../../anikai-desktop/docs/INJECT-RULES.md) bare-steady analogy).

### Higgs voice (optional)

Setup → **Voice**:

1. Stage/download Higgs pack + engine (`stage-higgs-voice` parity with desktop).
2. Readiness probe (server port, weights).
3. If no clone preset: force **clone wizard**—10–20s WAV via mic or **screen/tab audio capture** (desktop parity).
4. Reply stream: parse **inline Higgs tags** (`<|emotion:…|>`, `<|style:…|>`) — **color-coded** in UI like companion chat; TTS path strips/sends tags per `media-higgs-voice.js` behavior.
5. User toggle: voice on/off per session; text always retained.

---

## System awareness (initialize once per advisor session)

When llama-server slot becomes **continuous**, inject a **System digest** block (vault-cached hash; refresh on setting change):

- Keeper version, vault paths, active `projectId`(s), registered workspace roots.
- Model file hash, mmproj, context window, K/V types, spill mode, GPU/RAM **reservation vs live** when probed.
- Installed skills, media slots, Higgs readiness.
- OS, timezone, locale; disk free on vault drive.
- What the advisor **may** do (vault write, staging, read repo) vs **must not** (product repo writes, transcript overwrite).
- Available tools/guides (lean list); full `guide(id)` on demand.

Digest is **fact**, not persona. Identity notes remain separate.

---

## KV rollover (continuity, not reset)

When generation hits cap or context shifts:

1. **Checkpoint** partial segment to vault (`advisor-thread.jsonl` + optional KV snapshot file).
2. Re-inject **tool + consent digest** ([PROJECT-KEEPER-ADVISOR-TOOLS.md](PROJECT-KEEPER-ADVISOR-TOOLS.md#rollover-inject-tool-anti-hallucination)) — not full persona replay.
3. **Continue** in same session binding with resume inject: “continuing from checkpoint”—no fresh “Hello I am…”
4. Update **earliest retained turn** in UI footer; rolled material remains in vault on disk.
5. Advisor may call retrieval for facts older than KV retention.

Never conflate rollover with wiping transcript or identity.

---

## Session reminders & “nosy” progress

Parallels: `companion-idle-roam` **perception tick** + thread **catchUpSinceTs** ([COMPANION-INFERENCE-SPEC](../../anikai-desktop/docs/COMPANION-INFERENCE-SPEC.md)).

| Mechanism | Behavior |
|-----------|----------|
| `lastInferTs` | Updated each advisor generation |
| `catchUpSinceTs` | Cursor for vault/ledger/git delta since last infer |
| `perceptionTick` | Timer when user idle; advisor *may* (not must) ask about time gap or progress |
| `sessionReminderInject` | Optional lean chip: “N hours since last turn; M ledger lines; K open checkboxes stale” |

Advisor tools: `diff_since_last_infer`, `open_threads_stale`, `plan_checklist_status`.

Tone: forward, co-director—“we still haven’t…”—not nagging assistant.

---

## Raw output → chat segments

Parse stream into ordered **segments** (store raw + kind):

| Kind | UI | Style |
|------|-----|--------|
| `user` | User bubble | default |
| `thinking` | Collapsible / inline stream | italic, muted color |
| `afterthought` | Below main reply | italic, distinct accent (allow in behavior contract) |
| `reply` | Primary visible | preserve `<p>`, `<li>`, `<ul>`, `<ol>`, `<strong>`, etc. |
| `tool` | Tool card | monospace header + body |
| `tool:grep` / `tool:read` | **Live code block** | path, line range, syntax highlight; fills as chunks arrive |
| `media` | Image/audio/video preview | inline + lightbox |
| `file` | File preview card | open in OS / preview text |
| `diagram` | Mermaid mini + expand | link to Diagrams tab |
| `higgs-tag` | Inline colored spans | emotion/style tokens |
| `options` | Option strip | see below |

**Family parse:** Gemma A4B channel markers when present; fallback split without salvage demotion on live path (companion inference parity). **ThoughtSegmentTags**-style extraction for `<tool>`, `<choices>` / keeper options XML.

Chronicle tab may use simplified view; **Advisor tab** uses full segment fidelity.

---

## `keeper_options` — model-designed questions

Evolution of desktop `<choices>` ([chat-interactive-choices.js](../../anikai-desktop/shared/chat-interactive-choices.js)) without the 2–4 option cap.

### Emission

Advisor emits in **thought or reply** (configurable; default thought-only for options, reply may repeat short question):

```xml
<keeper_options question="Which approach for chat streaming?" limit="5" layout="thumbnails">
  <option id="1" title="Channel parse">
    <summary>Gemma channels + segment UI</summary>
    <body><p>…</p><ul><li>…</li></ul></body>
    <files>
      <file path="chat.js" lines="120-188" preview="ref:grep-abc"/>
    </files>
    <attach type="diagram" ref="diagrams/stream.mmd"/>
  </option>
  …
</keeper_options>
```

Or tool call: `keeper_options({ question, options: [...] })` with same schema.

### UI behavior

- **Thumbnail row:** one button per option; label = `title` or truncated `summary`; **no fixed max** (user/model `limit` attribute optional).
- **Eye / preview:** modal or drawer—scroll full `body`, file snippets, diagrams, code blocks; **Choose** commits selection; **Close** dismisses.
- **Multi-file per option:** stacked file cards with line ranges (option 1 = approach A files; option 2 = different files).
- **User counter-proposal:** footer field “Your option / question / pushback”—sends as user message linked to `optionsId`.
- **Numbered reply path:** model may write “1–3” in prose; buttons still map to ids 1–3.
- Optional **media** per option in preview (images, mermaid, generated logos).

Static UI chrome; **content** entirely model-authored.

---

## Attachments & vision sizing

- Chat accepts drag/drop: image, audio, video, files.
- **Vision ingest dimensions:** use **native width × height** when within runtime probe limits (e.g. 1920×1080 stays 1920×1080).
- When either dimension exceeds probe max (2K/4K presets in Setup):
  - **Policy A:** uniform scale to fit max edge (document scale factor in manifest).
  - **Policy B:** tile grid with overlap (user chooses default for “above 1080p”).
- Manifest records `originalWxH`, `deliveredWxH`, `tiles`, `policy`.
- Preview in chat uses delivered assets; lightbox can show original file path.

---

## Topics, ideas, progress (project nosiness)

Under each `projects/<id>/`:

```text
topics/
  chat-features.md      # idea doc, freeform + links to pairs
  networking-tools.md
progress/
  checklist.json          # checkbox items, sources: plan | topic | transcript | advisor
features/                 # optional stable ids for cross-linking
```

Advisor may **create/update topic docs** (append or structured sections)—never overwrite transcript.

**Progress tab** merges: plan task lists, topic checklists, open threads, advisor prompts. Checkbox state changes log to `progress/events.jsonl` with `pairId` / advisor turn id.

---

## Hook scope & project routing

**User-level** Cursor hooks (`~/.cursor/hooks.json`) → global `keeper enqueue`.

**Before chronicle** on each ingest:

1. Wake/start Tauri sidecar; wait until health OK or setup gate.
2. **Project router** (warm KV when available): inputs = `workspaceRoot`, hook payload snippet, recent queue tail → outputs `projectId` or **`pendingProject`** proposal.
3. If **new project** (no match above confidence threshold): emit **`project_confirm`** event to UI — do **not** write transcript until resolved.

### New project confirm dialog

| Field | Content |
|-------|---------|
| Title | “New project?” |
| Body | Router **reason** (e.g. “Topic looks like a new app idea: *networking tools* — no matching project under this workspace.”) |
| Suggested slug | `networking-tools` + display name |
| **Accept new project** | Creates `projects/<id>/`, then drains queued turn into that project |
| **Use existing** | Picker of known projects |
| **Defer** | Hold turn in queue until user chooses |

Reason text is **model- or heuristic-generated** but always shown verbatim for audit in `project.json` `createdReason`.

4. Append transcript under resolved project; run summarize job.

Same hook from another IDE talking about a **different app idea** can land in a **different project folder** without manual reconfig—router + **confirm** for new project.

---

## Chat rooms (external thread mapping)

Under each project:

```text
projects/<id>/rooms/
  <source>-<roomKey>/
    room.json          # program, title, workspaceRoot, externalIds
    transcript.jsonl   # append-only worker turns mapped here
    cursor.json        # lastSeenTranscriptOffset, lastSeenLine, matchHash
```

| Field | Purpose |
|-------|---------|
| `source` | `cursor \| antigravity \| android-studio \| anikai \| manual` |
| `roomKey` | Stable id from IDE (Cursor chat/composer id, AS tab, Anikai thread key) |
| `title` | Human label when available |

**Match verification before append:**

1. Compare `roomKey` + `source` + optional `workspaceRoot`.
2. If hook payload includes transcript snippet hash, match against last line hash chain.
3. On mismatch: **hold** + surface in UI (“wrong room?”) — never overwrite; append-only only after match OK.

Companion tools: `list_rooms`, `sync_ide_transcripts` (scan known dirs e.g. Cursor `agent-transcripts/`, compile since `cursor.json` offset), `append_room_turn`.

Hooks remain **fast path**; companion may **backfill** missed turns on perception tick or user ask.

---

## Companion mode (perception → drives → intent)

Port Anikai **`companion-drive-state.js`** pattern (deterministic ticks, no fake RNG sentience):

```text
perception (cheap facts: idle ms, stream active, unread rooms, last Higgs emotion)
  → drives (curiosity, socialPull, boredom, reachOut)
  → intent (ask_question | sync_transcripts | nudge_user | run_tool | wait)
```

- **Higgs tags** in advisor reply → `lastEmotion` → **emotion tilt** on drives (same `EMOTION_DRIVE_TILT` table).
- **Peer autonomy:** not a servant “main character” bot — co-director may reach out when `reachOut` crosses threshold (configurable), ask questions, run **keeper tools** (transcript sync, grep vault, npm skill in staging).
- **Anam Cara drift** toggle: gentle idle perception tick; optional solo message when drives + quiet hours allow (desktop parity).

Intents enqueue **companion-initiated** jobs (distinct from hook queue); UI shows intent chip + outcome in advisor thread.

---

## Shell: Tauri + Svelte

- **Keeper v1:** Tauri 2 + **Svelte** (reactive stores for token/segment streaming).

- Dark sleek base (squad panel DNA).
- Thinking / afterthought: italic + hue shift.
- Tools: bordered cards; grep/read: editor-like blocks.
- Higgs tags: semantic colors (emotion vs style).
- Options: compact thumbnails; preview modal readable at length.

---

## Phase mapping

| Phase | UI deliverable |
|-------|----------------|
| 1 | Tauri shell + Setup + empty Advisor layout |
| 2 | Segment parser (text only) + stream tab raw |
| 3 | Options preview + user counter-proposal |
| 4 | Tool/grep streaming blocks + attachments |
| 5 | Higgs tags + TTS |
| 6 | Identity notes + pulses + session reminders |
| 7 | Topics/progress checklists UI |
| 8 | Companion drives/intent + room sync tools + project confirm modal |

---

## Color & typography (direction)
