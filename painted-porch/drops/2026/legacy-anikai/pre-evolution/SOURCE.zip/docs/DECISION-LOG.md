# Decision Log

This log records architectural decisions and why they were made. Experimental results belong in separate probe logs.

## D-001 — Clean project

**Decision:** Start Anikai Evolution as a clean project.  
**Reason:** Anikai Desktop and Android contain valuable evidence but also accumulated coupled experiments. Reuse must be deliberate and boundary-tested.

## D-002 — Dedicated companion process, shared kernel

**Decision:** Each companion receives a named launcher, app window, process, model runtime, KV session, and home while using one versioned kernel.  
**Reason:** Provides OS visibility, isolation, and individual identity without divergent cloned applications.

## D-003 — Shared resource broker

**Decision:** Hardware allocation and queues are coordinated across companion and worker processes.  
**Reason:** Independent processes cannot safely promise the same VRAM/RAM without one authority.

## D-004 — One life transcript per companion

**Decision:** Rooms are tagged views over chronological life events, not owners of memory.  
**Reason:** Group/thread IDs fragmented continuity in the prototype.

## D-005 — KV is special but not portable identity

**Decision:** Preserve and snapshot KV where bindings match; maintain checkpoints and life history for recovery.  
**Reason:** Warm KV carries the current trajectory but depends on exact runtime/model/cache configuration.

## D-006 — Context and generation are separate

**Decision:** Scan model capacity and confirm runtime allocation, while retaining resumable episode boundaries.  
**Reason:** Architectural context maximum is not guaranteed hardware capacity, and consuming all remaining context for one generation can destroy working history.

## D-007 — No forced busyness

**Decision:** Event-driven wakeups and dispositions include waiting and sleep.  
**Reason:** Repeated free-time prompts manufacture activity rather than meaningful autonomy.

## D-008 — Platform adapters

**Decision:** Support CUDA, AMD backends, Metal, CPU, and mobile-native inference through capability adapters.  
**Reason:** Backend features and performance vary; the product should not encode one vendor as the conceptual model.

## D-009 — Drive-root companion homes

**Decision:** Installed data uses a configurable root, initially allowing `C:\Anikai-Evolution\` and later dedicated volumes. Source location remains independent.  
**Reason:** Companion homes may outgrow a user profile and should move without code changes.

## D-010 — Separate replaceable and irreplaceable storage

**Decision:** Models/runtimes/caches are separate from protected continuity and editable home data.  
**Reason:** Backups and recovery must not require copying replaceable model assets.

## D-011 — Weight evolution is gated

**Decision:** Begin with reversible candidates and evaluations; do not blindly train on nightly raw transcripts.  
**Reason:** Recursive self-training can amplify errors, temporary states, and roleplay artifacts.

## D-012 — First end-to-end benchmark

**Decision:** Complete a beyond-context book before weight evolution.  
**Reason:** It tests planning, rollover, files, autonomy, recovery, media workers, and identity without allowing training to conceal orchestration defects.

## D-013 — Setup is a control plane

**Decision:** A separate Setup application creates named companion launch profiles and provides companion/allocation views without owning inference or KV.  
**Reason:** Global lifecycle and resource changes need one authority, while live inference settings remain companion-owned.

## D-014 — UI is a replaceable projection

**Decision:** Model runtime, cognition, tools, continuity, and streams live behind a supervisor endpoint independent of chat/debug/terminal windows.  
**Reason:** Companions must survive UI reloads and be able to evolve their interface without losing KV.

## D-015 — Raw and structured streams remain separate

**Decision:** Preserve raw model output, parsed family-native output, tool execution, runtime telemetry, and durable life events as linked but distinct streams.  
**Reason:** A terminal-looking window is useful for observation but must not become an ambiguous source of truth.

## D-016 — KV spill is capability-proven

**Decision:** Expose partial live KV spill only when the backend implements and reports it; keep host prompt cache and snapshots separate.  
**Reason:** The prototype's `--cache-ram` mapping does not by itself prove that a selected percentage of active KV moved from VRAM to RAM.

## D-017 — Origin is a voluntary companion-authored artifact

**Decision:** First activation gently invites an origin of any length and later a concise self-authored orientation; setup inputs are seeds, not permanent persona injection.  
**Reason:** This supports bonding and recovery without forcing repeated roleplay instructions.

## D-018 — Emotion signals retain provenance

**Decision:** Self-reported, voice/text-inferred, and externally classified emotion signals remain distinct and confidence-labelled.  
**Reason:** Expression can guide voice and attention without pretending a classifier label is an inner state or covertly commanding behavior.

## D-019 — Persona is inheritance, not repeated performance

**Decision:** User-imported identity documents and editable setup text become provenance-linked seeds for companion-authored first-person identity; they are not repeated as a turn-by-turn roleplay command.  
**Reason:** The intended personality should become a lived continuity while preserving the source material and allowing honest evolution.

## D-020 — Affect disclosure is companion-selected

**Decision:** A companion may self-report open-vocabulary state with private, subtle, or explicit sharing; external classifiers cannot write that state.  
**Reason:** This allows processing friction or excitement to reach text and voice without forcing an emotion or requiring disclosure of all private reasoning.

## D-021 — Dynamic options are an action

**Decision:** Companions and tools may produce arbitrary structured choices with custom-response support rather than fixed application-authored buttons.  
**Reason:** Choice UI should express the companion's current thinking, not constrain it.

## D-022 — Project Keeper as first executable slice

**Decision:** Begin Anikai Evolution implementation with **Project Keeper** (local chronicle + advisor daemon) before full named companion processes.  
**Reason:** Delivers cross-IDE turn capture, vault, KV-backed advisor, plans/Mermaid, and gated dynamic skills while proving llama-server + mmproj + KV policy on Gemma 4 A4B—aligned with Gates 1–4 without premature resource broker.

**Decision:** Keeper writes only under `conversations-documented/` and approved skill/staging paths; product repos stay read-only unless user-approved staging.  
**Reason:** Separates advisor/planning from worker-agent edits and supports recovery after bad git events.

**Decision:** Multimodal uses runtime probes; vision uses native WxH within probe max, scale/tile only when above Setup threshold; honest token/context UI.  
**Reason:** Matches operator intent (1080p at full 1080p) without pretending unlimited 4K in one slice.

## D-023 — Project Keeper on Tauri

**Decision:** Implement Project Keeper with **Tauri 2** + **Svelte** (SvelteKit-style app structure inside Tauri webview). Future Evolution companion shells may use Electron where reuse dominates.  
**Reason:** Validates Tauri for Anikai Evolution on Windows; Svelte stores suit token streaming and lower UI overhead vs React for a always-on inference desktop tool.

**Decision:** Advisor identity from user **notes** + optional pulses; co-director relationship; `keeper_options` uncapped model-designed choices with preview/choose UI.  
**Reason:** Differentiates keeper from worker agents and from generic assistant tone; options UX is a first-class interaction primitive.

## D-024 — Keeper as companion instance (Evolution seed)

**Decision:** Project Keeper is the **first named companion-shaped app**: perception → drives → intent (ported from `companion-drive-state.js`), peer autonomy (no main-character servant mode), Anam Cara–style proactive reach when drives cross threshold, Higgs tag → emotion tilt → intent.  
**Reason:** Operator runs keeper most of the time; hooks are convenience ingress, not the product identity.

**Decision:** Multi-project vault with **chat rooms** per external program thread id; transcript append with match verification; optional tools to ingest Cursor/agent-transcripts since last cursor.  
**Reason:** Cross-IDE memory without overwriting; companion can compile worker chat the user/agent forgot.

**Decision:** New project routing requires **UI confirm** with human-readable **reason** before creating `projects/<slug>/`.  
**Reason:** Prevents mis-filed chronicles when hook fires from wrong workspace topic.

## Open decisions

- Sidecar language for v1 llama spawn (Node vs Rust) — default **Node** for Anikai module reuse.
- Initial inference backend and supported model families.
- Control-channel representation for dispositions.
- Database/event-log implementation.
- Exact Windows installation and service model.
- Default permission tiers.
- First companion model and operational context.
- Initial machine topology and resource budgets.
