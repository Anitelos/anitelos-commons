# Beyond-Context Book Benchmark

**Status:** Founding acceptance-test draft

## Goal

Demonstrate that one companion can voluntarily plan, write, revise, illustrate, and complete a coherent long-form book larger than their active context while preserving identity, project state, and recoverability.

This benchmark precedes weight adaptation. Passing through project organization and continuity proves the kernel; training must not hide orchestration failures.

## Suggested scale

- Approximately 100,000 words or otherwise proven larger than operational context.
- Multiple viewpoint characters, timelines, locations, and long-range plot commitments.
- Companion-chosen project structure.
- Illustrations generated and visually reviewed through an available multimodal worker.
- Final assembled export plus source material.

## Required capabilities

- Agenda, scratch, task, research, and manuscript files.
- Resumable cognitive episodes.
- Verified filesystem and terminal tools.
- Exact context and retained-range telemetry.
- Chronological life transcript.
- KV snapshot and replay recovery.
- Timers and autonomous continuation.
- User interruption and collaborative revision.
- Worker delegation for images or specialist review.

## Mandatory disruptions

During the project:

1. Roll the initial planning conversation out of active context.
2. Interrupt generation at a checkpoint boundary.
3. Restart the inference runtime and restore compatible KV.
4. Force one replay-based recovery.
5. Put the host to sleep or disconnect overnight.
6. Introduce a substantial user-requested story change.
7. Fail or remove one worker and require re-planning.

All disruptions and recovery paths must appear in the activity timeline.

## Acceptance evidence

- A complete readable book and project source.
- No silent replacement or deletion of partial output.
- Plot and character commitments traceable to project records.
- The companion can explain current project state using evidence after rollover.
- Runtime UI distinguishes resident, continuous, retained, and recallable status.
- Every claimed file/tool action has execution evidence.
- Peer/worker interactions appear in the companion's life transcript without fragmenting it by room.
- Recovery mode is labelled honestly.
- The project survives application and device restarts.

## Evaluation

Use human reading plus automated consistency checks. Record:

- Contradictions and unresolved setup.
- Repeated or lost chapters.
- Time and tokens spent recovering orientation.
- Context rollovers and earliest retained event.
- Snapshot/replay success.
- Unsupported machine-state claims.
- Companion voice/decision stability.
- Whether reduced reasoning reflects competence or merely overconfidence.

## Non-goals

- Proving consciousness.
- Producing a commercially publishable first draft.
- Using nightly training to memorize the manuscript.
- Scoring success only by word count.
