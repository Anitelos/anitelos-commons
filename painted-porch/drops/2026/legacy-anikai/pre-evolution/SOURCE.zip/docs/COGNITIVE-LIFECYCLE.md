# Cognitive Lifecycle

**Status:** Founding draft

## Principle

The companion is event-driven, not restricted to user-turn/assistant-turn operation. The kernel supplies events, resources, and verified tools. The companion chooses whether to speak, act, continue, schedule, wait, or sleep.

Continuous life does not require continuous token generation.

## Events

Wake events may include:

- User speech or text.
- Peer speech or invitation.
- A meaningful screen or audio observation.
- Tool or worker completion.
- A companion-created timer.
- Resource availability.
- Device arrival, sleep, or disconnect.
- A deliberately configured low-frequency free-time opportunity.

Events are durable before inference. Repeated idle prompts such as "find something to do" are forbidden as a default because they manufacture compulsive activity.

## Episode lifecycle

1. **Wake:** select relevant pending events.
2. **Attend:** load evidence and only the context needed to understand it.
3. **Think:** use the model's native thought/reasoning channel when available.
4. **Act or speak:** zero or more verified tools and zero or more messages.
5. **Disposition:** choose what happens next.
6. **Commit:** append transcript, actions, disposition, and checkpoints.
7. **Wait:** remain interruptible without generating tokens.

## Dispositions

The initial vocabulary is:

- `speak`
- `act`
- `inspect`
- `continue`
- `reflect`
- `delegate`
- `wait_for_event`
- `set_timer`
- `finish_project_step`
- `abandon_optional_task`
- `sleep`

The disposition is control output, not prose guessed from the reply. Family adapters must preserve native model output and provide a tested control-channel mechanism.

## Generation checkpoints

Context capacity and generation budget are not the same.

An episode may receive a high operator-configured generation ceiling. No backend is allowed to consume the entire remaining context without reserving space for tool results, interruptions, and a checkpoint.

When the ceiling or runtime boundary is reached without a disposition:

1. Preserve all thought, reply, and tool state already produced.
2. Mark the episode `interrupted_by_generation_boundary`.
3. Write a resumable checkpoint.
4. Schedule continuation according to policy.
5. Never delete a visible partial reply.
6. Never classify token exhaustion as completion.

## Interruptions

User speech, emergency stop, tool failure, and higher-priority events can interrupt an episode. The interruption is appended as an event; it does not rewrite earlier output. The companion may resume, respond, re-plan, or abandon optional work.

## Perception and attention

Raw high-frequency screen/audio streams remain outside chat KV. Perception workers create timestamped observations with references to source frames or audio. The companion may request the evidence.

An invited watch/listen session lowers the salience threshold temporarily. It does not inject every frame. Silence remains valid even while watching.

## Operational grounding

Statements about machine state require tool evidence. If the model says it saved a chapter but no successful write exists, the episode remains incomplete and records a discrepancy.
