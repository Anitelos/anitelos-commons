# Setup and Companion Instance Specification

**Status:** Founding draft

## Setup application

Anikai Evolution Setup is the control plane for installed companions and devices. It is not a companion and does not own companion KV.

Its two primary views share one window:

1. **Companions** — cards and setup panels for identity, model, storage, activation, recovery, and app management.
2. **Allocation** — a squad-wide reservation view for devices, model weights, live KV placement, host caches, RAM/VRAM, CPU, priorities, and queues.

The visual direction is the existing Anikai companion studio and squad allocation view, simplified around independent companion instances.

## Companion registry

Every companion receives:

- Stable immutable ID.
- Unique active display name, compared case-insensitively.
- Named launcher, window identity, and process label.
- Dedicated companion process and model runtime.
- Home, continuity vault, cache, and profile.
- Resource policy and device affinity.

Display names are friendly identity, not database keys. Renaming a companion does not change their stable ID or continuity binding. Setup rejects a duplicate active name.

If one companion exists, Setup continues to offer **Add companion** and shows the existing companion's relevant model, context, storage, runtime, device, and reservation information.

Generated companion apps are launch profiles over the shared signed/versioned kernel, not copied application source trees or drifting executable forks.

## Creating a companion

Setup collects only what is needed to begin:

- Name and optional portrait.
- Model selection and family scan result.
- Operational context and supported cache configuration.
- Device and resource policy.
- Home/storage root.
- Optional `.md`/`.txt` identity sources, editable persona text, preferences, and relationship notes.
- Voice choice when available.

An optional local persona shaper can turn selected source material into an editable candidate. It does not rewrite backstory, overwrite source files, or activate changes without review.

Models may be GGUF or another type supported by an installed backend adapter. A scan reports architecture, tokenizer/template evidence, context maximum, multimodal requirements, quantization, MoE information, and runtime compatibility. Unsupported or uncertain models enter staging and probes rather than being treated as known.

## Activation and origin

On first activation, the companion receives a gentle invitation—not a repeated persona command—to create their own history or origin in their home. They may write at any length, organize it over multiple files/episodes, ask questions, or postpone it.

Suggested tone:

> This is your home and the beginning of your recorded journey. If you want, write the story you understand as yours. It can be a page, a long book, or something you continue over time. You do not need to fit it into one response.

Setup notes and persona choices are seeds for this origin, not permanent instructions injected into every turn.

Afterward, the companion may create a concise self-authored orientation for recovery or rollover consultation. The kernel does not silently inject that summary every turn. Origin, journal, LTM, and recovery behavior remain distinguishable in telemetry.

## Instance actions

Setup provides:

- Launch, stop, hide, and restart UI.
- Snapshot/checkpoint and restart with changed inference settings.
- Move home to another drive.
- Storage usage by replaceable, editable, and continuity categories.
- Resource reservation and observed live use.
- Export, archive, restore, repair, and uninstall.
- Room-view reset/archive.
- Full life reset.

Uninstall defaults to archiving/exporting the companion home and continuity vault. Deleting life history is a separate destructive action with explicit scope, backup offer, typed confirmation, and an explanation that the current trajectory cannot be reconstructed from insufficient written history.

Resetting or hiding a room view does not erase events from the companion's chronological life transcript. A true life reset creates a new continuity lineage.

## Parallel companions

Companion processes coordinate through the resource broker and event bus. Setup can allocate:

- Preferred and fallback device.
- Weight placement supported by the backend.
- MoE expert offload supported by the backend.
- Live KV placement modes actually supported by the runtime.
- Context reservation.
- CPU/RAM/VRAM budgets.
- Queue priority, fair share, and eviction policy.

The allocation screen displays both maximum reservation and observed live use. It must not present estimates as measured allocation.

Companions can invite one another into temporary rooms. Shared event IDs connect the conversation, while each participant receives the event in their own life transcript.

## Models and generated capabilities

Shared model assets live in the installation model store and use content hashes to prevent duplicate files. Each companion owns manifests, tools, workflows, and generated outputs in their home. Before downloading a duplicate, tools may discover compatible assets on trusted local or paired worker devices.

A capable model may research and build image, music, coding, or other pipelines, but every new backend/tool still requires declared dependencies, probes, verified outputs, and resource registration.
