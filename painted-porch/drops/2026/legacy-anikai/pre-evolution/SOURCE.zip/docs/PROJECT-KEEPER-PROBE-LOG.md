# Project Keeper — probe log

Append-only record of probes (pass/fail + evidence). Spec: [PROJECT-KEEPER-SPEC.md](PROJECT-KEEPER-SPEC.md).

---

*(Earlier entries above.)*

### 2026-07-26 — Phase 2 slice (advisor server + Day 0)

**Shipped:** `llama-advisor.js` (borrowed runtime, GGUF context scan via desktop `gguf-metadata`, K q8 / V turbo4, `--cache-ram`, MoE flags, `-ngl 999`, `-np 1`); `/v1/advisor/start|stop`, live `/v1/inference/status`; Day 0 `/v1/advisor/day0`; summarize queue drain; UI scale uses transform (clips window); script roots via `/v1/discover/scripts`; Cursor+Antigravity badges + mtime sort.

**Manual probe:** Restart sidecar → Inference → **Start advisor server** (needs valid `llamaRuntimeDir` + GGUF) → **Write Day 0** → backfill + **Drain summarize queue (1)** → check `home/conversations/projects/advisor/notes/`.

**Not yet:** Native llama-server tool-calling in thought channel; per-message context rings + dim on rollover; run_script execution after consent.

### 2026-07-26 — Advisor chat chunk

**Shipped:** `/v1/advisor/chat` NDJSON stream, `/v1/advisor/history`, `AdvisorPane.svelte` (thought/reply/tool bubbles, consent banner, ask hold), Inbox pending questions, vault `advisor-thread.jsonl`.

**Manual probe:** Restart sidecar → Inference start server → Advisor send message → Raw transcript → trigger `{"tool":"ask_user",...}` in model output → Inbox/ banner.

### 2026-07-26 — Phase 1 scaffold

**Shipped:** `anikai-evolution/project-keeper/` Tauri 2 + Svelte template; Node sidecar (`18765`); vault append; project confirm API + Svelte banner; drive-state port; hook templates; D-024 spec updates.

**Manual probe:** `npm run sidecar` → Setup in UI → probe turn → accept new project → verify `conversations-documented/projects/*/transcript/*.jsonl`.

**Blocked on machine:** Rust not in PATH for `tauri dev` until [prerequisites](https://tauri.app/start/prerequisites/) installed.
