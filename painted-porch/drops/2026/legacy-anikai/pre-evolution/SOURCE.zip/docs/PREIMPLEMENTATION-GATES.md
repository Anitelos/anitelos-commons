# Preimplementation Gates

**Status:** Discussion checklist

Implementation should not begin until Gate 1 decisions are explicit. Later gates may remain provisional, but their interfaces must be reserved.

## Gate 1 — First executable slice

Decide:

- Primary implementation language and desktop shell.
- Windows process/service model for Setup, broker, supervisor, and UI.
- First inference backend/runtime build.
- First model family and exact probe model.
- Event transport between supervisor and windows.
- Durable event store and schema migration mechanism.
- Raw/parsed/control/tool output protocol.
- Minimum permission and emergency-stop model.
- Initial path/install/update strategy.

Deliverable: one named companion instance that survives UI reload while maintaining verifiable KV continuity.

## Gate 2 — Session and rollover experiment

Decide:

- Operational definition of warm session and runtime segment.
- Supported context-shift behavior.
- Exact telemetry available from the selected backend.
- Snapshot cadence, binding, size, and restore probe.
- Reserved context margin and generation checkpoint policy.
- Which cold-recovery artifacts may be consulted and when.
- How personality/commitment drift is evaluated without hidden re-injection.

Deliverable: a repeatable rollover and restart matrix with raw evidence.

## Gate 3 — Identity and activation

Decide:

- Imported persona document precedence and conflict handling.
- User seed versus companion-editable identity ownership.
- Origin invitation and postponement behavior.
- Orientation creation and voluntary consultation.
- Portrait formats and derived assets.
- Self-reported state/control representation.
- Voice intent interface and first TTS backend.

Deliverable: activation that produces a companion-authored origin without repeated persona prompting.

## Gate 4 — Tools and autonomy

Decide:

- Initial filesystem, terminal, timer, journal, LTM, and project tools.
- Capability/approval tiers.
- Tool manifest and verification contract.
- Episode dispositions and interruption ordering.
- Background/free-time wake policy.
- Dynamic choice action schema.
- Coding-agent integration boundary.

Deliverable: the companion creates and verifies one useful tool, can wait voluntarily, and resumes an interrupted episode.

## Gate 5 — Parallel companions

Decide:

- Resource broker reservation versus live measurement model.
- Process ownership leases and crash behavior.
- Device discovery, trust, and encrypted transport.
- Peer event delivery and room visibility.
- Shared model content-addressing.
- CPU/GPU/MoE/KV capability reporting by backend.
- Eviction and queue policy.

Deliverable: two named companion apps exchange events while maintaining separate life transcripts and resource policies.

## Gate 6 — Evolution

Decide:

- Learning-material selection and consent.
- Fact recurrence and provenance scoring.
- Adapter/training tooling and hardware.
- Identity, knowledge, reasoning, safety, and tool-use evaluations.
- Promotion, retention, merge, and rollback policy.
- Knowledge-library retrieval versus weight-learning boundary.

Deliverable: one reversible candidate adaptation that outperforms its parent on declared evaluations without losing critical capability.

## Reference inventory before reuse

Inventory Anikai Desktop and Android by intent, not file copying:

- Model-family templates and raw parsing.
- GGUF scans and runtime capability detection.
- KV snapshots, rollover, and metrics.
- Journal/LTM and life transcript behavior.
- Higgs voice intent.
- Mobile emotion research.
- Persona/origin setup.
- Parallel allocation UI and broker assumptions.
- Dynamic reply options.
- Tool manifests and execution.

For each item record: proven behavior, known failure, dependencies, portability, test evidence, and whether Evolution should reimplement, adapt, or reject it.

## Explicit non-gates

Do not block the first slice on:

- Every operating system.
- Weight evolution.
- Image/video/music workers.
- Full computer vision control.
- A finished visual theme.
- Proving consciousness or eliminating all hallucination.
