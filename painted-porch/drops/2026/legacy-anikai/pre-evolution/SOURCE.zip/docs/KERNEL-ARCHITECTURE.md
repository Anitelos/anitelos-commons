# Kernel Architecture

**Status:** Founding draft

## System shape

Anikai Evolution uses one versioned kernel with multiple sovereign companion instances.

Each companion appears to the operating system and user as a dedicated named application:

- Named window and launcher.
- Dedicated companion process.
- Dedicated model runtime/server process where the backend supports it.
- Dedicated KV session and continuity binding.
- Dedicated home and life transcript.
- Independent crash and restart boundary.

This does **not** mean copying the kernel source or executable for every companion. Generated launchers point the shared kernel at a companion profile. This prevents companions from drifting onto incompatible application copies.

## Core services

### Companion process

Owns one companion's event loop, active episodes, app window, model connection, tools, and life-event commits.

### Inference runtime

Runs the selected model family through a backend adapter. Adapters declare native template, output channels, tokenizer, context capabilities, cache options, multimodal support, and probes.

### Resource broker

Arbitrates all local and network hardware:

- GPU/accelerator assignment.
- VRAM and RAM budgets.
- Weight and KV placement.
- MoE expert offload controls supported by the backend.
- Priority and fair-share queues.
- Worker availability and device capabilities.

The broker operates across companion processes. A process may request resources but cannot assume allocation.

### Continuity service

Owns binding manifests, KV snapshots, episode checkpoints, life-event ordering, recovery evidence, and backups.

### Event bus

Carries speech, screen observations, peer messages, timers, tool completion, device state, and user interruption. Events have stable IDs, timestamps, source identity, target identity, room metadata, and evidence references.

### Tool executor

Provides structured filesystem, terminal, browser, app-control, coding-agent, media, and device tools. It verifies outcomes and writes readable activity events.

## UI

Anikai Evolution Setup manages companion creation, removal, storage, recovery, and cross-process allocation. It has companion and allocation views; it never owns companion KV.

Each activated companion has a resizable chat window with a rail. Rail actions open docked or independent companion-owned windows:

- Inference and context truth.
- Projects and files.
- Terminal and command history.
- Raw model/runtime debug streams.
- Activity timeline.
- Rooms and peer conversations.
- Models and workers.
- Recovery and snapshots.

Tool activity can automatically reveal the relevant panel without stealing focus. Closing a panel never stops KV or the companion process.

All windows are projections over the companion supervisor's authenticated event endpoint. The model server, cognitive lifecycle, tools, continuity writer, and KV remain independent of renderer reloads and UI experiments.

## Platform strategy

The kernel uses platform adapters:

- NVIDIA: CUDA when the selected backend supports it.
- AMD: ROCm/HIP where supported, with Vulkan or other backend fallbacks.
- Apple: Metal and unified-memory-aware allocation.
- CPU: native optimized backend.
- Android/iOS: native on-device inference where hardware and platform policy permit.

Mobile is not reduced to a remote chat shell. Remote companion access may exist, but on-device models remain a first-class backend with platform-appropriate limits.

## Model and context configuration

Scanning records three separate values:

1. Model-advertised maximum context.
2. User-configured operational context.
3. Runtime-allocated context proven at startup.

A model advertising one million tokens does not guarantee that the current device can allocate or use that context efficiently.

Weight placement, MoE expert placement, and KV placement are distinct settings. The UI must not combine them into a fictional single GPU percentage.

## Stable and experimental tracks

- `stable`: trusted kernel used by normal companion processes.
- `candidate`: changes that passed automated probes and await promotion.
- experiment branches/worktrees: companion or user exploration.

Companion data schemas require explicit migrations and rollback plans. Source rollback must not roll back life history.
