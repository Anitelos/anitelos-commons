# Project Keeper — Advisor tools & operator gates

**Status:** Draft (Phase 2+)  
**Parent:** [PROJECT-KEEPER-SPEC.md](PROJECT-KEEPER-SPEC.md), [PROJECT-KEEPER-ADVISOR-UI.md](PROJECT-KEEPER-ADVISOR-UI.md)

## Principles

1. **No scripted “ask at pair 10/20.”** Those were examples only. The advisor asks when something is interesting, confusing, or worth co-director input—including mid-thought (“wait… I should ask them”).
2. **Backfill = read + per-pair summary** — one turn pair per inference step by default (KV continuity across steps). Segment batching is an operator perf toggle only.
3. **Tools are real or gated** — filesystem/script/run proposals require consent unless pre-approved. **`ask_user`** is always available and does not need pre-approval.
4. **Rollover re-injects the tool digest** — after context shift, replay lean tool rules + consent state to reduce tool hallucination (same spirit as Anikai inject on compress/rollover, not persona nagging).

---

## Tool catalog (v1)

| Tool | Consent | Pause inference | Notes |
|------|---------|-----------------|-------|
| `ask_user` | Never | **Yes** (hold job until answer or timeout) | Questions, “check this with me”, mid-thought curiosity |
| `read_vault_note` | Never | No | Paths under vault only |
| `list_script_roots` | Never | No | On-demand npm scripts from registered roots |
| `propose_tool` | First use per **activity class** | Optional | “I want ability X” — UI + vault manifest |
| `run_script` | First use per script id / class | Yes while running | Staging/sidecar only; never product repo write |
| `run_shell` | First use per **activity class** | Yes while running | Sandboxed cwd; evidence in vault |

**Activity class** = coarse bucket for “don’t ask again” (e.g. `run_script:stage-*`, `run_shell:read-only`, `propose_tool`). Normal **`ask_user` / chat** are not gated.

---

## `ask_user` (pause or carry on)

**Behavior:**

1. Advisor emits tool call (native or structured block) with `{ questions[], context, urgency? }`.
2. Sidecar sets job state **`waiting_operator`**, appends to `open-questions.jsonl` with `kind: ask_user_hold`.
3. UI shows banner / Inbox entry; inference **does not** spawn another job on the same slot until resolved or timed out.
4. **Operator replies** → answer injected as next user message; job resumes from checkpoint (warm KV when possible).
5. **No reply** → if `timeoutMs` elapsed (configurable; `0` = wait forever), sidecar marks hold **`expired_carry_on`**, injects short system note (“no answer; continue without assuming”), advisor continues.

Mid-thought: parser treats tool call inside reasoning channel like finishing a reply segment—thought may contain “wait…” then `ask_user`, then resume thought/reply after answer or timeout.

---

## Consent UI (first time per activity)

When a gated tool is invoked:

1. **Accept once** — allow this invocation only.
2. **Accept, don’t ask again** — persist consent for that activity class in `tool-consent.json`.
3. **Decline** — tool not run; advisor must **explain what it needed and why** (one short reply to operator, vault log).

On **decline**, optional follow-up: operator can grant later from Setup → Tool permissions.

---

## Backfill reading loop

For each historical pair:

1. Load pair + metadata (`historical`, `sourceTimestamp`, `threadFileMtime`).
2. Advisor **summarizes this pair** (user intent, agent delivery, ideas, drift vs now).
3. May call **`ask_user`**, **`read_vault_note`**, research tools anytime—not on a schedule.
4. Append `notes/backfill-pairs/<thread>-pair-<n>.md` and optional line in pair index.

Historical rule (repeat on rollover): *file paths and counts in the transcript may be stale; use timestamps vs wall-clock now.*

---

## Rollover inject (tool anti-hallucination)

On KV rollover / compress boundary, inject **once** (not every turn):

- Tool catalog lean list + consent summary (“run_shell: denied”, “run_script:stages: always”).
- Link to `notes/backfill-policy.md` during backfill jobs.
- Reminder: **verified tools only** — do not claim runs/files without tool result events.

---

## Implementation map

| Piece | Location |
|-------|----------|
| Consent store | `sidecar/advisor-tools.js` → `tool-consent.json` |
| Ask holds | `pending-ask-user.jsonl` + `open-questions.jsonl` |
| Per-pair queue | `backfill-read-queue.jsonl` (1 pair per job default) |
| HTTP | `/v1/advisor/tools/*`, `/v1/advisor/ask-user/*` |
| UI | Advisor tab: consent card, ask banner, Inbox (Phase 2+) |

Probe evidence → [PROJECT-KEEPER-PROBE-LOG.md](PROJECT-KEEPER-PROBE-LOG.md).
