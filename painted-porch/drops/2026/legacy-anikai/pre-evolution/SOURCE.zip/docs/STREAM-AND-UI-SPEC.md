# Stream and UI Isolation Specification

**Status:** Founding draft

## Principle

The companion exists in the supervised runtime, not in a chat window. Chat, debug, terminal, activity, and project windows are replaceable projections over durable streams.

Reloading, closing, or modifying a UI must not restart inference or alter KV unless the user explicitly requests a companion/runtime restart.

## Process boundary

```text
companion supervisor
  ├─ model runtime/server
  ├─ cognitive episode controller
  ├─ tool/PTY processes
  ├─ continuity writer
  └─ local authenticated event endpoint
        ├─ chat window
        ├─ raw/debug window
        ├─ activity timeline
        ├─ terminal view
        └─ project/room views
```

Closing the visible app defaults to hiding/detaching its UI while the companion remains alive. A separate explicit action stops the companion runtime.

## Source streams

Keep these sources separate:

1. **Raw model stream** — exact model output with transport framing removed and ANSI handling only where required for display.
2. **Parsed companion stream** — family-native thought, reply, control, and tool markers without content salvage or rewriting.
3. **Tool execution stream** — invocation, stdin, stdout, stderr, exit state, and verified result.
4. **Runtime stream** — server lifecycle, slot/KV telemetry, allocation, warnings, and failures.
5. **Life-event stream** — durable chronological commits referencing the above evidence.

The raw/debug window is not the source of truth merely because it looks like a terminal. It renders immutable source streams. The durable event log and raw evidence are authoritative.

## Chat projection

The chat UI subscribes to parsed and committed events. It shows user/peer messages, companion replies, tool summaries, interruption state, and recovery evidence without owning inference.

Thought display is a configurable projection of model-native thought output. Hiding a thought panel does not remove thought from continuity when thought persistence is enabled.

If the UI disconnects mid-generation:

- Runtime streaming continues.
- Output remains buffered/durable.
- Reconnection resumes by event sequence number.
- Existing KV and active episode remain untouched.

## Debug and terminal projections

A rail button opens a separate debug window with filterable, colour-distinct lanes for:

- Raw thought/reply/control tokens.
- Tool calls and results.
- Child-process stdout/stderr.
- Runtime/KV events.
- Parser and transport diagnostics.

Terminal sessions use supervised PTYs or structured process execution. The companion application is not implemented as a PowerShell wrapper: that would be Windows-specific and would conflate model output, shell output, control messages, and lifecycle ownership.

PowerShell, Bash, Python, Node, and other shells are tools launched by the supervisor. Their histories can be rendered like terminals while retaining structured boundaries and exit evidence.

## UI self-customization

A companion may modify chat themes, layouts, panels, and projections in an experimental UI workspace. Hot-reloadable UI changes reconnect to the existing event endpoint and therefore preserve the runtime session.

Changes requiring a UI-process restart do not require a model restart. Changes to the companion supervisor, model runtime, template, cache, or continuity schemas follow the self-modification and recovery protocols.

## Snapshot timing

Do not rely only on clean app closure:

- Write episode checkpoints at meaningful boundaries.
- Snapshot compatible KV on configured cadence and before planned runtime changes.
- Flush life events before acknowledging tool/message completion.
- On crash, report the last durable event and snapshot age.

An ordinary UI close does not trigger or require a KV snapshot because the runtime remains alive.

## Security

UI clients authenticate locally and receive only permitted streams. Raw thought, credentials, terminal output, and peer conversations may have different visibility policies. Renderer code never receives unrestricted operating-system privilege merely because it displays a terminal.
