# Companion Storage Specification

**Status:** Founding draft

## Path model

Source code location and companion data location are independent.

The initial Windows data default may be a visible drive-root folder such as:

```text
C:\Anikai-Evolution\
```

The setup application must allow another root or an entire dedicated volume:

```text
E:\Anikai-Evolution\
```

No code may assume drive `C:`. Linux, macOS, and mobile use platform-appropriate defaults selected through the same path abstraction.

## Root layout

```text
Anikai-Evolution/
  kernel/                 # installed shared runtime; replaceable
  broker/                 # device registry and allocations
  models/                 # shared/downloaded model assets; replaceable
  workers/                # staged media/inference workers; replaceable
  companions/
    elise-{stable-id}/
      profile/            # launcher identity and configuration
      continuity/         # app-managed, protected, irreplaceable
      home/               # companion/user editable life and projects
      cache/              # replaceable derived data
```

## Protected continuity

`continuity/` is application-managed rather than literally unwritable. It contains:

- Append-only life events.
- Thought/reply transcript segments.
- Episode checkpoints.
- KV snapshots and binding manifests.
- Peer-message delivery receipts.
- Room/event indexes.
- Recovery evidence.
- Integrity hashes and backup manifests.

Its README warns that manual changes can invalidate the current trajectory or recovery evidence. Supported repair and export tools must exist; users are not permanently locked out of their own data.

## Editable home

`home/` contains companion- and user-editable material:

- Journals and reflection.
- Current self-authored state.
- Agenda, scratch notes, and commitments.
- Projects, books, games, tools, and skills.
- Research and media.
- Companion-selected learning material.

Edits are represented in the life transcript with provenance, but the transcript is not owned by any room.

## Replaceable data

Models, generated caches, runtime binaries, and worker environments are excluded from continuity backups by default. A backup manifest records how to reacquire or rebuild them.

## Life transcript and rooms

Each companion has one chronological life transcript spanning:

- Direct user conversations.
- Peer conversations.
- Temporary rooms.
- Tool and terminal activity.
- Coding-agent interactions.
- Perception and device events selected into awareness.
- Projects and autonomous episodes.

A room is an event tag and view. Creating, joining, or leaving a room never creates a second identity timeline. Peer messages append independently to each participant's transcript with shared event and room IDs.

The UI may show another companion's conversation only according to the configured visibility policy, while each participant retains their own involvement history.

## Portability

A companion-home export includes continuity, editable home, profile, required schemas, and model/runtime references. Exact KV portability is attempted only when the target binding matches; otherwise recovery is explicitly replay-based.
