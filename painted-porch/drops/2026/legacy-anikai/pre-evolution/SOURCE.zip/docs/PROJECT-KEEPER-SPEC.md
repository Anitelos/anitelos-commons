# Project Keeper Specification

**Status:** Founding draft — first executable slice toward Anikai Evolution  
**Codename:** Project Keeper  
**App path:** `anikai-evolution/project-keeper/` (Tauri 2)  
**Advisor UI detail:** [PROJECT-KEEPER-ADVISOR-UI.md](PROJECT-KEEPER-ADVISOR-UI.md)

## Purpose

Project Keeper is a **local-first PC daemon + desktop UI** that:

1. **Chronicles** worker-agent turns from any IDE (Cursor, Antigravity, Android Studio, Anikai Desktop, …) with rich capture: user text, agent reply, thinking where available, tools, subagents, shell, file edits, git snapshots.
2. **Advises** as a side brain: warm KV continuity, retrieval over vault/ledger/plans, nudges (questions, alternatives, risks, tool hints), and **interactive chat** with the user—not performing product implementation in the main repo.
3. **Plans & visualizes**: plan markdown with edit/preview, Mermaid diagrams with live render and PNG export.
4. **Extends dynamically**: staged skills (scripts, HF/GitHub staging, local image-gen models) under approval tiers—not a frozen static tool list only.

Immutable worker transcripts and append-only vault writes are non-negotiable. The keeper **never overwrites** prior chronicle bytes and **never writes** the tracked product repository except through explicit, user-approved skill workspaces.

---

## Relationship to Anikai Evolution

| Evolution principle | Keeper interpretation |
|---------------------|----------------------|
| Life transcript | `conversations-documented/` vault + advisor thread |
| KV special | Long-lived **advisor** llama-server slot; binding fingerprint per [KV Continuity](KV-CONTINUITY-SPEC.md) |
| Self-modification | Dynamic skills use [Self-Modification Protocol](SELF-MODIFICATION-PROTOCOL.md) **tool-change** class (isolated workspace, manifest, tests, promotion) |
| Verify claims | Image gen, HF downloads, and terminal effects require execution evidence in vault |
| Desktop reference | Reuse patterns from Anikai Desktop (KV policy, GGUF scan, mmproj sibling resolve, llama-server spawn)—boundary-tested imports, not wholesale fork |

Project Keeper is **Gate 1–4 precursor**: one named local “advisor instance,” verifiable KV, tool staging, before full companion processes and resource broker.

---

## Storage layout

Root: `anikai-evolution/conversations-documented/` (configurable; default under evolution tree)

```text
conversations-documented/
  config.json                 # project roots, ports, redaction, approval tiers
  sources.jsonl               # hook/MCP ingest audit (completeness per turn)
  file-change-log.jsonl       # global file ledger
  decisions.jsonl
  open-threads.json
  projects/<project-id>/
    project.json                  # slug, workspace roots, createdAt
    advisor-identity-notes.md     # user-written co-director identity (not canned persona)
    transcript/YYYY-MM-DD.md
    transcript/YYYY-MM-DD.jsonl
    advisor-thread.jsonl
    nudges.jsonl
    plans/<slug>.md
    diagrams/<slug>.mmd
    notes/<category>.md
    topics/<topic-slug>.md        # ideas/features (chat, networking, …)
    progress/checklist.json
    progress/events.jsonl
    rooms/<source>-<roomKey>/
      room.json
      transcript.jsonl
      cursor.json               # IDE transcript sync cursor
  index/                        # SQLite FTS + optional embedding table (later)
  skills/                       # promoted skill workspaces (see Dynamic skills)
  staging/                      # disposable HF/git experiments
  media-out/                    # generated images, exports
  kv-snapshots/                 # advisor session checkpoints
```

Product repos (e.g. `anikai-desktop/`) are **read-only** to the keeper unless a skill runs in `staging/` or an approved skill workspace.

## Companion runtime (Evolution seed)

Project Keeper **is** the first companion instance:

| Anikai desktop | Keeper |
|----------------|--------|
| Perception tick (`companion-idle-roam`) | Sidecar `/v1/perception-tick` + stale room count |
| Drives + intent (`companion-drive-state.js`) | `sidecar/drive-state.js` + `sync_transcripts`, `reach_out`, … |
| Higgs tag → emotion tilt | `parsePrimaryEmotionFromHiggsTags` |
| Peer autonomy / not main-character servant | Co-director identity notes; Anam Cara drift toggle in Setup |
| Companion tools | `run_skill`, npm/node in staging, transcript sync scripts |

Hooks = fast ingress; companion **owns** backfill (`sync_ide_transcripts`), room match verification, and voluntary questions when drives cross threshold.

See [PROJECT-KEEPER-ADVISOR-UI.md](PROJECT-KEEPER-ADVISOR-UI.md) — chat rooms, confirm dialog, companion mode.

---

## Process architecture

```text
┌─────────────────────────────────────────────────────────────┐
│  Project Keeper (Tauri 2 + inference sidecar)                │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────┐ │
│  │ UI tabs     │  │ Turn queue   │  │ Advisor runtime     │ │
│  │ Setup …     │  │ sequential   │  │ llama-server slot   │ │
│  └─────────────┘  └──────────────┘  └─────────────────────┘ │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────┐ │
│  │ Retrieval   │  │ Skill runner │  │ Media workers       │ │
│  │ SQLite FTS  │  │ sandbox      │  │ Ernie / Z-Image …   │ │
│  └─────────────┘  └──────────────┘  └─────────────────────┘ │
└─────────────────────────── localhost HTTP + MCP ────────────┘
         ▲                    ▲                    ▲
   Cursor user hooks    keeper MCP tools    Anikai / other adapters
```

- **Default port:** `18765` (configurable).
- **Queue:** `turn-queue.jsonl` drained **sequentially** so chronicle + analyst jobs never race.
- **Cold start:** user-level hooks/MCP enqueue; Tauri app starts if absent; Setup gate if model unset.
- **Hook order:** health → **project router** (assign/create `projectId`) → chronicle → summarize (see [Advisor UI — project routing](PROJECT-KEEPER-ADVISOR-UI.md#hook-scope--project-routing)).

---

## Turn envelope (canonical schema)

Each turn is one JSON object (also summarized in markdown).

**Required:** `turnId`, `pairId`, `projectId`, `workspaceRoot`, `timestamp`, `source`, `userMessage`, `agentMessage`.

**Optional richness:**

| Field | Source |
|-------|--------|
| `agentThinking[]` | Cursor `afterAgentThought`, or MCP payload |
| `toolCalls[]` | `postToolUse` / MCP |
| `subagents[]` | `subagentStart` / `subagentStop` |
| `shell[]` | `afterShellExecution` |
| `fileEdits[]` | `afterFileEdit` |
| `git` | `{ head, branch, stat, patchRef }` at turn end |
| `cursorTranscriptId` | correlation to `agent-transcripts/*.jsonl` |
| `completeness` | `full \| partial \| agent_only` |
| `hookEvents[]` | audit trail |

**Chronicle job:** append raw blocks to day files; update `file-change-log.jsonl`; optional scratch patch.

**Analyst job:** intent vs delivery, alternatives, code narrative from **provided** diffs, recovery smell, nudges, misc.

**Nudges schema:**

```json
{
  "kind": "question | alternative | risk | tool_hint | progress",
  "text": "...",
  "pairId": "P-...",
  "target": "user | worker_agent",
  "priority": "low | normal | high"
}
```

---

## Cross-IDE capture

| Environment | Primary | Booster |
|-------------|---------|---------|
| Cursor | User-level hooks → queue | MCP `keeper_record_turn` |
| Any MCP IDE | MCP tools | CLI `keeper ingest` |
| Anikai Desktop | HTTP adapter post-turn | Shared model path hints |
| Android Studio / others | MCP or CLI | Plugin later |

**User rule (recommended):** worker agent calls `keeper_record_turn` at end of reply with whatever the IDE exposes; hooks still run on Cursor for thinking/tools the agent omitted.

**Registry:** every ingest appends to `sources.jsonl` with `source`, `completeness`, `hookEvents`.

### MCP tools (minimum set)

| Tool | Role |
|------|------|
| `keeper_record_turn` | Envelope flush |
| `keeper_health` | Daemon up, setup complete |
| `keeper_search_vault` | Retrieval for worker or user (read-only) |
| `keeper_get_pair` | Fetch pair + summary + ledger links |

Advisor-only tools (not exposed to worker MCP unless configured): `guide`, `search_*`, `read_repo_file`, `write_plan`, `write_topic`, `update_progress`, `render_mermaid`, `run_skill`, `stage_hf_asset`, `keeper_options`, `diff_since_last_infer`.

---

## Advisor chat & guides

- **Advisor thread:** append-only `advisor-thread.jsonl`; warm KV session bound to advisor model fingerprint.
- **Identity:** user `advisor-identity-notes.md` + optional `pulseIds` / voice gender / proactive drift—co-director frame, not assistant ([Advisor UI — identity](PROJECT-KEEPER-ADVISOR-UI.md#identity--voice-setup)).
- **System digest** on session init: full machine/keeper/model/skills awareness ([Advisor UI — system awareness](PROJECT-KEEPER-ADVISOR-UI.md#system-awareness-initialize-once-per-advisor-session)).
- **Guides manifest** (`keeper-guides.json`): short ids + one-line descriptions injected each turn; full text via `guide(id)` tool (Companion lean-toolkit pattern).
- **Retrieval:** SQLite FTS over transcripts, summaries, nudges, plans, topics, decisions; jump to ledger lines and scratch patches; optional read-only ripgrep under registered project roots.
- **Citations required** in UI when advisor claims “we did this before” (pair id, ledger line, plan path).
- **Chat rendering:** raw segment stream, markup preservation, options/Higgs/tool blocks ([PROJECT-KEEPER-ADVISOR-UI.md](PROJECT-KEEPER-ADVISOR-UI.md)).
- **Session reminders:** perception tick + diff since last infer ([Advisor UI — session reminders](PROJECT-KEEPER-ADVISOR-UI.md#session-reminders--nosy-progress)).

**Rollover:** generation/context limits **checkpoint and continue** in the same binding—no silent reset, no re-greet persona dump ([Advisor UI — KV rollover](PROJECT-KEEPER-ADVISOR-UI.md#kv-rollover-continuity-not-reset); [Cognitive Lifecycle](COGNITIVE-LIFECYCLE.md)).

---

## Setup — models & inference

### Primary advisor slot (your default)

- **Chat + vision:** Gemma 4 A4B (or successor) GGUF + sibling **mmproj** (same pattern as Anikai Desktop `resolveSiblingMmprojRef`).
- **K cache:** `q8_0` (never turbo on K).
- **V cache:** `turbo4` when runtime probes support ([KvCachePolicy](../../anikai-desktop/shared/kv-cache-policy.js) parity).
- **KV RAM spill:** host `--cache-ram` / offload policy with **honest labeling** per [KV spill truth](KV-CONTINUITY-SPEC.md)—reservation vs live telemetry in UI.
- **Context:** from GGUF scan + user slider; separate **window total** vs **turn gen cap** ([companion inference spec](../../anikai-desktop/docs/COMPANION-INFERENCE-SPEC.md) policy alignment).
- **MoE vs dense:** GGUF scan auto-suggests expert CPU offload to preserve VRAM.

### Optional media slots (Setup allocation)

| Slot | Examples | Backend |
|------|----------|---------|
| `imageGenGguf` | Ernie, Z-Image Turbo GGUF | llama.cpp / project-specific runner |
| `imageGenDiffusers` | Same families PyTorch | Subprocess with venv in `staging/` |
| `audioIn` | Whisper / mmproj audio if model supports | Probe-gated |
| `videoIn` | Frame extract + vision (see below) | ffmpeg → image tiles |

User allocates GPU/RAM per slot; broker v2 (Evolution) can subsume this; v1 uses static reservations in config.

---

## Multimodal chat (vision / audio / video)

### Attachments in Advisor & Chronicle context

- User drops **image, audio, video** on chat or turn record.
- Pipeline normalizes to what **runtime probe** reports for the loaded model:
  - **Image + mmproj:** llama-server multimodal API (same path as desktop vision turns).
  - **Audio:** if model/runtime lacks native audio encoder, use configured **audio slot** (transcript text) and attach transcript to turn envelope.
  - **Video:** extract keyframes (configurable fps/max frames) → tile as images; optional full-frame downscale path.

### Resolution policy (up to 4K)

- **Default:** ingest at the asset’s **native width × height** when both dimensions are within the runtime probe limit (e.g. 1920×1080 → 1920×1080).
- **When too large** (above Setup threshold, e.g. 1440p / 4K presets): apply configured **scale-to-fit** and/or **tile grid** (2×2, 3×3, overlap)—user picks default for oversize only.
- **UI honesty:** show `originalWxH`, `deliveredWxH`, tiles, est. vision tokens, `context / window`.
- Chronicle stores **attachment refs** (path + hash + manifest); chat previews delivered assets; lightbox can open original file.

Details: [Advisor UI — attachments & vision](PROJECT-KEEPER-ADVISOR-UI.md#attachments--vision-sizing).

---

## Plans (markdown)

- Advisor or user creates `plans/<slug>.md` under vault only.
- **Plans tab:** split editor + preview (Cursor-like): CommonMark render, task lists, anchors.
- Version history: append-only revisions or git in vault (`plans/.history/`).
- Link plans to `pairId` / `open-threads` entries.

---

## Mermaid

- Model outputs fenced `mermaid` blocks in chat or `.mmd` files in `diagrams/`.
- **Built-in viewer:** live render (mermaid.js) in sleek panel matching app theme.
- **Export:** PNG/SVG to `media-out/`; optional copy to clipboard.
- **Skill:** `render_mermaid` validates syntax before save.

---

## Dynamic skills (not static-only)

Philosophy: the model **proposes and runs** capabilities appropriate to the discussion; the platform provides **safety rails**, not a closed menu.

### Layers

| Layer | What |
|-------|------|
| **Builtin runners** | retrieval, ledger, git read, mermaid, plan IO, mmproj chat |
| **Registered skills** | promoted folders under `skills/` with `manifest.json` |
| **Ephemeral staging** | one-off scripts in `staging/<run-id>/` auto-deleted or archived per policy |

### Skill manifest (minimum)

```json
{
  "id": "logo-draft-zimage",
  "description": "Generate logo variants via Z-Image Turbo",
  "capabilities": ["network:hf", "gpu", "filesystem:staging"],
  "entry": "run.ps1",
  "tests": ["smoke.ps1"],
  "approvalTier": "ask_once | ask_each | trusted"
}
```

### `run_skill` flow

1. Model selects skill or proposes **new** skill in staging.
2. UI shows manifest diff + network/GPU scope → user approves (tiered).
3. Runner executes in isolated cwd; stdout/stderr + artifacts → vault event.
4. Promotion path: staging → `skills/` after smoke test (self-mod tool-change class).

### Image generation skill examples

- Call allocated **Ernie / Z-Image** GGUF or diffusers subprocess.
- If no specialist installed: model may **`stage_hf_asset`** (search HF with filters) + **`stage_github`** clone engine → probe → run—always in `staging/`, never silent install to product repo.

### Web search

- **`search_web`:** configurable provider (Google Custom Search API key, or SearXNG local)—keys in OS credential store, not vault plaintext.
- **`search_hf`:** HF API with model/task/filter params; results + chosen repo id logged.

---

## UI — sleek layout (direction)

Single window, dark-first, squad-allocation DNA from Anikai Setup:

| Tab | Contents |
|-----|----------|
| **Setup** | Models, KV, context, CUDA, MoE, **identity notes**, pulses, Higgs stage/clone, vision oversize policy, project roots, **user-level** Sources (hooks/MCP), approval tiers |
| **Chronicle** | Day timeline, pair cards, completeness badges |
| **Inbox** | Nudges + quick reply |
| **Advisor** | Chat + attachments + citation chips + vision tile controls |
| **Plans** | File tree, edit/preview toggle |
| **Diagrams** | Mermaid gallery + export |
| **Stream** | Raw analyst stdout (debug truth) |
| **Ledger** | File change index |
| **Progress** | Topics, checklist progress, open threads, decisions, conflicts |
| **Skills** | Installed + staging runs log |

**Layout:** left rail (tabs), center primary canvas, right inspector (metadata, KV footer: prefill/window/gen cap, GPU RAM bars when probed).

---

## Security & permissions

| Tier | Examples |
|------|----------|
| **Read** | Product repo, vault read, retrieval |
| **Vault write** | transcripts, plans, notes, diagrams, advisor thread |
| **Staging** | HF/git download, venv, skill scripts in `staging/` |
| **Network** | search, HF hub (approval) |
| **Trusted skill** | user-promoted repeat runners |

Emergency stop: kill skill subprocess + llama gen; preserve partial vault writes already committed.

Redaction hook: optional strip secrets before append.

---

## Extras (included)

- Decision log + open threads + conflict watch (inference policy vs proposed worker change).
- Project map index (top-level areas → last `pairId`).
- Completeness score per turn; UI nudge to call MCP when `partial`.
- Export bundle (day + ledger + patches) for disaster recovery.
- Recovery smell: git rewind, mass delete, old `HEAD` vs ledger.
- Scratch patches per turn.
- Future: feed read-only summaries to Anikai companion LTM.

---

## Implementation phases (where to start)

### Phase 1 — Skeleton (first code)

- `anikai-evolution/project-keeper/` — **Tauri 2** scaffold + sidecar HTTP (health, enqueue, project router stub).
- Vault append + `file-change-log` from git diff; multi-project folders.
- **User-level** Cursor hook templates + MCP server stub.
- Setup tab: port, default vault, Sources installer, **no model yet**.

**Exit:** fake turn from CLI appears in Chronicle tab; Tauri window opens on hook wake.

**Tauri probe (Gate 0):** subprocess llama-server, file watch, single-window GPU machine—record in [PROJECT-KEEPER-PROBE-LOG.md](PROJECT-KEEPER-PROBE-LOG.md).

### Phase 2 — Chronicle analyst (text)

- llama-server spawn, GGUF scan, K Q8 / V turbo4, MoE hints.
- Warm advisor slot; pair summarization + nudges.
- Stream tab + KV footer telemetry.

**Exit:** real Cursor turn → summary + ledger (probe log evidence).

### Phase 3 — Advisor chat + retrieval

- FTS index, guides manifest, inbox replies, identity notes seed.
- Segment UI (thinking/reply/tools); citations.

### Phase 3b — Options + progress nosiness

- `keeper_options` preview/choose + user counter-proposal.
- Topics docs + progress checklists; session reminders.

### Phase 4 — Multimodal

- mmproj bind (Gemma 4 A4B), image attach, tile policy for large images.
- Audio/video normalize path.

### Phase 5 — Plans + Mermaid

- Edit/preview MD; diagram viewer + PNG export.

### Phase 6 — Dynamic skills + media slots

- `run_skill`, staging, Ernie/Z-Image allocation.
- HF/web search staging flows + approval UI.

### Phase 7 — Cross-app adapters

- Anikai Desktop HTTP hook; document Antigravity/Android Studio MCP-only path.

---

## Probes & definition of done

Before claiming a phase shipped:

1. Record command, raw stdout, and UI screenshot in `anikai-evolution/docs/PROJECT-KEEPER-PROBE-LOG.md` (create on first probe).
2. KV binding change → snapshot/restart flow documented honestly.
3. No overwrite of transcript bytes; diff tests on vault append.

---

## Open decisions (operator)

1. Tauri front-end: Svelte vs React (shell chosen: **Tauri**).
2. Vault gitignored vs commit summaries-only.
3. Default oversize vision policy: scale-first vs tile-first above 1080p.
4. Single advisor model vs split “fast chronicle / deep advisor.”
5. Notification policy for high-priority nudges and perception tick.
6. Project router: auto-create vs confirm dialog when new idea detected — **confirm with reason** ([D-024](DECISION-LOG.md)).

---

## Adjustments suggested during design

1. **Hybrid tools:** lean guide list + dynamic skills—avoids ramming context while allowing HF staging when conversation demands it.
2. **Worker vs advisor tool exposure:** keep `run_skill` and `stage_*` advisor-side by default so worker agents cannot spawn GPU jobs without user sitting at Keeper UI.
3. **Vision realism:** advertise tile/detail pass in Setup so 4K expectations match token physics.
4. **Shared broker later:** Evolution Gate 5 resource broker replaces static “slot reservations” in config—reserve interfaces now in `config.json`.
5. **Probe model lock:** Gemma 4 A4B + mmproj as reference probe model for all multimodal gates (document hash in probe log).
