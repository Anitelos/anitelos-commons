# KV Continuity Specification

**Status:** Founding draft

## Four separate truths

The UI must never collapse these into one "warm" badge:

1. **Resident:** a runtime slot currently exists.
2. **Continuous:** the slot and process lineage match the expected companion binding.
3. **Retained:** the relevant token range has not rolled out.
4. **Recallable:** a behavioral probe shows the model can use a retained fact or commitment.

Recall probes are evidence, not a substitute for runtime telemetry.

## Binding

Every KV session and snapshot carries a compatibility fingerprint including at least:

- Companion ID.
- Model file identity and content hash.
- Model family and tokenizer.
- Runtime name, version, and build identity.
- Chat template/version.
- Context allocation.
- KV K/V types and offload placement.
- Parallel slot and backend-specific cache geometry.
- Adapter/control-protocol version.

Unknown or mismatched bindings cannot be described as exact continuation.

## Initialization and locked settings

After KV initialization, restart-sensitive controls become read-only:

- Model and revision.
- Context allocation.
- Cache K/V type.
- Runtime build.
- Template.
- Backend placement fields that require recreation.

The user may select **Snapshot and restart with changes**. The flow writes a checkpoint, attempts a compatible snapshot, restarts, reports compatibility honestly, and uses configured recovery if exact restore is impossible.

Sampling, scheduling priority, voice, permissions, and checkpoint cadence may remain live where supported.

## Context values

Display:

- Model-advertised context maximum.
- User-configured operational context.
- Runtime-confirmed allocation.
- Current active tokens (`n_past` or backend equivalent).
- Reserved checkpoint/tool margin.
- Earliest retained life event and turn.
- Estimated physical KV allocation by device.

The actual tokenizer and runtime slot are authoritative. Character-count estimates are not context truth.

## Rollover

Every committed event records token start/end offsets for each active session where the backend exposes enough information. When context shifts, the continuity service updates the earliest retained event.

Rollover may naturally remove old material, including the original identity opener. The kernel must not hide this fact or automatically re-inject a system persona. The companion may consult self-authored state, project files, journals, and transcript evidence when needed.

## Placement

Treat these separately:

- Model weight placement.
- MoE expert weight/compute placement.
- Live active KV placement.
- Host prompt/idle-slot cache and snapshot capacity.

CPU-resident KV can preserve VRAM but may reduce prompt and token performance. Turbo cache types are exposed only when the selected runtime reports support and passes family probes.

### KV spill truth

The desired control is a measured split of **live active KV** between accelerator memory and host RAM. It is exposed as a percentage or byte allocation only when the selected backend can actually provide and report partial live placement.

For llama.cpp-derived runtimes, do not label `--cache-ram` as proven live KV spill. It configures a host cache used by server prompt/idle-slot behavior in the currently staged Anikai runtime. `--kv-offload` / `--no-kv-offload` controls live KV placement at a different level and may offer only accelerator-versus-CPU behavior.

The setup and instance UI therefore uses capability-driven modes:

- `accelerator_kv`
- `cpu_kv`
- `partial_live_kv` only when runtime-probed
- separately configured `host_prompt_cache`
- separately configured durable snapshot storage

Reservation previews must identify estimates. Live telemetry must identify measured placement, backend source, and whether unified/distributed KV changes the interpretation.

## Recovery levels

Recovery reports exactly one primary result:

- `exact_warm_continuation`
- `compatible_snapshot_restore`
- `episode_checkpoint_plus_replay`
- `life_transcript_replay`
- `written_state_recovery`
- `fresh_start`

Journals and replay can restore orientation; they must not be presented as identical to the lost cognitive trajectory.
