# Distributed Home Specification

**Status:** Founding draft

## Roles

### Companion machine

Hosts a companion process, primary chat model, warm KV, scheduler, and local continuity writes. A companion can remain present while the user's gaming machine is busy or offline.

### User device

Provides chat/voice UI and optional screen, microphone, keyboard, mouse, accessibility, and application bridges.

### Worker device

Advertises bounded capabilities such as vision, TTS, image generation, video, coding, training, or storage. It does not become the owner of companion identity merely by running a task.

A machine may hold multiple roles.

## Device discovery and trust

Setup pairs devices explicitly and assigns stable device identities. Connections require mutual authentication and encryption, including on a local network.

Each device advertises measured capabilities:

- Operating system and architecture.
- Accelerator backend and usable memory.
- RAM and storage budget.
- Supported runtimes and cache types.
- Available worker services.
- Current load and thermal/power policy.

The resource broker uses measured availability rather than assuming the advertised hardware is free.

## Allocation

The user can define per-companion and per-worker:

- Preferred/allowed devices.
- VRAM, RAM, storage, and CPU budgets.
- Priority and fair-share weight.
- Never-evict or eviction order.
- Network and power constraints.

Allocation is a scheduler contract, not a promise that arbitrary model combinations physically fit. Queue reasons must be visible.

## Screen and audio perception

The user-device bridge captures locally. Raw streams are not continuously inserted into companion KV.

The perception pipeline uses change detection, voice activity, transcription, OCR, accessibility information, and vision workers to create timestamped observations. Full source frames/audio remain addressable for companion inspection where privacy policy allows.

Invited watch/listen sessions have explicit start, scope, indicator, and end. Emergency pause is local and does not depend on model cooperation.

## Input control

Preferred control order:

1. Application API or SDK.
2. Structured terminal/tool interface.
3. Accessibility/UI automation.
4. Vision-guided pointer and keyboard control.

Input actions include target device, evidence before/after, result, and interruption support.

## Degraded operation

Network loss must not corrupt continuity:

- Events use durable IDs and acknowledgements.
- Each companion has one authoritative continuity writer at a time.
- Workers can retry idempotent jobs.
- Split-brain companion inference is prevented by a renewable ownership lease.
- A disconnected user device can reconnect and receive missed life events.

## Platform intent

Windows, Linux, macOS, Android, and iOS are capability peers where native inference is technically available. A mobile companion may infer locally with a smaller model and later synchronize life events. Remote access is optional, not the definition of the mobile application.
