# CosyVoice runtime implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Current state (code)

- Engine catalog present under `ExpressiveEngineKind.COSYVOICE`.
- Runtime path implemented via `CosyVoiceRuntimePack`.
- Native adapter plumbing exists through `CosyVoiceNativeOnnxAdapter`.
- Warmup lock, diagnostics hinting, reference controls, and streaming path are present.

Primary references:

- `.../voice/catalog/ExpressiveVoiceCatalog.kt`
- `.../voice/provider_runtimes/VoiceProviderRuntime.kt` (`CosyVoiceRuntimePack`)
- `.../voice/provider_runtimes/local_runtime/CosyVoiceNativeOnnxAdapter.kt`
- `.../voice_subtabs/arrangement_subtab/content/CosyTuningArrangementTab.kt`

---

## Operational goals

1. convert current adapter bring-up into deterministic operational readiness,
2. ensure reference-audio controls map correctly to output behavior,
3. stabilize synth + streaming parity and lock/failure handling,
4. make diagnostics precise enough for fast field triage.

---

## Checklist

- [ ] Warmup lock behavior validated (retry windows and state reset correctness).
- [ ] Pack inspection coverage complete (missing assets, bad graph mixes, wrong profile).
- [ ] Reference/reprocess controls verified end-to-end.
- [ ] Streaming chunk synthesis and finalization path tested.
- [ ] Runtime error taxonomy documented (adapter init, synth fail, profile mismatch).

---

## Dependencies

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Umbrella: `../VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Mixed pipeline relation: `../../../pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial dedicated CosyVoice runtime plan split from umbrella voice doc. |
