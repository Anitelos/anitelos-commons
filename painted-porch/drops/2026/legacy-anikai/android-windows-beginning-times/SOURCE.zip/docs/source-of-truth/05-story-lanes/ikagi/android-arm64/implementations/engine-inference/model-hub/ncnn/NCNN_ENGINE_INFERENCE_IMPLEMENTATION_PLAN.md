# NCNN engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define NCNN as an ANIKAI engine-inference family for efficient mobile-native inference paths (especially CV/helper workloads), with explicit JNI/runtime integration requirements and lane ownership boundaries.

---

## Scope

This file covers NCNN for:

- native CV/helper inference tasks where NCNN is a fit,
- optional lightweight generation-assist/prepost transforms,
- Vulkan/CPU execution policy and capability manifesting,
- adapter integration into Swarm/task lanes.

This file does **not** replace:

- generation-quality contracts and creative targets in `generation/`,
- pipeline stage choreography in `pipelines/`,
- anti-drift backlog history in `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`.

---

## What NCNN is (in ANIKAI terms)

NCNN is a native inference runtime optimized for mobile performance and often used for vision-oriented tasks. In ANIKAI it should be treated as an explicit engine family with adapter contracts, not an implicit "native helper" bucket.

ANIKAI value:

- performant native helper execution for selected model classes,
- strong fit for perception and image-analysis assists,
- optional Vulkan acceleration path when device profile allows.

Rule: NCNN lane is real only when native assets + adapter + session + output contract succeed.

---

## Role model (single truth)

| NCNN lane | Ownership |
|-----------|-----------|
| **Companion primary text** | Not primary default role. |
| **Vision/helper specialists** | Core NCNN ownership candidate. |
| **Generation primary pixels** | Only if explicitly validated and documented per adapter (not assumed). |
| **Pipeline assist stages** | Allowed for preprocess/postprocess/helper inference stages. |

---

## Android implementation plan (JNI/native runtime)

### 1) Native packaging strategy

- decide NCNN artifact packaging pattern (bundled libs vs model-pack downloads),
- align ABI targets with app-native matrix,
- define Vulkan optionality and CPU fallback behavior.

### 2) JNI checklist

- [ ] Native target declared in CMake and included in Android build.
- [ ] JNI bridge API documented per task (input contract/output schema).
- [ ] Model/param asset validation path exists before run.
- [ ] Runtime lifecycle (init, reuse, close, cancel) is stable.
- [ ] Errors propagate to user-visible degraded states.

### 3) Capability manifest contract

Each NCNN row should include:

- adapter id + task family,
- expected model asset set and versioning rules,
- IO artifact schema (mask/boxes/keypoints/classification),
- execution policy (Vulkan preferred? CPU fallback?),
- lane eligibility and preset mapping.

---

## App integration map

### A) Engine registry and model hub

- register NCNN family with explicit badges in model hub,
- expose capability and host/runtime metadata in diagnostics.

### B) Swarm specialist integration

- bind NCNN adapters to specific specialist lane IDs,
- enforce explicit adapter resolution (no hidden substitution),
- keep fail states visible and categorized.

### C) Imaging and reflex helpers

- allow NCNN helper artifacts to feed pipeline/reflex layers where declared,
- keep ownership boundaries clear (helper inference vs final generative claims).

### D) UX/runtime transparency

- label output source runtime (`NCNN`) where results are consumed,
- log execution mode (Vulkan vs CPU fallback) for debugging and trust.

---

## Phased delivery

### Phase 0 - scaffolding

- define NCNN adapter schema and placeholder registry rows,
- add build and diagnostics scaffolding.

### Phase 1 - first helper lane

- deliver one operational NCNN helper from app asset input to output artifact.

### Phase 2 - acceleration + hardening

- stabilize Vulkan/CPU policy by device class,
- verify lifecycle and thermal behavior in repeated runs.

### Phase 3 - parity and expansion

- align controls and fail-state semantics with other engine families,
- expand task pack set with capability-pack discipline.

---

## Verification gates (before "operational" claim)

- one NCNN task runs successfully on target devices and writes valid artifacts,
- fallback mode behavior is deterministic and observable,
- Swarm lane uses shared adapter resolution path,
- no silent cloud/provider fallback for failed local NCNN claims.

---

## Open decisions

- first NCNN operational task target (segmentation vs landmark vs detection),
- minimum device class for Vulkan default,
- asset distribution strategy for NCNN model packs.

---

## Linked todos

- `todo/mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial NCNN engine inference implementation plan split from local media model-family mentions. |
