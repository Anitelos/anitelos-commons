# ONNX imaging post (desktop runner)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.onnx.imaging` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Desktop runner for upscale, rembg, depth, inpaint, DWPose — weights in models/onnx/.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

onnxruntime-node npm today; optional unify into pack.onnx later.

## Staging path

`npm onnxruntime-node + models/onnx/`

## Unlocks (no model weights)

onnx_upscale, onnx_bg_remove, onnx_portrait_depth, onnx_inpaint, onnx_pose_dwpose

## Verification smoke

One stack VERIFIED e.g. rembg or upscale.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
