# Kitten runtime implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

---

## Current state (code)

- Catalog lane exists under `ExpressiveEngineKind.KITTEN`.
- Curated model metadata is present in `ExpressiveVoiceCatalog`.
- Full synthesis/runtime parity is not yet confirmed as operational in the same way as Kokoro lane.

Primary references:

- `.../voice/catalog/ExpressiveVoiceCatalog.kt`
- `.../voice/provider_runtimes/VoiceProviderRuntime.kt`
- `.../voice/orchestration/VoiceOrchestrator.kt`

---

## Anikai-engine-first policy

- First target is ANIKAI-local runtime execution with honest diagnostics.
- If the lane cannot reach operational quality in current cycle, mark **Needs revisit** and shelve without blocking other lanes.
- Return later with explicit changelog and test matrix continuation.

---

## Operational goals

1. validate Kitten pack/runtime profile detection and readiness signaling,
2. verify end-to-end synth behavior through orchestrator and UI session states,
3. confirm pack asset requirements and missing-file diagnostics,
4. align lane naming and user-facing labels with actual executing stack.

---

## Checklist

- [ ] Pack contract validation (model/tokens/assets).
- [ ] Runtime readiness and fallback messaging.
- [ ] Synth quality and stability sweep.
- [ ] Voice session and streaming behavior validation (if supported).
- [ ] Final lane status decision: `Operational` or `Needs revisit`.

---

## Dependencies

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Umbrella: `../VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Mixed pipeline relation: `../../../pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial dedicated Kitten runtime plan with Anikai-engine-first + shelve/return policy. |
