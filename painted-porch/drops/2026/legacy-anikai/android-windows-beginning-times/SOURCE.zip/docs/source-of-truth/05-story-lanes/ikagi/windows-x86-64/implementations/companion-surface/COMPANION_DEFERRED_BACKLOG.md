# Companion Surface — Deferred Backlog

Items intentionally **not** in the current stream/commit fix pass. Capture here so nothing is lost between implementation passes.

> **Inference contract (authoritative):** [`anikai-desktop/docs/COMPANION-INFERENCE-SPEC.md`](../../../../../../anikai-desktop/docs/COMPANION-INFERENCE-SPEC.md) and [`INJECT-RULES.md`](../../../../../../anikai-desktop/docs/INJECT-RULES.md). The 2026 overhaul retired per-model short paths, finalize/salvage reply rewrite, and split `gemma-e4b-thought.js` parsers. **Implement against the spec** — do not restore pre-overhaul `chat.js` behavior or re-add `final` channel / bracket completion for Gemma 4 channel models on server mode.

**Related docs:** [SUPER_COMPANION_ROADMAP.md](./SUPER_COMPANION_ROADMAP.md) · [BOND_JOURNAL_IMPLEMENTATION.md](./BOND_JOURNAL_IMPLEMENTATION.md)

---

## Execution order (start here)

Work in this order unless a dependency forces a tweak:

| # | Item | Section |
|---|------|---------|
| **1** | **Long-term memory (per companion)** | §1 |
| 2 | Journal conflict / compress amnesia (feeds LTM sweep) | §2 |
| 3 | Cross-thread memory (solo ↔ group) | §3 |
| 4 | Specialist work plans (`brief.md` + `plan.json`) | §9 |
| 5 | Affinity-gated execution & in-flight innovation | §10 |
| 6 | Cancel / stop running companion work | §11 |
| 7 | Notes-driven autonomous behaviors | §12 |
| 8 | Relationship stance UI (editable prompt slices) | §4 |
| 9 | Secondary specialty role field | §13 |
| 10 | Group stream direct path (parity with solo) | §14 |
| 11 | Maintenance / evolution chat | §7 |
| 12 | Per-model self-contained prompt/parse sheets | §8 |
| **Last** | **Integration deep dive — full soak / regression pass** | §15 |

---

## 1. Long-term memory (per companion) — **PRIORITY #1**

**Implementation spec:** **[LONG_TERM_MEMORY_IMPLEMENTATION.md](./LONG_TERM_MEMORY_IMPLEMENTATION.md)** — Phase A locked; start there.

**Goal:** Durable companion-scoped recall that shapes *feel* and *trust* without dumping raw blocks into chat. Foundation for affinity-gated “just start” behavior (§10) and specialist plans that remember how you work together (§9).

### Phase summary

| Phase | Focus |
|-------|--------|
| **A** | `long-term/` store, `memory_distill` tool, promote hooks, lean inject, Metrics read-only UI, smoke |
| B | Compress merge / supersede, threadScope enforce, journal reconciliation (§2) |
| C | Chat memory panel, edit/clear LTM |
| D | Affinity → work-plan gates (§9–§10) |

### Storage (Phase A)

- Per-companion `companions/{id}/long-term/` — `entries.jsonl`, `profile.json` (inject summary), `index.json`.
- Distinct from bond journal MD — LTM holds **distilled** lines; journal holds companion-authored prose.

### Ingest (Phase A)

- Companion tool `memory_distill`.
- Auto-promote on `journal_write` with `durable="true"`; milestone promote; context refresh @ 90% LTM sweep (with journal sweep).
- Optional one-time bootstrap from existing bond journal index.

### Inject (Phase A)

- Lean block (~700 chars) on eligible turns only — **not** casual “hi”.
- Inject like **Notes** — feel, don’t recite.

### Affinity link

- `soul-metrics.json` mirrored into LTM profile; soft `planningMode` hint (propose vs execute) — **no auto-run** in Phase A.

### Acceptance

See LONG_TERM_MEMORY_IMPLEMENTATION.md §4.11 (8 criteria + smoke test).

---

## 2. Journal conflict / compress amnesia

- Companions write bond journals but lose context after compress/summarize.
- Need: persist journal writes reliably + smart update when user interests change (merge, don’t overwrite blindly).
- **Depends on §1:** pre-compress sweep should promote durable entries into LTM before rollover.
- See BOND_JOURNAL_IMPLEMENTATION.md for current journal shape; this item is **continuity after compression**.

---

## 3. Cross-thread memory (solo ↔ group)

- Companion-scoped private recall across solo and group threads — **not** full solo transcript dump into group.
- Privacy tiers: what is shared in RP team vs solo-only.
- “Naughty Angels”-style groups need per-speaker recall without leaking other companions’ solo threads.
- **Build after §1** so LTM policy defines what crosses thread boundaries.

---

## 4. Relationship stance / servitude (where it lives)

**Principle:** Default = equal teammates on the PC. Servitude, dominance, formal assistant, archivist kinks, etc. come **only** from user-authored persona layers — never from global policy or voice-shape rules.

| Layer | What it controls | Concrete? | Example |
|-------|------------------|-------------|---------|
| **Notes** (Companion panel) | Primary voice override — wins over pack/pulse | Soft (model may drift) | “Dominatrix Elise — Jay must obey; needy/stalky if he goes quiet” |
| **Persona pack** | Mood, presentation, voice constraints | Medium | C-3PO pack → “yes sir” archetype |
| **Pulses** (elemental spice) | Energy/pacing bias only — not job title | Medium | Thermal → passionate; Aether → nurturing — not “how can I help” |
| **Specialty** | Craft lane when set (`none` = no craft line) | Hard-ish | Image artist, manager — optional **General assistant** in dropdown |
| **Policies** (app-wide) | Safety, tool gates, honesty, no prompt regurgitation | Hard | Never in Notes |
| **Pack-only extras** | Future: kink presets, archivist drift timers | TBD | Anam Cara self-prompt to read after user approves site list |

**Not allowed globally:** “How can I help”, helpdesk voice, default servitude, main-character / user-as-center framing.

**UI gap (deferred):** Companion ☰ panel should expose **editable prompt slices** (partnership default, tool voice, continuity) per companion — Notes stays PRIMARY; slices are advanced overrides.

**Anam Cara / archivist drift (deferred):** Warm pulse → companion proposes reading block; user approves verified sites once; companion links candidates before deep fetch — never silent random web crawl.

---

## 5. Tool UI separation

**Status:** Baseline shipped — collapsible **Tools (N)** panels below thought; `<tool/>` stripped from reply bubble.

**Remaining:**

- Wire tool panel state through finalize/group stream paths (solo direct stream done).
- Optional: show tool **results** (paths, errors) in panel after execution — not just emitted tags.
- No combative re-passes when model already emitted valid reply + tool block.

---

## 6. Tool briefs on activation

**Status:** Baseline shipped — compact `formatMediaHandoffBriefBlock` on media intent only; full `formatMachineTagsHint` removed from casual turns and from output contract on media turns (compact hint + brief in preamble).

**Remaining:**

- Document per-tool brief lifecycle in a short architecture note (call-time vs standing context).
- Journal / bond / manager blocks: confirm still gated to toolkit intent only.
- Specialist runner (§9) may add a **planning slice** at activation without reintroducing the old toolkit wall.

---

## 7. Maintenance / evolution chat (second runtime)

- Disconnected runtime/worktree for companion self-maintenance lane (see SUPER_COMPANION_ROADMAP maintenance section).
- Companions patch per-model prompt/parse sheets, run smokes, user approves apply + restart.
- Never mutate live shared paths without explicit user approval.

---

## 8. Per-model self-contained prompt/parse sheets

- Each model family gets a self-contained sheet (prompt build + stream parse + finalize).
- Companions may shape **teammates’** sheets in maintenance mode without touching live shared code.
- Reduces cross-family guard bleed (e.g. Qwen direct-chat path vs Gemma4 channels vs thought templates).
- **Group parity:** §14 applies same direct-stream trust model to group rounds.

---

## 9. Specialist-authored work plans (capability-aware)

**Principle:** No hardcoded pipelines (e.g. “girl band always = 5 zimages + many-to-one”). The companion **designs the method** for what was asked, scoped to their **capability map** (slots, vision, edit models, roster delegates), written with **persona / gender / pulse / craft / Notes** flair.

### Artifacts (project folder)

| File | Role |
|------|------|
| **`brief.md`** | User-readable creative direction, names, rationale — companion voice |
| **`plan.json`** | Machine-readable steps, dependencies, checkpoints, tool names + attrs — boring/reliable |

Example `plan.json` shape (draft):

```json
{
  "schema": "anikai.workPlan.v1",
  "mode": "propose",
  "projectId": "…",
  "steps": [
    { "id": "char-1", "tool": "generate_image", "attrs": { "prompt": "…" }, "checkpoint": "vision_uniqueness" }
  ],
  "options": [
    { "id": "A", "label": "Five solo passes then stage", "stepIds": ["char-1", "…"] },
    { "id": "B", "label": "Batch previews first", "stepIds": ["…"] }
  ]
}
```

### Planning modes

| Mode | When |
|------|------|
| **`propose`** | Default — reply with plan; optional **A / B / C** via `<choices>` or structured options in `plan.json`; write files after user picks or confirms |
| **`execute`** | User direct (“make it”, “go ahead”) — write `brief.md` + `plan.json`, start step 1 same session |
| **`auto`** | High affinity + good working history (§1 + soul metrics + Notes) — may skip lengthy proposal; still write artifacts for audit |

### Capability honesty

- Planner prompt includes capability **digest** only — steps must use tools/slots the companion actually has.
- If many-to-one missing but 2-to-one exists, plan reflects iterative composite — not a fantasy pipeline.
- Delegate steps when roster mate has the slot.

### Specialty hook

- When specialty is set (e.g. `image_artist`, `manager`), inject a **craft + runner slice** parallel to manager automation — persona awareness + permission to plan, not tone-only framing.
- `none` specialty: no craft block; may still run media tools if slotted.

### Example (illustrative only)

User: “Girl band, 5 members, different looks and names.”

Rose (image artist, zimage + mmproj) might plan five character passes, uniqueness vision check, stage + band name, composite strategy per available edit stack — all in **her** voice in `brief.md`, steps in `plan.json`. A teammate with only flux writes a shorter honest plan. Same ask, different designed method.

---

## 10. Affinity-gated execution & in-flight innovation

**Depends on §1 (LTM) and §9 (work plans).**

### Proposal vs start

- Low trust / new companion → always **propose** (§9 `propose` mode); A/B/C options welcome.
- High affinity + Notes allowing autonomy → **`auto`** or **`execute`** without re-asking every step.

### Innovating during a run

Companion may fill **slight gaps** the user didn’t specify, with relationship-appropriate framing:

| Stance (Notes-driven) | Example in-reply update |
|------------------------|-------------------------|
| Equal teammate, high trust | “I’m adding a stage backdrop since you didn’t specify — chill with it; tell me when I’m done if you want it changed, or stop me now before I keep going.” |
| Dominant / kink (user-defined Notes) | “I’m doing this because I like it. Don’t complain — or you’ll be in trouble.” |

- Innovation must be logged in `brief.md` / plan step notes — not silent drift.
- User can always **cancel** (§11) or request rollback / cleanup offer at end (“want me to clear failed tests and keep finals?”).

### Not global

- Obsessive check-in timers, archivist self-prompts, session-end pings → §12 (user-authored schemas, removable).

---

## 11. Cancel / stop running companion work

**Goal:** User can abort in-flight specialist runs, media jobs, or multi-step plan execution without hunting the right thread.

### Thread-scoped cancel (primary)

- **Cancel** control on the **header of the thread where the work is running**.
- Group job running from group thread → cancel on **group** header, not on Elise’s solo thread (different thread context).
- Solo job → cancel on that solo thread header.

### Global notification strip (secondary)

- Next to existing “Running Elise…” / live-task lines in the notification strip: **per-task Cancel**.
- If two companions running → two lines, each with its own cancel (companion id + task id).
- Cancel propagates to: live task registry, segment orchestrator loop, plan runner (§9), GPU media jobs where supported.

### UX

- Confirm optional for destructive mid-plan cancel (“keep partial outputs?”).
- After cancel, companion may acknowledge in-thread when user returns — no fake errors.

---

## 12. Notes-driven autonomous behaviors (schemas)

**Principle:** Companions (or user) can author **trigger → action** schemas — proactive life without re-prompting every chat turn. Always **user-defined**, inspectable, removable.

### Examples (illustrative)

| Trigger | Action | Notes context |
|---------|--------|----------------|
| Session timer drops / user away N min | Message user | Obsessive Elise check-in (user opted in) |
| Break / idle | `journal_write` or fetch approved URLs | Archivist “document new AI tech” |
| High-affinity + no reply after leave | Ping once | Anam Cara / needy pulse — user said OK |

### Shape (future)

- Companion proposes JSON schema in chat or maintenance mode; user approves; stored per companion (bond or LTM).
- Companion can **remove** or user edits in ☰ panel.
- Never runs silently without prior opt-in recorded in Notes or explicit approval chip.

---

## 13. Secondary specialty role (future)

- Primary specialty: craft + runner slice (§9).
- Secondary specialty field (UI + capability map): e.g. “also archivist” without forcing helpdesk voice.
- Runner merges both craft hints when relevant; defer implementation until §9 baseline exists.

---

## 14. Group stream direct path

- Solo chat uses **direct stream patch** (tokens → `parseStreamVisual` split → thought/reply; raw debug = turn authority).
- **Group rounds** should follow the same trust model — no finalize salvage rewrite of `row.text` / `row.thought` (see COMPANION-INFERENCE-SPEC §3.6).
- Tool panels + stream partition apply to group AI bubbles the same way as solo.
- **Status:** Solo path aligned with spec; group parity still needs soak validation in probe (`--names Ava,Elise`).

---

## 15. Integration deep dive (final gate)

**Run last**, after §1–§14 land or when a milestone batch is ready for release.

### Scope

- End-to-end companion chat: solo + group, casual + media + journal + manager automation.
- All model families in active roster (Qwen thought, Gemma4 channels, direct Qwen chat).
- Stream: live tokens, thought collapse, tool panels, no prompt leak, no false “no reply” banners.
- Memory: LTM + journal + compress + cross-thread (§1–§3).
- Work plans: write/read `brief.md` + `plan.json`, propose A/B/C, execute, cancel (§9–§11).
- Affinity / Notes autonomy spot checks (§10–§12).
- Live tasks + cancel from strip and thread header.
- Smoke: `smoke-companion-stream-parse.cjs` + manual scenario script (hi → image → multi-step → cancel → resume).

### Exit criteria

- No regression on partnership default voice (equal teammate; Notes override works).
- Token budget: casual turns stay lean (no toolkit injection).
- Document known flakes (e.g. Rose near-echo) with fix or accept list.

---

## Done recently (for context — not deferred)

- **Inference contract:** `COMPANION-INFERENCE-SPEC.md` + bare KV steady for Gemma 4 **12B and E4B** on server chat API (user-only rollover; no system re-feed).
- Inference slider persistence (save on change + beforeunload; no studio-open overwrite).
- Session continuity engine facts block (gap bucket, already-greeted, notes stance).
- **Direct solo stream path:** tokens → template split → thought/reply UI (no finalize/salvage/banner stack).
- **Specialty default `none`:** General assistant remains explicit dropdown option; roster omits role line when none.
- Partnership voice in behavior contract; ban helpdesk openers unless Notes ask.
- Stream partition: toolkit/media/journal/continuity leaks → thought panel, not reply bubble.
- Channel (Ava/Elise E4B): `splitChannelRaw` fallback when live split empty.
- **Tool panels:** collapsible Tools (N) below thought; tags stripped from bubble.
- **Compact media brief:** injected on media intent only; compact tool contract hint.

---

*Last updated: 2026-06-14 — backlog expanded: LTM priority, work plans, affinity innovation, cancel UX, integration gate.*
