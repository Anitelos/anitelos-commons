# Reflex Bridge Packet Schema and Wake Thresholds

Status: Draft implementation companion  
Depends on: `REFLEX_BRIDGE_24_7_ROAMING_ARCHITECTURE.md`

## 1) Goal

Define concrete packet formats and default wake thresholds for the Reflex Bridge lane.

Reflex emits observations. Main AI reasons.

## 2) Packet Schema (v1)

```json
{
  "schemaVersion": 1,
  "source": "reflex_bridge",
  "eventType": "roam_precheck",
  "summary": "Battery entered saver profile and thermal is nominal.",
  "evidence": [
    "batterySaver=true",
    "thermalState=NORMAL",
    "charging=false",
    "timeWindow=night_roam"
  ],
  "candidateLocations": [],
  "confidence": 0.82,
  "knownGaps": [
    "no_recent_user_prompt_context",
    "filesystem_scan_not_run"
  ],
  "requiresMainReasoning": true,
  "issuedAt": 1763354012000
}
```

## 3) Event Types

- `roam_precheck`: preflight readiness snapshot
- `file_candidate`: potential path/asset hint
- `notif_digest`: compressed notification summary
- `thermal`: sustained thermal condition change
- `power`: charging/battery saver/risk transition
- `schedule`: timer/calendar-driven check-in

## 4) Field Semantics

- `summary`: one factual line, no directive language.
- `evidence`: short key/value style facts.
- `candidateLocations`: optional hints only.
- `confidence`: reflex certainty (`0.0..1.0`), never interpreted as truth.
- `knownGaps`: what reflex did not observe.
- `requiresMainReasoning`: always `true` by contract.

## 5) Forbidden Reflex Output

- No action commands (`do_x`, `must_run`).
- No policy toggles.
- No user-intent verdicts.
- No tool invocation directives.

If present, discard those fields before main-model handoff.

## 6) Default Wake Thresholds (v1)

Wake main AI only when at least one rule is met:

- `confidence >= 0.72` and `eventType in {file_candidate, roam_precheck}`
- Any `thermal` event with sustained state >= warning for 2 consecutive windows
- Any `power` event with risk transition (`battery < 12%` and not charging)
- `notif_digest` where high-priority count >= 2
- `schedule` events explicitly marked critical by user setting

Otherwise queue packet and continue reflex-only operation.

## 7) Queue Policy

- Keep bounded queue, default max 32 packets.
- Coalesce duplicate low-priority packets by `eventType + key evidence`.
- Preserve latest high-priority packet per type.
- Expire non-critical packets after 15 minutes.

## 8) Main AI Intake Rules

On wake:

1. Validate packet schema and sanitize forbidden fields.
2. Re-check live context (memory/journal/current workspace).
3. Treat `candidateLocations` as hints, not targets.
4. Ask user when ambiguity remains.
5. Log outcome back to reporter diagnostics.

## 9) Example Packets

### File Candidate

```json
{
  "schemaVersion": 1,
  "source": "reflex_bridge",
  "eventType": "file_candidate",
  "summary": "Potential voice pack change detected in assets/tts/xtts.",
  "evidence": [
    "path=Anikai App/src/main/assets/tts/xtts",
    "modifiedCount=4",
    "lastWriteMs=1763354710000"
  ],
  "candidateLocations": [
    "Anikai App/src/main/assets/tts/xtts",
    "Anikai App/src/main/java/com/anikai/soul/voice"
  ],
  "confidence": 0.76,
  "knownGaps": [
    "did_not_scan_peer_folders"
  ],
  "requiresMainReasoning": true,
  "issuedAt": 1763354725000
}
```

### Notification Digest

```json
{
  "schemaVersion": 1,
  "source": "reflex_bridge",
  "eventType": "notif_digest",
  "summary": "Two high-priority notifications arrived in the last 3 minutes.",
  "evidence": [
    "highPriorityCount=2",
    "channels=messages,calendar",
    "windowSec=180"
  ],
  "candidateLocations": [],
  "confidence": 0.8,
  "knownGaps": [
    "message_body_redacted"
  ],
  "requiresMainReasoning": true,
  "issuedAt": 1763354802000
}
```

## 10) Voice Preview Note

For Voice Studio preview, reflex may emit generated sample lines in a separate preview lane.
That preview generation must stay isolated from conversation reasoning and policy routing.
