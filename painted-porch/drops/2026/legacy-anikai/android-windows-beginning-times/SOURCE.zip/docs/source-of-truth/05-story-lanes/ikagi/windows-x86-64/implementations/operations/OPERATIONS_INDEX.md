# Windows x86-64 — operations index (docs ↔ todos)

| Field | Value |
|-------|-------|
| **Doc staging** | In progress |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-18 |

**Purpose:** one checklist that **bridges** stable implementation docs under `implementations/` and **scoped todos** under `todo/`, so multi-companion / group-chat work does not get lost across GGUF, companion surface, and inference policy changes.

**Rule:** each row links a **topic**, its **anchor doc(s)**, and an **active todo** if one exists.

**Recommended read order:** [`../companion-surface/DESKTOP_WORKSHOP_STATE.md`](../companion-surface/DESKTOP_WORKSHOP_STATE.md) (product map) → this index → active row for your goal → linked plan doc → code paths in that plan’s “Code today” section.

---

## Checklist (companion chat & mate network)

| Topic | Anchor doc(s) | Todo / bridge | Doc staging |
|--------|-----------------|---------------|-------------|
| **Group chat & mate network (parent)** | [`../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md`](../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md) | Started |
| **Thought / reply segment pipeline** | [`../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) | B1–B3 done; **C1** partial (`<complexity/>`); **E+** next | In progress |
| **Companion execution & agent (sandbox, agentic loop, team)** | [`../companion-surface/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](../companion-surface/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md) | [`../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md) — **P0+ not started** | Started |
| **Live conversation & engine modes** | [`../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) | (after B1–B3 + E+) | Started |
| **Desktop copilot (screen see / act)** | [`../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md) | J1–J4 after E+ and semi-duplex voice | Started |
| **Workforce & orchestration vision** | [`../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md`](../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md) (§18 order, §19 doc review) | **W2–W4 + W5a.0–2 done**; next W5a.4–6 | In progress |
| **Companion media library & vision memory** | [`../companion-surface/COMPANION_MEDIA_LIBRARY.md`](../companion-surface/COMPANION_MEDIA_LIBRARY.md) | M0–M4 done (image/audio/video ingest + preflight) | In progress |
| **GGUF text generation (solo chat today)** | [`../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) | In progress |
| **Companion text inference policy** | [`../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) §8 | `companion-text-inference.js`, Persona UI | In progress |
| **GGUF context length (chat `-c`)** | [`../generation/imaging/IMAGING_GENERATION_INDEX.md`](../generation/imaging/IMAGING_GENERATION_INDEX.md) + `gguf-metadata.js` | Probe on import + `model-runtime:get`; sync Persona context limit | In progress |
| **GGUF image / Media Magic** | [`../generation/imaging/IMAGING_GENERATION_INDEX.md`](../generation/imaging/IMAGING_GENERATION_INDEX.md) | [`../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md`](../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md) | In progress |
| **GGUF engine / session (E+)** | [`../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Group todo phase D; `llama-server` | Planned |
| **Prompt shaping (thought / teammate)** | [`../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md) + `gguf-prompt-shaper.js` | Group todo phase A–B | In progress |
| **Per-model runtime (GPU layers)** | [`../companion-surface/desktop-overlay-and-panels/`](../companion-surface/desktop-overlay-and-panels/) | Models panel; predict tokens on **companion** only | In progress |
| **Android role taxonomy (reference)** | [`../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`](../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md) | [`../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md) | Started |
| **Android handover / swap (reference)** | [`../../../android-arm64/implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`](../../../android-arm64/implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md) | (fold into group todo phase F) | Not started |
| **Desktop overlay / companions** | [`../companion-surface/desktop-overlay-and-panels/`](../companion-surface/desktop-overlay-and-panels/) | Group todo phase A | In progress |
| **Runtime packs & installer (bare app + optional inference)** | [`RUNTIME_PACKS_AND_INSTALLER.md`](RUNTIME_PACKS_AND_INSTALLER.md) | P0 doc; P1+ pack downloader | Started |
| **Desktop workshop state (index)** | [`../companion-surface/DESKTOP_WORKSHOP_STATE.md`](../companion-surface/DESKTOP_WORKSHOP_STATE.md) | Living map — update when catalogues/shell/lanes ship | In progress |
| **Engine capability platform (Windows)** | [`../engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md) | Tick VERIFIED smokes per family before pipeline ports | Started |
| **Pipeline ↔ engine matrix** | [`../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md) | Portrait / sprite / voice deps | Started |
| **Motion-sense engines (About registry)** | [`../../../../../anikai-desktop/assets/about-guide/motion-sentience-registry.json`](../../../../../anikai-desktop/assets/about-guide/motion-sentience-registry.json) | [`../../todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md`](../../todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md) | Started |
| **Magnet panels workspace** | [`../companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](../companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md) | [`../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md`](../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md) | Started |

Add rows when new implementation docs land under `companion-surface/`, `generation/text/`, `generation/imaging/`, or `operations/`.

---

## Narrative glue (why this index exists)

Solo companion chat (GGUF + thought stream + capability map) is **shipping in slices**. Group chat (“mate network”), per-companion **session roles**, **plan anchors**, and **multi-model residency** are a **second layer** on top of the same inference stack—not a separate product. This index keeps that dependency order visible: **engine + solo chat policies first**, **orchestration second**, **roaming/automation last**.

**Imaging (GGUF)** shares the same installer runtime (`dist:full` stages `sd.exe` + media-python) but is a **separate product lane**—see [`../generation/imaging/IMAGING_GENERATION_INDEX.md`](../generation/imaging/IMAGING_GENERATION_INDEX.md).

---

## Changelog (this index)

| Date | Note |
|------|------|
| 2026-05-15 | Initial index: group chat mate network parent plan + bridges to GGUF text/engine/companion surface todos. |
| 2026-05-17 | Rows for companion inference, GGUF context probe, Media Magic; B1–B3 done note; media library IPC landed; imaging index link. |
| 2026-05-17 | [`RUNTIME_PACKS_AND_INSTALLER.md`](RUNTIME_PACKS_AND_INSTALLER.md): bare app, GGUF/voice/engine pack catalog, Android parity. |
| 2026-05-18 | Runtime packs doc: endgame staging, python.media dedup, CPU/CUDA installer, mtmd-in-core, Device CUDA cautions. |
| 2026-05-18 | Group plan §7 + workforce §12: solo multi-chat parallelism (`maxParallelInferences` vs residents), compute federation; E+.3b/E+.5 slices. |
| 2026-05-18 | [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md): Jarvis-style screen capture, executor, one copilot per machine; J1–J4 after E+. |
| 2026-05-18 | Workforce §17: companion-orchestrated image handoff (W5a slices); replaces star-button-only as primary path. |
| 2026-05-18 | Workforce doc complete (vision): §18 build order, §19 doc review checklist. |
| 2026-05-20 | Execution-agent scope map: sandbox/security, agentic memory loop, team blackboard (Antigravity export). |
