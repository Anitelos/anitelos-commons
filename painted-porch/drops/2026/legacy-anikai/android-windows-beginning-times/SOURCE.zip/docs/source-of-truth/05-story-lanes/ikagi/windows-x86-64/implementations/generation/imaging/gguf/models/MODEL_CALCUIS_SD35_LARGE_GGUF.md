# Model sheet — SD 3.5 Large (calcuis GGUF)

| Field | Value |
|-------|-------|
| **Pack family** | `sd3_clip_stack` |
| **HF** | [calcuis/sd3.5-large-gguf](https://huggingface.co/calcuis/sd3.5-large-gguf) |

**Get pack (5 files):** one `sd3.5_large-*.gguf` + `diffusion_pytorch_model.safetensors` (pig VAE, pack root) + `clip_l.safetensors` + `clip_g.safetensors` + `t5xxl_fp8_e4m3fn.safetensors` in `models/sd35-large-calcuis/`.

Anikai passes **`--diffusion-model`** on the `.gguf` DiT and **`--vae`** on the pig file (same `diffusion_pytorch_model.safetensors` as the lite Get pack; lite stores it under `vae/`).

**Gated:** Stability AI community license on Hugging Face.
