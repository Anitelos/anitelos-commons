# Engine inference capability platform (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Android parent (same ideas, different EPs):** [`../../../android-arm64/implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../../android-arm64/implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

**Hub index:** [`model-hub/MODEL_HUB_INDEX.md`](model-hub/MODEL_HUB_INDEX.md)

**Pipeline ↔ engine matrix:** [`PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](PIPELINE_ENGINE_DEPENDENCY_MATRIX.md)

**Workshop map:** [`../companion-surface/DESKTOP_WORKSHOP_STATE.md`](../companion-surface/DESKTOP_WORKSHOP_STATE.md)

---

## One sentence

**Engines are inventory; pipelines are recipes; registries are the menu.** Windows should tick **engine readiness** first so portrait, sprite, voice, and user-built Playground graphs plug in without rediscovering “what runtime do I need?”

---

## Why engine-first is correct (and not opposite to “proof in the pudding”)

| Layer | What you tick | What users feel |
|-------|---------------|-----------------|
| **1 — Runtime family** | GGUF server, ORT session, FluidSynth, future FOMM pack… | “Engine installed / probed / VERIFIED” |
| **2 — Model pack** | Manifest row in About + on-disk files | “This depth.onnx is here” |
| **3 — Pipeline stage** | Portrait 4-shot, sprite NESW, rig test… | “Generate companion set” works |

`PortraitDepthOnnxRuntime.kt` is **layer 3** calling **layer 1** (ONNX Runtime via `NeuralFoundry`). It does not replace an engine plan — it assumes ORT + a file at `Profiles/portrait-onnx/depth.onnx`.

**Strategy you described is right:** expand engine hub + registry honesty on desktop **before** re-porting every Android pipeline screen. Once layer 1–2 are boring, Windows pipelines are mostly **UI + path conventions + stage wiring** (your “tweaking for showcase”).

**“Proof” still matters** — but proof for engines is a **smoke matrix** (one graph per family), not a full Suno clone. Pipeline proofs come after the engine row hits **VERIFIED**.

---

## North star: every engine, user pipelines

Long-term Anikai is a **local workshop** where:

1. **Any supported runtime family** can host packs (GGUF, ONNX, NCNN, … where platform makes sense).
2. **Capability probes** gate UI — no fake buttons.
3. **Playground / pipeline editor** composes stages: `{ engine, pack, task, inputs, outputs }` with provenance labels.

Android chases **device-native** stacks (QNN, LiteRT, FOMM-on-SNPE). Windows chases **desktop-native** stacks (GGUF + `llama-server`, ORT + DirectML, bundled CLI tools). Same **taxonomy**, different active rows — see hub index **Platform fit** column (to maintain in [`PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](PIPELINE_ENGINE_DEPENDENCY_MATRIX.md)).

**Do not** implement every stub family on Windows. **Do** document each family once and mark `active` | `stub` | `android-only` so registries stay honest.

---

## Readiness ladder (tick engines with this)

Same semantics as Android parent plan — every engine family should report:

| State | Meaning |
|-------|---------|
| `INSTALLED` | Runtime binary / ORT build present (`runtime-packs`) |
| `SUPPORTED` | EP / backend available on this machine |
| `LOADABLE` | Session or server starts with declared pack |
| `VERIFIED` | Minimal forward pass + output contract succeeded |
| `DEGRADED` | Fallback active, labeled |
| `UNAVAILABLE` | Visible reason |

**Registry + About** show **model** rows; **Settings → Check runtimes** and future **Engine hub** panel show **family** rows. Anikai Registry merges both when a pack is on disk.

**One smoke per family beats ten catalogue entries** without `VERIFIED`.

---

## Windows active engine roadmap (ordered)

| Priority | Family | Unlocks (pipelines) | Tick doc |
|----------|--------|---------------------|----------|
| **E0** | **GGUF** (`llama-server`, `sd.exe`, mtmd) | Chat, image txt2img, vision attach | [`model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| **E1** | **ONNX Runtime** (CPU + DML) | Depth overlay, x4 post, sprite post, many voice graphs | [`model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| **E2** | **Audio MIDI** (FluidSynth) | Lane 2 music | [`../generation/audio/MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md`](../generation/audio/MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md) |
| **E3** | **Voice runtimes** (Piper, Kokoro, … per pack) | Sentience → Voice, TTS | [`../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) |
| **E4** | **FOMM / motion ONNX** | Portrait rig test, sprite motion (Windows path TBD — may differ from QNN) | Android [`fomm/`](../../../android-arm64/implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| **E5** | **Python media sidecar** | Lane 4 neural audio, Diffusers imaging | imaging / audio generation indexes |
| **Later** | OpenCV DNN, NCNN, … | Niche graphs | stub until promoted |

---

## Desktop ONNX: not “imaging only”

ONNX on Windows must cover the same **breadth** Android uses, with desktop EP policy:

| ONNX use (examples) | Android pointer | Windows pack path pattern |
|---------------------|-----------------|---------------------------|
| Portrait depth overlay | `PortraitDepthOnnxRuntime.kt` | `%ANIKAI_HOME%/Profiles/portrait-onnx/depth.onnx` (parity path) |
| Sprite x4 / upscale post | Sprite pipeline DAG | `models/onnx/<pack>/` per manifest |
| Voice / vocoder graphs | Voice registry families | `runtime-packs` + `voice.onnx` probe |
| FOMM detector/generator | FOMM engine plan | TBD: ORT vs ported bundle (document before pipeline) |

**Implementation shape (mirror Android):**

- `main-process/onnx-runtime-adapter.js` — session, EP probe, tensor I/O, diagnostics string (like `PortraitDepthOnnxRuntime.diagnostic()`).
- Pipeline stages call adapter with **manifest row id**, not raw ORT APIs in UI code.

---

## Registries vs engine hub (avoid duplicate work)

| Artifact | Role |
|----------|------|
| `assets/about-guide/*-registry.json` | **Education + HF catalogue** — families, stacks, honest limits |
| `shared/anikai-registry-catalog.js` | **Unified table** — buckets, caps, on-disk merge |
| `engine-inference/model-hub/*` | **How to run** — probe, EP, session, VERIFIED smoke |
| `generation/*/models/` | **Product routing** — resolution, errors, lane labels |
| `pipelines/*` | **Stage DAG** — which engine ids, in what order |

When adding a model to About, **always** attach: `engineFamily`, `capabilityIds[]`, `runtimePackId` (if any). That prevents orphan catalogue rows.

---

## User-built pipelines (Playground) — dependency

Playground is not blocked on finishing portrait/sprite on Windows. It **is** blocked on:

1. Stable **stage contract** JSON (engine id, pack id, inputs, outputs) — workforce §11 interchange direction.
2. At least two **VERIFIED** engines (GGUF + ONNX) so graphs are real, not fake nodes.

Engine hub work **is** Playground foundation.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial Windows capability platform; engine-first strategy; ONNX breadth; readiness ladder. |
