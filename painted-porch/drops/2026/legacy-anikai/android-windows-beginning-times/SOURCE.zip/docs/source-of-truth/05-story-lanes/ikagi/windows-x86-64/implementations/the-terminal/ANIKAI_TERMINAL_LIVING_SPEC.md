# Anikai Terminal — living specification

| Field | Value |
|-------|-------|
| **Doc type** | Forever / living — append changelog rows; do not treat as frozen contract |
| **Status** | Planning + partial dev hooks (`dev:cluster-debug`, npm catalog) |
| **End-game** | In-app terminal with PowerShell (and other backends), tied to workshop + companions |
| **Not for v1** | Full PTY shell, auto-run companion commands without HITL |

**Contributing:** [`CONTRIBUTING_TO_THIS_FOLDER.md`](CONTRIBUTING_TO_THIS_FOLDER.md) · **npm scripts:** [`anikai-desktop/npm/`](../../../../../../../anikai-desktop/npm/)

---

## Why this exists

Anikai Desktop is an **AI workshop**: GGUF, ONNX, Python, diffusers, downloads, CUDA residency, multi-window shell, companions, familiars, project tree. Failures show up as subprocess exits, VRAM pressure, and layout glitches — not as one friendly error dialog.

We need:

1. **Logcat-style clarity** for humans (filters, pause, snippets — newbie-readable).
2. **No firehose into companions** while inference runs (VRAM + latency).
3. **A path to PowerShell / cmake / WSL** for power users — **sandboxed and opt-in**, not on the hot path.
4. **npm dev commands** discoverable in-app eventually (`npm run smoke-onnx-imaging`, etc.).

This document is the **single north star** for that work.

---

## Principles (non-negotiable)

| # | Principle |
|---|-----------|
| P1 | **Always capture** structured events in a main-process ring buffer (cheap). |
| P2 | **UI terminal is opt-in** — opened from chat ≡ menu (or dock later); paused buffer while reading. |
| P3 | **Companions / Overseer read snapshots**, not live streams, unless user explicitly attaches a snippet. |
| P4 | **Inference path stays clean** — no PowerShell spawn, no per-line LLM, while GGUF/CUDA is active. |
| P5 | **Line order:** time → hardware → inference → task → short message (detail collapsed). |
| P6 | **npm scripts** are catalogued in `anikai-desktop/npm/` with human + JSON registry for future **Run** buttons. |

---

## Names

| Name | Meaning |
|------|---------|
| **Workshop Log** | Structured event bus (`workshopLog.emit`) — always on |
| **Anikai Terminal** | User-facing panel: tail, filter, pause, copy, run catalogued npm tasks |
| **Overseer** | Future powerhouse spirit / familiar role: filters ERROR/WARN, reports to user or companion |
| **Dev mirror** | Optional copy of selected domains to OS terminal (`ANIKAI_CLUSTER_DEBUG`, `npm run dev:cluster-debug`) |

---

## Event line shape (Workshop Log)

```text
2026-05-22T14:03:01.120  INFO  hw.cuda       gpu=0 vram=12.4/16.0 GB
2026-05-22T14:03:01.450  INFO  infer.gguf    companion=c_abc job=inf_12 model=gemma-4-e4b nGpu=99
2026-05-22T14:03:02.001  WARN  task.pack     job=dl_9 stack=gguf.asr phase=download pct=42
2026-05-22T14:03:02.800  ERROR infer.onnx    job=img_3 op=dwpose exit=1
```

### Levels

`debug` · `info` · `warn` · `error` · `fatal`

### Domains (filter chips — plain English in UI)

| Domain id | UI label | Examples |
|-----------|----------|----------|
| `hw` | Hardware | CPU, CUDA device, VRAM, disk space |
| `hw.cuda` | GPU / CUDA | residency, OOM, device lost |
| `shell` | Windows & layout | dock/chat cluster, magnet z-order |
| `infer.gguf` | GGUF / llama | sd.exe, chat completion, argv, exit code |
| `infer.onnx` | ONNX | Media Magic, pose, inpaint |
| `infer.python` | Python engines | media-python, PersonaLive, diffusers |
| `io` | Files | project tree R/W, model import |
| `task.pack` | Downloads | HF packs, `pack-download` jobs |
| `task` | Jobs & queue | inference queue, pending turns |
| `companion` | Companions | thread id, detach, segment phase |
| `user` | You | explicit user actions (settings, run smoke) |
| `security` | Safety | guard blocks, sandbox denials |
| `npm` | Dev scripts | output from catalogued `npm run` (when run from Terminal) |

### Payload

Optional JSON `detail` per line (collapsed in UI). Never put full prompts or secrets in `message` — use `detail.promptRef` or omit.

---

## Architecture

```mermaid
flowchart TB
  subgraph always [Always — main process]
    Emit[workshopLog.emit]
    Ring[(ring buffer 2–5k)]
    Emit --> Ring
  end

  subgraph optional [Optional consumers]
    Dev[OS terminal mirror]
    Panel[Workshop Terminal UI]
    Overseer[Overseer snapshot API]
    Disk[(rotating workshop.log.jsonl)]
  end

  Ring --> Dev
  Ring --> Panel
  Ring --> Overseer
  Ring -.-> Disk

  subgraph later [End-game — HITL only]
    PS[PowerShell PTY]
    CMake[cmake backend]
    WSL[WSL / Ubuntu backend]
  end

  Panel --> PS
  Panel --> CMake
  Panel --> WSL
```

---

## UI placement

| Entry | Phase | Notes |
|-------|-------|-------|
| Chat header **≡ menu** → **Workshop Terminal** | **M1** | Primary home for pros; always near companion |
| Settings → Device → Software | M4 | Link + “Check runtimes” + live tail |
| Dock button | Later | Optional duplicate |
| Companion says “open terminal” | M2+ | Tool opens panel or attaches last ERROR snapshot |

**Code today:** `#chatHeaderMenuDropdown` in `chat.js` — **Workshop Terminal (soon)** menu item + hint dialog (M1 replaces with full panel).

---

## npm integration

All first-party scripts live under `anikai-desktop/scripts/` and are documented in:

- [`anikai-desktop/npm/README.md`](../../../../../../../anikai-desktop/npm/README.md) — human catalog  
- [`anikai-desktop/npm/scripts-registry.json`](../../../../../../../anikai-desktop/npm/scripts-registry.json) — future Terminal **Run** picker  

**Today (terminal / dev):**

| Command | Purpose |
|---------|---------|
| `npm run dev` | Electron + dev help banner |
| `npm run dev:cluster-debug` | Same + `[anikai-cluster]` shell layout logs |
| `npm run smoke-*` | Lane verification (ONNX, MIDI, music, …) |
| `npm run stage-*` | Bundle runtimes into `resources/` for installer |

**Future (in-app):** Terminal shows registry rows with **Run** → main spawns `npm run <id>` with `stdio` piped into `domain=npm` lines (user-initiated only).

---

## Overseer / companions

| Actor | Reads | When |
|-------|-------|------|
| **User** | Workshop Terminal UI | Debugging, filters, pause |
| **Reporter familiar** (planned) | Short summary of last N WARN/ERROR | Optional thought preamble |
| **Overseer** (future spirit) | `workshopLog.snapshot({ levels, domains, sinceMs })` | On interval or user ask |
| **Active companion turn** | **Never** full live tail | Only user-pinned snippet in message |

**Snapshot API (planned):**

```javascript
workshopLog.snapshot({
  sinceMs: 60_000,
  levels: ['warn', 'error'],
  domains: ['infer.gguf', 'hw.cuda'],
  maxLines: 80,
});
```

Returns frozen array — safe to paste into chat or send to small model.

---

## PowerShell & multi-backend shell (end-game)

**Not M0/M1.** Tied to execution-agent sandbox ([`COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md`](../anikai-agent-workflows/execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md)).

| Backend id | Use |
|------------|-----|
| `powershell` | Default on Windows — workshop automation, file ops with consent |
| `cmd` | Legacy / batch |
| `wsl` | Ubuntu-style userland |
| `cmake` | Configure/build native deps |
| `anikai-npm` | Wrapper around catalogued scripts only (safest) |

**Companion flow (end-game):**

1. Companion proposes command in chat (code block).
2. User **Run in Terminal** or **Edit then Run**.
3. Output streams to `domain=npm` or `domain=shell` — not into GGUF context unless user copies snippet.

---

## Phased delivery

| Phase | Deliverable | Shipped? |
|-------|-------------|----------|
| **M0** | `workshop-log.js` ring buffer + `emit()`; wire pack-download, gguf-completion, cluster debug → `shell` | Planned |
| **M1** | Chat ≡ → Workshop Terminal panel (filter, pause, copy, export snippet) | Planned |
| **M1b** | Terminal **Scripts** tab reads `scripts-registry.json`, Run with confirm | Planned |
| **M2** | `snapshot` IPC + Overseer / Reporter integration | Planned |
| **M3** | Rotating `workshop.log.jsonl` under `%ANIKAI_HOME%/logs/` | Planned |
| **M4** | Settings integration + hardware banner on open | Planned |
| **M5** | PowerShell PTY pane (HITL, cwd sandbox) | End-game |
| **M6** | Backend dropdown + companion suggest/run | End-game |

---

## Mapping: app function → log domain (inventory)

Use this when wiring `emit()` — extend via CONTRIBUTING.

| App area | Main-process / component | Domain |
|----------|---------------------------|--------|
| Chat turn / segments | `chat.js` + segment orchestrator | `companion`, `task` |
| GGUF chat | `gguf-completion.js` | `infer.gguf` |
| GGUF image / sd.exe | `gguf-completion.js` | `infer.gguf` |
| Model GPU residency | `model-residency.js` | `hw.cuda`, `task` |
| Pack download | `pack-download.js` | `task.pack` |
| ONNX imaging | smoke + Media Magic | `infer.onnx` |
| Python media | `media-python` subprocess | `infer.python` |
| PersonaLive | `personalive-rig.js` | `infer.python` |
| Project tree | workspace IPC | `io` |
| Dock / chat / tree layout | `main.js` cluster | `shell` |
| Magnet panels | `window-magnet-registry.js` | `shell` |
| Familiar guard | `familiar-guard.js` | `security` |
| Runtime probe | `sentience-runtime-probe.js` | `hw` |
| User settings save | settings IPC | `user` |

---

## Open questions (add answers in changelog)

| # | Question |
|---|----------|
| Q1 | Separate HWND for Terminal vs drawer inside chat? |
| Q2 | Max ring buffer size vs spill to disk? |
| Q3 | Should `npm run` from Terminal work when app is packaged (no node_modules)? |
| Q4 | Overseer as dedicated familiar vs Settings spirit slot? |

---

## Related docs

| Doc | Topic |
|-----|--------|
| [`WSL_TERMINAL_AND_STREAMING_PLAN.md`](WSL_TERMINAL_AND_STREAMING_PLAN.md) | WSL backend details, streaming model, pipeline-vs-raw terminal modes |
| [`DESKTOP_WORKSHOP_STATE.md`](../anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md) | Workshop layers index |
| [`FAMILIAR_ROLES.md`](../anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md) | Reporter role |
| [`RUNTIME_PACKS_AND_INSTALLER.md`](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) | Runtime packs |
| [`COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md`](../anikai-agent-workflows/execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md) | Shell HITL |

---

## Changelog (living)

| Date | Author | Change |
|------|--------|--------|
| 2026-05-28 | — | Added WSL-focused companion doc: `WSL_TERMINAL_AND_STREAMING_PLAN.md` (pipeline-vs-raw modes, normalized stream schema, WSL backend requirements) |
| 2026-05-22 | — | Initial living spec: Workshop Log, Terminal UI, npm catalog folder, chat ≡ entry, Overseer snapshots, PowerShell end-game |
| 2026-05-22 | — | Chat ≡ **Workshop Terminal (soon)** stub; `the-terminal/npm/` dev checks runbook + guardrails; `smoke-magnet-panels` in package.json |
| | | *Add rows above when scope changes — users and AI welcome.* |
