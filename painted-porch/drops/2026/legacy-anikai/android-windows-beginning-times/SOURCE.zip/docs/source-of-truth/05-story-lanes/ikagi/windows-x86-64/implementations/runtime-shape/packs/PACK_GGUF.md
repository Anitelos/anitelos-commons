# GGUF runtime pack (default)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.gguf` |
| **Tier** | shipped |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** llama.cpp binaries: chat, vision (mtmd), sd.exe imaging, music arranger JSON.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

resources/llama-bin via stage-runtimes / dist:full.

## Staging path

`resources/llama-bin`

## Unlocks (no model weights)

chat, vision-mmproj, image-gguf, music-arranger-json

## Verification smoke

llama-completion --version; sd.exe --help; mtmd smoke on attach.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
