# TODO — Windows text role orchestration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-09 |

---

## Source implementation docs

- `implementations/generation/text/TEXT_GENERATION_LANE_INDEX.md`
- `../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md` (role taxonomy T1–T5; shared intent)

---

## Intent

- Mirror Android’s **role-first** text strategy (T1 fast through T5 creative) on **Windows**: same role ids where possible so handover and documentation stay portable.
- Define how the **Electron** shell chooses fast vs deep lanes under memory and UX constraints (no thermal API parity required, but honest degradation).
- Keep **model swap** explicit when user changes companion or model slot from the companion panel.

---

## Checklist (working)

- [ ] Adopt T1–T5 role ids in desktop scheduler metadata (even if only T1 + T3 are implemented first).
- [ ] Document “fast default, deep on demand” policy for companion chat vs future pipeline steps.
- [ ] Align thread-activity / notification story with multi-companion UI (see desktop implementation code paths).
- [ ] When Android `ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN` evolves, port **policy-shaped** excerpts here if Windows needs the same packet schema.

---

## Linked operations

- `todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`
- `implementations/generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-09 | Created Windows text-role orchestration todo; parallels Android `TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md` at lane level. |
