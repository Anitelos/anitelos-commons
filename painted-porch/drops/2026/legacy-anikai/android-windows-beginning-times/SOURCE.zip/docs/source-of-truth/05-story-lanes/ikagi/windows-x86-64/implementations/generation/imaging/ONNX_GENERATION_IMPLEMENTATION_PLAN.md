# ONNX generation implementation plan (Android imaging)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define ONNX as a generation-outcome lane in ANIKAI imaging (not just runtime plumbing), including practical model-use recommendations, stage roles, and quality-gated rollout strategy.

---

## Scope

This file covers ONNX generation planning for:

- ONNX as primary generator where validated mobile exports exist,
- ONNX as mandatory post-pass lane for QUALITY uplift,
- ONNX role in Sprite Maker, portrait stills, and concept-to-pack flows,
- phased rollout from baseline output to showcase-grade outputs.

This file does **not** replace:

- ONNX runtime internals in engine-inference docs,
- FLUX generation planning,
- imaging pipeline stage authority contracts.

---

## What ONNX is useful for in ANIKAI generation

ONNX is ANIKAI's most practical cross-model generation lane when graph shape/opset constraints are known.

Recommended roles:

- **Primary generation (optional):** when a mobile-validated txt2img/img2img graph exists.
- **Post quality chain (core):** upscale/restore/detail passes after primary bytes.
- **Helper transforms:** segmentation/depth/palette assists where graph quality is stable.

ONNX should usually be considered the "reliable composable chain" lane.

---

## ONNX generation role split (single truth)

| Role | ONNX ownership |
|------|-----------------|
| **S1/S2 primary generation** | Allowed when a tested fixed-shape export is available for target device class. |
| **S3 sharpen/upscale** | Core ONNX responsibility for QUALITY stack. |
| **S4 palette/outline unify** | Common ONNX helper role (or CPU fallback with explicit label). |
| **S5/S6 pack + animation prep** | App pipeline ownership (ONNX optional helper only). |

Rule: ONNX lane claims require adapter + manifest + session pass + artifact validation.

---

## Example generation uses (app-facing)

### 1) Sprite Maker quality chain

- Primary: ONNX txt2img/img2img when export is validated, otherwise non-ONNX primary lane.
- Post: ONNX upscale/restore always considered for QUALITY.
- Output: facings with runtime trail metadata.

### 2) Portrait still quality lift

- Primary still source from best available lane.
- ONNX cleanup chain for edge/readability consistency.
- Output consumed by portrait pack contract.

### 3) Concept iteration pipeline

- Fast ONNX primary preview (when available) for quick iteration.
- QUALITY pass with stronger ONNX post stack before pack/export.

---

## Model example recommendations (starting set)

These are recommendation categories, not final locked model IDs:

- **Primary txt2img class exports** (fixed-shape mobile-friendly).
- **4x upscale/detail class** graphs for S3 quality lift.
- **Restoration/deartifact class** graphs for cleanup.
- **Segmentation/depth helper class** graphs for pre/post supports.

When selecting a candidate graph, record:

- opset compatibility,
- fixed input shape contract,
- precision constraints (fp16/fp32/int8),
- expected memory envelope by device class.

---

## Phased implementation plan

### Phase 0 - contract lock

- define ONNX generation profile matrix (`FAST`/`BALANCED`/`QUALITY`),
- finalize artifact metadata trail fields for ONNX runs,
- lock candidate graph short-list for primary and post roles.

### Phase 1 - ONNX generation baseline

- operationalize one ONNX generation path (primary or post-first depending on device realities),
- ensure deterministic output persistence and error labeling.

### Phase 2 - QUALITY stack

- chain at least one S3 graph and validate visual uplift,
- add optional S4 helper pass for game-ingest readability.

### Phase 3 - broaden graph catalog

- expand model families while preserving strict manifest/validation discipline,
- keep preset/device gates explicit and user-visible.

---

## Validation gates (before operational claim)

- one ONNX generation flow produces valid persisted output in-app,
- QUALITY chain runs deterministically on at least one supported device class,
- failures are visible and do not silently masquerade as success,
- outputs meet intended contract resolution and are judged against floor docs.

---

## Open decisions

- ONNX-first vs ONNX-post-first operational claim sequencing,
- minimum graph set required before labeling ONNX generation lane "operational",
- preset defaults per device class.

---

## Linked docs

- `implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`
- `implementations/generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`
- `implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`

---

## Linked todos

- `todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial ONNX generation implementation plan added as generation-side counterpart to engine-inference ONNX runtime plan. |
