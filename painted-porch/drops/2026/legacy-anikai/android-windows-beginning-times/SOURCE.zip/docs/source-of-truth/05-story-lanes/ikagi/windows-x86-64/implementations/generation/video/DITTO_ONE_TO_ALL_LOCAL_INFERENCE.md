# Ditto & One-to-All — local inference in Anikai

| Field | Value |
|-------|-------|
| **Status** | Staged runtime packs (same pattern as PersonaLive / Lance) |
| **UI** | Media Magic → **Video** → **Models** → **Ditto V2V** / **One-to-All** |

Weights download via **Get pack** in the app. **Code + Python venv** ship like other Anikai runtimes: stage once, then use **Import bundled runtime** on the lane gate (or `resources/*-runtime` in dev).

---

## Upcoming upstream staging (same PersonaLive / Ditto pattern)

When wiring inference runners, stage these repos next:

| Lane | Upstream repo | Notes |
|------|---------------|--------|
| **HoloCine** | [github.com/yihao-meng/HoloCine](https://github.com/yihao-meng/HoloCine) | Wan2.2 sidecars + HoloCine weights |
| **LingBot-World** | [github.com/robbyant/lingbot-world](https://github.com/robbyant/lingbot-world) | Camera-pose world model; torchrun today |
| **Hunyuan-GameCraft** | Tencent GameCraft upstream + HF weights | Keyboard/mouse camera control |

Planned scripts: `stage-holocine.cjs`, `stage-lingbot.cjs`, `stage-gamecraft.cjs` (or extend `stage-emerging-media.cjs`).

---

## Developer staging (same as other runtimes)

From `anikai-desktop/`:

```bash
npm run stage-ditto
npm run stage-one-to-all
# or both:
npm run stage-video-specialists
```

This will:

1. **Clone** the upstream repo into `resources/ditto-runtime/engine` or `resources/one-to-all-runtime/engine`
2. Create **`venv/`** and install dependencies (`pip install -e .` for Ditto; `requirements.txt` for One-to-All)
3. Write **`stage-ready.json`**

Optional: `set ANIKAI_STAGE_PYTHON=py -3.10` if the default `python` is not 3.10+.

**Not committed to git** — `engine/` and `venv/` are gitignored (like `personalive-runtime`).

**Installer:** `electron-builder` copies `resources/ditto-runtime` → `ditto-runtime/` and `one-to-all-runtime/` next to the app (`package.json` `extraResources`).

---

## End-user flow inside Anikai

1. **Maintainer / dev** runs `npm run stage-ditto` (and/or `stage-one-to-all`) on a build machine.
2. User installs Anikai **or** runs from source after staging.
3. **Media → Models → Ditto / One-to-All** — gate shows steps:
   - **Import bundled runtime** (copies staged tree into `%ANIKAI_HOME%/runtime-packs/ditto.runtime.win` etc.)
   - **Get model pack** (HF weights into `models/`)
4. Gate turns green → workspace → **Generate**.

Pack IDs: `ditto.runtime.win`, `one_to_all.runtime.win` (see `runtime-packs-registry.json`).

---

## Ditto / Editto

| Piece | Location |
|-------|----------|
| Runtime pack | `ditto-runtime/` (engine + venv) |
| VACE base | `models/ditto/Wan2.1-VACE-14B/` |
| Adapters | `models/ditto/Ditto_models/` |
| Inference | `engine/inference/infer_ditto.py` |

**UI:** source clip + editing instruction (V2V).

---

## One-to-All

| Piece | Location |
|-------|----------|
| Runtime pack | `one-to-all-runtime/` |
| Weights | `models/one-to-all/One-to-All-14b/` or `One-to-All-1.3b_2/` |
| Inference | `engine/video-generation/inference_14b.py` or `inference_1.3b.py` |

**UI:** reference still + driving motion video.

Upstream may still need path hooks (`ANIKAI_REF_IMAGE`, `ANIKAI_MOTION_VIDEO`, `ANIKAI_OUTPUT_MP4`) — see bridge `media-python/run_one_to_all.py`.

---

## Overrides (optional)

| Env | Purpose |
|-----|---------|
| `ANIKAI_DITTO_ROOT` | Engine folder instead of pack |
| `ANIKAI_DITTO_PYTHON` | Python exe instead of pack venv |
| `ANIKAI_ONE_TO_ALL_ROOT` | One-to-All repo root |
| `ANIKAI_ONE_TO_ALL_PYTHON` | Python exe |

---

## Code map

| Piece | Path |
|-------|------|
| Stage scripts | `scripts/stage-ditto.cjs`, `scripts/stage-one-to-all.cjs` |
| Runtime helpers | `main-process/ditto-runtime.js`, `one-to-all-runtime.js` |
| Runner | `main-process/media-specialist-upstream-video.js` |
| Bridges | `media-python/run_ditto_v2v.py`, `run_one_to_all.py` |
| Registry | `specialist-runtime-packs.js` → `PACK_BUNDLED` |
