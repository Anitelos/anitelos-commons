# ANIKAI 7-Day World-Readiness TODO

Status: **ACTIVE SPRINT**  
Owner: ANIKAI core build (solo + collab assist)  
Goal: ship a public-facing build that is readable, stable, and demo-worthy.

---

## Rules for this sprint

- Prioritize **readability + reliability + clear flow** over new depth features.
- Any change that increases confusion, duplicate lanes, or hidden ownership is out of scope.
- If a doc conflicts with live runtime behavior, runtime/spec wins and stale doc is deleted.
- Keep one source of truth for each domain:
  - `ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md` (runtime contract),
  - `docs/source-of-truth/**` (governance/catalog/roadmap/history).
- **Multimodal “show it works” honesty:** when Day 4 / Day 8 touch image, audio export, or sprite pipelines, reconcile copy and executor behavior with `LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md` so demos do not imply full on-device diffusion where the path is still provider or prep-only.

---

## Day 0 - Lock the narrative

- [ ] Lock user-facing naming:
  - [ ] Confirm `ANIKAI Console` (or final replacement).
  - [ ] Ensure no legacy "Settings Hub" naming leaks in primary UI text.
  - [ ] Lock voice lane naming contract:
    - [ ] `Voice Studio` = core ANIKAI companion voice authoring (studio + arrangement + emotion tabs).
    - [ ] `Voice Forge` (working title) = project/game voice-FX authoring lane in Creations.
    - [ ] Avoid `Voice FX` as primary route name if it collides with Studio terminology.
- [ ] Lock public story arc:
  - [ ] Week 1: ANIKAI presentability.
  - [ ] Week 2: game prototype polish.
  - [ ] Week 3: live co-build + pipeline-to-runtime showcase.

---

## Day 1 - Navigation and surface clarity

- [ ] Verify top-level routes are coherent:
  - [ ] `Home`
  - [ ] `Chat`
  - [ ] `ANIKAI Console` (control surface)
  - [ ] `Creations`
- [ ] Remove/redirect stale entry points:
  - [ ] No ghost links to removed hub surfaces.
  - [ ] No dead route labels in cards, dialogs, or hints.
- [ ] Validate one-click return loops:
  - [ ] Home -> Console -> Home
  - [ ] Home -> Creations -> Home
  - [ ] Chat -> relevant settings/help -> Chat

---

## Day 2 - Resona stabilization (nemesis pass)

- [ ] Clarify room identity in chat header:
  - [ ] Solo/life thread labeling is clear.
  - [ ] Project/collab labeling is clear.
- [ ] Member visibility:
  - [ ] Room member list dropdown is stable and scrollable.
  - [ ] Companion + members appear consistently.
- [ ] Runtime controls consistency:
  - [ ] Lobby AI participation toggles behave deterministically.
  - [ ] Delegated runs/auto catch-up/file sync toggles persist.
- [ ] Exit behavior:
  - [ ] "Exit project thread" flow is explicit and non-destructive.

---

## Day 3 - Bond Store and ownership boundaries

- [ ] Enforce lane ownership contract in UX text:
  - [ ] Bond Store = continuity/memory/journal.
  - [ ] Resona = collab runtime/project room behavior.
  - [ ] Creations = pipeline/project build/export lifecycle.
- [ ] Add explicit handoff messaging:
  - [ ] What goes to Bond Store and why.
  - [ ] What stays in Resona room state.
- [ ] Remove ambiguous copy that implies multiple owners for same artifact.

---

## Day 4 - Export/save destination hardening

- [ ] Add "saved to" confirmations for every export-heavy action:
  - [ ] file/folder target,
  - [ ] lane target (Bond Store / Creations / external),
  - [ ] how to reopen.
- [ ] Audit and fix mismatched destination labels:
  - [ ] UI label matches actual write path.
  - [ ] "in app" vs "out of app" intent is explicit before execution.
- [ ] Validate return loops:
  - [ ] Export -> open result -> discuss result in chat.

### Voice Forge pipeline integration (project/game voice lane)

- [ ] Add new Creations route for project voice processing (working title: `Voice Forge`):
  - [ ] Keep separate from companion `Voice Studio` presets/state.
  - [ ] Route copy makes this explicit: "for project/game characters, not base ANIKAI companion voice."
- [ ] Define non-destructive handoff from Voice Studio:
  - [ ] `Import from Studio` copies a voice bake/profile snapshot into project space.
  - [ ] Imported snapshot does not mutate Studio defaults.
  - [ ] Project edits never overwrite ANIKAI companion tuning.
- [ ] Implement DSP overlay chain MVP (DAW-lite, mobile-safe):
  - [ ] effect enable/bypass per slot,
  - [ ] reorder chain,
  - [ ] wet/dry controls,
  - [ ] output limiter safety.
- [ ] Add first-pass creature/depth overlays:
  - [ ] formant/pitch shaping,
  - [ ] saturation/distortion lane,
  - [ ] short reverb/space lane,
  - [ ] optional parallel growl/noise layer (low-cost profile).
- [ ] Add preset lifecycle:
  - [ ] save preset per character/archetype,
  - [ ] duplicate/rename/archive,
  - [ ] export preset JSON + preview wav.
- [ ] Define runtime data contract for game ingestion:
  - [ ] `voiceBakeId` (source),
  - [ ] `voiceFxPresetId`,
  - [ ] `fxParams`,
  - [ ] `renderMode` (`realtime` or `offline_bounce`),
  - [ ] scene/application tags.
- [ ] Validate end-to-end ingest loop:
  - [ ] Voice Studio bake -> Import to Voice Forge -> FX tweak -> export preset -> load in game runtime test.

### Sprite pipeline integration (new game-asset lane)

- [ ] Implement Creations sprite pipeline type selector (required):
  - [ ] `CREATURES` (characters/lifeforms),
  - [ ] `ENVIRONMENTAL` (water/trees/props),
  - [ ] `MAP_GEN`,
  - [ ] `TOWNS_GENERATOR`.
- [ ] Match UI fields to `SPRITE_COMPANION_ASSET_SPEC.md` contract:
  - [ ] style,
  - [ ] camera mode,
  - [ ] theme/biome,
  - [ ] frame size profile,
  - [ ] notes.
- [ ] Enforce export folder contract:
  - [ ] `sprites/creatures/*`,
  - [ ] `sprites/environmental/*`,
  - [ ] `sprites/map_gen/*`,
  - [ ] `sprites/towns_generator/*`.
- [ ] Emit runtime-ready metadata:
  - [ ] root `manifest.json`,
  - [ ] per-asset `meta.json`,
  - [ ] preview `thumb.png`.
- [ ] Validate ingest loop:
  - [ ] generate -> export -> reopen in Creations library,
  - [ ] export package consumable without manual rename/cleanup.

---

## Day 5 - Gemma 4 compatibility track

- [ ] Validate Gemma 4 load and inference path:
  - [ ] cold load,
  - [ ] first response,
  - [ ] sustained conversation turn quality,
  - [ ] fallback behavior when unsupported route/settings.
- [ ] Add user-visible compatibility hints:
  - [ ] clear message when model cannot run under current route/device config.
- [ ] Ensure no legacy text references unsupported model assumptions.

---

## Runtime hardening track (carry-over; keep active)

- [ ] Tighten all current on-device runtimes to GGUF-level tuning quality:
  - [ ] GGUF (continue polish + capability gating + docs)
  - [ ] LiteRT (profile knobs, reliability toggles, thermal behavior, clear UI contract)
  - [ ] ONNX Runtime (session/options presets, post-pass controls, shape/opset safety UX)
  - [ ] MLC (when active again: equivalent tuning + telemetry + fallback contract)
- [ ] Build a single **runtime tuning surface** pattern in User Access:
  - [ ] consistent section headers, `!` docs, expand/collapse behavior, density profile
  - [ ] dynamic vs manual mode behavior parity across engines
  - [ ] capability-driven enabling/disabling (no dead toggles)
- [ ] Investigate and document additional model runtimes/families (edge-first):
  - [ ] MediaPipe Tasks (Vision/Photoshop-style specialists: Segmentation, Face Mesh, Gesture)
  - [ ] NCNN / MNN (Vulkan-optimized engines for fast Image/Sprite upscaling & FX)
  - [ ] ExecuTorch (Native PyTorch portability for the latest research models like SAM)
  - [ ] SNPE / QNN (Qualcomm NPU offloading for "Ultra-Power-Saving" background inference)
  - [ ] text families
  - [ ] image diffusion families
  - [ ] audio/music families
  - [ ] video/frame families
- [ ] Diffusion family practical track (mobile reality, not marketing):
  - [ ] FLUX.1 GGUF (city96/FLUX.1-dev-gguf) runner investigation + adapter contract
  - [ ] FLUX.2 klein GGUF (unsloth/FLUX.2-klein-4B-GGUF) runner investigation + adapter contract
  - [ ] per-family graph/engine differences documented in runtime manifest notes
  - [ ] explicit quality/latency/thermal presets per family
- [ ] Keep one anti-drift handoff per active runtime track (no scattered mini-notes):
  - [ ] Current canonical handoff for native GGUF diffusion lives in `LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md` under **Native GGUF diffusion handoff (current exact state)**.
  - [ ] If focus shifts, resume from that ordered list before opening new runtime spike branches.
- [ ] Long game checkpoint:
  - [ ] "Ultimate multi-model edge device" roadmap stays modular (adapters + manifests + policies), not one monolith per model.
  - [ ] ANIKAI mobile and ANIKAI PC share contracts first, then diverge only where platform requires.

---

## Day 6 - UI readability + demo capture prep

- [ ] Readability pass:
  - [ ] contrast,
  - [ ] spacing,
  - [ ] tiny text legibility,
  - [ ] title/subtitle hierarchy.
- [ ] Remove stale debug/history copy from primary-facing surfaces.
- [ ] Record-ready flow checks:
  - [ ] no obvious jank in Home/Console/Chat/Creations.
  - [ ] Voice Studio + Voice Forge labels are visually distinct and understandable in <5 seconds.
  - [ ] No modal naming conflict between companion voice controls and project voice pipeline controls.
  - [ ] no unresolved compile errors.
  - [ ] no broken click paths in demo route.

---

## Day 7 - Publish package

- [ ] Produce final "showable" build.
- [ ] Record:
  - [ ] short Home + Console walkthrough,
  - [ ] short Creations pipeline clip,
  - [ ] short Voice Studio -> Voice Forge handoff clip,
  - [ ] short collab/Resona clip.
- [ ] Post:
  - [ ] longform recap,
  - [ ] short clips,
  - [ ] pinned roadmap note.

---

## Day 8 - Logo Generator Pipeline (anti-drift checkpoint)

- [ ] Define MVP pipeline scope:
  - [ ] input fields (`brand_name`, style family, color lane, mood/energy, optional reference),
  - [ ] output pack (hero, app icon, transparent variant, social crop).
- [ ] Implement staged flow:
  - [ ] prompt builder,
  - [ ] candidate generation (`N` variants),
  - [ ] auto-rank + manual pick,
  - [ ] refine pass for text readability/shape stability,
  - [ ] export + save destination confirmation.
- [ ] Add runtime metadata trail:
  - [ ] source prompt,
  - [ ] model/runtime lane used,
  - [ ] timestamp + version,
  - [ ] parent-child lineage for refinements.
- [ ] Add quality guardrails (practical, not perfection):
  - [ ] logo text legible at small preview,
  - [ ] no warped glyph output in final candidate,
  - [ ] icon-safe variant produced.
- [ ] Add creation showcase hooks:
  - [ ] one-click "make alive" handoff target for video pipeline lane (future),
  - [ ] saved artifact appears in Creations library with clear reopen/edit flow.
- [ ] Ship-check:
  - [ ] generate -> pick -> refine -> export -> reopen works end-to-end in app.

---

## Giant doc cleanup checklist (must execute in sprint)

### A) Immediate stale-plan removals (done)

- [x] Remove `CONVERSATIONAL_NAV_AND_PERMISSIONS_PLAN.md`
- [x] Remove `PORTRAIT_PRESENCE_MVP_PLAN.md`
- [x] Remove `VOICE_AFFECT_AND_SOUL_METRICS_PLAN.md`
- [x] Remove `MOOD_LIBRARY_PHASE_PLAN.md`

### B) Remaining roadmap hygiene

- [ ] Review each file in `docs/source-of-truth/02-roadmap/` and assign one status:
  - [ ] `ACTIVE`
  - [ ] `MERGE_INTO_SPEC`
  - [ ] `DELETE`
- [ ] Merge surviving essentials into:
  - [ ] `ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md` (runtime behavior),
  - [ ] `ANIKAI_FUTURE_IMPLEMENTATION_BACKLOG.md` (future scope).
- [ ] Delete all merged-or-obsolete roadmap docs after merge commit.

### C) Catalog/governance alignment

- [ ] Ensure governance docs do not reference removed lanes/screens.
- [ ] Ensure catalog docs reflect current route names and control-surface naming.
- [ ] Ensure no doc encourages restoring removed legacy hubs.

### D) History integrity

- [ ] Append a history note describing this cleanup wave and rationale.
- [ ] Keep only one active roadmap voice to prevent "revert by old markdown."

---

## Must-not-regress list

- [ ] User Access remains the canonical behavior control surface.
- [ ] Companion can explain blocked gates and request consent to enable.
- [ ] Settings Hub legacy entry surfaces remain removed from primary flow.
- [ ] Chat header/state panels use current naming (no ancient labels).
- [ ] Context/token legacy panel remains removed from default chat UI.

---

## Release confidence checks (ship gate)

- [ ] Build passes without Kotlin compile errors.
- [ ] Smoke test:
  - [ ] Home,
  - [ ] Console,
  - [ ] Chat (solo + project/lobby),
  - [ ] Creations.
- [ ] Export/save map verified by manual roundtrip tests.
- [ ] Demo script runs end-to-end without route confusion.

---

## Notes

- Ideas can continue during sprint, but every idea must be assigned:
  - **Now (ship-week)** or
  - **Backlog (post-showcase)**.
- This sprint optimizes visibility and coherence first; deep expansion can follow once public narrative and trust are established.
