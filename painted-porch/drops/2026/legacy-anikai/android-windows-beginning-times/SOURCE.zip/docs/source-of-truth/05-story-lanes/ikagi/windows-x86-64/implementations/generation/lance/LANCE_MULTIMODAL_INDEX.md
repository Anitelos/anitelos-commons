# Lance unified multimodal (Windows desktop)

[Lance](https://lance-project.github.io/) — 3B native unified model (ByteDance) for image and video **understanding, generation, and editing**.

**Not** [Apple LiTo](https://github.com/apple/ml-lito) (`ml-lito`) — that repo is **image→3D** under **Generating → 3D**.

## Registry

- `anikai-desktop/assets/about-guide/lance-registry.json`
- About → **Generating → Video → Model catalogue → Lance** section
- Media Magic → **Video → Lance** tab (links + staged multi-step UI)
- Weights: `models/lance/lance-3b/` via **Get pack** on `lance-3b-unified` (full HF tree expand)

## Capabilities (one checkpoint family)

- Text→image · text→video
- Image / video editing (single-step and multi-turn)
- Intelligent video (structured planning)
- Video / image understanding (VQA, captions)

Capability rows in the catalogue are **teaching aliases** — they share the same download pack.

## Runtime staging

From `anikai-desktop/` (Git + Python 3.11+ on PATH):

```bash
npm run stage-lance
# optional HF tree under resources/lance-runtime/downloads/:
# set ANIKAI_STAGE_LANCE_DOWNLOAD_WEIGHTS=1
```

- Engine: `resources/lance-runtime/engine/` (clone of https://github.com/bytedance/Lance)
- Venv: `resources/lance-runtime/venv/`
- Weights (separate): Get pack **lance-3b-unified** → `models/lance/lance-3b/`
- Paper: https://arxiv.org/abs/2605.18678
- Desktop inference bridge: **planned** (dedicated Lance venv, not generic `media-python-runtime`)

## Relation to other lanes

- **Imaging** — still T2I / edit can stay on GGUF/Diffusers; Lance is an optional unified alternative.
- **Video** — T2V / edit without a separate Wan-only stack when Lance ships; primary desk tab under **Media → Video → Lance**.
- **3D** — use **threed-registry** for mesh/splat; Lance does not replace Hunyuan3D / SHARP / LiTo.
