# Ikagi — Android (arm64-v8a)

**Scope:** the main phone track: OEM quirks, scoped todos, long-lived implementation notes, and the workflow bridge (`todo` → `implementations` → `complete`).

**Sister lane (desktop):** [`../windows-x86-64/`](../windows-x86-64/) uses the **same folder rhythm** for todos and implementations; **plans are authored separately**—no requirement to read or mirror the other lane unless you choose to.

## Workflow (same idea as your note)

| Folder | Meaning |
|--------|---------|
| `todo/` | Active thinking with **scope lanes** (`low-` / `mid-` / `high-`) plus `shelved/` for pause-not-dead items. |
| `implementations/` | **Stable idea parking**—what you mean when you say “we do it like this,” without mixing checkbox chaos in here. |
| `complete/` | **Archived wins**—mirror the implementation layout when something actually ships or you deliberately freeze the design. |

**When to open:** Android-first product/engine ideas before they graduate into `02-roadmap` or code comments.

## Quick links

- OS / device truth: [`os-quirks/`](./os-quirks/)
- Work queue: [`todo/`](./todo/)
- Stable designs: [`implementations/`](./implementations/)
- Engine inference model hub index (active + future stubs): [`implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md`](./implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md)
- Done mirror: [`complete/`](./complete/)
