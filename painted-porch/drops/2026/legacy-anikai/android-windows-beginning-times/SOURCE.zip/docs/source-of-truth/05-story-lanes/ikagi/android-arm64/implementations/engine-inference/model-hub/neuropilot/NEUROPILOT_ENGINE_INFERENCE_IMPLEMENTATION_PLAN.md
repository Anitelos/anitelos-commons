# MediaTek NeuroPilot engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: reserve an ANIKAI engine-inference lane for **MediaTek NeuroPilot** on Dimensity-class devices. Analogous role to Qualcomm QNN/SNPE for MTK NPUs; enables vendor-optimal paths where generic ONNX/NNAPI under-deliver.

---

## Scope

This file covers NeuroPilot for:

- vendor NPU/DSP inference where MTK exposes NeuroPilot APIs,
- capability manifest + device-class probes for MTK chipsets,
- future Swarm/Sentience helper lanes bound to declared MTK-capable packs.

This file does **not** define MTK SDK versions, legal redistribution of NeuroPilot binaries, or shipping timelines.

---

## Why this runtime matters for ANIKAI

- broad Android coverage on MediaTek flagships and mid-tier,
- potential thermal wins vs CPU-only or generic NNAPI paths,
- honest labeling when NeuroPilot is unavailable (wrong chip, missing libs, policy).

Rule: NeuroPilot claims are valid only after vendor probe + session init + output contract pass on a target Dimensity device.

---

## Role model (single truth)

| NeuroPilot lane | Ownership |
|-----------------|-----------|
| Vision/audio helper on MTK | Candidate when pack + SDK alignment exists. |
| Primary companion text | Not assumed default; quality bar TBD. |
| Sentience perception | Allowed if latency and privacy contracts meet bar. |
| Swarm pipeline stages | Allowed when step declares `runtimeFamily=neuropilot` and passes manifest. |

---

## Android implementation plan (stub checklist)

### 1) Vendor integration prerequisites

- [ ] Confirm NeuroPilot SDK distribution model (NDA, Play policy, ABI coverage).
- [ ] Define minimum Dimensity / NeuroPilot API level matrix.
- [ ] JNI bridge boundary and crash isolation strategy.

### 2) Adapter/session checklist

- [ ] `neuropilot` adapter id registered in engine registry (no-op until SDK wired).
- [ ] Capability probe: chipset match + library presence + init success.
- [ ] Tensor IO contract documented per reference pack.
- [ ] Explicit failure taxonomy (unsupported chip, missing lib, init fail).

### 3) Manifest contract (draft)

Each NeuroPilot-capable pack row should declare:

- `runtimeFamily: neuropilot`,
- required `.nb` / vendor bundle paths (format TBD when SDK locked),
- capability flags and lane eligibility,
- fallback runtime (`onnx` / `ncnn` / `litert`) when NeuroPilot unavailable.

---

## Phased delivery

- **Phase 0:** stub registry + documentation only (this doc).
- **Phase 1:** one reference model path on one Dimensity reference device.
- **Phase 2:** integrate with capability platform readiness states.

---

## Open decisions

- first reference task family (CV vs audio vs small LLM delegate),
- SDK packaging strategy inside APK vs dynamic download,
- relationship to existing ONNX Runtime NNAPI delegate (avoid duplicate work).

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)
- [`../qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) (Qualcomm parity reference)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for MediaTek NeuroPilot future lane. |
