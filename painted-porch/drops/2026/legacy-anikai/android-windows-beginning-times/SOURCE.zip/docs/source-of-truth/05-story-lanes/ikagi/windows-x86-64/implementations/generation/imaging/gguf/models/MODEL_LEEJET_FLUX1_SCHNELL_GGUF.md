# Model sheet — leejet / FLUX.1-schnell-gguf

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [leejet/FLUX.1-schnell-gguf](https://huggingface.co/leejet/FLUX.1-schnell-gguf)  
- Base: [black-forest-labs/FLUX.1-schnell](https://huggingface.co/black-forest-labs/FLUX.1-schnell)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the diffusion `.gguf` (matches Anikai `downloadPacks`).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- Encoders bundle (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  

## Pack family

`flux1_clip_t5`

## Product

- **Preset id:** `flux1_schnell_gguf_leejet`  
- **Profile:** `flux_schnell_gguf` — 1024², 4 steps, cfg 1  

## Anikai router

**partial** — split-pack shipped; E2E open.

## Links

- [`MODEL_CITY96_FLUX1_SCHNELL_GGUF.md`](./MODEL_CITY96_FLUX1_SCHNELL_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
