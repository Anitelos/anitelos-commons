# Engine inference capability platform plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-09 |

Purpose: define ANIKAI's parent inference-engine platform so model families from Hugging Face and local packs can be installed, probed, routed, and used by Swarm/Soul capabilities without hardcoding each feature as a one-off pipeline.

---

## Why this exists

ANIKAI is moving from "one model per feature" toward a capability-native runtime platform.

The app should not ask only "what model is selected?" It should ask:

- what runtime can load this pack,
- what files and sidecars are present,
- what capabilities are proven on this device,
- what Swarm/Soul roles the model is allowed to serve,
- what fallback or degraded state is honest when the capability is unavailable.

This parent doc coordinates the individual engine-inference implementation plans. The child docs remain the durable source for runtime-specific details. Todos are execution handles and may move to completed later; implementation docs stay archived and editable.

---

## Platform principle

Model presence is not capability.

Capability is only real after:

1. **Model pack manifest** declares required files, sidecars, runtime family, quant/profile, license, and intended capabilities.
2. **Runtime adapter** exists for the engine family and task shape.
3. **Capability probe** validates device/runtime support and required model files.
4. **Session init** succeeds with explicit backend/provider state.
5. **Output contract** is proven by at least one observed pass.
6. **UI/Swarm routing** uses the same pass/fail state instead of placeholder assumptions.

---

## Parent capability layers

### 1) Model pack manifest

Every installable pack should expose a manifest row with:

- model id, display name, source URL, license, and local storage root,
- runtime family (`gguf`, `onnx`, `ncnn`, `litert`, `mediapipe`, `qnn`, `executorch`, `mnn`, `fomm`, plus future: `neuropilot`, `samsung_enn`, `hiai`, `aicore`, `android_nnapi_direct`, `paddle_lite`, `apache_tvm`, `tengine`, `opencv_dnn`, `skia_graphics`; see [`model-hub/MODEL_HUB_INDEX.md`](model-hub/MODEL_HUB_INDEX.md)),
- required files and sidecars (`mmproj`, tokenizer, vocab, config, graph metadata, prompt assets),
- declared capabilities (`text_generation`, `chat`, `vision_understanding`, `audio_understanding`, `asr`, `tts`, `image_generation`, `image_postprocess`, `motion_generation`, `embedding`, `classification`, `turn_detection`, `emotion_detection`),
- profile guardrails (RAM floor, context limit, threads, backend hints, thermal class),
- lane eligibility (companion primary, fast response, Swarm specialist, background helper, pipeline stage).

### 2) Runtime adapter registry

The app needs one registry that maps:

`runtime family + capability + model pack -> adapter id -> probe -> session -> output contract`

This prevents the UI from exposing controls that are not backed by real runtime capability, such as QNN chips without a QNN-enabled provider path or multimodal buttons without `mmproj`.

### 3) Capability probe and readiness

Each adapter reports:

- `INSTALLED`: files exist,
- `SUPPORTED`: device/runtime/backend can attempt this lane,
- `LOADABLE`: session init succeeds,
- `VERIFIED`: minimal forward pass/output contract succeeded,
- `DEGRADED`: fallback is active and labeled,
- `UNAVAILABLE`: visible reason exists.

Rule: app surfaces should enable advanced controls only from readiness state, not from hardcoded model names.

### 4) Swarm and Soul role binding

Users should be able to assign models to roles by capability:

- companion brain,
- fast live response,
- verifier,
- journal summarizer,
- screen/image analyst,
- ASR/hearing lane,
- turn detector,
- emotion detector,
- TTS/voice renderer,
- image generator,
- postprocess/upscaler,
- animation/motion lane,
- background reflex helper.

The role binder must accept multiple candidates and choose by user policy (`speed-first`, `quality-first`, `battery-first`, `local-only strict`) plus observed readiness.

---

## Model fusion checklist (cross-service readiness)

Before a model is treated as fusion-ready across Sentience, Swarm, Soul, or Meridian-related services, the following checks must pass:

- [ ] Model pack includes manifest metadata for runtime family, capability flags, and service eligibility tags.
- [ ] Required artifacts/sidecars are present (`tokenizer`, config, vocab, `mmproj`, graph files, etc.).
- [ ] Runtime probe passes on current device/backend (`SUPPORTED` at minimum).
- [ ] Session init and minimal forward pass/output contract pass (`LOADABLE` -> `VERIFIED`).
- [ ] Role assignment path exists for both service families where relevant (`sentience.*` and/or `swarm.*`).
- [ ] Primary and fallback chain is defined per assigned role.
- [ ] Degraded/fallback state is visible in UX and logs (no silent fallback).
- [ ] Handover packets include `servicePlane`, adapter id, capability id, latency, and fail/degraded reason fields.
- [ ] Shared model pool is used by Sentience and Swarm (no duplicated registration systems).
- [ ] Unassign/disable behavior leaves safe defaults and explicit unavailable state.

Rule: more models only help when they can be fused through the same readiness and handover contract; adding models without this checklist increases orchestration drift.

---

## Child implementation checklist

| Engine/project | Status | Ownership | Source doc | Active todo |
|----------------|--------|-----------|------------|-------------|
| **GGUF** | In progress | Text, chat, multimodal with sidecars, possible specialized native decode lanes | [`model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`](../../todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md) |
| **ONNX** | In progress | Image/runtime graph execution, postprocess helpers, current Kokoro/Cosy voice backend class | [`model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md) | [`../../todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md`](../../todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md) |
| **LiteRT** | Not started | Lightweight Android-native helper lanes and delegate-backed always-alive tasks | [`model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md`](../../todo/mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md) |
| **MediaPipe** | Not started | Vision/recognition/helper models with Android-friendly IO contracts | [`model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`](../../todo/mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md) |
| **NCNN** | Not started | Efficient mobile CV/helper workloads and native JNI inference paths | [`model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md`](../../todo/mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md) |
| **QNN/SNPE** | Not started | Qualcomm NPU/DSP class lane with strict device capability gating | [`model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md`](../../todo/mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md) |
| **ExecuTorch** | Not started | PyTorch-to-edge model families and research-first mobile deployment | [`model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md`](../../todo/mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md) |
| **MNN** | Not started | Optional high-performance mobile inference with tuning/benchmark strategy | [`model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md`](../../todo/mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md) |
| **FOMM** | Not started | Qualcomm ONNX motion inference for sprite/character animation lanes | [`model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`](../../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md) |
| **NeuroPilot (MTK)** | Future (stub) | MediaTek Dimensity NPU vendor path | [`model-hub/neuropilot/NEUROPILOT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/neuropilot/NEUROPILOT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **Samsung ENN** | Future (stub) | Exynos NPU / Eden-class vendor path | [`model-hub/samsung_enn/SAMSUNG_ENN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/samsung_enn/SAMSUNG_ENN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **HiAI** | Future (stub) | Huawei Kirin regional / legacy lane | [`model-hub/hiai/HIAI_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/hiai/HIAI_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **AICore / system AI** | Future (stub) | Android OS-managed on-device inference (e.g. Gemini Nano class) | [`model-hub/aicore/AICORE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/aicore/AICORE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **NNAPI direct** | Future (stub) | Direct NNAPI/SL4A vs delegate-only stacks | [`model-hub/android_nnapi_direct/ANDROID_NNAPI_SL4A_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/android_nnapi_direct/ANDROID_NNAPI_SL4A_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **Paddle Lite** | Future (stub) | PaddlePaddle mobile / OCR-leaning ecosystem | [`model-hub/paddle_lite/PADDLE_LITE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/paddle_lite/PADDLE_LITE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **Apache TVM** | Future (stub) | Compiler-first optimized kernels | [`model-hub/apache_tvm/APACHE_TVM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/apache_tvm/APACHE_TVM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **Tengine** | Future (stub) | ARM-focused lite runtime alternative | [`model-hub/tengine/TENGINE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/tengine/TENGINE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **OpenCV DNN** | Future (stub) | Classic CV nets via OpenCV `dnn` | [`model-hub/opencv_dnn/OPENCV_DNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/opencv_dnn/OPENCV_DNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |
| **Skia / graphics FX** | Future (stub) | Shader/LUT/Vulkan fast path (non-tensor) | [`model-hub/skia_graphics_pipeline/SKIA_GRAPHICS_PIPELINE_INFERENCE_IMPLEMENTATION_PLAN.md`](model-hub/skia_graphics_pipeline/SKIA_GRAPHICS_PIPELINE_INFERENCE_IMPLEMENTATION_PLAN.md) | — |

Index: [`model-hub/MODEL_HUB_INDEX.md`](model-hub/MODEL_HUB_INDEX.md)

---

## First vertical slice

Do not try to operationalize every runtime family at once.

Recommended first platform slice:

1. **Manifest + readiness schema** shared across all engines.
2. **GGUF text + multimodal sidecar gating** (`mmproj` and equivalent checks).
3. **ONNX/Kokoro voice readiness honesty** (CPU/NNAPI/QNN labels only when provider state is real).
4. **One ONNX utility/image helper** with a verified output contract.
5. **Role binding surface** that lets Swarm/Soul choose by capability, not model name.

This slice gives ANIKAI enough runtime maturity to stop adding placeholder UI and start adding real capability-backed pipelines.

---

## Verification gates before "platform operational"

- A model pack manifest can describe at least one GGUF text pack, one GGUF multimodal pack with sidecar, one ONNX helper pack, and one voice pack.
- Runtime registry returns consistent readiness states across app restart.
- UI controls enable/disable from readiness state, not static placeholders.
- Swarm role binding can select a model by capability and receive an explicit fail reason if unavailable.
- Handover packets include model id, runtime family, adapter id, capability, latency, and degraded/fallback state.
- Child docs are updated when a runtime-specific implementation changes.

---

## Relationship to generation and pipeline docs

This doc owns inference capability and runtime readiness.

**Cross-engine integration smoke (mandatory link):** pipeline-layer harness for multi-runtime **handover**, **unload/load between models**, **per-hop timing**, and **failure matrix** — [`../pipelines/WHISPER_CHAIN_CAPABILITY_SMOKE_PIPELINE_PLAN.md`](../pipelines/WHISPER_CHAIN_CAPABILITY_SMOKE_PIPELINE_PLAN.md).

It does not own:

- image/music/video quality bars,
- full product UX,
- one-button pipeline choreography,
- story-specific generation contracts.

Those remain in `generation/` and `pipelines/`. This doc answers whether the app can honestly run, probe, and route the required model capabilities.

---

## Open decisions

- Minimal manifest format for v1: JSON, Kotlin data model, or generated schema.
- Whether capability probes should run at install time, app launch, or on-demand.
- How much benchmark data is required before enabling `speed-first` routing.
- Whether QNN/SNPE and NNAPI labels should be hidden until backend probes pass.
- First GGUF multimodal pack target and required `mmproj` handling.

---

## Linked todos

- [`../../todo/high-scope/TODO_ENGINE_INFERENCE_CAPABILITY_PLATFORM.md`](../../todo/high-scope/TODO_ENGINE_INFERENCE_CAPABILITY_PLATFORM.md)
- [`model-hub/MODEL_HUB_INDEX.md`](model-hub/MODEL_HUB_INDEX.md)
- Child todos listed in the checklist above (stub families have no dedicated todo until work starts).

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-08 | Created parent engine inference capability platform plan and linked child runtime implementation docs. |
| 2026-05-08 | Added cross-service model fusion checklist for Sentience/Swarm/Soul readiness gating. |
| 2026-05-09 | Added future vendor/OS/alternative engine stub plans and `MODEL_HUB_INDEX.md` lookup. |
| 2026-05-09 | Hard-linked whisper-chain capability smoke pipeline plan under `implementations/pipelines/` for cross-runtime handover and timing harness. |
