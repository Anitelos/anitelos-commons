# FLUX generation implementation plan (Android imaging)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define how ANIKAI uses FLUX-family models for image generation outcomes (not runtime-family mechanics), with practical model-use recommendations, stage ownership, and implementation gates tied to existing ONNX/native progress.

---

## Scope

This file covers FLUX generation planning for:

- text-to-image and image-to-image outcomes in Creations/Sprite lanes,
- recommended use split between FLUX.1 and FLUX.2-class candidates,
- integration with existing ONNX post-pass and pipeline stage contracts,
- practical phased rollout from "works" to showcase quality.

This file does **not** replace:

- engine runtime internals in `engine-inference/model-hub/*`,
- global anti-drift execution log in `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`,
- sprite quality floor contracts in `sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`.

---

## What FLUX is useful for in ANIKAI

FLUX-family models are strongest as high-quality primary pixel generators (S1/S2) when paired with ANIKAI's on-device adapter discipline and post-pass stack.

Recommended roles:

- **Character still generation** for Sprite Maker and portrait packs.
- **Style-tethered img2img** from in-app user refs (identity lock and direction consistency).
- **Concept iteration** for assets/background motifs before pack/export pipeline.

Not the role:

- FLUX is not the same lane as companion text GGUF understanding.
- FLUX quality claims must still pass pipeline and floor contracts; no "small blurry success."

---

## Model family posture (Flux 1 + Flux 2)

| Family | Suggested ANIKAI use | Notes |
|--------|----------------------|-------|
| **FLUX.1-class** | First practical quality lane for txt2img/img2img where export/runtime path is stable. | Best first candidate for "operational" generation path tied to current JNI/ONNX progress. |
| **FLUX.2-class (e.g., klein variants)** | Experimental/next-wave quality lane after FLUX.1 pass criteria are stable. | Heavier and likely stricter device gating; use as QUALITY-track expansion, not day-1 default. |

Recommendation: ship FLUX.1 operational path first, then add FLUX.2 as gated upgrade lane.

---

## Example generation uses (app-facing)

### 1) Sprite Maker N·E·S·W base set

- Input: prompt + style ref + direction hints (from in-app pickers).
- FLUX role: generate per-facing stills with consistent identity.
- Post: ONNX sharpen/upscale for QUALITY preset.
- Output: facings written into pack schema flow.

### 2) Portrait/cutscene stills

- Input: character prompt + portrait style pack + optional prior reference.
- FLUX role: produce high-readability closeup still.
- Post: optional ONNX cleanup for edges/details.
- Output: portrait artifacts routed to portrait contract docs.

### 3) Concept-to-game-ingest bridge

- Input: loose concept prompt.
- FLUX role: produce initial high-quality concept still.
- Follow-up: palette/outline unify stage for game readability.
- Output: pack-ready asset candidates with runtime metadata trail.

---

## Stage ownership (aligned to existing pipeline schema)

| Stage | FLUX ownership |
|-------|----------------|
| **S1 - Primary pixels** | Core FLUX ownership candidate. |
| **S2 - Consistency** | Core FLUX ownership candidate (seed/ref tether/second pass). |
| **S3 - Sharpen/upscale** | Typically ONNX post lane, not FLUX itself. |
| **S4 - Palette/outline unify** | Optional ONNX/CPU helper lane. |
| **S5/S6 - Pack + animation prep** | App/pipeline contract lanes. |

This keeps FLUX as generation engine while ONNX continues to carry robust post duties.

---

## Current progress anchor (reality snapshot)

- ONNX post-pass planning exists and is in progress (`ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`).
- Native GGUF diffusion work is close but still requires canonical decode/output validation for reliable claim.
- FLUX-family references exist in local-media backlog but lacked dedicated generation contract until this doc.

So current posture: **planning ready, implementation not yet operational**.

---

## Implementation plan (phased, buildable)

### Phase 0 - contract lock

- finalize FLUX lane capability rows (what each adapter can/cannot do),
- lock preset policy for FLUX (`FAST`, `BALANCED`, `QUALITY` expectations),
- define minimum output sizes tied to quality-floor contract.

### Phase 1 - FLUX.1 operational baseline

- run one FLUX.1 path end-to-end for txt2img on supported device class,
- add ref-driven img2img variant for consistency use-cases,
- persist outputs with runtime id + preset metadata.

### Phase 2 - QUALITY stack hardening

- integrate ONNX post-pass chain after FLUX primary output,
- validate visual uplift at authored output sizes,
- enforce visible fail/degraded states when chain cannot run.

### Phase 3 - FLUX.2 experimental lane

- add FLUX.2 klein-class lane as gated profile,
- benchmark memory/thermal impact and adjust device gates,
- promote only if quality/time tradeoff is acceptable.

---

## Validation gates (before operational claim)

- one FLUX lane produces valid persisted image output in-app,
- Sprite/portrait flow consumes outputs without manual patching,
- ONNX post chain is deterministic for QUALITY where enabled,
- failure states are explicit (no silent provider/procedural substitution),
- output quality is judged against sprite/portrait floor contracts at intended resolution.

---

## Open decisions

- first exact FLUX.1 bundle/profile for operational baseline,
- threshold to classify FLUX.2 lane as optional experimental vs operational,
- preset defaults by device class and thermal envelope.

---

## Linked engine/runtime docs

- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`
- `implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`
- `implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`

---

## Linked todos

- `todo/mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial FLUX generation implementation plan created from local-media split and Flux 1/2 backlog mentions. |
