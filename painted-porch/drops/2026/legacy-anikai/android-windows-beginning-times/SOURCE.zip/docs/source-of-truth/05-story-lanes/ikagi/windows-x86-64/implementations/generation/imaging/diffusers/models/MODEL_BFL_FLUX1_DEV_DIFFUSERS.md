# Model sheet — FLUX.1 Dev (BFL Diffusers)

| Field | Value |
|-------|-------|
| **HF** | [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev) |
| **Gated** | Yes — HF token required |

Primary **sprite / concept** Diffusers lane in [`../DIFFUSERS_IMAGING_STACK_LIBRARY.md`](../DIFFUSERS_IMAGING_STACK_LIBRARY.md). Pair with ONNX x4 post for NESW quality uplift.
