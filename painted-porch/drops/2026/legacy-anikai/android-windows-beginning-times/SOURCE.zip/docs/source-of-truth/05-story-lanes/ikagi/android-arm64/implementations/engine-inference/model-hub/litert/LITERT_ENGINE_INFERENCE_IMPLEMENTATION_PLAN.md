# LiteRT engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define LiteRT as an ANIKAI engine-inference family (separate from generation/pipeline docs), including Android delegate strategy, model capability manifesting, and lane integration for lightweight on-device tasks.

---

## Scope

This file covers LiteRT for:

- lightweight text/helper inference lanes where LiteRT is selected,
- vision/audio helper tasks that ship as `.tflite`/LiteRT-compatible assets,
- device-gated acceleration paths (CPU/GPU/NNAPI where applicable),
- Swarm/pipeline helper routing for LiteRT-capable adapters.

This file does **not** replace:

- image/media quality targets in `generation/`,
- multi-stage orchestration contracts in `pipelines/`,
- anti-drift history in `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`.

---

## What LiteRT is (in ANIKAI terms)

LiteRT is the low-overhead runtime lane for compact on-device inference packs. It is useful for fast helper tasks and some primary lanes on constrained devices.

ANIKAI value:

- low memory footprint lane for portable model packs,
- strong fit for helper perception/transforms and fallback profiles,
- practical "FAST/BALANCED" path where heavier runtimes are unavailable.

Rule: LiteRT capability is active only when adapter + manifest + delegate/session init + output schema all pass.

---

## Role model (single truth)

| LiteRT lane | Ownership |
|-------------|-----------|
| **Companion primary text (optional)** | Allowed when selected and quality bar is acceptable for that device/profile. |
| **Vision/audio helper inference** | Core LiteRT ownership for small helper packs and transforms. |
| **Primary diffusion-quality generation** | Generally not primary default unless explicitly validated and documented per adapter. |
| **Pipeline helper stages** | Allowed for fast preprocess/postprocess lanes when declared. |

---

## Android implementation plan (runtime + delegates)

### 1) Runtime/delegate strategy

- define supported delegates per capability pack (CPU baseline, optional GPU/NNAPI),
- keep delegate selection deterministic by preset + device class,
- log delegate choice and fallback reason in diagnostics.

### 2) Adapter/session checklist

- [ ] LiteRT adapter interface row(s) declared in engine registry.
- [ ] Session init path validates tensor IO specs before execution.
- [ ] Delegate init errors map to explicit fallback paths.
- [ ] Cancellation and resource cleanup verified under repeated runs.
- [ ] Error taxonomy visible in app surfaces (not silent downgrade).

### 3) Manifest contract

Each LiteRT pack row should include:

- adapter id + runtime kind (`LiteRT`),
- expected input tensor shape/dtype and output schema,
- delegate policy by preset/device class,
- capability flags (task type and lane eligibility),
- thermal/memory hints for scheduler.

---

## App integration map

### A) Model hub / runtime matrix

- expose LiteRT as explicit engine family in model hub cards,
- show capability badges + host/delegate hints,
- avoid model-name hardcoding in lane decisions.

### B) Swarm/task lanes

- bind LiteRT helper packs to specific specialist lane ids,
- ensure lane execution requires adapter resolution and manifest pass,
- fail visibly when LiteRT pack is incompatible on current device.

### C) Imaging/music/video helper usage

- LiteRT can own helper transforms (segmentation-like assist, preprocessing, classification),
- generation claims remain tied to generation docs and quality contracts,
- keep output labeling explicit (`LiteRT helper`, `LiteRT primary` only when true).

### D) Companion surface behavior

- show source/runtime metadata in logs and user-facing diagnostics,
- preserve local-first rules and explicit fallback toggles.

---

## Phased delivery

### Phase 0 - schema and registry

- lock LiteRT manifest schema + adapter IDs,
- add diagnostics and lifecycle scaffolding.

### Phase 1 - one operational helper pack

- deliver one end-to-end LiteRT helper lane with artifact output and validation.

### Phase 2 - delegate hardening

- stabilize delegate policy across device classes,
- add thermal-aware switching and retry controls.

### Phase 3 - cross-engine parity

- align controls/labels with GGUF/ONNX/MediaPipe lanes,
- keep fallback behavior transparent and measurable.

---

## Verification gates (before "operational" claim)

- one LiteRT task runs end-to-end on device and writes expected artifact/schema,
- delegate fallback behavior is deterministic and logged,
- Swarm lane uses same adapter resolution logic as other engines,
- no hidden provider substitution when LiteRT lane fails.

---

## Open decisions

- which LiteRT task becomes first operational reference pack,
- minimum acceptable quality for any LiteRT primary text lane,
- delegate default policy for mid-tier devices.

---

## Linked todos

- `todo/mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial LiteRT engine inference implementation plan split from local media model-family mentions. |
