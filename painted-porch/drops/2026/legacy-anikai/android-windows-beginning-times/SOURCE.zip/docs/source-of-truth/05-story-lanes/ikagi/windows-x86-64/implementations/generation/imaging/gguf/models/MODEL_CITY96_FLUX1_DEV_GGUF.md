# Model sheet — city96 / FLUX.1-dev-gguf

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [city96/FLUX.1-dev-gguf](https://huggingface.co/city96/FLUX.1-dev-gguf)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the diffusion `.gguf` (matches Anikai `downloadPacks`).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- Base / encoders (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  

## Pack family

`flux1_clip_t5` — [`../gguf/GGUF_MODEL_PACK_FAMILIES.md`](../gguf/GGUF_MODEL_PACK_FAMILIES.md)

## Weight layout (split-pack)

```text
models/flux1-dev/
  flux1-dev-Q4_K.gguf
  vae/ae.safetensors
  text_encoder/          # clip_l
  text_encoder_2/          # t5xxl
```

## Product

- **Preset id:** `flux1_dev_gguf_city96`  
- **Profile:** `flux_dev_gguf` — 1024², ~28 steps, cfg 1  

## Anikai router

**partial** — uses existing `buildFluxSplitPackSdArgs` when sidecars present.

## Checklist

- [ ] E2E with split-pack  
- [ ] Lane index tick  

## Links

- [`MODEL_CITY96_FLUX1_SCHNELL_GGUF.md`](./MODEL_CITY96_FLUX1_SCHNELL_GGUF.md)  
- [`MODEL_LEEJET_FLUX1_DEV_GGUF.md`](./MODEL_LEEJET_FLUX1_DEV_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
