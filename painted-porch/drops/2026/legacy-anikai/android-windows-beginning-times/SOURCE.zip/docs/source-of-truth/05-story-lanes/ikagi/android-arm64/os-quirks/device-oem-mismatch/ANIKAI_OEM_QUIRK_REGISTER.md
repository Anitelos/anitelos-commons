# ANIKAI OEM Quirk Register

## Purpose
Track real-device compatibility gaps without losing product direction.

Use this register when a lane fails on a device so ANIKAI can:
- keep truthful runtime gating,
- preserve fallback behavior,
- and re-test quickly when OEM/vendor/runtime updates land.

Reference contract: `ANIKAI_PLATFORM_FIRST_GATE.md`

---

## Status Keys
- `READY`: Stable on tested profile(s), default-enabled.
- `BETA`: Mostly stable, limited matrix and/or known caveats.
- `EXPERIMENTAL`: Included for targeted testing.
- `BLOCKED`: Not currently viable on this profile.

---

## Error Class Keys
- `E_PLATFORM_BLOCKED`
- `E_DRIVER_INCOMPATIBLE`
- `E_RUNTIME_MISSING`
- `E_INIT_FAILED`
- `E_EXECUTION_FAILED`
- `E_FALLBACK_ACTIVE`

---

## Active Quirks

| Date (UTC) | OEM/Model | Android | SoC/GPU | Lane | Error Class | Symptom | Current Mitigation | Status | Next Action |
|---|---|---|---|---|---|---|---|---|---|
| 2026-05-09 | Samsung S24 class (user-reported) | 14/15 class (API35 runtime behavior observed) | Adreno/Exynos class (TBD) | Compose UI frame-rate logging | E_FALLBACK_ACTIVE (noise suppression workflow) | Repeating `View.setRequestedFrameRate frameRate=NaN` logs during Compose draw traversal (`Api35Impl.setRequestedFrameRate`) on device; not observed on Pixel 9 emulator in same flows | Root power-save path now fully gates heavy root visual pipeline; explicit root frame-rate request removed during isolation; documented log filter/mute + debugger caller-capture playbook | BETA | Re-test after next Compose/runtime/OEM update; if noisy + user-visible jank appears, capture fresh stack and perf trace before code-level mitigation |
| 2026-04-01 | Samsung S24 class (user-reported) | 14 | Adreno/Exynos class (TBD) | Piper local voice | E_PLATFORM_BLOCKED + E_FALLBACK_ACTIVE | Process-based Piper execution from app-data path fails with `error=13 Permission denied` | Native JNI lane added, runtime data wiring added, fallback to Android TTS remains active | BETA | Validate JNI lane on same profile after rebuild; if still failing, capture `piper_jni_bridge` exit code and update root cause |
| 2026-04-01 | Mixed OEM classes (matrix pending) | 13/14 | Varies | Vulkan local lane | E_DRIVER_INCOMPATIBLE (profile-dependent) | Vulkan not available or unstable on some device profiles | Runtime capability gating + alternate GPU/CPU lanes preserved | BETA | Expand matrix by OEM profile and maintain per-profile gate map |
| 2026-04-01 | All profiles | 13/14 | Varies | XTTS local voice | E_INIT_FAILED (feature completeness) | Runtime libraries detected, synthesis adapter path not complete | Explicit runtime/adapter status messaging and Piper/Power fallback | EXPERIMENTAL | Implement complete XTTS synthesis adapter and promote state only after matrix pass |

---

## Intake Template (New Device Report)

Copy this section for each new issue:

- **Date (UTC):**
- **Reporter:**
- **OEM/Model:**
- **Android version:**
- **SoC/GPU (if known):**
- **Lane:**
- **Error class:**
- **Observed symptom:**
- **Key logs:**
- **Fallback behavior observed (yes/no):**
- **Current status:**
- **Owner:**
- **Next action + ETA:**

---

## Exit Criteria Per Row

A quirk row can move to `READY` only when:
1. Fix confirmed on the original failing profile.
2. Fallback still verified when forced failure is simulated.
3. UI/runtime status strings remain truthful.
4. Release notes include the compatibility update.

