# Music generation implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define ANIKAI's music generation outcomes and recommended model/runtime forms (similar planning depth to imaging generation docs), while keeping engine-runtime internals in engine-inference docs.

---

## Scope

This file covers:

- what types of music generation ANIKAI should support first,
- recommended runtime/model forms by use-case,
- quality/preset expectations and device-class posture,
- phased implementation order from guaranteed local output to richer neural lanes.

This file does **not** replace:

- runtime-family internals (ONNX/LiteRT/NCNN/etc.),
- Creations orchestration sequence contract (pipeline doc),
- voice runtime plans.

---

## Music generation forms (recommended)

| Form | What it does | Why it matters for ANIKAI |
|------|---------------|---------------------------|
| **Parametric / deterministic composer** | Generates structured music from rules (tempo, scale, chord progressions, motifs) with synth layers. | Guarantees local sovereignty and fast baseline output on all device classes. |
| **Sample + FX scene builder** | Arranges loops/one-shots + effect chains into stems/mix. | DAW-lite path for creative control without heavyweight model dependency. |
| **MIDI + soundfont/SFZ renderer** | Converts composition plans into playable instrument output. | Lightweight, controllable, and portable local lane. |
| **Neural short-loop generator (ONNX-class)** | Produces short musical ideas/timbre loops from prompt/seed/context. | Adds richer texture while keeping bounded runtime cost. |
| **Neural stem separation / repair** | Splits vocals/drums/bass/other or restores source quality. | Enables remix and iterative production workflows in Creations. |

---

## Model/runtime example recommendations

### 1) Baseline local-first lane (ship first)

- Parametric composer + sample/FX chain + MIDI renderer.
- Output: deterministic WAV/PCM stems and master mix.
- Presets:
  - `FAST`: short loop, minimal FX.
  - `BALANCED`: longer arrangement with moderate layering.
  - `QUALITY`: full stem render + mastering pass.

### 2) Neural additive lane (phase 2+)

- ONNX short-loop/music sketch models as optional additive source.
- ONNX stem-separation/restoration helpers for remix and cleanup.
- Keep optional by device profile and explicit user toggle.

### 3) Optional cloud/key lane (always labeled)

- User-supplied key workflows may exist for external generation,
- but must never silently replace local-labeled generation claims.

---

## App-facing music generation uses

1. **Creations quick soundtrack**  
   Prompt/theme -> loop + mood stems -> exported track.

2. **Scene-based adaptive music kit**  
   Generate calm/action variants from same motif for game/story scenes.

3. **Voice-bed generator**  
   Create low-volume underscoring for narration/voice outputs.

4. **Remix and variation pass**  
   Load prior output -> stem split/FX variation -> new version export.

---

## Quality and preset contract

| Preset | Intent | Typical behavior |
|--------|--------|------------------|
| **FAST** | immediate idea capture | short duration, fewer layers, low compute |
| **BALANCED** | default creative run | moderate length, layered arrangement |
| **QUALITY** | production-oriented local render | full stems, optional neural enhancement, mastering pass |

Operational rule: a generation run is only "successful" when valid audio artifacts are written to disk with metadata trail (runtime id, preset, duration, source lane).

---

## Phased implementation plan

### Phase 0 - contract lock

- define output artifact schema (stems + master + metadata),
- lock preset behavior and minimum success criteria,
- align naming and storage with Creations path contract.

### Phase 1 - guaranteed local baseline

- implement parametric/deterministic lane end-to-end,
- include sample/FX and MIDI render path,
- ensure every supported device class gets usable local output.

### Phase 2 - neural additive capability

- integrate ONNX short-loop lane and one stem utility lane,
- gate by device profile and thermal policy,
- keep visible fail/degraded labels.

### Phase 3 - advanced chaining

- combine motif generation, variation, stem post, and master pass in one flow,
- expose iterative controls in Creations without bloating default UI.

---

## Validation gates (before "operational" claim)

- at least one local path writes valid PCM/WAV artifacts in app flow,
- metadata trail is persisted and visible in Creations history,
- fallback behavior is explicit (no hidden cloud substitution),
- quality preset differences are observable and documented.

---

## Open decisions

- first baseline synth/sample kit and default durations,
- first ONNX neural music utility to adopt (loop gen vs stem split first),
- max default duration per device class for thermal safety.

---

## Linked docs

- `implementations/pipelines/CREATIONS_MUSIC_GENERATOR_PIPELINE_PLAN.md`
- `implementations/pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`
- `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`

---

## Linked todo

- `todo/mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial music generation implementation plan created from local media split requirements. |
