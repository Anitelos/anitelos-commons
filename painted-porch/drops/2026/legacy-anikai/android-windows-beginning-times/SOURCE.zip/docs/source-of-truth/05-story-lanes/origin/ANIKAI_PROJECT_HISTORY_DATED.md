# ANIKAI Project History (Dated)

Compiled from:
- `git log --reverse --date=short --pretty=format:"%ad|%h|%s"`
- curated inclusions and domain catalog snapshots absorbed into source-of-truth

---

## Timeline Summary

### 2026-03-17 to 2026-03-19
- Baseline recovery, module stabilization, and early persona/optical/pet restoration.
- Companion direction began replacing legacy pet/embedded bridge patterns.

### 2026-03-20 to 2026-03-22
- Identity, guardian/safety, automation audit, memory routing, and consolidated intelligence surfaces expanded.
- Product framing and constitution alignment matured.

### 2026-03-23 to 2026-03-26
- Companion continuity, onboarding unification, runtime lane setup, and browse/setup quality passes.

### 2026-03-28 to 2026-03-31
- Companion live voice recovery work, model/runtime controls, local voice-pack onboarding, storage consolidation.
- Universal build defaults and runtime bundling strategy established.

### 2026-04-01
- Platform-first gate + OEM quirk register introduced as governing docs.

### 2026-04-02
- Migration architecture pivot documented in source-of-truth:
  - Root model clarified as `ui`, `soul`, `learning`, `memory`, `app-uses`, `integrations`.
  - Connector/pack/call-lane/surface-adapter boundaries formalized.
  - Guardrails locked: shared-pack promotion by reuse and no file over 500 lines.

---

## Key Dated Milestones

| Date | Commit | Milestone |
|---|---|---|
| 2026-03-17 | `715cd83` | Project backup baseline and recovery checkpoint |
| 2026-03-19 | `d3b5e4f` | Local lobby + ANIKAI-native control recovery |
| 2026-03-20 | `650942c` | Guardian safety/wellbeing mirror path |
| 2026-03-20 | `e17fdaf` | Consolidated intelligence console direction |
| 2026-03-21 | `f3b7c26` | Maps and voice companion flow expansion |
| 2026-03-22 | `300531e` | Companion-first interaction surface launch |
| 2026-03-24 | `1899186` | GGUF Vulkan benchmark lane |
| 2026-03-24 | `2f3205b` | GPU backend controls + reflex guidance |
| 2026-03-25 | `7ec3630` | Universal build defaults and tester simplification |
| 2026-03-29 | `cc5b921` | Companion observer + pulse-to-speech + partial STT |
| 2026-03-30 | `6a6ba41` | Local voice-pack onboarding and runtime bridge |
| 2026-03-31 | `b587ff9` | Universal build lock + bundled voice runtimes |
| 2026-04-01 | `a1e02af` | Android platform-first gate + OEM quirk register |
| 2026-04-02 | `docs-wave` | Source-of-truth migration architecture pivot + guardrails |

---

## Inclusions State Mapping

### Implemented and evolved
- Companion continuity and memory lanes.
- Guardian and automation audit lanes.
- GGUF/MLC runtime control surfaces.
- Universal build defaults with capability-driven routing.

### Started, evolved, or merged
- MLC lane: integrated as optional packaged lane.
- XTTS lane: runtime detection and setup path integrated; synthesis remains future backlog item.
- Multiple older plan docs were merged into runtime/onboarding/companion surfaces or moved to archive.

### On hold (useful, not fully complete)
- XTTS full synthesis adapter.
- Some expansion plan waves are tracked in `ANIKAI_FUTURE_IMPLEMENTATION_BACKLOG.md`.

---

## Full Commit History (Dated Index)

```text
2026-03-17|715cd83|backup: Work + legacy snapshot — Vault, Neural Link, Teaching/Sleep, Memory schema, permissions/options, overseer backlog, tools/teaching_trainer
2026-03-18|e545f77|checkpoint: LiteRT Student, soul injection, sovereignty, model path fix
2026-03-18|90edc84|chore: remove :app module and add Gradle wrapper
2026-03-18|213e796|fix(jarvis): add missing persona/voice settings fields
2026-03-18|1d1a527|feat(jarvis): add boot animation and optical cortex screens
2026-03-18|85e235c|fix(jarvis): restore build after new screens
2026-03-18|5261cd8|feat(jarvis): restore Optical Cortex scan pipeline
2026-03-18|2927146|feat(jarvis): restore AI Pet protocol
2026-03-18|2269935|feat(jarvis): wire persona calibration + boot animation
2026-03-18|933ef40|feat(jarvis): add Optical Cortex + AI Pet routes
2026-03-18|aebe424|feat(jarvis): align permission UI to cognitive anatomy
2026-03-18|99b3ac7|fix(jarvis): apply persona calibration to AI system prompt
2026-03-18|4aa14b4|chore(jarvis): canonicalize event type constants
2026-03-18|c9ca1c2|chore(jarvis): reduce Pet conflict alert noise
2026-03-18|12640d8|feat(jarvis): activate Pet observer mode per Team thread
2026-03-18|1fb07c4|feat(jarvis): post Pet observer join disclaimer
2026-03-18|1a34e57|feat(jarvis): swap-shifts detection + draft handshake in Pet mode
2026-03-18|bc7d68f|chore(jarvis): tighten swap confirmation gate
2026-03-18|a07fb97|chore(jarvis): remove magic event type strings
2026-03-18|061fc07|docs: move VAULT_API contract doc
2026-03-18|7ad8ac9|docs: remove root VAULT_API.md
2026-03-19|03402c3|chore(jarvis): checkpoint recovered project state
2026-03-19|7948e7f|refactor(jarvis): remove embedded work-app bridge
2026-03-19|c5c5f2e|refactor(jarvis): make pet chat ANIKAI-native
2026-03-19|d3b5e4f|feat(jarvis): add local lobby and restore AI controls
2026-03-19|a3b2755|feat(jarvis): expand local lobby room controls
2026-03-19|18e23c0|refactor(jarvis): polish local lobby room UX
2026-03-20|2e2bc44|feat(jarvis): evolve ANIKAI identity and health systems
2026-03-20|97b88b4|refactor(jarvis): rename room pet flows to companion
2026-03-20|650942c|feat(jarvis): add guardian safety and wellbeing mirror
2026-03-20|8591e1b|refactor(jarvis): reframe guardian copy as companion defenses
2026-03-20|fc556f2|docs(jarvis): refresh roadmap and feature maps
2026-03-20|8ffc6fb|feat(jarvis): align constitution and tier behavior
2026-03-20|e17fdaf|feat(jarvis): consolidate intelligence console
2026-03-20|0fa7e53|feat(jarvis): add mobile IDE copilot writes
2026-03-20|a7d77de|feat(jarvis): deepen teaching runtime and warmup polish
2026-03-20|3c270e6|fix(jarvis): harden warmup lifecycle cleanup
2026-03-20|8ddd5f2|feat(jarvis): align model compatibility guidance
2026-03-20|aa384b1|feat(jarvis): add teaching guide surfaces
2026-03-20|06ec30f|feat(jarvis): add guided screen control
2026-03-20|a1175a4|feat(jarvis): add automation audit screen
2026-03-20|ec222fa|feat(jarvis): expand settings task automation
2026-03-20|938e13b|feat(jarvis): broaden curated automation tasks
2026-03-20|df6c00e|feat(jarvis): add battery optimization assistant
2026-03-20|da03ced|feat(jarvis): add device care assistant
2026-03-20|a8f3d90|feat(jarvis): add bounded recovery cleanup tools
2026-03-20|88426e7|feat(jarvis): add memory routing context profiles
2026-03-20|a364644|feat(jarvis): make memory context event-first
2026-03-20|248217e|feat(jarvis): add prime aspect overlays
2026-03-20|ac36213|feat(jarvis): polish companion surfaces and browser handoff
2026-03-21|574f7af|perf(jarvis): gate prompt helpers by intent
2026-03-21|e3b4abb|feat(jarvis): show active supports in chat console
2026-03-21|d698ee5|feat(jarvis): make chat overlay sections collapsible
2026-03-21|c8c7e0d|feat(jarvis): add phase-a intent routing
2026-03-21|f3b7c26|feat(jarvis): add maps and voice companion flows
2026-03-21|4fc95e5|feat(jarvis): add sovereign utility boundaries and brain profiles
2026-03-21|63647d9|feat(jarvis): split permissions from abilities setup
2026-03-21|0a66985|feat(jarvis): finalize sovereign tester authority flow
2026-03-21|0670bf2|feat(jarvis): add private tester build guards
2026-03-21|744fa90|feat(jarvis): add model download help to onboarding
2026-03-21|f760178|refactor(jarvis): simplify onboarding model selection
2026-03-21|e6f4d1f|feat(jarvis): add curated gguf onboarding downloads
2026-03-21|010f9fa|refactor(jarvis): unify local runtime lanes
2026-03-21|8dd8292|feat(jarvis): polish onboarding-first product flow
2026-03-21|be64b0b|feat(jarvis): expose tester authority in onboarding
2026-03-21|55ea3ba|feat(jarvis): add ANIKAI identity foundation
2026-03-22|dc72288|feat(jarvis): regroup control plane around lumen pulse
2026-03-22|643a6de|docs: record engine and control-plane checkpoints
2026-03-22|5b501c9|feat(jarvis): align sovereign utility boundaries
2026-03-22|9509fae|feat(jarvis): extend control-plane identity
2026-03-22|0df0835|feat(jarvis): surface teaching runtime status
2026-03-22|d522cdc|feat(jarvis): turn home into a guided control console
2026-03-22|c0c6782|docs: archive completed plans and simplify roadmap docs
2026-03-22|4832ff4|feat(jarvis): align system constitution and tiering copy
2026-03-22|fc304d9|refactor(jarvis): tighten consolidated console language
2026-03-22|474f903|feat(jarvis): ship capability presence and Resona surfaces
2026-03-22|300531e|feat(jarvis): launch companion-first interaction surfaces
2026-03-23|177b1fc|feat(jarvis): deepen companion continuity and live presence
2026-03-23|db7924a|feat(jarvis): unify onboarding flow and app themes
2026-03-24|6631257|perf(jarvis): prewarm GGUF earlier and align NDK tooling
2026-03-24|5b8d6a8|feat(jarvis): vendor local GGUF and MLC runtimes
2026-03-24|2b88316|feat(jarvis): wire local runtime controls into companion flows
2026-03-24|8747fee|docs: capture local runtime packaging and validation
2026-03-24|f2dbc5d|feat(jarvis): tune GGUF warmup reuse and context depth
2026-03-24|1899186|feat(jarvis): add GGUF Vulkan benchmark lane
2026-03-24|2f3205b|feat(jarvis): add GPU backend controls and reflex guide lane
2026-03-24|6acb977|feat(jarvis): persist and surface reflex controls
2026-03-24|b292f64|chore(build): add native build wrapper and guide
2026-03-24|d9db88c|feat(jarvis): reserve managed reflex helper lane
2026-03-24|c7a1af0|feat(jarvis): surface tester runtime readiness
2026-03-24|a4b3eb1|feat(jarvis): activate managed reflex helper lane
2026-03-24|bf90b7b|feat(jarvis): harden helper warmup for live turns
2026-03-24|58d7838|chore(build): add universal tester build lane
2026-03-25|29f05c2|fix(jarvis): add clean local state reset
2026-03-25|8d9e2d3|fix(jarvis): keep tester authority override available
2026-03-25|94ee8db|chore(repo): ignore staged opencl prep sources
2026-03-25|7ec3630|feat(jarvis): simplify tester onboarding and default universal build
2026-03-25|77f937f|feat(jarvis): add floating tester diagnostics tools
2026-03-25|19776d0|feat(jarvis): simplify onboarding brain setup and browse flow
2026-03-25|46a42c0|fix(jarvis): restore simple live browse setup flow
2026-03-25|fed2849|fix(jarvis): show local ggufs in browse tab
2026-03-25|4017172|refactor(jarvis): split onboarding setup sections
2026-03-25|0b813bb|fix(jarvis): separate onboarding browse from recommended
2026-03-26|0207098|fix(jarvis): stabilize and polish onboarding flow
2026-03-26|3884354|fix(jarvis): refine onboarding device access copy
2026-03-26|e775d13|feat(jarvis): add deferred workspace and audience-aware handoff
2026-03-26|e869dbc|feat(jarvis): streamline onboarding and settings guidance
2026-03-28|a0570cd|feat(jarvis): restore companion soul and live voice flow
2026-03-29|ed0dc05|feat(jarvis): fix model reload perf, add turn trace, tune runtime profile
2026-03-29|68c2247|refactor(jarvis): remove old branding, capacity limits, and premium gates
2026-03-29|cc5b921|feat(jarvis): wire CompanionObserver, pulse-to-speech routing, and live partial STT
2026-03-29|a936099|fix(jarvis): resolve sealed class message access and composable scope errors
2026-03-29|84f5521|fix(jarvis): resolve setSystemPrompt crash and live voice session cycling
2026-03-29|2c1ec83|fix(jarvis): voice transcript delivery, token limits, and prewarm threading
2026-03-29|b20d12d|feat(jarvis): deepen Bond Store workflows and live companion flow
2026-03-29|a76aa0e|feat(jarvis): add persona voice profiles and memory callback diagnostics
2026-03-30|6a6ba41|feat(jarvis): ship local voice-pack onboarding and runtime bridge
2026-03-31|cac4974|feat(jarvis): unify companion memory lanes and storage controls
2026-03-31|a0c0c5e|docs: add full ANIKAI inclusions catalog
2026-03-31|c7a315f|feat(jarvis): polish Ikagi onboarding and home hero flow
2026-03-31|e6e0d9c|feat(jarvis): unify voice runtime onboarding for final build
2026-03-31|b587ff9|feat(jarvis): lock universal build and bundle voice runtimes
2026-03-31|bedc14d|docs(build): lock instructions to single universal path
2026-03-31|a939a1c|chore(jarvis): remove temporary XTTS asset docs files
2026-04-01|a1e02af|docs(platform): add Android gate and OEM quirk register
```

