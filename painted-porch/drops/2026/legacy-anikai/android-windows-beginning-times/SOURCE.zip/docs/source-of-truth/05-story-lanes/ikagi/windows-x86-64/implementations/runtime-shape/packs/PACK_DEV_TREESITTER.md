# Dev tree-sitter pack

| Field | Value |
|-------|-------|
| **Pack id** | `pack.dev.treesitter` |
| **Tier** | B |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Companion workspace awareness — parse project structure for codegen/refactor tools.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

Per-language tree-sitter WASM or native .dll set; lazy download by language.

## Staging path

`desktop-data/runtime-packs/dev.treesitter/`

## Unlocks (no model weights)

workspace-parse, symbol-outline

## Verification smoke

Parse package.json + one .ts file.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
