# GGUF model pack families (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

**Purpose:** Define how Anikai will **auto-route** dropped-in image GGUFs to the correct `sd.exe` CLI shape. Each **family** is one probe + one argument builder; individual HF repos are [`../models/MODEL_*.md`](../models/) sheets that map to a family.

**End game:** User places weights under `ANIKAI_HOME/models/` → app detects pack family → applies **profile defaults** (steps, CFG, size) → Media Magic / companion only need **prompt + optional style** — no manual `--vae` / encoder wiring.

**Engine reference:** `vendor/stable-diffusion.cpp/docs/` (authoritative CLI per family).

**Product rules:** [`GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  
**Per-repo sheets:** [`../models/`](../models/)  
**Lane index (E2E ticks):** [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)

---

## Router status legend

| Status | Meaning |
|--------|---------|
| **shipped** | Probe + `runImageGenerationMain` branch exists in `gguf-completion.js` |
| **partial** | Profiles / readiness only; routing incomplete |
| **planned** | Documented; implementation not started |
| **phase2** | Img2img / edit / vision — documented for later slice |

---

## Family registry

| `pack_family_id` | sd.cpp doc | CLI shape (summary) | Anikai router | Profile(s) | Phase |
|------------------|------------|---------------------|---------------|------------|-------|
| `flux1_clip_t5` | [`flux.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/flux.md) | `--diffusion-model` + `--vae` + `--clip_l` + `--t5xxl` | **shipped** (folder split-pack) | `flux_schnell_gguf`, `flux_dev_gguf`, `shuttle_31_flux` | txt2img; img2img `-i` phase2 |
| `flux1_chroma` | [`chroma.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/chroma.md) | flux1 + `--chroma-disable-dit-mask` | planned | *(chroma)* | txt2img |
| `flux1_kontext` | [`kontext.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/kontext.md) | flux1 encoders + **edit** `-r` | planned | *(kontext)* | **phase2** edit |
| `flux2_llm_vae` | [`flux2.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/flux2.md), [`ernie_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/ernie_image.md) | `--diffusion-model` + `--vae` + `--llm` | **shipped** (W1: klein 4B/9B, ERNIE, flux2-dev variants) | `flux2_klein_*`, `ernie_image_*`, `flux2_dev_gguf` | txt2img; img2img `-r` phase2 |
| `sd_single_m` | [`sd.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/sd.md) | `-m <one.gguf\|ckpt>` | **shipped** (W1) | `sd15_gguf` | txt2img now; img2img phase2 |
| `sdxl_single_m` | [`sd.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/sd.md) | `-m <xl.gguf>` optional `--vae` | **shipped** (W1) | `sdxl_gguf` | txt2img |
| `qwen_image_llm_vae` | [`qwen_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/qwen_image.md) | `--diffusion-model` + `qwen_image_vae` + Qwen2.5-VL + `--flow-shift` | planned | *(qwen_image)* | txt2img |
| `z_image_llm_vae` | [`z_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/z_image.md) | `--diffusion-model` + FLUX.1 `ae.sft` + Qwen3-4B | planned | *(z_image)* | txt2img |
| `sd3_clip_stack` | [`sd3.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/sd3.md) | `-m` or diffusion + `--clip_l` + `--clip_g` + `--t5xxl` | **shipped** | `sd3_medium_gguf`, `sd35_large_gguf` | txt2img |
| `ovis_llm_vae` | [`ovis_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/ovis_image.md) | `--diffusion-model` + `ae.sft` + Ovis LLM | planned | *(ovis)* | txt2img |
| `distilled_sdxl` | [`distilled_sd.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/distilled_sd.md) | Often `sd_single_m` / SDXL with tiny UNet | planned | *(ssd1b)* | txt2img |
| `wan_video` | [`wan.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/wan.md) | Video graph | **phase2** | — | **future** (video lane) |
| `qwen_image_edit` | [`qwen_image_edit.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/qwen_image_edit.md) | Edit pipeline | **phase2** | — | **future** (vision edit) |

---

## Detection order (proposal)

When `runImageGenerationMain` resolves a `.gguf` path, evaluate **most specific first** (avoid generic `flux` catching klein / chroma):

1. `flux2_llm_vae` — filename / tensor metadata: `flux2`, `klein`, `ernie-image`, `flux2-dev`  
2. `qwen_image_llm_vae` — `qwen-image`, `qwen_image`  
3. `z_image_llm_vae` — `z-image`, `z_image`  
4. `ovis_llm_vae` — `ovis-image`, `ovis_image`  
5. `flux1_chroma` — `chroma`  
6. `flux1_kontext` — `kontext`  
7. `flux1_clip_t5` — `flux1`, `flux.1`, `shuttle`, `schnell`, `flux-dev` (not flux2)  
8. `sd3_clip_stack` — `sd3`, `sd3.5`  
9. `sdxl_single_m` — `sdxl`, `xl-`  
10. `sd_single_m` — `sd-v1`, `v1-5`, `sd15`, default single-file  

If probe fails → **honest error** listing missing sidecars (never silent `single -m` for families that need encoders).

---

## Standard folder layouts (user drop-in)

### Optional `models/_shared/` (multi-pack / companion reuse)

Anikai seeds on first install (see `anikai-desktop/assets/models-folder/README.txt`):

```text
models/
  README.txt
  _shared/
    text-encoders/     # optional: one LLM/CLIP/T5 file reused by several packs
    vae/               # optional: shared VAE weights
  my-pack-a/ …
  my-pack-b/ …
```

Use when the **same** encoder or VAE is referenced from multiple image packs and/or the companion **chat/reasoning** slot (must still match the pack family’s expected encoder — see per-model sheets). Wire paths in **Models → Imaging sidecars → override**. If encoders are only used by one pack, keep them inside that pack folder instead.

### `sd_single_m`

```text
models/my-sd15/
  v1-5-pruned.q8_0.gguf
```

### `sdxl_single_m`

```text
models/my-sdxl/
  sdxl-base.q8_0.gguf
  vae/                          # optional if baked in
    sdxl_vae.safetensors
```

### `flux1_clip_t5` (Anikai split-pack convention)

```text
models/my-flux/
  flux1-schnell-Q4_K.gguf
  vae/ae.safetensors            # or ae.sft
  text_encoder/                 # clip_l
  text_encoder_2/               # t5xxl (sharded OK)
```

### `flux2_llm_vae`

```text
models/my-klein-9b/
  FLUX.2-klein-9B-Q4_K_S.gguf
  vae/flux2_ae.safetensors
  text_encoders/qwen_3_8b-….gguf
```

ERNIE-Image uses same shape; LLM slot = **Ministral 3B** (see ERNIE sheets).

### `qwen_image_llm_vae`

```text
models/my-qwen-image/
  qwen-image-Q8_0.gguf
  vae/qwen_image_vae.safetensors
  text_encoders/Qwen2.5-VL-7B-Instruct-….gguf
```

### `z_image_llm_vae`

```text
models/my-z-image/
  z_image_turbo-Q4_K.gguf
  vae/ae.sft
  text_encoders/Qwen3-4B-Instruct-….gguf
```

### `sd3_clip_stack`

```text
models/my-sd35/
  sd3.5_large.safetensors       # or .gguf when converted
  clip_l.safetensors
  clip_g.safetensors
  t5xxl_fp16.safetensors
```

---

## Manifest / preset mapping (future)

| Field | Role |
|-------|------|
| `pack_family_id` | Router key |
| `profile_id` | `sd-gguf-image-profiles.js` defaults |
| `preset_id` | Models panel + `media-models.json` row |
| `hf_repos[]` | Download hints (diffusion + sidecars) |
| `capabilities` | `txt2img`, `img2img`, `edit` (honest gating) |

---

## Model sheets by family

| Family | Sheets |
|--------|--------|
| `sd_single_m` | [`MODEL_GGUF_FAMILY_SD15_SINGLE_FILE.md`](../models/MODEL_GGUF_FAMILY_SD15_SINGLE_FILE.md), [`MODEL_CITY96_SD15_V15_GGUF.md`](../models/MODEL_CITY96_SD15_V15_GGUF.md) |
| `sdxl_single_m` | [`MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md`](../models/MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md), [`MODEL_CITY96_SDXL_GGUF.md`](../models/MODEL_CITY96_SDXL_GGUF.md) |
| `flux1_clip_t5` | [`MODEL_CITY96_FLUX1_SCHNELL_GGUF.md`](../models/MODEL_CITY96_FLUX1_SCHNELL_GGUF.md), [`MODEL_CITY96_FLUX1_DEV_GGUF.md`](../models/MODEL_CITY96_FLUX1_DEV_GGUF.md), [`MODEL_LEEJET_FLUX1_DEV_GGUF.md`](../models/MODEL_LEEJET_FLUX1_DEV_GGUF.md), [`MODEL_LEEJET_FLUX1_SCHNELL_GGUF.md`](../models/MODEL_LEEJET_FLUX1_SCHNELL_GGUF.md), [`MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC.md`](../models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC.md) |
| `flux1_chroma` | [`MODEL_SILVEROXIDES_CHROMA_GGUF.md`](../models/MODEL_SILVEROXIDES_CHROMA_GGUF.md) |
| `flux1_kontext` | [`MODEL_QUANTSTACK_FLUX1_KONTEXT_DEV_GGUF.md`](../models/MODEL_QUANTSTACK_FLUX1_KONTEXT_DEV_GGUF.md) |
| `flux2_llm_vae` | [`MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](../models/MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md), [`MODEL_LEEJET_FLUX2_KLEIN_4B_GGUF.md`](../models/MODEL_LEEJET_FLUX2_KLEIN_4B_GGUF.md), [`MODEL_LEEJET_FLUX2_KLEIN_9B_GGUF.md`](../models/MODEL_LEEJET_FLUX2_KLEIN_9B_GGUF.md), [`MODEL_CITY96_FLUX2_DEV_GGUF.md`](../models/MODEL_CITY96_FLUX2_DEV_GGUF.md), [`MODEL_UNSLOTH_ERNIE_IMAGE_GGUF.md`](../models/MODEL_UNSLOTH_ERNIE_IMAGE_GGUF.md), [`MODEL_UNSLOTH_ERNIE_IMAGE_TURBO_GGUF.md`](../models/MODEL_UNSLOTH_ERNIE_IMAGE_TURBO_GGUF.md) |
| `qwen_image_llm_vae` | [`MODEL_QUANTSTACK_QWEN_IMAGE_GGUF.md`](../models/MODEL_QUANTSTACK_QWEN_IMAGE_GGUF.md) |
| `z_image_llm_vae` | [`MODEL_UNSLOTH_Z_IMAGE_GGUF.md`](../models/MODEL_UNSLOTH_Z_IMAGE_GGUF.md), [`MODEL_LEEJET_Z_IMAGE_TURBO_GGUF.md`](../models/MODEL_LEEJET_Z_IMAGE_TURBO_GGUF.md) |
| `sd3_clip_stack` | [`MODEL_GGUF_SD3_MEDIUM.md`](../models/MODEL_GGUF_SD3_MEDIUM.md), [`MODEL_GGUF_SD35_LARGE.md`](../models/MODEL_GGUF_SD35_LARGE.md) |
| `ovis_llm_vae` | [`MODEL_LEEJET_OVIS_IMAGE_GGUF.md`](../models/MODEL_LEEJET_OVIS_IMAGE_GGUF.md) |
| `distilled_sdxl` | [`MODEL_SEGMIND_SSD1B_GGUF.md`](../models/MODEL_SEGMIND_SSD1B_GGUF.md) |

Diffusers-only / encoder-swap / non-GGUF rows remain in the lane index (FHDR, BFL full klein, ponpoke encoder doc — not a separate desktop catalogue stack).

---

## Implementation waves (GGUF)

| Wave | Families | Goal |
|------|----------|------|
| **W0** (now) | `flux1_clip_t5`, `flux2_llm_vae` (klein 9B) | Media Magic txt2img; readiness honesty |
| **W1** | Generalize `flux2_llm_vae` (ERNIE, klein 4B); `sd_single_m`, `sdxl_single_m` | **Shipped** in `gguf-completion.js` + profiles |
| **W2** | `qwen_image_llm_vae`, `z_image_llm_vae` | Latest CN / Alibaba stacks |
| **W3** | `sd3_clip_stack`, `flux1_chroma`, `ovis_llm_vae` | Breadth |
| **W4** | `flux1_kontext`, `qwen_image_edit`, img2img flags | Vision edit slice |

Music / video: **separate** lane docs when promoted; do not overload this file.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial pack-family registry, detection order, folder layouts, sheet index, implementation waves. |
| 2026-05-18 | W1 shipped: `classifyGgufImagePackFamily`, `buildFlux2LlmPackSdArgs`, SD1.5/SDXL single `-m`. |
