# GGUF music generation (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-10 |

Purpose: plan **local music-related generation** where a **GGUF** (or GGUF-class) **decoder** is part of the story—without pretending every chat LM is a music engine. This doc separates **what we might ship** (roles, outputs, handoffs) from **what must be proven** in native code and manifests.

**Audio lanes (read first):** [`../../AUDIO_GENERATION_LANES_OVERVIEW.md`](../../AUDIO_GENERATION_LANES_OVERVIEW.md) — explains the five lanes (parametric, MIDI+soundfont, ONNX SFX, codec-token neural, singing voice) and how Suno-style results are a pipeline of multiple models. This doc focuses on the GGUF slice of those lanes.

**Lane 2 renderer (MIDI + soundfont):** [`../../MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md`](../../MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md) — FluidR3 GM staging, FluidSynth, `generate_music`.

**GGUF engine (Windows):** [`../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Android music lane (reference scope, not identical stack):** [`../../../../../../android-arm64/implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](../../../../../../android-arm64/implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md)

**Model paths / import:** [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)

---

## Honest scope lanes

| Lane | Description | GGUF involvement |
|------|-------------|-------------------|
| **A — Textual / symbolic music** | Model outputs structured tokens (ABC, MIDI-like JSON, chord charts) consumed by a **separate renderer** (soft synth, sampler, or export). | GGUF `text_decode` only; **no** implied audio bytes from weights alone. |
| **B — Native audio decode in GGUF** | Only if/when a **validated** adapter exposes `audio_generation` or equivalent in the engine manifest with on-device proof. | Same rules as imaging: **engine plan + probe** before UI. |
| **C — Hybrid** | GGUF plans structure; external DSP or ONNX runs transforms. | Document handoff fields in output contract. |

Default until proven: **Lane A** is the only lane allowed in product copy; **B** stays behind explicit capability flags.

---

## Output contract (music layer)

When music generation runs, attach:

- `model_type_id` (e.g. `gguf_decoder_lm` for lane A, or `gguf_audio_decode` if lane B exists later),
- `representation` (`abc` | `midi_json` | `pcm_s16le` | …),
- `engine_adapter_id`,
- `renderer_id` (which component turns representation → playable audio).

---

## Linked todos

| Todo | Path |
|------|------|
| GGUF music desktop | [`../../../../../todo/mid-scope/TODO_GGUF_MUSIC_DESKTOP.md`](../../../../../todo/mid-scope/TODO_GGUF_MUSIC_DESKTOP.md) |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-10 | Initial GGUF music generation plan: lanes A/B/C, output contract, engine + Android music reference links. |
