# Model sheet — ERNIE-Image (Baidu Diffusers)

| Field | Value |
|-------|-------|
| **HF** | [baidu/ERNIE-Image](https://huggingface.co/baidu/ERNIE-Image) |

Native Diffusers tree with Baidu `text_encoder/model.safetensors`. GGUF stacks: [`../../gguf/models/MODEL_UNSLOTH_ERNIE_IMAGE_GGUF.md`](../../gguf/models/MODEL_UNSLOTH_ERNIE_IMAGE_GGUF.md).
