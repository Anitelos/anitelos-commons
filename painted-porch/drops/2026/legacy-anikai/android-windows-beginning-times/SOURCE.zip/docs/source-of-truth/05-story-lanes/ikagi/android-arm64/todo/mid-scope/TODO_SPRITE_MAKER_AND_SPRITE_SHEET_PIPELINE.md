# TODO — Sprite Maker + Sprite Sheet pipeline (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation docs

- `implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`
- `implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`
- `implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Deliver a single product flow from concept intake to tidy NESW still approval to sprite-sheet output.
- Keep model roles explicit: Flux primary, ONNX x4 post, and clear route selection.
- Prevent UI confusion by disabling invalid options based on current route/attachments/assigned models.
- Ensure animation style is not one-size-fits-all via archetype variation and profile-driven defaults.

---

## Checklist (working)

- [ ] Lock Sprite Maker route controls: prompt-only, ref+prompt, ref+vision-assist+prompt.
- [ ] Wire disable rules for route controls when prerequisites are missing (reference image, assigned lane).
- [ ] Keep model profile controls explicit (`Flux.1 default`, `Flux.2 experimental`) with disabled-state reasons when unavailable.
- [ ] Ensure local generation path uses Flux primary + ONNX x4 post in QUALITY where compatible.
- [ ] Add NESW approval gate before sprite-sheet compose can start.
- [ ] Define motion-archetype preset list (5-10) and map each to frame behavior profile.
- [ ] Implement auto-archetype selection from character profile (`background`, `identity`, `mission`) when user does not pick a preset.
- [ ] Keep user override available after auto-pick and before sheet build.
- [ ] Define Sprite Sheet Maker compose contract (input still set + archetype + frame plan + output layout).
- [ ] Export metadata trail including route/model profile/archetype/stage timings for each completed sheet.
- [ ] Validate two distinct archetype outcomes from different character profiles to prove non-uniform animation behavior.

---

## UI matrix rollout checkpoints

- [ ] Route matrix enforced: `Prompt only` / `Reference + prompt` / `Reference + vision assist + prompt` enable gates and reason strings match implementation doc.
- [ ] Model matrix enforced: `Flux.1`, `Flux.2`, and `ONNX x4 post` enable gates and reason strings match implementation doc.
- [ ] Primary action matrix enforced: `Generate NESW`, `Approve NESW set`, and `Generate sprite sheet` are blocked until required prerequisites pass.
- [ ] Archetype control matrix enforced: auto/manual/override controls follow profile-context and catalog availability gates.
- [ ] Disabled-state UX audit complete: disabled controls remain visible, dimmed, with concise reason text directly below control.

---

## Model readiness chips (planned)

- [ ] Add strip or chips for **Flux.1**, **Flux.2** (separate curated downloads + filename-based secondary scan), **ONNX x4**, **FOMM** (`missing` / `downloaded` / `ready`).
- [ ] Define **ready** rules: GGUF loadable; ONNX post resolver match; FOMM zip unpacked with `detector` + `generator` ONNX tokens present.
- [ ] Keep chips informational; toggle matrix remains authoritative for enabled actions.

---

## Animation dialog + preview checkpoints

- [ ] Add post-NESW animation dialog entry point (separate from still-generation controls).
- [ ] Implement facing selector options: `North`, `East`, `South`, `West`, `All`.
- [ ] Implement `All` mode ordered run (`N -> E -> S -> W`) with per-facing status updates.
- [ ] Block animation generation until NESW approval gate passes.
- [ ] Show numeric generation progress percent during sheet generation (with current-facing label in `All` mode).
- [ ] Enable in-place loop preview when sheet output is ready (single-facing immediately; all-facing when complete).
- [ ] Keep still fallback preview when animation frame generation fails for a facing.

---

## v1 deterministic sheet strip (frame row)

- [x] Baseline **8 frames per facing row** on v1 compose (fixed constant; subtle pixel-offset motion loop for smoother idle motion than a 4-frame strip). *Implemented in Sprite Sheet Maker (`V1_SHEET_FRAMES_PER_ROW`).*
- [ ] After baseline validates: optional **user or settings control** for frames-per-row (still capped by memory / export policy).
- [ ] After baseline validates: **archetype or frame-plan** selection maps to **alternate offset loops** (for-loop style variations: walk, bob, breathe, etc.) without duplicating pipeline entry points.

---

## Dual-lane motion model checkpoints (Qualcomm + fallback)

- [ ] Add Qualcomm FOMM lane capability probe (detector + generator session readiness).
- [ ] Add `v1 motion sheet pipeline` lane and keep it operational on non-Qualcomm devices.
- [ ] Implement lane selection policy: prefer Qualcomm lane when eligible, otherwise fallback.
- [ ] Add explicit UI/metadata lane label (`v2_motion_sheet_pipeline` vs `v1_motion_sheet_pipeline`) during generation and in exports.
- [ ] Add optional route toggle (`Auto` / `v1 motion sheet pipeline` / `v2 motion sheet pipeline (qualcomm, onnx strat)`).
- [ ] Validate parity pass: same NESW set can complete sprite-sheet generation through both lanes.

---

## Schema rollout checkpoints

- [ ] Define and persist `CharacterProfile` schema fields used for archetype auto-selection.
- [ ] Define and persist `SpritePipelineRunSpec` for route/model/preset/lane traceability.
- [ ] Define and persist `NeswArtifactSet` with approval flag and facing URIs.
- [ ] Define and persist `SpriteSheetComposeSpec` including `targetFacingMode` and archetype mode.
- [ ] Ensure exported metadata references schema ids (`runId`, `setId`, `composeId`) for auditability.

---

## Linked operations

- `todo/mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md`
- `todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (parent dependency)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Added **v1 sheet strip** checkpoints: 8 frames/row shipped; future items for configurable frame count and archetype-driven offset loops. |
| 2026-05-06 | Added Qualcomm motion lane + universal fallback execution checkpoints with explicit lane labeling and user override requirement. |
| 2026-05-06 | Added animation dialog/preview checkpoints and schema rollout checkpoints for implementation tracking. |
| 2026-05-06 | Added UI matrix rollout checkpoints so route/model/action/archetype disable-state logic is tracked in execution checklist. |
| 2026-05-06 | Created combined Sprite Maker + Sprite Sheet mid-scope todo with disable-state UX, archetype variation, and metadata tracking checklist. |
