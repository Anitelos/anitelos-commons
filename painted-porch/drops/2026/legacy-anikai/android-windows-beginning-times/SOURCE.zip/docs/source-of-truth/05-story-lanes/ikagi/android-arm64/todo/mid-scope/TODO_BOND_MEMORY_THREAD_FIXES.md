# TODO — Bond memory/thread fixes (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/companion-surface/BOND_STORE_ISSUES_AND_FIXES_PLAN.md`

---

## Intent

- Maintain execution handle for Bond/Meridian memory thread issues and fix plan.
- Keep the roadmap historical context, but track actionable work in todo form.
- Ensure thread model handoff and storage contract references stay synced.

---

## Checklist (working)

- [ ] Extract current open implementation items from the Bond fixes plan into active subtasks.
- [ ] Reconcile storage/runtime links now that docs live under story lanes.
- [ ] Keep progress log entries mirrored with dated todo updates.
- [ ] Set each item status (`In progress` / `Operational` / `Needs revisit`).

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created todo bridge for Bond memory/thread implementation plan. |
