# Companion media library & vision memory (Desktop)

| Field | Value |
|-------|-------|
| **Doc staging** | In progress |
| **Operations** | M0–M4 shipped (desktop) |
| **Last reviewed** | 2026-05-17 |

**Purpose:** Per-companion **kept files** (image, audio, video), **catalog captions**, and **prompt injection** so chat can reference earlier media without rescanning every turn — with honest metadata about what was actually encoded, transcribed, or only described from metadata.

**Related:** [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) (B3 micro-captions), [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](WORKFORCE_AND_ORCHESTRATION_VISION.md), [`LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md).

**Code (2026-05-17):** `main-process/companion-media-library.js`, `project-media-library.js`, `media-comparisons-store.js`, `media-ffmpeg.js`, `shared/media-file-kinds.js`, `shared/media-preflight-prompts.js`, `shared/companion-media-library-prompt.js`; IPC in `main.js`; wired in `components/chat.js` (ingest, library prompt block, footer metadata, profile library list + rescan, ¬ refs, preflight scans for image/audio/video, media access report, turn summary chips). **M0–M4 done** (chat-only; no Companion panel Files tab).

---

## 1. Problem today

| Behavior | Limit |
|----------|--------|
| `imagePath` on send | Only the **current** attachment is passed to mtmd — **one image per inference call**. |
| Follow-up text (“Vivre is male…”) | Model sees **recent text** only; prior images are **not** re-fed unless attached again. |
| Recovery pass (image turn) | After planning thought exists, recovery may be **text-only** — no second vision pass. |
| Message storage | Attachments were not always persisted on disk with the thread — history lost paths. |
| Message footer | Shows chat model + CUDA; does **not** say whether **vision / mmproj** ran this turn. |

So in a two-image thread (sketch → group lineup), the companion can sound confident while only **one** image was ever encoded — or none on a text-only follow-up.

---

## 2. Target: per-companion home folder

Under `ANIKAI_HOME`:

```text
companions/
  <companionId>/
    config.json          # mirror / overlay of configs/companions/<id>.json
    thread.json          # optional export; primary chat still in renderer localStorage until migrated
    media/
      index.json         # catalog of kept files
      files/
        <mediaId>_<safeName>.png   # copy or hardlink of dropped path
    journal/             # later: companion-scoped notes
```

**`media/index.json` entry (v1):**

```json
{
  "id": "m_abc123",
  "originalName": "asta-luna-party.png",
  "storedPath": "files/m_abc123_asta-luna-party.png",
  "contentHash": "sha256:…",
  "mime": "image/png",
  "mediaKind": "image",
  "firstSeenAt": "2026-05-16T…",
  "lastUsedAt": "2026-05-16T…",
  "caption": "Six fantasy characters in a dark painterly lineup; labels include Vivre, Cora, …",
  "captionSource": "vision_turn|micro_caption|user_edit",
  "captionModelRef": "…/mmproj….gguf",
  "threadRefs": ["msgTs1", "msgTs2"]
}
```

**Dedup:** Same `contentHash` or same `originalName` in this companion folder → reuse entry; optional **Rescan / rewrite captions** toggle re-runs vision and updates `caption`.

---

## 3. Turn routing (conversation flow)

```mermaid
flowchart TD
  Send[User sends message] --> Att{Attachment this turn?}
  Att -->|yes| InLib{In companion media index?}
  InLib -->|no or force rescan| Vision[mtmd: encode image + plan/reply]
  InLib -->|yes, fresh caption| Inject[Inject caption block into prompt]
  Att -->|no| Ref{Text references prior media?}
  Ref -->|yes| Inject
  Ref -->|no| Text[Text-only GGUF]
  Vision --> Save[Upsert index.json + copy file]
  Save --> Inject
  Inject --> Gen[Generate reply]
```

**Prompt block (sketch):**

```text
Companion media library (already seen — do not claim you cannot see these):
- [m_1] vivre-sketch.jpg: "Profile pencil sketch, sharp jaw, flowing hair…" (seen 2026-05-16)
- [m_2] asta-luna-party.png: "Six-character dark fantasy lineup…" (seen 2026-05-16)

Current turn: user attached [m_2] — full vision pass this turn.
```

**Compare two images:** User asks to compare A and B:

- If both have captions → inject both; optional **Rescan both** runs two micro-captions or one mtmd pass with **current** attach only (v1: micro-caption pass per file, then text planner).
- v2: multi-image mtmd / llama-server when E+ lands.

---

## 4. Message footer metadata

Extend `inferenceMeta` on AI messages:

| Field | Meaning |
|-------|---------|
| `visionUsed` | `true` if mmproj+image ran this completion |
| `mmprojRef` | Projector file (basename for UI) |
| `imageAttached` | `true` if this turn had user attachment |
| `mediaIds` | Library ids used from cache (no rescan) |
| `visionRescan` | User toggled force rescan |
| `temperatureUsed` | Sampling temp from the completion (when auto rails) |
| `thoughtBudgetPct` | Companion inference policy thought % |
| `preflightScans` | Count of sequential vision scans before main reply |

**Footer example:**  
`Gemma-4 … · CUDA on · ~410 tok · vision · mmproj-Gemma-…gguf · library: m_1,m_2`  
or  
`… · text only · library: m_1 (cached)`  

---

## 5. UI surfaces (chat-first — no extra panel tabs)

| Surface | v1 | later |
|---------|----|-------|
| Chat | Attach, ¬ refs, preflight thought blocks, footer (`vision` / `library` / `text only`), media access errors in reply | In-chat image gen from discussion |
| Companion profile (from chat header) | Media library list, **Rescan** checkbox, open folder | Optional caption edit inline |
| Group thread | Project media under `group-threads/<id>/media/`; vision lead for preflight | — |

**Not planned:** a separate **Files** tab on the Companion panel — avoids more UI; library management stays in chat + profile.

**Rescan toggle (companion profile):** “When the same filename is attached again, refresh vision caption.” Shipped in profile dialog.

---

## 6. Phasing

| Phase | Deliverable | Status |
|-------|-------------|--------|
| **M0** | Persist `attachment` on messages (library paths); footer shows `vision` / `text only` / `library · ids` + mmproj basename | Done |
| **M1** | IPC: ingest attachment → `companions/<id>/media/`; `index.json`; caption via preflight scan or micro-caption | Done |
| **M2** | Inject library block on text-only turns; cached captions when same file reattached (no redundant vision) | Done |
| **M3** | Chat-only polish: compare notes visible in chat (summary chips + expanded compare block), preflight/compare skip notices, ¬ picker hints (comparison pairs, no-caption warn), media access honesty (no new panel tab) | Done |
| **M4** | Audio/video ingest + library `mediaKind`; preflight captions (audio text/ASR-ready; video poster frame + vision when ffmpeg/mmproj); attach picker; honest access report | Done |

**Rescan** is not M3 — it shipped with the companion profile block (M0–M2 era).

### What M0 “library paths” means (not the same as “project paths”)

| Storage | When | Path on disk |
|---------|------|----------------|
| **Companion library** (M0) | Solo chat: user attaches an image | `ANIKAI_HOME/companions/<companionId>/media/files/<mediaId>_name.png` |
| **Project library** (group) | Group chat: attachment on a project thread | `ANIKAI_HOME/group-threads/<groupId>/media/files/<pmId>_name.png` |

**M0 change:** Before, the chat bubble often stored the **file picker’s temp path** (e.g. under Downloads or a one-off path). After reload, thumbnails broke and the app could not find the file. Now ingest runs **before** the user message is saved, and the message stores the **stable library copy** under `companions/.../media/files/`. That is for **per-companion** memory, not for opening arbitrary project folders on disk.

**Project paths** are the parallel lane for **group threads** (same ingest + index pattern, different root folder). Solo companions can still **read** project libraries in prompt (profile → “Projects involved in”) without a separate Files tab.

### Project media library (group threads)

Per-project storage (same roster as group **memberIds**):

```
ANIKAI_HOME/group-threads/<groupId>/media/
  index.json
  files/<pm_…>_<name>.ext
```

- Group chat attachments ingest here (not into individual companion folders).
- **One vision lead** per round: member with the largest chat model (name heuristic, e.g. `12B`) + mmproj runs preflight scans; others use project captions only.
- Solo threads: companions see project libraries for every group they belong to (profile → **Projects involved in**).
- Reference without re-drop: type **¬** mid-sentence (like `@`) to pick from personal + accessible project media (`¬[pm_…]` tokens).

Plans remain under `group-threads/<id>/plan/` (draft, anchor, revisions).

**Pairwise comparisons** (separate from per-file captions):

```
<mediaRoot>/comparisons.json   # e.g. sketch.png vs lineup.png notes
```

- Preflight multi-image compare saves here automatically.
- Model tools (no UI toggles): `media_ephemeral_scan` (vision for this question only — never overwrites catalog caption), `media_pair_compare` (stored pair note for regressions / future diffs).

### Multi-image preflight (until Phase E+ multi-`imagePath`)

When the user attaches **two or more new** library files in one turn:

1. **Ingest** each file (hash dedupe).
2. **Preflight scan** — one vision call per new file → standalone `<thought>` + `CAPTION:` line saved to library (uncompared descriptions).
3. **Compare pass** (optional) — text-only thought when 2+ new scans, relating captions to the user question.
4. **Main reply** — text-only planning + answer using library block (no second vision on those files).

Cached-only attachments skip scans; the main thought uses library captions. UI shows separate collapsible thought blocks: `Viewing filename`, then `Comparing references`, then the usual planning thought.

**Later:** in-chat image generation from discussion (no mode switch); img2img with prompt shaping + reference image pass-through.

---

## 7. What the model can “see” or “hear” (M4 reference)

This section is the **setup + pass-through checklist** for images, audio, and video in chat. The companion never gets raw pixels or audio waveforms in the **main planning/reply** path unless noted — it gets **library captions** and optional **one-shot vision** on attach.

### 7.1 One-page matrix

| Media kind | Stored in library | Preflight (before main reply) | What goes into the **main** GGUF prompt | Follow-up turns (no re-attach) |
|------------|-------------------|-------------------------------|----------------------------------------|----------------------------------|
| **Image** | Copy under `media/files/` + `index.json` | **Vision** via `llama-mtmd-cli` + **mmproj** → `CAPTION:` saved | **Text-only** library block + captions; **not** re-encoding image unless single new image + mmproj (legacy `imagePath` path) | Library captions + `¬[m_…]` refs; optional `media_ephemeral_scan` tool for fresh vision |
| **Audio** | Same | **Chat model** text scan (filename, size, duration); **no waveform** | Library **caption text** only (may say “audio not transcribed”) | Same; **no true “hearing”** until ASR is wired |
| **Video** | Same | **ffmpeg** extracts **one poster frame** (if available) → **vision** on frame if **mmproj**; else chat text scan | Library caption (poster-frame description or honest “not visually scanned”) | Same; tools cannot play video — only stored caption + ephemeral scan on poster |

**Rule of thumb:** After preflight, the model “knows” the file from **words in `index.json`**, not from re-opening the file each turn.

### 7.2 What you need installed / assigned (operator checklist)

| Requirement | Images | Audio | Video | Where to set |
|-------------|--------|-------|-------|----------------|
| **Chat GGUF** (text) | Required for preflight + reply | Required | Required | Companion → Models → **Chat** slot |
| **mmproj** (vision projector) | Required for vision preflight & ephemeral image scan | Not used | Required for **poster-frame** vision (not full video) | Companion → Models → **mmproj** slot (pairs with chat model family) |
| **llama-mtmd-cli** (bundled with llama runtime) | Used for vision one-shots | — | Used when scanning poster frame | Shipped with desktop llama-bin / dev `vendor/llama.cpp` build |
| **ffmpeg** on PATH (optional) | — | — | **Poster frame** extract (`ANIKAI_FFMPEG` override) | OS install; without it, video gets **text-only** preflight |
| **Audio / ASR model** (e.g. whisper GGUF) | — | **Not wired yet** — captions are honest about missing transcription | — | Companion → Models → **Audio** slot (future) |
| **CUDA / VRAM** | Vision loads chat + mmproj | Text-only scan is light | Poster + vision is one frame | Models panel runtime |

**Group chat:** One **preflight lead** per round — largest chat model; **mmproj** only if the attach queue includes **image or video**. Audio-only attachments can preflight with **chat only** (no mmproj on the lead).

### 7.3 Supported file types (attach picker)

| Kind | Extensions (v1) |
|------|-----------------|
| Image | `.png`, `.jpg`, `.jpeg`, `.webp`, `.gif`, `.bmp`, `.avif` (ingest also allows `.heic`) |
| Audio | `.mp3`, `.wav`, `.m4a`, `.aac`, `.ogg`, `.opus`, `.flac`, `.wma`, `.aiff` |
| Video | `.mp4`, `.mkv`, `.webm`, `.mov`, `.avi`, `.m4v`, `.wmv`, `.mpeg`, `.mpg` |

Unsupported types are rejected at ingest (`unsupported_media_type`) and surfaced in the **Media access report**.

### 7.4 End-to-end: what passes into chat on send

```mermaid
flowchart TD
  subgraph user [User]
    A[Attach file(s) or type ¬ refs]
    M[Send message]
  end
  subgraph ingest [Main process — always]
    I[Copy to library path]
    X[index.json + mediaKind]
  end
  subgraph pre [Preflight — if new or rescan]
    P1[Image: mtmd + mmproj]
    P2[Audio: chat text scan]
    P3[Video: ffmpeg poster then optional mtmd]
    C[Optional compare pass 2+ files]
  end
  subgraph prompt [Planning prompt]
    L[Companion media library block]
    R[Media access report if blocked]
    T[Tools hint: ephemeral_scan / pair_compare]
  end
  subgraph main [Main GGUF turn]
    G[Text-only thought + reply uses captions]
    V[Exception: single image + mmproj may pass imagePath]
  end
  A --> M
  M --> I --> X
  X --> P1
  X --> P2
  X --> P3
  P1 --> C
  P2 --> C
  P3 --> C
  C --> L
  X --> L
  L --> R --> G
  G --> V
```

**Step by step:**

1. **Attach** — Chat attach button → `dialog:pick-media-files` (or legacy image-only picker). Paths are **not** stored on the user bubble until ingest succeeds.
2. **Ingest** (IPC `companions:media-ingest` / `projects:media-ingest`) — File copied to `ANIKAI_HOME/.../media/files/<id>_name.ext`. Returns `mediaId`, `mediaKind`, `needsCaptionThisTurn`, `needsVisionThisTurn` (images only).
3. **Preflight** (if queue non-empty) — Collapsible thought blocks in the **assistant** bubble:
   - `Viewing …` — image vision scan  
   - `Listening to …` — audio catalog scan  
   - `Reviewing …` — video (poster or text)  
   - `Comparing references` — when 2+ new files scanned  
   - **Notice** blocks if preflight/compare skipped  
4. **Prompt injection** — `buildCompanionMediaLibraryPromptBlock()` adds:
   - Per-file lines: `[m_id] name: "caption" (seen date)`  
   - Project libraries for groups the companion belongs to  
   - `comparisons.json` pairwise notes  
   - **Media access report** listing failures + fixes  
5. **Main reply** — Default: **no** image bytes in the main completion after preflight. Exception: exactly **one** new **image** attach + mmproj may still set `imagePath` on the main turn (solo); group rounds use library text only after preflight.
6. **Persistence** — User message stores **library absolute paths**, not temp picker paths. AI footer may show `preflight ×N`, `media · image,audio`, `compare saved`, `vision` / `text only` / `media blocked`.

### 7.5 Referencing media without re-attaching

| Method | What happens |
|--------|----------------|
| **¬ picker** | Type `¬` in the composer → pick from companion + accessible project libraries → inserts `¬[m_abc]` or `¬[pm_xyz]`. Resolves to library ids; **no** file re-ingest if caption exists. |
| **Re-attach same bytes** | Hash match → reuse entry; caption reused unless **Rescan** enabled in companion profile. |
| **`media_ephemeral_scan` tool** | Model requests one-off vision for a library id; does **not** overwrite catalog caption. Needs **mmproj** + image (or video poster path). |
| **`media_pair_compare` tool** | Writes/reads `comparisons.json`; text planner compares two **existing** captions. |

### 7.6 What is *not* passed to the model today

| Capability | Status |
|------------|--------|
| Full **video** decode (motion, sound on timeline) | **No** — one poster frame max |
| **Audio transcription** (whisper / ASR) | **No** — audio slot exists in schema but desktop does not run ASR yet |
| **Multiple images** in one `imagePath` / mtmd call | **No** — sequential preflight scans; compare is text-on-captions |
| Raw file bytes in prompt | **No** — only captions and optional single image path |
| Companion “watching” user screen / mic | **No** — attach or library only |

### 7.7 Honesty & UI signals

If something failed, the user should see it in:

- **Preflight notice** thought blocks (“Preflight skipped”, “Compare skipped”)  
- **Media access report** in the planning prompt (model instructed to explain in plain language)  
- **Turn summary chips** (e.g. “Compare not saved”, “N media issues”)  
- **Message footer**: `media blocked`, `attach · vision blocked`, `attach · no vision`, `library · m_1,pm_2`, `media · audio,video`

See §8 (formerly §7) for the product honesty rule.

### 7.8 Future: true “read/hear/watch”

| Upgrade | Enables |
|---------|---------|
| **ASR** on audio slot (whisper.cpp / GGUF) | Real speech in `caption`; honest “transcribed” preflight |
| **ffmpeg** audio extract + ASR | Video dialogue in catalog |
| **Phase E+** `llama-server` + multimodal session | Faster rescans; eventual multi-image session API |
| **In-chat generation** (later M?) | Discuss → generate image without leaving thread |

---

## 8. Honesty rule

If no vision pass and no library caption exists for a referenced file, the companion must report **why** (ingest failed, no mmproj, scan failed, preflight skipped) and a **fix** when known — injected via `Media access report` in the planning prompt (`shared/companion-media-library-prompt.js`). Never imply sight without `visionUsed` or a library `caption`. Do not silently fall back to ephemeral picker paths as fake vision input.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-16 | Initial plan: M0–M4 phasing, project media, comparisons. |
| 2026-05-17 | M0–M2 wired in chat (ingest, library injection, footer, cached reattach). |
| 2026-05-17 | Clarify: no Companion panel Files tab; M3 = chat-only; rescan in profile. |
| 2026-05-17 | Media access report (honest failures, no fake vision paths). |
| 2026-05-17 | M4: audio/video ingest, preflight captions, ffmpeg poster frames, media attach picker. |
| 2026-05-17 | §7 operator matrix: requirements per media kind, chat pass-through, not-yet list. |
