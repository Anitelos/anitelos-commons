# GGUF text generation (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-09 |

Purpose: **text generation** product and capability contract for the **`gguf_decoder_lm`** model type on Windows—what the user sees (chat, roles, streaming, handoffs), how it maps to **engine** tasks, and which **todos** track delivery. For **load, probe, JNI/FFI, and task matrix**, use the engine plan linked below.

**Lane index (all text model types on Windows):** [`../TEXT_GENERATION_LANE_INDEX.md`](../TEXT_GENERATION_LANE_INDEX.md)

**Engine (wrapper / execution):** [`../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Android GGUF engine parity (concepts):** [`../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Desktop models directory + import:** [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md) (includes **Local GGUF chat**: building `llama-completion` from `vendor/llama.cpp` and `ANIKAI_LLAMA_*` env vars for the Electron bridge.)

---

## Scope

This file covers **GGUF-backed text generation** on Windows:

- capability ids exposed to **companion + panels**,
- **role** mapping hints (T1–T5) for this type,
- **output contract** fields for downstream lanes,
- relations to **vision-conditional** text when the engine declares `vision_understand`.

This file does **not** redefine engine load mechanics (see engine-inference GGUF plan).

---

## Model type id

| id | Typical artifacts |
|----|-------------------|
| `gguf_decoder_lm` | `.gguf`; optional projector sidecars for multimodal **understanding** |

---

## Capabilities (user-facing slices)

Each row is a stable **`capability_id`** for UI, manifest, and logs. Implementation must match **engine** prerequisites from the engine plan (`text_decode`, sidecars, etc.).

| capability_id | User-visible meaning | Engine prerequisite | Notes |
|-----------------|----------------------|---------------------|--------|
| `chat_stream` | Token stream into companion UI | `text_decode` + streaming path | Primary desktop experience. |
| `chat_complete` | Single-shot completion | `text_decode` | Tools / batch / fallbacks. |
| `long_context` | Extended context window | Manifest `ctx_max` + successful probe | May trade against T1 latency. |
| `tool_friendly_output` | Structured or parse-friendly output | Runtime + prompting / grammar as available | Pipelines / handover. |
| `vision_conditional_text` | Answer about attached image | `vision_understand` + required sidecars | Sentience may **supply** frames; engine owns decode. |

Future: split any hot row into `generation/text/gguf/capabilities/<capability_id>.md` if it outgrows this page.

---

## Role mapping (policy, not brand lock-in)

Reuse Android T1–T5 semantics; scheduler picks role from **latency, depth, memory**, not from filename:

| Role | Typical GGUF profile on desktop |
|------|----------------------------------|
| T1 Fast live chat | Smaller quant, shorter ctx, aggressive decode settings |
| T3 Deep reasoner | Larger weights, higher ctx, slower lane |

Full taxonomy: [`../../../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`](../../../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md)

---

## Model relations (within text generation)

```mermaid
flowchart LR
  subgraph type [gguf_decoder_lm]
    CAPS[capabilities table]
  end
  subgraph roles [T1-T5]
    T1[T1]
    T3[T3]
  end
  subgraph engine [Engine inference]
    EP[GGUF engine plan / probe]
  end
  CAPS --> EP
  EP --> T1
  EP --> T3
```

---

## Output contract (text generation layer)

Every completion (stream or batch) should carry:

- `model_type_id` → `gguf_decoder_lm`
- `bundle_id` / file fingerprint
- `role_id` when assigned (`T1`…`T5`)
- `engine_adapter_id`
- optional `quality_hint` / stop reason

Downstream **voice** or **sentience** consumes these fields without re-probing the file.

---

## Linked docs

| Topic | Path |
|-------|------|
| Lane index | [`../TEXT_GENERATION_LANE_INDEX.md`](../TEXT_GENERATION_LANE_INDEX.md) |
| Engine GGUF | [`../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| **Per-model notes** | [`models/README.md`](models/README.md) — Gemma 4 E4B: [`models/GEMMA4_E4B_ANIKAI.md`](models/GEMMA4_E4B_ANIKAI.md) |
| Chat timeline phased plan | [`CHAT_TURN_TIMELINE_PHASED_PLAN.md`](CHAT_TURN_TIMELINE_PHASED_PLAN.md) |

---

## Linked todos

| Todo | Path |
|------|------|
| GGUF text on desktop | [`../../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) |
| Windows text roles | [`../../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md) |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Split from monolithic `TEXT_GENERATION_MODEL_TYPES_AND_CAPABILITIES.md`; GGUF-only text generation plan with capability table, roles, output contract, engine + todo links (Android-style). |
| 2026-05-10 | Model download doc path → `companion-surface/…`; cross-link to Local GGUF build + env section. |
| 2026-05-20 | `models/` folder + Gemma 4 E4B Anikai doc; chat turn timeline phased plan. |
