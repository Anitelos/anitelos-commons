# Model sheet — family: SD 1.x single-file GGUF (`sd_single_m`)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## What it is

**Stable Diffusion 1.4 / 1.5 / 2.x** checkpoints converted to a **single `.gguf`** (or legacy `.ckpt` / `.safetensors`) loaded with `sd-cli -m <file>`. No separate CLIP/T5 folders. Lowest-friction “drop one file” path for Anikai plug-and-play.

**Pack family:** `sd_single_m` — see [`../gguf/GGUF_MODEL_PACK_FAMILIES.md`](../gguf/GGUF_MODEL_PACK_FAMILIES.md).

## Representative HF GGUF sources

| Publisher | Repo | Notes |
|-----------|------|--------|
| city96 | [stable-diffusion-v1-5-gguf](https://huggingface.co/city96/stable-diffusion-v1-5-gguf) | Common desktop smoke target |
| TheBloke / community | Various `*sd-v1-5*.gguf` | Same family; verify graph in smoke |
| User-converted | `sd-cli -M convert` from [runwayml/stable-diffusion-v1-5](https://huggingface.co/runwayml/stable-diffusion-v1-5) | Offline conversion per [`quantization_and_gguf.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/quantization_and_gguf.md) |

## Weight layout

```text
models/<any-name>/
  v1-5-pruned-emaonly.q8_0.gguf
```

## sd.cpp reference

```text
sd-cli -m ../models/v1-5-pruned-emaonly.q8_0.gguf -p "a lovely cat" -H 512 -W 512
```

## Anikai (proposal)

| Item | Value |
|------|--------|
| **Profile id** | `sd15_gguf` (exists in `sd-gguf-image-profiles.js`) |
| **Defaults** | 512², 28 steps, cfg 7, euler_a |
| **Router** | `planned` — detect `sd15`/`v1-5`/`sd-v1` in basename → `sd_single_m`, skip flux probes |
| **Img2img** | phase2 — `-i` + `--strength` per `sd.md` |

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- Example repo sheet: [`MODEL_CITY96_SD15_V15_GGUF.md`](./MODEL_CITY96_SD15_V15_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Family umbrella sheet for SD1.5-class single GGUF. |
