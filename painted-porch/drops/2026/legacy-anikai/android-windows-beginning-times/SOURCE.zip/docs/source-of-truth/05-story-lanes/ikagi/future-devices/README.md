# Future devices (iPhone, VR, …)

**Scope:** anything not Android-first—enough structure to **capture** without pretending parity exists yet.
