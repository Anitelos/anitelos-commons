# GGUF model family notes (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Reference |
| **Last reviewed** | 2026-05-20 |

Per-model (or per-family) notes for **how Anikai Desktop actually runs** a weight file — not generic HF cards. Use this folder when a model needs custom prompts, engine flags, parser templates, or known failure modes.

**Parent lane:** [`../GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md)

**Chat UX / timeline phased plan:** [`../CHAT_TURN_TIMELINE_PHASED_PLAN.md`](../CHAT_TURN_TIMELINE_PHASED_PLAN.md)

---

## Documents

| Model / family | File | Status |
|----------------|------|--------|
| Gemma 4 E4B (chat + mmproj) | [`GEMMA4_E4B_ANIKAI.md`](GEMMA4_E4B_ANIKAI.md) | Living doc — issues + planned Anikai fixes |
| SmolLM2-Rethink-360M (familiar / classifier) | [`SMOLLM2_RETHINK_360M_ANIKAI.md`](SMOLLM2_RETHINK_360M_ANIKAI.md) | Optional reflex router |

Add new rows when a second primary chat template (Qwen-VL, Phi, etc.) needs the same level of operational detail.

**Familiars (reflex layer):** [`../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md`](../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md) · [`FAMILIAR_ROLES.md`](../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md)
