# TODO — GGUF music generation on desktop (Windows x86-64, mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-20 |

---

## Source implementation docs

- `implementations/generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Start from **Lane A** (symbolic / textual music representation + separate renderer) unless/until **Lane B** (native audio decode from GGUF) is proven on device.
- Keep product copy honest: no implied “GGUF = full song audio” without capability flags and probes.

---

## Checklist (working)

- [x] Representation contract v1: `midi_json` / `planJson` + ABC subset → `midi-composition-parser.js` → Lane 2 renderer.
- [x] GGUF arranger: chat slot → JSON plan (`gguf-music-arranger.js`, `arranger="gguf"` on `generate_music`).
- [ ] If pursuing native audio decode (Lane B), add engine manifest fields + probe gates.
- [ ] Desktop UX: document export / play paths in About guide (partial — outputs under `generated-media/audio/`).

---

## Linked operations

- `../../../android-arm64/implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-10 | Created GGUF music desktop todo linked to GGUF music generation plan. |
