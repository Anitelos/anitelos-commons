# Model sheet — leejet / Ovis-Image-7B-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [leejet/Ovis-Image-7B-GGUF](https://huggingface.co/leejet/Ovis-Image-7B-GGUF)  
- **FLUX.1 ae (recommended, Apache-2.0):** [second-state/FLUX.1-schnell-GGUF — ae.safetensors](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/resolve/main/ae.safetensors) (or [tree/main](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main)).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- sd.cpp: [`ovis_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/ovis_image.md)  

## Pack family

`ovis_llm_vae` — diffusion GGUF + FLUX.1 `ae.sft` + Ovis 2.5 text encoder.

## Weight layout

```text
models/ovis-image/
  ovis_image-Q4_0.gguf
  vae/ae.sft
  text_encoders/ovis_2.5.safetensors
```

## Product

- **Preset id:** `ovis_image_gguf_leejet`  
- **Profile (proposal):** `ovis_image_gguf` — cfg 5, offload flags  

## Anikai router

`planned`

## Checklist

- [ ] Router + probe  
- [ ] E2E smoke  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
