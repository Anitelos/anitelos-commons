# Frame Rate Noise Playbook (Android / Compose / API 35)

Use this to keep AI tracing readable while still being able to investigate `setRequestedFrameRate(... NaN)` spam when needed.

## Incident record (2026-05-09, Samsung S24 class)

### Scope observed
- Reproducible on Samsung S24 class physical device.
- Not reproduced on Pixel 9 emulator in the same app flows.
- Seen while testing AI usage paths; noise made log-based AI tracing difficult.

### What we changed during investigation
1. Added debug probe (`ComposeFrameProbe`) in app root:
   - logs route changes,
   - logs approximate fps/frame count/recomposition window.
2. Removed explicit root `preferredFrameRate(60f)` request to isolate internal calls.
3. Upgraded Power Save / Minimalist behavior from "UI toggle only" to actual runtime gating at app root:
   - disables root `hazeSource` / `sky`,
   - disables root backdrop capture sources (`prismBackdropSource` / `cloudyBackdropSource`),
   - passes `sky = null` to downstream glass surfaces via root wiring.
4. Captured caller stack on `Api35Impl.setRequestedFrameRate` with NaN condition.

### Key finding
- Captured NaN stack was:
  - `androidx.compose.ui.platform.Api35Impl.setRequestedFrameRate(...)`
  - followed by framework draw traversal (`View.draw`, `ViewRootImpl`, `Choreographer`, etc.).
- No ANIKAI app symbol appeared in the captured call chain.
- Working conclusion: this is Compose/framework + OEM behavior (Samsung/API35 class), not a direct app caller bug.

### Operational decision
- Treat as known OEM/platform noise unless behavior regresses into visible jank.
- Keep logs usable via filter/mute workflow (Section 1) during AI tracing.

## 1) Clean AI tracing (hide frame-rate noise)

### Option A: Filter in terminal (recommended)

```powershell
adb logcat --pid (adb shell pidof -s com.anikai) | rg -v "setRequestedFrameRate|Api35Impl.setRequestedFrameRate|AndroidComposeView.dispatchDraw"
```

### Option B: Temporarily reduce View tag verbosity

```powershell
adb shell setprop log.tag.View W
```

Restore default behavior later:

```powershell
adb shell setprop log.tag.View I
```

## 2) Focused frame-rate investigation

Use a narrow stream:

```powershell
adb logcat ComposeFrameProbe:I View:I *:S
```

Expected pattern on noisy devices:
- `frameRate=60.0` on `AndroidComposeView` when an explicit frame-rate request is active.
- `frameRate=NaN` on transient/internal views during draw traversal.

## 3) Catch exact runtime caller (best signal)

Set a logpoint (no suspend) in Android Studio:

- **Method:** `android.view.View.setRequestedFrameRate`
- **Condition:** `java.lang.Float.isNaN(frameRate)`
- **Log message:** include `this`, `this.getClass().getName()`, and stack trace.

Alternative higher-level breakpoint:

- **Method:** `androidx.compose.ui.platform.Api35Impl.setRequestedFrameRate`
- **Condition:** frame-rate argument is `NaN`
- **Action:** log stack only

This isolates who is requesting NaN at runtime without flooding normal logs.

### Android Studio logpoint expression notes (important)
- `Evaluate and log` must be a valid Java/Kotlin expression.
- Template-style `{this}` placeholders are invalid in this field.
- For static methods, `this` may be unavailable; prefer stack trace checkbox and simple text.

Known-good expression:

```java
"NaN frame request, thread=" + Thread.currentThread().getName()
```

Recommended: enable built-in **Stack trace** checkbox and keep expression simple.

## 4) Confirm whether app visuals are the driver

With Power Save / Minimalist mode enabled, root glass/backdrop effects are gated off in app shell.

If NaN spam persists even then:
- It is likely framework / Compose / device behavior (not app animation/theme logic).

## 5) Quick checklist before deep dive

- Reproduce with latest debug build.
- Keep one clean AI tracing terminal and one frame-rate terminal.
- Check `ComposeFrameProbe` route/fps/recomposition output while reproducing.
- If needed, capture a short screen recording + synchronized logcat window.

## 6) Escalation criteria

Escalate beyond log filtering only if at least one is true:
- visible UI jank/frame drops correlate with NaN spam,
- battery/thermal behavior regresses specifically on affected OEM profile,
- same issue reproduces across multiple OEMs after Compose/runtime updates.

## 7) Regression verification checklist (S24 class)

Run this checklist after:
- Compose BOM/runtime updates,
- targetSdk/API behavior changes,
- Samsung firmware / One UI updates,
- major visual pipeline changes in app shell.

### Environment snapshot
- [ ] Record device model + build fingerprint.
- [ ] Record app build variant and git commit.
- [ ] Record Compose BOM, Kotlin plugin, compileSdk, targetSdk values.

### Baseline behavior capture (no filters)
- [ ] Run `adb logcat ComposeFrameProbe:I View:I *:S` for 60-90s idle on home route.
- [ ] Confirm whether `setRequestedFrameRate frameRate=NaN` appears.
- [ ] Note route/fps/recomposition values from `ComposeFrameProbe` during same window.

### AI tracing usability check (with filter)
- [ ] Run filtered trace command from Section 1 (Option A).
- [ ] Verify AI/service logs are readable and no critical categories are hidden accidentally.

### Power Save / Minimalist gate check
- [ ] Enable power-save/minimalist mode in app.
- [ ] Re-run baseline capture for 60-90s.
- [ ] Verify root visual gate behavior remains active (no accidental regressions in root wiring).
- [ ] Compare NaN rate vs non-minimal mode and note delta.

### Caller-path sanity check (spot validation)
- [ ] Use `Api35Impl.setRequestedFrameRate` NaN-conditioned logpoint once.
- [ ] Confirm stack still resolves to Compose/framework draw traversal.
- [ ] Confirm no new ANIKAI app symbol appears in the NaN path.

### Performance / user-visible impact check
- [ ] Scroll and interact across Home, Chat, and one sheet-heavy route for 2-3 minutes.
- [ ] Confirm no user-visible jank, hitching, or thermal anomaly tied to NaN periods.
- [ ] If issues appear, capture short perf trace + synchronized logcat and escalate.

### Pass criteria
- [ ] AI tracing remains usable with filter workflow.
- [ ] No app-visible regressions (jank/thermal/battery anomalies) attributable to this quirk.
- [ ] NaN path remains framework/OEM-owned (not app-symbol-owned).

