# IP & risk log (device-adjacent)

**Scope:** incidents or decisions where **hardware vendor behavior** meets **IP / liability** (for example: bundled assets, preinstalled hooks you must not depend on, regional restrictions).

**When to open:** the question is “could this bite us in court or in platform review?”—not “why did JNI crash.”
