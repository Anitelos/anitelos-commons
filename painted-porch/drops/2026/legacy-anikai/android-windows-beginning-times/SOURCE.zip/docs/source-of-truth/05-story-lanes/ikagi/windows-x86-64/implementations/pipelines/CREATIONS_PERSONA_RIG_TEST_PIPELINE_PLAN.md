# Creations persona rig test pipeline plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-07 |

Purpose: define a practical hybrid avatar test lane that upgrades companion motion from pure 2D pivot/warp toward a rig-driven + neural-enhanced flow, while staying device-realistic for mobile.

---

## Scope

This file covers:

- a **Creations test surface** for persona rig behavior,
- stick/skeleton rig controls for face + body cues (speech + mood),
- staged handoff from rig-only motion to FOMM-assisted motion transfer,
- multi-view persona references for turn handling.

This file does **not** replace:

- FOMM engine bring-up details (`engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`),
- portrait shot planning contract (`generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`),
- portrait pack manifest schema (`generation/imaging/PORTRAIT_PACK_SCHEMA.md`),
- sprite sheet product flow (`pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`).

---

## Product hypothesis (single truth)

We can reduce “flat 2D pivot feel” by splitting animation into two coordinated lanes:

1. **Base deterministic rig lane** (always available): fast, low-power, phoneme/mood-driven.
2. **Neural motion lane** (FOMM-class, capability-gated): higher-fluidity enhancement when device/runtime are ready.

Rule: no fake success. If neural lane is unavailable or fails, label active lane and keep deterministic rig behavior.

---

## 3-stage test path

### Stage A — Persona rig test (rig only)

- Build a test actor from simple line/shape primitives:
  - head, jaw/mouth line, eye lines, brow lines, shoulders, forearms/hands.
- Drive motion by:
  - phoneme buckets (`rest`, `A`, `E`, `O`, `M/B/P`),
  - mood tags (`calm`, `focus`, `warm`, `alert`),
  - speech energy/prosody (subtle arm/head emphasis).
- Add lightweight depth illusion:
  - z-axis feeling via scale/parallax/offset, not full 3D mesh.

Current implementation snapshot:

- `PersonaRigTestScreen` exists in Creations and is reachable from nav.
- Rig canvas is live with head/eyes/brows/mouth/torso/arms/legs primitives.
- Speech controls are wired: script presets, energy/speed/emphasis sliders, mood chips.
- Phoneme signal generation is wired through Kokoro phoneme detection and feeds rig signal.
- Voice preview is wired with on-device TTS progress tracking so rig animation follows utterance time.
- This is still Stage A and should be treated as rig-first prototype quality.

### Stage B — Single-image persona bind

- Use one full persona image reference generated from profile flow.
- Retain rig as motion controller source.
- Test visual quality and coherence under speech animation without side turns.

### Stage C — Multi-view persona bind

- Move to 8-view set for yaw buckets:
  - `N, NE, E, SE, S, SW, W, NW`.
- Switch reference by turn angle so side-facing output stays identity-consistent.
- Keep body movement bounded until view-switch quality is stable.

---

## Runtime lane design

| Lane | Role | Expected behavior |
|------|------|-------------------|
| **v0 deterministic rig** | Primary baseline | Always-on motion for speech/mood, low-latency, predictable output. |
| **v1 neural assist (FOMM-class)** | Optional enhancement | Motion transfer pass for improved fluidity; must expose capability and failure reasons. |
| **v1b PersonaLive** | Optional enhancement (PC / flagship) | Portrait still + driving stream; see [`PORTRAIT_RIG_MOTION_STRATEGY.md`](PORTRAIT_RIG_MOTION_STRATEGY.md) and [`../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md). |

Neural lane is an enhancement pass, not the only path. **PersonaLive** is a **separate engine family** from FOMM (diffusion sidecar, not Qualcomm detector/generator ONNX).

---

## Motion control contract (rig lane)

Minimum control channels:

- `mouthShape` (phoneme bucket),
- `blinkState`,
- `browState`,
- `headNodTilt`,
- `armGestureMode`,
- `bodySway`.

Input sources:

- TTS/voice stream timing,
- emotion/mood signals from companion state,
- optional scripted gesture presets for test scenarios.

---

## Real-time expectations (FOMM lane)

FOMM-class motion can be near-real-time on strong devices at constrained resolution, but should be treated as:

- **capability-gated** (device + model + session readiness),
- **quality-latency tradeoff sensitive**,
- not guaranteed uniform FPS across all phones.

Operational policy:

- label active lane in UI/metadata,
- expose frame timing and drop behavior,
- avoid silent fallback switching.

---

## Integration with portrait contracts

Portrait generation remains upstream:

1. profile planner/autogen outputs persona shots,
2. selected shots feed rig/neural references,
3. pack schema records scene references + motion hints.

For Stage C, expand shot generation toward multi-view references (8-direction set) before expecting robust turn animation.

---

## Validation gates (before “operational” claim)

- [x] Stage A rig test surface exists with speech-driven animation controls and live voice preview wiring.
- [ ] Stage A rig test can run continuous speech animation with phoneme + mood mapping for 60s without drift/reset artifacts.
- [ ] Stage A includes at least 3 gesture presets and one low-energy idle mode.
- [ ] Stage B single-image bind keeps identity stable under talk cycle (no severe face tearing).
- [ ] Stage C 8-view switching works with clear yaw-bucket rules and no undefined angle state.
- [ ] Neural lane capability probe is visible and deterministic (ready/not-ready with explicit reason).
- [ ] Per-lane telemetry captured (`avg_frame_ms`, `p95_frame_ms`, active lane label, fallback events).

---

## Linked docs

- `implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `implementations/generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`
- `implementations/generation/imaging/PORTRAIT_PACK_SCHEMA.md`
- `implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`

---

## Linked todo

- `todo/mid-scope/TODO_CREATIONS_PERSONA_RIG_TEST_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-07 | Initial Persona Rig test pipeline plan: staged rig-first path, optional FOMM enhancement lane, and 8-view turn strategy. |
| 2026-05-07 | Updated current-state snapshot: Stage A screen, rig primitives, phoneme signal mapping, and TTS-driven live preview are now wired; operations moved to In progress. |
