# TODO — ExecuTorch engine inference integration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Establish ExecuTorch as a real model-family lane for PyTorch-first mobile inference.
- Track backend selection, adapter registration, and lane-level integration work.
- Keep capability-driven UI/routing aligned with installed packs.

---

## Checklist (working)

- [ ] Finalize ExecuTorch artifact intake/conversion policy for ANIKAI packs.
- [ ] Implement adapter + manifest schema and runtime session initialization checks.
- [ ] Ship one operational helper/specialist pack end-to-end.
- [ ] Add deterministic backend fallback policy + diagnostics.
- [ ] Bind at least one Swarm lane to ExecuTorch adapter resolution.
- [ ] Ensure explicit degraded/failure states without silent cloud substitution.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created ExecuTorch inference integration todo during runtime-family expansion pass. |
