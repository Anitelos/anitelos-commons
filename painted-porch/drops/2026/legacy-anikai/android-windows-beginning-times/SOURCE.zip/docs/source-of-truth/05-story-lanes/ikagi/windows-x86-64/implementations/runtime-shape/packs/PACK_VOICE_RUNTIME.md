# Voice runtime pack (eSpeak + ONNX + Piper)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.voice` |
| **Tier** | active |
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Companion TTS: espeak-ng fallback, ORT neural voices, optional Piper CLI.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Phonemes (why voices sound “almost real”)

Companion and Compose TTS do not speak raw letters — a **G2P** step turns text into **phonemes** (sound units), then a **vocoder** turns phonemes into waveform. Stress, vowel length, and timbre come from accurate phonemes + a rich voice model. **Singing** (Articulations) adds **pitch and duration** per phoneme.

| Path | Phoneme source |
|------|----------------|
| Kokoro (Compose presets) | `kokoro-onnx` pip (`espeakng-loader`) |
| Piper / XTTS (native) | [`pack.voice.espeak`](./PACK_VOICE_ESPEAK.md) — `espeak-ng-data/` |
| eSpeak fallback | Same `voice.espeak` pack |

About → **Sentience → Voice** and **Generating media → Articulations** explain the three voice lanes (companion speak vs Compose preset vs singing).

## Vendoring target

[`pack.voice.espeak`](./PACK_VOICE_ESPEAK.md), voice.onnx, voice.piper; reuse Android espeak-ng-data tree.

## Staging path

`desktop-data/runtime-packs/voice.espeak|voice.onnx|voice.piper`

## Unlocks (no model weights)

tts-espeak, tts-onnx, tts-piper

## Verification smoke

```bash
cd anikai-desktop
npm run stage-voice-engines
npm run smoke-voice-engines
```

(Speaking + articulations Python engines — see [`PACK_VOICE_ENGINES_BUNDLE.md`](./PACK_VOICE_ENGINES_BUNDLE.md). eSpeak-only: `npm run stage-voice-espeak`.)

Then **Settings → Device → Software → Check runtimes** — `voice.espeak` should report OK.

Speak test phrase on each backend (eSpeak fallback, ONNX, Piper when staged).

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
| 2026-05-22 | `npm run stage-voice-espeak` — MSI exe + third_party espeak-ng-data; user runtime-packs override |
