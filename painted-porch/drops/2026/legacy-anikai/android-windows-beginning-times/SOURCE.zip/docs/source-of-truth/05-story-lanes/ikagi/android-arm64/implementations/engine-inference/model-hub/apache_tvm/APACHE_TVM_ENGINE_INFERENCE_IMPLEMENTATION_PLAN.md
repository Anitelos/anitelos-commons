# Apache TVM engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: document **Apache TVM** as a **compiler-first** path: optimize and deploy models to generated C++/OpenCL/Vulkan/Metal backends rather than relying on a single fat runtime. Useful when bespoke kernels beat generic ORT/LiteRT on specific graphs.

---

## Scope

This file covers TVM for:

- compilation pipeline from ONNX / Relay / Relax IR to Android-deployable artifacts,
- runtime integration (`libtvm_runtime`) and JNI glue,
- explicit developer workflow (compile server vs on-device compile policy).

This file does **not** promise fast iteration for end users unless ANIKAI ships precompiled bundles.

---

## Role model (single truth)

| TVM lane | Ownership |
|----------|-----------|
| Specialist compiled subgraph | Candidate for performance-critical CV/audio kernels. |
| Interactive user-import compile loop | Future/advanced; heavy tooling. |

---

## Android implementation plan (stub checklist)

- [ ] Define compilation ownership (CI-built bundles vs developer workstation).
- [ ] Artifact layout for Android packaging (`.so`, weights, metadata).
- [ ] Adapter id `apache_tvm` + minimal runtime loader.
- [ ] Safety: no arbitrary user-supplied TVM compile on device without sandbox policy.

---

## Open decisions

- first graph family worth TVM investment vs sticking to ORT/NCNN,
- OpenCL vs Vulkan targets on Android GPU classes.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for Apache TVM compiled inference lane. |
