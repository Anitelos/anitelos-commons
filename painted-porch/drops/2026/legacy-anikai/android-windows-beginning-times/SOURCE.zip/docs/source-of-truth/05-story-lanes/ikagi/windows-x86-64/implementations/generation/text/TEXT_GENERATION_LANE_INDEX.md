# Text generation lane (Windows x86-64) — index

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-09 |

This file is the **entry point** for Windows **text generation**: it tells you which **model types** exist on desktop, where each type’s **product + capability** story lives, how that connects to **engine-inference** (load/probe/execute), and which **todos** track execution work. There is no separate README in this folder; navigation is **doc-to-doc** only.

---

## Story (three layers)

1. **Engine-inference** answers: *can this binary run on this machine, with which flags, and what tasks does it honestly support?*  
2. **Generation / text / &lt;type&gt;** answers: *what does the user get for chat, roles, streaming, and handoffs for that model type?*  
3. **Todo / mid-scope** answers: *what shipped vs what is still unchecked?*  

Android uses the same separation: engine plans live under `engine-inference/model-hub/<family>/`, text **roles** live under `generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`, and work is tracked under `todo/mid-scope/` with explicit links from the implementation docs.

---

## Model types on Windows (one plan per type)

| Model type | Text generation plan | Engine implementation | Tracking todo |
|------------|----------------------|------------------------|---------------|
| **GGUF** (decoder LM, `.gguf`) | [`gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](./gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md) | [`../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) |
| **ONNX text** (future) | *plan TBD when engine doc is promoted* | `engine-inference/model-hub/onnx/` (stub) | *todo TBD* |

Add a new row here whenever a new **type** gets a real plan file under `generation/text/<type>/`.

---

## Roles (shared taxonomy, Android-authored)

Windows schedulers should reuse the same **T1–T5** role ids as Android so docs and future handover packets stay portable:

- [`../../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`](../../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md)

Desktop-specific orchestration work (when to pick T1 vs T3, how Electron exposes that) is tracked in:

- [`../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md)

---

## Sentience and other lanes (hooks only)

When **sensory** or **fusion** stacks produce packets that **text** must summarize, the handoff contract will live primarily under `implementations/sentience/` and reference this lane by **role + capability ids**—not by duplicating engine load rules here.

---

## Linked todos (lane-wide)

| Todo | Intent |
|------|--------|
| [`../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) | First desktop text stack (GGUF) in companion / Electron. |
| [`../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md) | T1–T5 policy and swap behavior on Windows. |

---

## Superseded / renamed docs

- `TEXT_GENERATION_MODEL_TYPES_AND_CAPABILITIES.md` — **superseded** by this index + per-type plans under `generation/text/<type>/`. The old file remains as a one-line forwarder so external links keep resolving.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Added lane index: per-model-type table, Android role link, Windows todos, no README navigation. |
| 2026-05-09 | Split GGUF text generation into `gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`. |
