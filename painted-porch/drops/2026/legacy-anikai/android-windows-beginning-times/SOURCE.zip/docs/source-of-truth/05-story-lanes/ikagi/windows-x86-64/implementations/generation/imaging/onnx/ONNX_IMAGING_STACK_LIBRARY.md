# ONNX imaging stack library (Windows x86-64)

| Field | Value |
|-------|-------|
| **Parent plan** | [`ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) |
| **Engine plan** | [`../../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| **Lane index** | [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md) |

ONNX graphs for **post-process**, **matting**, **depth**, **pose**, and **restore** — not primary txt2img (that stays GGUF / Diffusers). PersonaLive portrait **motion** is **Python**, not this table — see [`../python/PYTHON_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../python/PYTHON_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md).

---

## Use-case map (yours + general library)

| Use case | Family id | Stack | Pipeline doc |
|----------|-----------|-------|----------------|
| **Sprite NESW post-upscale** | `onnx_image_post` | 4× UltraSharp | [`SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../../../../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md) |
| **Portrait depth overlay (Stage B)** | `onnx_portrait_depth` | Depth Anything v2 small | [`PORTRAIT_RIG_MOTION_STRATEGY.md`](../../../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md) |
| **Sticker / sprite cutout** | `onnx_matting` | U²-Net / rembg | General asset prep |
| **Face cleanup after gen** | `onnx_face_restore` | GFPGAN | Social portrait polish |
| **Pose-driven img2img / video prep** | `onnx_pose` | DWPose / OpenPose ONNX | Control and rig reference — **PoseIntent** presets (Familiar) |
| **Masked local edit** | `onnx_inpaint` | LaMa ONNX | Inpaint region via mask PNG |
| **OpenPose grid demos** | `anikai_pose_intent` | App pose library | One skeleton → N style prompts (see motion architecture doc) |
| **Legacy Android motion (deprecated product lane)** | `onnx.motion.fomm` | FOMM detector + generator | Engine hub only — not imaging catalogue primary |

---

## Stack registry (About catalogue)

| Stack id | Role | Status | Sheet |
|----------|------|--------|-------|
| `onnx-ultrasharp-x4` | 4× upscale / sharpen post | planned | [`models/MODEL_ONNX_ULTRASHARP_X4.md`](./models/MODEL_ONNX_ULTRASHARP_X4.md) |
| `onnx-portrait-depth` | Depth map beside hero still | planned | [`models/MODEL_ONNX_PORTRAIT_DEPTH.md`](./models/MODEL_ONNX_PORTRAIT_DEPTH.md) |
| `onnx-rembg-u2net` | Background removal | planned | [`models/MODEL_ONNX_REMBG_U2NET.md`](./models/MODEL_ONNX_REMBG_U2NET.md) |
| `onnx-gfpgan-face` | Face restoration | planned | [`models/MODEL_ONNX_GFPGAN.md`](./models/MODEL_ONNX_GFPGAN.md) |
| `onnx-dwpose` | Pose keypoints aux | partial | [`models/MODEL_ONNX_DWPOSE.md`](./models/MODEL_ONNX_DWPOSE.md) |
| `onnx-inpaint-lama` | LaMa inpaint | partial | [`models/MODEL_ONNX_INPAINT_LAMA.md`](./models/MODEL_ONNX_INPAINT_LAMA.md) |

Add rows when a graph is probed on device and hooked from Media Magic or a pipeline stage.

**Runtime pack:** `pack.onnx.imaging` (Software tab) · **Weights:** About Get pack per stack.

---

## Pack layout

```
models/onnx/<stack-id>/
  *.onnx
  # optional manifest.json with input size + EP hints
```

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Stack library from sprite + portrait rig plans; five starter families for desktop catalogue. |
