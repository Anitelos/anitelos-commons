# Companion specialties (crafts) and group session roles

| Field | Value |
|-------|-------|
| **Scope** | Desktop companions — identity vs in-group choreography |
| **Code** | `assets/persona-defaults/specialty-catalog.json`, `shared/companion-specialty.js`, `shared/group-role-policy.js` |
| **Vision (deep)** | [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) |

Use this doc as the **index** when other Windows implementation docs mention **manager**, **specialty**, **craft**, or **session role** — link here instead of re-explaining.

---

## Two axes (do not conflate)

| Axis | User-facing name | Stored on | Purpose |
|------|------------------|-----------|---------|
| **Specialty / craft** | Specialty | `companions.json` → `specialty` | **Persistent identity** — what job this companion does solo and in delegation prompts |
| **Session role** | Session role (in this group) | `group-threads/<id>/thread.json` → `members[].sessionRole` | **Per-group hat** — speak order, plan capture, Lead-last synthesis |

A musician stays `musician` but can be `note_taker` in Project A and `teammate` in Project B.

```mermaid
flowchart LR
  subgraph solo [Solo chat]
    S[specialty]
    C[companion GGUF turn]
    S --> C
  end
  subgraph group [Group thread]
    SR[session role]
    RR[round-robin order]
    SR --> RR
  end
```

---

## Specialty catalog (shipped W4)

Source of truth: `anikai-desktop/assets/persona-defaults/specialty-catalog.json`.

| id | Label | Typical use |
|----|-------|-------------|
| `general` | General assistant | Default; balanced help |
| `image_artist` | Image artist | Still images, visual direction |
| `video_creator` | Video creator | Motion and clips |
| `musician` | Musician | Audio / music handoffs |
| `programmer` | Programmer | Code, tooling; desktop copilot candidate |
| `writer` | Writer | Prose and narrative |
| `editor` | Editor | Copy tightening |
| `researcher` | Researcher | Synthesis and sources |
| `designer` | Designer | UX / layout |
| `data_analyst` | Data analyst | Tables and metrics |
| `financier` | Financier | Budgets and models |
| `strategist` | Strategist | Priorities and framing |
| `coach` | Coach | Goals and feedback |
| `educator` | Educator | Teaching flows |
| `marketer` | Marketer | Positioning and campaigns |
| `legal_advisor` | Legal advisor | Risk framing (not legal advice) |
| `audio_engineer` | Audio engineer | Technical audio |
| `animator` | Animator | Motion planning |
| **`manager`** | **Manager** | **Orchestration lead** — see below |
| `archivist` | Archivist | Records and pointers |

Fallback in code if catalog missing: `shared/companion-specialty.js` (`FALLBACK_SPECIALTIES`).

---

## Manager specialty (canonical summary)

**Manager** is a **companion craft**, not a familiar role and not the same as group **Lead**.

| Question | Answer |
|----------|--------|
| What is it? | Specialty id `manager` — “orchestration across specialists and future automation lead.” |
| Where set? | Companion editor → Persona / specialty (catalog dropdown). |
| vs **Lead** session role? | **Lead** = speaks **last** in a group round, synthesizes, user still approves plan. **Manager** = workforce **orchestrator** specialty for delegation and (later) autonomous pipelines. |
| vs **Familiars**? | Familiars are **reflex sidekicks** (guard, classifier). Manager is a **full companion** with chat GGUF and roster visibility. |
| Automation | No separate autopilot toggle in v1: **`manager` specialty** is the switch for future Manager-autonomous mode ([`WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) §9). |
| User-directed work | Any specialty (e.g. image artist) can still narrate a multi-step job; Manager is not required for every pipeline. |

**Docs that mention Manager** — prefer linking this section:

- [`../../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md)
- [`../TEAM_BLACKBOARD_ORCHESTRATION.md`](../TEAM_BLACKBOARD_ORCHESTRATION.md)
- [`../../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../../WHAT_IS_ANIKAI_ON_WINDOWS.md) (group + manager companion)
- [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) (full tables)

---

## Group session roles (shipped W3 / W6)

Source: `shared/group-role-policy.js`. Assigned in chat → **Members** (not Persona editor).

| id | Label | Round behavior |
|----|-------|----------------|
| `opener` | Opener | Speaks **first** when assigned |
| `teammate` | Teammate | Default contributor |
| `planner` | Planner | Structure and steps; may capture plan |
| `critic` | Critic | Challenge assumptions |
| `note_taker` | Note-taker | Plan draft + open questions |
| `archivist` | Archivist | Pointers to prior work |
| `facilitator` | Facilitator | Keeps discussion on topic |
| `lead` | Lead | Speaks **last**; synthesis — user **Continue / Revise / Lock** |

Sort: opener first → … → **lead last** (`roundOrderRank`).

---

## Familiars vs companions

| | Companions | Familiars |
|---|------------|-----------|
| Identity | Specialty + persona pack | Archetype (droid, sprite, …) |
| Models | Chat, Sight, Media, … | One GGUF (+ guard uses shared Prompt Guard dir) |
| Group | Session role per thread | Blocklist per familiar; reflex follows **active companion** |
| Docs | This file | [`../Familiars/FAMILIAR_ROLES.md`](../Familiars/FAMILIAR_ROLES.md) |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial index from `specialty-catalog.json`, `group-role-policy.js`, workforce vision |
