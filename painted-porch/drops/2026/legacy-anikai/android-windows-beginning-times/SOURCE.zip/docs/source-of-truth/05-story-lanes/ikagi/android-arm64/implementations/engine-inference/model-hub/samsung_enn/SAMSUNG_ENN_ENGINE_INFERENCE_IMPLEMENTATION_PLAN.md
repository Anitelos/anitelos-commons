# Samsung ENN (Exynos NPU) engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: reserve an ANIKAI engine-inference lane for **Samsung Exynos Neural Network (ENN / Eden)** paths on Exynos devices (e.g. Galaxy S series in relevant regions). Enables vendor-native NPU use where Snapdragon QNN does not apply.

---

## Scope

This file covers ENN for:

- Exynos NPU inference when Samsung SDK/API surface is available to the app,
- device-class detection and honest unsupported paths on Snapdragon-only builds,
- future manifest rows for ENN-specific model bundles.

This file does **not** cover One UI system exclusives or undocumented private APIs.

---

## Role model (single truth)

| ENN lane | Ownership |
|----------|-----------|
| Vision/helper on Exynos | Candidate for Sentience/Swarm helpers. |
| Primary text | Not assumed; depends on SDK model support. |
| Cross-device parity | Must degrade cleanly on non-Exynos hardware. |

---

## Android implementation plan (stub checklist)

- [ ] Confirm public SDK availability, licensing, and ABI targets for ENN.
- [ ] Define Exynos detection signal vs misleading build props.
- [ ] Adapter id `samsung_enn` in registry (stub).
- [ ] Manifest schema for ENN bundle format when known.
- [ ] Fallback policy to ONNX/NNAPI/LiteRT on non-Exynos devices.

---

## Open decisions

- minimum Exynos generation for first supported path,
- packaging ENN runtime libs vs system-provided,
- regional/device matrix documentation.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for Samsung ENN / Exynos NPU lane. |
