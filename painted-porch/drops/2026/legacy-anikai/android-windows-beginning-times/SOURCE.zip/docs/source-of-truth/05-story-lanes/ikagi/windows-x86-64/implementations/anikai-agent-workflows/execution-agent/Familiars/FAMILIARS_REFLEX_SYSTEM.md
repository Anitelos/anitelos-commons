# Familiars — reflex sidekicks (design)

| Field | Value |
|-------|-------|
| **Doc staging** | Canonical (execution-agent) |
| **Operations** | **F1–F7 shipped** on desktop (familiars F1–F6; companion Persona/Inference/Metrics F7) |
| **Last reviewed** | 2026-05-20 |

**Purpose:** **Familiars** are small local agents (“sidekicks”) that sit beside full **Companions** in the workshop. Each familiar binds **one GGUF weight**, runs **short reflex tasks** (classify, scan, report, quick tools), and logs work to its own **journal** and **metrics** — without the full soul/persona pack or group specialty machinery.

**Related:** [`FAMILIAR_ROLES.md`](FAMILIAR_ROLES.md) · [`../ROLES_INDEX.md`](../ROLES_INDEX.md) · [`../../WINDOWS_DESKTOP_INDEX.md`](../../WINDOWS_DESKTOP_INDEX.md) · [`../Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](../Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) · [`../../anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md`](../../DESKTOP_WORKSHOP_STATE.md)

---

## One sentence

Companions are the **speakers**; Familiars are the **reflex crew** — fast, single-model helpers that companions (or the user) can invoke for time, folders, guardrails, routing, and micro-reports before or during a turn.

---

## UI layout (Companion panel)

| Element | Companions (today) | Familiars (target) |
|---------|-------------------|-------------------|
| Grid density | ~1 card per row (wide studio) | **3 cards per row** (smaller tiles) |
| Add flow | **+** → new companion | **+** → choose type: **Companion** \| **Familiar** |
| Model slots | Chat, Sight, Media, … | **One weight** per familiar (drag/drop or picker) |
| Pulse / specialty | Yes | **No** (not applicable) |
| Soul metrics in persona | Confidence, etc. | **Omitted** — short operational persona only |

```mermaid
flowchart TB
  subgraph panel [Companion panel]
    C[Companion cards - wide]
    F[Familiar cards - 3 per row]
  end
  subgraph fam [Familiar selected]
    T1[Persona]
    T2[Assign]
    T3[Inference]
    T4[Journal]
    T5[Metrics]
  end
  F --> T1
  F --> T2
  F --> T3
  F --> T4
  F --> T5
```

---

## Familiar editor tabs

### Persona

- **Short** sci-fi / fantasy archetype packs (not full “soul” documents).
- Starter archetypes (examples): **droid**, **fairy**, **pixie**, **gizmo**, **borrower**, **sprite**.
- Voice: operational, sidekick tone — “reports to the team”, not lead narrator.
- **No** sentience pack fields (confidence, valence rails, etc.).

### Assign

| Control | Behavior |
|---------|----------|
| **Role chips** | Toggle which **roles** this familiar may perform (multi-select on same familiar). Examples: `reporter`, `instructor`, `router`, `folder_scout`, `quick_edit`, `guard`, `classifier`. |
| **Companion pairing** | When a familiar is selected in the panel, companions show a small **checkbox**. Unchecked = add to familiar’s **blocklist** (do not auto-invoke for that companion). |
| **Default** | New companions are **allowed** for all familiars until explicitly blocked. Blocklist only grows when user opts out — not an allow-list. |

```mermaid
flowchart LR
  F[Familiar: Pixie router]
  C1[Companion A ✓]
  C2[Companion B ✗ blocked]
  C3[Companion C ✓]
  F --> C1
  F -.->|no reflex| C2
  F --> C3
```

### Inference

- Same **concept** as companion Persona inference today, but **only** for the familiar’s single GGUF:
  - temperature rails / token caps (likely **much smaller** defaults),
  - optional “companion decides” toggles,
  - link to one file under `models/`.
- **Split for full companions (parallel change):** move inference sliders out of Persona into dedicated **Inference** tab; add **Metrics** tab to companions too (see below).

### Journal

Append-only log per familiar:

| Field | Example |
|-------|---------|
| `ts` | When |
| `taskKind` | `report` \| `tool` \| `thought` \| `failure` |
| `summary` | One-line outcome |
| `detail` | Optional longer text / tool output |
| `requestedBy` | `user` \| `companion:<id>` \| `companion:<name>` |
| `toolName` | e.g. `folder_search`, `get_local_time` |
| `companionTarget` | Who the output was for |

### Metrics

Dashboard per familiar (and later rollup in companion Metrics):

| Metric | Notes |
|--------|--------|
| Companions worked with | Distinct companion ids (respecting blocklist history) |
| Tasks started / completed | Count by `taskKind` |
| Tasks failed | Explicit failure or timeout |
| Tool invocations | By `toolName` |
| Avg latency | Per task kind (ms) |
| Last active | Timestamp |
| Model ref | Current GGUF path |
| Optional later | Tokens in/out estimates, GPU queue waits, guard hits (malicious prompts) |

**Companion Metrics tab (requested):** same ideas at companion scope — which familiars helped this companion, success rate, last handoff.

---

## What familiars do (reflex jobs)

Not full chat turns. Typical jobs:

| Job | Description | Example model / stack |
|-----|-------------|------------------------|
| **Turn classifier** | Emit `<complexity/>` before main companion run | [`SmolLM2-Rethink-360M-GGUF`](https://huggingface.co/prithivMLmods/SmolLM2-Rethink-360M-GGUF) (see below) |
| **Prompt guard** | Binary benign / malicious on user or tool output | [Llama Prompt Guard 2 86M](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M) or [22M](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-22M) — **Transformers**, not `llama-completion` |
| **Reporter** | Short status blurb for UI or thought preamble | Small instruct GGUF |
| **Instructor** | One-step “how to fix” hint | Small instruct GGUF |
| **Folder scout** | List/search workspace paths (scripted + optional LLM summary) | Scripts + optional GGUF |
| **Quick edit** | Bounded SEARCH/REPLACE in sandbox (execution agent shared validator) | Script + policy |
| **Time** | Local time / schedule snippets | Script (`get_local_time`) or tiny model |

Familiars may expose **scripts** and **quick tools** registered in a familiar-specific manifest (subset of companion skill registry).

---

## Model notes

### SmolLM2-Rethink-360M (familiar + classifier candidate)

| Property | Detail |
|----------|--------|
| HF | [prithivMLmods/SmolLM2-Rethink-360M-GGUF](https://huggingface.co/prithivMLmods/SmolLM2-Rethink-360M-GGUF) |
| Size | ~360M params; Q4_K_M ~271 MB |
| Stack | **llama** arch — fits existing `llama-completion` |
| Training | Lightweight reasoning on distilled R1-style data |
| Anikai use | Default suggestion for **Familiar “router”** + optional global **turn classifier** ([`CHAT_TURN_TIMELINE_PHASED_PLAN.md`](../generation/text/gguf/CHAT_TURN_TIMELINE_PHASED_PLAN.md) Phase 5) |

Doc entry: [`../generation/text/gguf/models/SMOLLM2_RETHINK_360M_ANIKAI.md`](../generation/text/gguf/models/SMOLLM2_RETHINK_360M_ANIKAI.md)

### Llama Prompt Guard 2 (reflex guard — different integration)

| Property | Detail |
|----------|--------|
| HF | [meta-llama/Llama-Prompt-Guard-2-86M](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M) (22M variant for latency) |
| Task | **Text classification** — prompt injection / jailbreak patterns |
| Context | **512 tokens** — scan segments for long prompts |
| Stack | **Transformers / PyTorch** — not GGUF `llama-completion` today |
| Anikai use | Familiar role **`guard`**: run on **user input** (and optionally model outbound) before main companion inference; log hits in familiar journal |

**License:** Llama 4 Community License — review before bundling.

---

## Reflex invocation flow (target)

```mermaid
sequenceDiagram
  participant U as User
  participant G as Guard familiar optional
  participant R as Router familiar optional
  participant C as Companion Gemma
  participant J as Familiar journals
  U->>G: incoming message
  G-->>J: benign or malicious
  alt malicious
    G-->>U: block or warn
  else ok
    U->>R: classify turn optional
    R-->>J: complexity tag
    R-->>C: caps for this turn
    C-->>U: thought + reply
    C-->>J: tool events mirrored
  end
```

- Familiars use the **global inference queue** with **lower priority** than active companion chat (configurable).
- A familiar never replaces the companion’s Chat slot unless user explicitly pins one for a scripted dialog.

---

## Data model (sketch)

```text
configs/familiars/<familiarId>.json
  name, archetypeId, modelRef (single gguf path)
  inferencePolicy { ... smaller caps ... }
  assign: { roles: string[], blockedCompanionIds: string[] }
  scripts: string[]   // ids into familiar-scripts registry
  tools: string[]      // allowed quick tools

configs/familiars/<familiarId>/journal.jsonl
configs/familiars/<familiarId>/metrics.json
```

Companions gain optional:

```text
companion.familiarBlocklist[]  // inverse: familiars that must not auto-run (optional mirror)
companion.metrics { ... }      // new tab backing store
```

---

## Companion panel changes (companions + familiars)

| Change | Rationale |
|--------|-----------|
| **Split Persona \| Inference** (companions) | Persona = identity, packs, portrait; Inference = caps only |
| **Add Metrics tab** (companions) | Parity with familiar metrics |
| **One team column** — companions, then Familiars divider + 3-wide grid; **one tab bar** swaps by selection | No nested sections |
| **+ menu** | `New companion` / `New familiar` |

---

## Phased implementation

| Phase | Deliverable |
|-------|-------------|
| **F0** | This doc + workshop index link; archetype JSON stubs |
| **F1** | UI: familiar cards 3-wide; create familiar; single model slot; tabs shell (empty Journal/Metrics) — **shipped** in `panels.js` + `familiars.json` |
| **F2** | Assign chips + companion blocklist checkboxes — **shipped** |
| **F3** | Familiar journal + metrics persistence — **shipped** (`familiar-journal.js`, `configs/familiars/<id>/`) |
| **F4** | Turn **classifier** pre-pass before companion GGUF (active familiar + `classifier` role) — **shipped** |
| **F5** | Prompt Guard familiar — **shipped** (`familiar-guard.js`, `scripts/prompt-guard-classify.py`; Transformers when `models/prompt-guard-2-86m/` present, else heuristic) |
| **F6** | Script/tool familiars — **shipped** (`familiar-scripts.js`: time, folder_scout, quick_edit) |
| **F7** | Companion Metrics tab + Persona/Inference split — **shipped** (`companion-metrics.js`, `panels.js`) |

---

## Resolved decisions

| # | Decision |
|---|----------|
| Q1 | **Per active companion** — reflex routing follows whoever is speaking in chat so blocklists stay consistent (not one global router per group). |
| Q2 | **No shared GGUF** — each familiar owns exactly one weight file; assigning a file already bound elsewhere is rejected. |
| Q3 | **Prompt Guard integration (explainer):** Meta ships [Prompt Guard 2](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M) as a **Transformers** classifier (PyTorch/safetensors), not GGUF. **Python sidecar** = small helper process the Electron app starts to run that model. **ONNX** = export the same weights to a portable graph so **Node/main-process** can run inference without Python — fewer moving parts, more packaging work. Defer choice until **F5** spike. |
| Q4 | Classifier runs on **every user message** only when a familiar is **selected in the panel** **and** has the **`classifier` role** enabled in Assign (not global, not tied to companion `decide*` toggles). |
| Q5 | **Guard** uses the same gating as classifier (active familiar + **`guard`** role + companion blocklist). Weights live under `ANIKAI_HOME/models/prompt-guard-2-86m/` (or env `ANIKAI_PROMPT_GUARD_MODEL`); **F5 ships Python sidecar + JS heuristic fallback** (ONNX deferred). Malicious prompts **block the turn** before classifier / companion GGUF. |

---

## Linked todos (to create)

| Suggested id | Path |
|--------------|------|
| `TODO_FAMILIARS_REFLEX_DESKTOP` | `todo/mid-scope/TODO_FAMILIARS_REFLEX_DESKTOP.md` (create when implementation starts) |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial Familiars / reflex design from product notes; SmolLM2 + Prompt Guard links |
| 2026-05-20 | Q1–Q4 resolved; F1 desktop UI shipped (`familiars.json`, companion panel) |
| 2026-05-20 | F3 journal.jsonl + metrics.json per familiar; panel Journal/Metrics tabs live |
| 2026-05-20 | F4 familiar classifier IPC + chat cap routing (`familiar-classifier.js`) |
| 2026-05-20 | F5 prompt guard IPC + chat block pre-pass (`familiar-guard.js`); metrics `guardHits` / `guardScans` |
| 2026-05-20 | F6 script reflex (time, folder scout, quick edit); F7 companion Persona/Inference/Metrics tabs |
