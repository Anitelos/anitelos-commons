# Cloud voice provider plan (shared lane)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Scope

Single shared doc for cloud voice provider behavior, because provider depth is smaller than per-engine local runtime bring-up.

This lane is for:

- credential/routing behavior,
- provider fallback policy,
- UX messaging and diagnostics,
- guardrails with local-first strategy.

---

## Current state (code)

- Cloud runtime lane exists through `CloudTtsRuntimePack` and orchestrator routing.
- Routing mode and provider credentials are synchronized by `VoiceOrchestrator`.
- Local-vs-cloud mode is already influenced by settings and routing mode decisions.

Primary references:

- `.../voice/provider_runtimes/VoiceProviderRuntime.kt`
- `.../voice/orchestration/VoiceOrchestrator.kt`
- `.../data/AnikaiSettings.kt`

---

## Anikai-engine-first policy

- Default posture remains local-first where feasible.
- Cloud provider lanes are explicit, user-controlled, and visibly labeled.
- If cloud path is needed as interim fallback, keep diagnostics honest and return focus to local lane completion.

---

## Operational goals

1. deterministic routing behavior by mode (`LOCAL_ONLY`, cloud-preferred, etc.),
2. clear diagnostics for missing keys/provider mismatch,
3. stable cloud synthesis fallback without silently overriding local policy,
4. explicit user-facing source labels in voice/session outputs.

---

## Checklist

- [ ] Routing matrix validated for all supported mode/provider combinations.
- [ ] Provider credential validation and error taxonomy documented.
- [ ] UI/source labels verified (`local` vs `cloud`) for session transparency.
- [ ] Fallback guardrails confirmed against local-first policy.

---

## Dependencies

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Umbrella: `../VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial shared cloud provider doc for voice lane behavior and guardrails. |
