# Model downloads, ANIKAI home, and Models panel (desktop)

**Status:** design draft  
**Last reviewed:** 2026-05-10  
**Code touchpoints:** `anikai-desktop/main.js` (`ANIKAI_HOME`, `MODELS_DIR`), `preload.js` (`getAnikaiHome`, `getModelsDir`), Models panel in `anikai-desktop/components/panels.js`

---

## ANIKAI home (current)

**Decision:** **`Desktop/Anikai`** on Windows (`%USERPROFILE%\\Desktop\\Anikai`, e.g. `C:\\Users\\shino\\Desktop\\Anikai`). On macOS/Linux the default is **`~/Anikai`** until you add a platform-specific rule.

- **`MODELS_DIR`** = `ANIKAI_HOME/models/` — created on app startup if missing.  
- **Override:** set **`ANIKAI_HOME`** to an absolute path (portable install, second drive, or if Desktop is redirected e.g. OneDrive).  
- **Repo:** the Electron app still lives under `anikai-desktop/` in the git tree; **weights do not**—they stay under the Desktop (or overridden) root so clones stay small.

`settings.json` stays under Electron **`userData`** (window bounds, etc.).

---

## How downloads should work (phased)

### Phase 0 — “Bring your own files” (zero network code)

- User drops **`.gguf` / `.onnx` / etc.** into `models/` (or subfolders they create).  
- Models panel is a **live view of that folder** (filesystem is source of truth).  
- Proves drag/drop workspace + path wiring before any HF integration.

### Phase 1 — Hugging Face without drowning the average user

**Problem:** full `huggingface.co` UI is powerful but noisy (files tree, branches, xet, community cards).

**Recommended hybrid**

| Surface | Role |
|--------|------|
| **In-app “model browser” (lite)** | Search by model id or paste URL → **short card**: title, license snippet, size hints, **quant picker** (Q4_K_M, Q5, …) from Hub **files** API, **Download** with progress bar. Optional **“Open full page”** link for power users. |
| **System browser** | Fallback only, or for docs / community threads / first-time “what is a quant?” help. |

**Implementation sketch (no cloud inference):** renderer calls main via IPC → main uses **HTTPS** to `huggingface.co/api/...` (model metadata + file list) and **streams** file bytes into `models/<org>__<repo>/` (or similar). No need to embed a full webview for v1 if a card UI is enough.

**Quant UX:** one row per recommended quant with **size on disk** and **VRAM hint** (rough text from docs, later from benchmarks table).

### Phase 2 — Playground pairing

- Same **spatial model icons** become **node palette** or **pinned assets** in Playground (blueprint graph).  
- Graph stores **paths relative to ANIKAI_HOME** or stable model ids resolved at runtime.

---

## Models panel — open drag-and-drop workspace

**Goal:** not only a list — a **canvas** where each card represents a file or folder under `models/`, **repositionable**, **groupable** later, and accepting **OS drops** onto the panel (copy or move into `models/` with confirm).

**Behaviour**

1. **Done (v1):** top-level scan of `MODELS_DIR` → **tiles** (files + folders) with byte size for files; **filter** by name; **Refresh**; **Open folder** in Explorer (`shell.openPath`).  
2. **Next:** optional `model.json` sidecars (friendly labels, engine hints); deeper recursive listing.  
3. **Later:** drag tiles to **persist layout**; **drop from Explorer** into `models/`; **group** selections for Playground palette.

**Git:** weights live **outside** the repo under `ANIKAI_HOME`; nothing to ignore in git for those paths. Optional tiny **fixtures** in-repo stay explicit if you ever add them under `anikai-desktop/` for CI.

---

## Local GGUF chat (Electron bridge, current)

**Code:** `anikai-desktop/main-process/gguf-completion.js`, IPC `gguf:completion`, preload `runGgufCompletion`, chat uses companion **`modelSlots.chat`** when the value ends with **`.gguf`** (file must resolve under `MODELS_DIR`).

| Variable | Role |
|----------|------|
| **`ANIKAI_LLAMA_COMPLETION`** | Full path to `llama-completion.exe` (or Unix `llama-completion`). |
| **`ANIKAI_LLAMA_CPP_DIR`** | Directory that **contains** the binary (either name is resolved). |
| **`ANIKAI_LLAMA_NGL`** | Optional GPU layers for `-ngl` (default `0` = CPU). |
| **`ANIKAI_LLAMA_TIMEOUT_MS`** | Optional spawn timeout (default 900000). |
| **`CUDA_PATH`** | NVIDIA toolkit root (contains `bin`, `include`). When set, **Electron prepends** `CUDA_PATH\bin` to the child `PATH` so CUDA-built `llama-completion` finds `cudart` DLLs. |
| **`ANIKAI_CUDA_BIN`** | Optional override: full path to CUDA toolkit **`bin`** folder (same as `CUDA_PATH\bin`) if you do not use `CUDA_PATH`. |

Upstream CLI reference: `vendor/llama.cpp/tools/completion/README.md`.

### Building `llama-completion` from vendored `llama.cpp` (Windows x64)

Prerequisites (from upstream [`vendor/llama.cpp/docs/build.md`](../../../../../../../../vendor/llama.cpp/docs/build.md)): **Visual Studio 2022** with workload **Desktop development with C++**, including **CMake tools for Windows**. Use a **Developer PowerShell for VS 2022** (or x64 Native Tools prompt) so MSVC and CMake are on PATH.

From the **repository root** (`New`):

```powershell
cd vendor\llama.cpp
cmake -B build
cmake --build build --config Release -j $env:NUMBER_OF_PROCESSORS
```

**Where the exe lands** depends on the CMake generator and llama.cpp version:

- **Visual Studio generator (typical current layout):** `vendor\llama.cpp\build\bin\Release\llama-completion.exe`
- **Older / alternate VS layouts:** sometimes `vendor\llama.cpp\build\Release\llama-completion.exe`
- **Ninja / single-config trees:** often `vendor\llama.cpp\build\llama-completion.exe` or under `build\bin\`

Then either set **`ANIKAI_LLAMA_COMPLETION`** to the full path of the exe, or **`ANIKAI_LLAMA_CPP_DIR`** to the folder that **directly contains** `llama-completion.exe` (for the typical case above, that folder is `...\vendor\llama.cpp\build\bin\Release`, not `...\build` alone).

Quick check in PowerShell: `Get-ChildItem -Path vendor\llama.cpp\build -Recurse -Filter llama-completion.exe`

#### Optional: NVIDIA CUDA

- **One-command build (recommended):** from the repo root, run [`scripts/build-llama-cpp-cuda-win.ps1`](../../../../../../../../scripts/build-llama-cpp-cuda-win.ps1). It loads **Visual Studio** via **DevShell** (so `cl.exe` works), sets **`CUDA_PATH`**, uses **Ninja** + **`CMAKE_CUDA_COMPILER`**, and builds into `vendor/llama.cpp/build-cuda-ninja/`. Example: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts\build-llama-cpp-cuda-win.ps1` (add `-Generator VisualStudio` if you insist on MSBuild; ensure **`CUDA_PATH`** is set for the empty `CudaToolkitDir` case).
- Install the **[CUDA Toolkit](https://developer.nvidia.com/cuda-downloads)** (version compatible with your driver).
- Use a **fresh build directory** the first time you enable CUDA (e.g. `build-cuda`) so CMake is not stuck with a CPU-only cache from an older configure.
- From `vendor\llama.cpp` in **Developer PowerShell for VS 2022** (same C++ workload as the CPU build):

```powershell
cmake -B build-cuda -DGGML_CUDA=ON
cmake --build build-cuda --config Release -j $env:NUMBER_OF_PROCESSORS
```

Example when targeting **RTX 5080 (sm_120)** explicitly:

```powershell
cmake -B build-cuda -DGGML_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=120
cmake --build build-cuda --config Release -j $env:NUMBER_OF_PROCESSORS
```

- If `nvcc` warns it cannot pick a GPU architecture, set **`CMAKE_CUDA_ARCHITECTURES`** explicitly (see upstream [CUDA](../../../../../../../../vendor/llama.cpp/docs/build.md#cuda)). Examples: **`89`** for many RTX 40-series GPUs; **RTX 50 / Blackwell (e.g. RTX 5080)** is **compute capability 12.0 (sm_120)** — try **`-DCMAKE_CUDA_ARCHITECTURES=120`** with a **recent CUDA toolkit** that lists Blackwell support. If configure still fails, install the **latest** CUDA from NVIDIA, update CMake, or build on the machine with the GPU and try **`-DCMAKE_CUDA_ARCHITECTURES=native`** (upstream documents the “cannot find valid GPU for `-arch=native`” case).
- For a **portable** binary across NVIDIA GPUs, add **`-DGGML_NATIVE=OFF`** (longer compile, larger exe) per upstream.
- **ANIKAI desktop:** point **`ANIKAI_LLAMA_COMPLETION`** at the new `llama-completion.exe`, then set **`ANIKAI_LLAMA_NGL`** to how many layers to offload (start modest, e.g. `20`, and raise if VRAM allows; `0` is CPU-only).

##### Troubleshooting: CMake / ggml says **CUDA Toolkit not found**

Upstream uses **`find_package(CUDAToolkit)`** (`vendor/llama.cpp/ggml/src/ggml-cuda/CMakeLists.txt`). On Windows this is almost always **CMake not resolving the toolkit root** (not your game-ready driver).

1. **Restart the terminal** (or sign out) after installing CUDA — **`CUDA_PATH`** is written by the installer; shells that were already open will not see it.
2. **Confirm `nvcc` exists**, e.g. `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.x\bin\nvcc.exe` (the **`v12.x`** folder name matches what you installed).
3. **Set `CUDA_PATH`** to that **`CUDA\v12.x`** folder (the directory that contains **`bin`**, **`include`**, **`lib`**):
   - **Session:** `$env:CUDA_PATH = "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8"` (adjust version).
   - **Permanent:** System Properties → Environment Variables → **System** → New **`CUDA_PATH`** → same path.
4. **Pin `nvcc` for CMake** (still fails after step 3 — use your real version folder; forward slashes are safest):

```powershell
cmake -B build-cuda -DGGML_CUDA=ON `
  "-DCMAKE_CUDA_COMPILER=C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.8/bin/nvcc.exe"
```

Optional: **`-DCUDAToolkit_ROOT=C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.8`** (same root as `CUDA_PATH`).

5. **Use a VS-enabled shell** — **x64 Native Tools Command Prompt for VS 2022** or **Developer PowerShell for VS 2022**. `nvcc` needs MSVC (`cl.exe`) as the **host** compiler; a plain PowerShell with no VS environment often fails even when CUDA is installed.
6. **Re-run the CUDA installer** and ensure **Visual Studio integration** / **CUDA for Visual Studio** (wording varies by toolkit version) is checked if you skipped it the first time.
7. **Wipe the failed configure output** — delete the **`build-cuda`** folder (or pick a new name) before running `cmake -B ...` again so CMake does not reuse a bad cache.

Blackwell note: upstream may normalize **`120`** → **`120a-real`** internally; if CMake complains about architecture strings, see comments in `ggml/src/ggml-cuda/CMakeLists.txt` (CMake version vs `120a`).

##### MSBuild: **CUDA Toolkit found** then **`CudaToolkitDir` is empty** / `The CUDA Toolkit directory '' does not exist`

CMake’s **`find_package(CUDAToolkit)`** succeeded, but the **Visual Studio / MSBuild** CUDA rules (`CUDA *.targets`) run with an **empty `CudaToolkitDir`** during the **CUDA compiler identification** step. Typical with **VS Build Tools** + CMake’s default **Visual Studio generator** if **`CUDA_PATH`** is not visible to **MSBuild** (child processes).

1. Set **`CUDA_PATH`** to the toolkit root that contains **`bin\nvcc.exe`** (e.g. `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2`). Prefer a **System** environment variable, then **fully quit** the IDE/terminal and reopen so every **`msbuild`** child inherits it.
2. In the **same PowerShell session** before `cmake`, set explicitly and reconfigure into a **clean** `build-cuda`:

```powershell
$env:CUDA_PATH = "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
Remove-Item -Recurse -Force build-cuda -ErrorAction SilentlyContinue
cmake -B build-cuda -DGGML_CUDA=ON `
  "-DCMAKE_CUDA_COMPILER=C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.2/bin/nvcc.exe"
```

3. **Bypass MSBuild for CUDA** — use **Ninja** so CMake talks to **`nvcc` directly** (avoids the `ValidateCudaBuild` MSBuild target). Install [Ninja](https://github.com/ninja-build/ninja/releases) and ensure it is on **`PATH`**, then:

```powershell
$env:CUDA_PATH = "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2"
Remove-Item -Recurse -Force build-cuda-ninja -ErrorAction SilentlyContinue
cmake -B build-cuda-ninja -G Ninja -DCMAKE_BUILD_TYPE=Release -DGGML_CUDA=ON `
  "-DCMAKE_CUDA_COMPILER=C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.2/bin/nvcc.exe"
cmake --build build-cuda-ninja
```

4. Re-run the **CUDA installer** → **Modify** → enable **Visual Studio integration** for your installed VS / Build Tools so **`CudaToolkitDir`** is wired to the same toolkit version as **`CUDA 13.2.targets`**.

#### Optional: OpenSSL 3 (HTTPS — mainly `llama-server`)

- The **Electron chat bridge** uses **`llama-completion`** with a local prompt; it does **not** require TLS.
- **OpenSSL** is for **HTTPS** on **`llama-server`** (client TLS, reverse proxies). Upstream defaults **`LLAMA_OPENSSL=ON`**; if OpenSSL is missing, CMake usually prints **`OpenSSL not found, HTTPS support disabled`** and the build still completes.
- On Windows, install **OpenSSL 3** with headers/libs (e.g. Shining Light **full** layout, **vcpkg** `openssl`, or your org’s standard). Then reconfigure with **`OPENSSL_ROOT_DIR`** pointing at the install root (folder containing `include\openssl` and the `lib` tree CMake expects), for example:

```powershell
cmake -B build -DOPENSSL_ROOT_DIR=C:\OpenSSL-Win64
cmake --build build --config Release -j $env:NUMBER_OF_PROCESSORS
```

- Build / run **`llama-server`** with SSL per [`vendor/llama.cpp/tools/server/README.md`](../../../../../../../../vendor/llama.cpp/tools/server/README.md) (**Build with SSL** and `--ssl-key-file` / `--ssl-cert-file`).

#### Optional: Vulkan (AMD / Intel / NVIDIA via Vulkan)

- Install the **[Vulkan SDK](https://vulkan.lunarg.com/sdk/home#windows)** and configure with **`-DGGML_VULKAN=ON`** (see upstream **Vulkan** in the same [`build.md`](../../../../../../../../vendor/llama.cpp/docs/build.md#vulkan)). Runtime device selection is documented upstream (**`--device`**, **`--list-devices`**).
- **Practical split (e.g. RTX 5080):** ship **CUDA first** for best performance on that card; **add Vulkan later** in a **fresh** build directory (e.g. `-DGGML_CUDA=ON -DGGML_VULKAN=ON`) when you want cross-vendor fallback or dual-backend—only enable multi-backend when you plan to expose runtime choice; see upstream **multi-backend** notes in `docs/build.md`.

---

## Open questions (park in `todo/` when you pick)

- **Resume / checksum** for interrupted HF downloads (range requests or `huggingface_hub`-equivalent in Node).  
- **GGUF + mmproj** pairs: detect missing projector and show a **warning card** in UI.  
- **Verifier:** optional hash check against HF commit SHA (advanced).

---

## Related docs

- Implementations index (folder taxonomy): [`../../README.md`](../../README.md)  
- GGUF engine plan (runtime contract + trajectory): [`../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
- GGUF text generation (roles / output contract): [`../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-10 | Local GGUF bridge: env vars, Windows build steps for `llama-completion`, fixed related-doc links; last reviewed. |
| 2026-05-10 | Corrected typical VS output path to `build\bin\Release\`; `ANIKAI_LLAMA_CPP_DIR` note; PowerShell find snippet. |
| 2026-05-10 | Optional backends: CUDA, OpenSSL (llama-server HTTPS), Vulkan; pointers to upstream `build.md` and server SSL. |
| 2026-05-10 | RTX 50 / Blackwell (`CMAKE_CUDA_ARCHITECTURES=120`, sm_120) note; Vulkan-later product split for RTX 5080. |
| 2026-05-10 | CUDA “not found” on Windows: `CUDA_PATH`, `CMAKE_CUDA_COMPILER`, VS shell, wipe build dir. |
| 2026-05-10 | MSBuild empty `CudaToolkitDir`: system `CUDA_PATH`, Ninja workaround, CUDA–VS integration. |
| 2026-05-10 | Repo script `scripts/build-llama-cpp-cuda-win.ps1` (DevShell + Ninja + CUDA_PATH); linked from CUDA section. |
| 2026-05-12 | Electron GGUF spawn: prepend `CUDA_PATH\bin` or `ANIKAI_CUDA_BIN` to child PATH for CUDA DLLs. |
