# Model hub index (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Started |
| **Last reviewed** | 2026-05-10 |

Purpose: single lookup table for **engine-inference** implementation plans under `model-hub/`, mirroring the Android hub layout so you can jump between platforms by **family name**.

**Android hub (reference):** [`../../../../android-arm64/implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md`](../../../../android-arm64/implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md)

**Platform + pipeline deps:** [`../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md) · [`../PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](../PIPELINE_ENGINE_DEPENDENCY_MATRIX.md)

---

## Active on Windows (implement + tick VERIFIED)

| Family | Doc | Pipeline consumers (examples) |
|--------|-----|--------------------------------|
| **GGUF** | [`gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Chat, vision, `sd.exe` image, music arranger JSON |
| **ONNX Runtime** | [`onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Portrait depth, sprite post, voice graphs — **not imaging-only** |
| **Audio MIDI** (tool runtime) | [`../../generation/audio/MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md`](../../generation/audio/MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md) | Lane 2 render |
| **Voice packs** (Piper, Kokoro, …) | [`../../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](../../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) | Sentience → Voice |

---

## Stub / promote later (Windows)

| Family | Folder | Notes |
|--------|--------|-------|
| **FOMM / motion ONNX** | `fomm/` | Android plan is authoritative for graph semantics; Windows EP TBD |
| **PersonaLive** | [`personalive/`](../../../../android-arm64/implementations/engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) (Android doc) | Portrait motion sidecar; primary candidate for talking persona |
| OpenCV DNN | `opencv_dnn/` | |
| NCNN | `ncnn/` | |
| MNN | `mnn/` | |
| MediaPipe | `mediapipe/` | |
| LiteRT, ExecuTorch, Paddle, TVM, Tengine | respective folders | Promote only when a Windows pipeline needs them |

When adding a plan, append to **Active** and document one **VERIFIED** smoke in the plan’s verification section.

---

## Android-only families (documented, not Windows bring-up)

Mirror Android hub — do not spend Windows cycles unless a pack is explicitly ported.

| Family | Android doc |
|--------|-------------|
| QNN / SNPE | [`../../../../android-arm64/.../qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../android-arm64/implementations/engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| LiteRT | `litert/` on Android hub |
| FOMM (device path) | [`../../../../android-arm64/.../fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../android-arm64/implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| HiAI, Samsung ENN, NeuroPilot, AICore, NNAPI SL4A | See Android [`MODEL_HUB_INDEX.md`](../../../../android-arm64/implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md) |

---

## Generation (text) coordination

Text **lane index** and **per-type** plans (what users experience) live under:

- [`../../generation/text/TEXT_GENERATION_LANE_INDEX.md`](../../generation/text/TEXT_GENERATION_LANE_INDEX.md)
- [`../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md)

**Todos (no README):**

- [`../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md)
- [`../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md)

---

## Generation (imaging / music) coordination

Product lanes and mid-scope todos (engine plans stay in `model-hub/`):

- **GGUF imaging:** lane index [`../../generation/imaging/IMAGING_GENERATION_INDEX.md`](../../generation/imaging/IMAGING_GENERATION_INDEX.md), cross-cutting plan [`../../generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../../generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) — todo [`../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md)
- **GGUF music:** [`../../generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](../../generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md) — todo [`../../../todo/mid-scope/TODO_GGUF_MUSIC_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_MUSIC_DESKTOP.md)
- **ONNX engine (desktop):** [`onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) — todo [`../../../todo/mid-scope/TODO_ONNX_ENGINE_INFERENCE_DESKTOP.md`](../../../todo/mid-scope/TODO_ONNX_ENGINE_INFERENCE_DESKTOP.md)

**Model paths / import:** [`../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)

**Runtime packs (binaries only, not weights):** [`../../operations/RUNTIME_PACKS_AND_INSTALLER.md`](../../operations/RUNTIME_PACKS_AND_INSTALLER.md) — maps each hub family to a future `engine.*` / `gguf.*` installable pack; Settings → Runtime installer.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial Windows model hub index with GGUF as first engine doc. |
| 2026-05-09 | Linked text lane todos; lane index + GGUF text plan paths. |
| 2026-05-10 | ONNX promoted to active row; imaging + music coordination + ONNX todo links; model download canonical path. |
| 2026-05-17 | Link to runtime packs installer plan (bare app + optional inference per family). |
