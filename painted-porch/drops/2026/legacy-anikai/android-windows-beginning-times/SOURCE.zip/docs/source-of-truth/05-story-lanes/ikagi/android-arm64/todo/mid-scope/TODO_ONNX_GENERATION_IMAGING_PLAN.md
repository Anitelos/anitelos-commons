# TODO — ONNX generation imaging plan (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md`

---

## Intent

- Track ONNX generation outcomes separately from ONNX engine internals.
- Drive clear rollout for ONNX primary/post roles across Sprite and portrait flows.
- Keep quality/preset/device gating decisions explicit and reviewable.

---

## Checklist (working)

- [ ] Lock ONNX generation profile matrix (`FAST` / `BALANCED` / `QUALITY`).
- [ ] Select and validate first ONNX generation-capable graph path (or confirm post-first path).
- [ ] Deliver deterministic ONNX output persistence and metadata trail.
- [ ] Wire and validate at least one QUALITY S3 post graph chain.
- [ ] Define S4 helper pass policy (ONNX vs CPU) with explicit labeling.
- [ ] Promote operational status only after floor-resolution checks pass.

---

## Linked operations

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through imaging maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created dedicated ONNX generation todo bridge during generation-plan split pass. |
