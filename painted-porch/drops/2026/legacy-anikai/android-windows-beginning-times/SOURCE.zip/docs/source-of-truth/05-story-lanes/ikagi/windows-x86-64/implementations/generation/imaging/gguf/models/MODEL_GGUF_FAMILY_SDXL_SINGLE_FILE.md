# Model sheet — family: SDXL single-file GGUF (`sdxl_single_m`)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## What it is

**Stable Diffusion XL** base (and many fine-tunes) as **one GGUF** via `-m`, optionally with external VAE fix. Common for community checkpoints at 1024².

**Pack family:** `sdxl_single_m` — [`../gguf/GGUF_MODEL_PACK_FAMILIES.md`](../gguf/GGUF_MODEL_PACK_FAMILIES.md).

## Representative HF GGUF sources

| Publisher | Repo |
|-----------|------|
| city96 | [stable-diffusion-xl-base-1.0-gguf](https://huggingface.co/city96/stable-diffusion-xl-base-1.0-gguf) |
| community | `*sdxl*.gguf` quant stacks | Same router; smoke per file |

## Weight layout

```text
models/my-sdxl/
  sdxl-base-1.0-Q4_K.gguf
  vae/sdxl_vae.safetensors          # optional; recommended for some quants
```

## sd.cpp reference

```text
sd-cli -m ../models/sd_xl_base_1.0.safetensors --vae ../models/sdxl_vae-fp16-fix.safetensors -H 1024 -W 1024 -p "a lovely cat"
```

## Anikai (proposal)

| Item | Value |
|------|--------|
| **Profile id** | `sdxl_gguf` *(add to profiles)* |
| **Defaults** | 1024², ~25–30 steps, cfg 5–7, euler |
| **Router** | `planned` — basename `sdxl`, `xl-base`, `xl_` |
| **Img2img** | phase2 |

## Links

- [`MODEL_CITY96_SDXL_GGUF.md`](./MODEL_CITY96_SDXL_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Family umbrella for SDXL single-file GGUF. |
