# Proof run — phase 1: chat → media (local)

**Status:** planning  
**Related:** [`../../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../../WHAT_IS_ANIKAI_ON_WINDOWS.md), [`../../local-only-policy/`](../../local-only-policy/), [`../video/local-video-generation/`](../video/local-video-generation/)

**Important:** this phase is a **quick UI + wiring smoke test**, not a decision that any one checkpoint (including Gemma E4B) is the **main** or **only** brain of ANIKAI. The product center stays **Playground pipelines** (arbitrary model types, nodes, stacks, handoffs)—see [`../../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../../WHAT_IS_ANIKAI_ON_WINDOWS.md).

---

## True north (what the app becomes)

- **Models panel:** download **any** model type you need (GGUF, ONNX, audio, video, control, …).  
- **Playground:** compose **nodes and stacks**—cheap Flux GGUF, tiny ONNX imaging, music models, schedulers, later security / emotion / hand vision, etc.  
- **No obligation for one “super” 30B+ model:** quality and capability come from **many specialists + clear handoffs**, the same way real systems are built.

Phase 1 in *this* doc only proves: **chat can trigger a few local stacks and show results cleanly** before you invest in the full graph editor.

---

## What you want to feel in the product (phase 1 slice)

1. User types in **chat** → sees a **real image result** (not just a description).  
2. User asks for a **~30s music clip** → hears a **real audio file** in the thread.  
3. The same thread can **talk about** those artifacts (tone, changes, what worked).  
4. Everything **local** for this phase (no cloud inference).

Later: image→image, dedicated voice (TTS / clone / live conversation), true video generation, multi-node playground. This doc does **not** lock which weights you use for any step.

---

## Quick test stack (example only — swap freely)

**One convenient combo on a 5080-class box** is a **small** chat / VLM-class GGUF plus **tiny generative** sidecars—so you are not “going ham” with 30B+ while still learning attachment UX.

**Example chat / reasoning / “talk about it” LM (optional):**  
[Gemma 4 E4B community GGUF](https://huggingface.co/llmfan46/gemma-4-E4B-it-ultra-uncensored-heretic-GGUF) — *one* off-the-shelf path; **replace with any** small LM you prefer. If you use this repo: pair main quant (e.g. `Q4_K_M`) with **mmproj** (`gemma-4-E4B-it-mmproj-BF16.gguf`) for vision-language paths per their README.

**Example generative heads (pick what you like):**

- **Image file from prompt:** small **Flux** (or other diffusion) **GGUF** / local runtime—not the same job as a VLM’s “describe this image.”  
- **~30s music waveform:** a **music-generation** checkpoint / engine, not the LM’s text head.  
- **Tiny ONNX imaging:** valid for **fast pipeline nodes** later; same UI patterns apply.

**Honest modality split (whichever small LM you pick):**

- Most **VLMs** excel at **text**, **image/audio/video-in → text-out** (understanding, planning, critique).  
- **Raster image** and **music waveform** generation usually need **different weights** behind the same chat surface (tool / subprocess / second graph node).  
- **True T2V** → plan under [`../video/local-video-generation/`](../video/local-video-generation/).

So phase 1 is still **“one chat”**, not **“one .gguf does every tensor op.”**

---

## Suggested phase-1 wiring (still one thread)

| User-visible capability | Typical first approach (all local; models interchangeable) |
|-------------------------|------------------------------------------------------------|
| **Chat + reasoning + critique** | Small LM (e.g. Gemma-class **or** your pick). |
| **Prompt → image file** | **Image synthesis** stack (Flux-small, SD family, etc.). |
| **Prompt → ~30s music** | **Music generation** stack; LM can shape prompt / discuss output. |
| **Talk about outputs** | Same small LM in-thread. |
| **Video** | **Later / parallel:** understanding vs generation split per `../video/local-video-generation/`. |

Label attachments in UI with **which engine** produced them so users are not misled when you add nodes.

---

## Companion anatomy (later — design intent)

Long-term companion is **not** one monolith: **STT**, **TTS**, a **conversation-facing** model for human-like back-and-forth, **scheduler**, a strong **text** worker, an **orchestrator** that supervises PC + other models, plus niche **vision** (emotion from camera, hands, realtime security), **voice affect**, etc.—**handoffs** between roles, like **functions in an anatomy**, not a single “Samantha weights file.” Android’s **emotion / mood / voice** ideas can inform **policies and UX** without locking Windows UI to Android.

---

## UI presentation (minimum bar)

- **Image:** inline thumbnail + open full size; later regenerate / vary.  
- **Music:** inline player (~30s), optional waveform, explicit file path.  
- **Thread:** show **engine / node** provenance on attachments.

---

## Operational notes (if you use the example Gemma GGUF repo)

- **Pair files:** main quant `.gguf` + **mmproj** for vision paths (per HF README).  
- **Runners:** llama.cpp / LM Studio / Ollama-style flows are listed on that page; pick **one** IPC story for `anikai-desktop` v1.  
- **Uncensored community variants:** your app owns safety UX, logging, and defaults.

---

## Next doc to add (when coding starts)

- **IPC + artifact paths** (downloads dir, chat blob attach).  
- **Quant / VRAM matrix** for your hardware.

Link from `../desktop-overlay-and-panels/` or the relevant `../engine-inference/model-hub/*/` note when those exist.
