# Android arm64 — operations index (docs ↔ todos)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

**Purpose:** one checklist that **bridges** stable implementation docs and **scoped todos** so work does not get lost when categories split (e.g. local media → imaging + pipelines + audio + vision).

**Rule:** each row links a **topic**, its **anchor doc(s)**, and an **active todo** file if one exists. Titles in `todo/` may be renamed as categories narrow or widen.

**Mechanical coverage check** (after moves or new docs): [`TODO_COVERAGE_REPORT.md`](./TODO_COVERAGE_REPORT.md) — re-run the script and update the snapshot table when `gap_count` is not 0 or the file list changes.

**Doc staging / Operations roll-ups and open checkboxes per file:** [`DOC_PROGRESS_SNAPSHOT.md`](./DOC_PROGRESS_SNAPSHOT.md) — regenerate with [`../scripts/Generate-DocProgressReport.ps1`](../scripts/Generate-DocProgressReport.ps1).

---

## Checklist (local media & imaging focus)

| Topic | Anchor doc(s) | Todo / bridge | Doc staging (anchor) |
|--------|-----------------|----------------|----------------------|
| **Execution + anti-drift (whole non-text stack)** | [`../todo/mid-scope/TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md`](../todo/mid-scope/TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md) | [`../todo/mid-scope/TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md`](../todo/mid-scope/TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md) | In progress |
| **Sprite & character quality contract** | [`generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](./generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) | — | Started |
| **FLUX generation imaging implementation** | [`generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md`](./generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md`](../todo/mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md) | Not started |
| **ONNX generation imaging implementation** | [`generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md`](./generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md`](../todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md) | Not started |
| **GGUF engine inference implementation** | [`engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`](../todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md) | In progress |
| **ExecuTorch engine inference implementation** | [`engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md`](../todo/mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **LiteRT engine inference implementation** | [`engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md`](../todo/mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **MNN engine inference implementation** | [`engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md`](../todo/mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **ONNX image runtime + pipeline plan** | [`engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](./engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md) | [`../todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`](../todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md) | In progress |
| **FOMM (Qualcomm ONNX) engine inference** | [`engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`](../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md) | Started |
| **MediaPipe engine inference implementation** | [`engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`](../todo/mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **NCNN engine inference implementation** | [`engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md`](../todo/mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **QNN/SNPE engine inference implementation** | [`engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md`](../todo/mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **Text generation role strategy** | [`generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`](./generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md) | [`../todo/mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md`](../todo/mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md) | Not started |
| **ANIKAI handover/swap orchestration** | [`anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`](./anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md) | [`../todo/mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md`](../todo/mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md) | Not started |
| **Imaging pipeline roles (per-stage engines, not code schema)** | [`pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`](./pipelines/IMAGING_PIPELINE_QUALITY_STACK.md) | [`../todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`](../todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md) | Started |
| **Sprite Maker + Sprite Sheet pipeline** | [`pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](./pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md) | [`../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`](../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md) | Started |
| **Creations Persona Rig Test pipeline** | [`pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`](./pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md) | [`../todo/mid-scope/TODO_CREATIONS_PERSONA_RIG_TEST_PIPELINE.md`](../todo/mid-scope/TODO_CREATIONS_PERSONA_RIG_TEST_PIPELINE.md) | Started |
| **Portrait autogen (4 shots → animate)** | [`generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](./generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md) | [`../todo/mid-scope/TODO_CREATIONS_PERSONA_RIG_TEST_PIPELINE.md`](../todo/mid-scope/TODO_CREATIONS_PERSONA_RIG_TEST_PIPELINE.md) | Started |
| **Portrait pack on-disk schema** | [`generation/imaging/PORTRAIT_PACK_SCHEMA.md`](./generation/imaging/PORTRAIT_PACK_SCHEMA.md) | — | Started |
| **Music generation implementation** | [`generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](./generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md) | [`../todo/mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md`](../todo/mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md) | Not started |
| **Creations music generator pipeline** | [`pipelines/CREATIONS_MUSIC_GENERATOR_PIPELINE_PLAN.md`](./pipelines/CREATIONS_MUSIC_GENERATOR_PIPELINE_PLAN.md) | [`../todo/mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md`](../todo/mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md) | Not started |
| **Voice runtime umbrella/index** | [`generation/audio/voice/VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`](./generation/audio/voice/VOICE_RUNTIME_IMPLEMENTATION_PLAN.md) | [`../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md`](../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md) | In progress |
| **Kokoro runtime lane** | [`generation/audio/voice/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md`](./generation/audio/voice/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md) | [`../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`](../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md) | In progress |
| **CosyVoice runtime lane** | [`generation/audio/voice/COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md`](./generation/audio/voice/COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md) | [`../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md`](../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md) | In progress |
| **XTTS runtime lane** | [`generation/audio/voice/XTTS_RUNTIME_IMPLEMENTATION_PLAN.md`](./generation/audio/voice/XTTS_RUNTIME_IMPLEMENTATION_PLAN.md) | [`../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md`](../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md) | Needs work |
| **Kitten runtime lane** | [`generation/audio/voice/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md`](./generation/audio/voice/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md) | [`../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`](../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md) | Needs work |
| **VITS runtime lane** | [`generation/audio/voice/VITS_RUNTIME_IMPLEMENTATION_PLAN.md`](./generation/audio/voice/VITS_RUNTIME_IMPLEMENTATION_PLAN.md) | [`../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md`](../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md) | Needs work |
| **Cloud voice providers (shared lane)** | [`generation/audio/voice/CLOUD_VOICE_PROVIDER_PLAN.md`](./generation/audio/voice/CLOUD_VOICE_PROVIDER_PLAN.md) | [`../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md`](../todo/shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md) | In progress |
| **Voice+music workforce pipeline (lyric -> gen -> mix -> optional voice overlay)** | [`pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`](./pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md) | [`../todo/shelved/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md`](../todo/shelved/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md) | In progress |
| **Bond memory/thread fixes roadmap** | [`companion-surface/BOND_STORE_ISSUES_AND_FIXES_PLAN.md`](./companion-surface/BOND_STORE_ISSUES_AND_FIXES_PLAN.md) | [`../todo/mid-scope/TODO_BOND_MEMORY_THREAD_FIXES.md`](../todo/mid-scope/TODO_BOND_MEMORY_THREAD_FIXES.md) | In progress |
| **Resona unification roadmap** | [`resona/RESONA_UNIFICATION_PLAN.md`](./resona/RESONA_UNIFICATION_PLAN.md) | [`../todo/mid-scope/TODO_RESONA_UNIFICATION_ROADMAP.md`](../todo/mid-scope/TODO_RESONA_UNIFICATION_ROADMAP.md) | In progress |
| **Reflex roaming bridge architecture + packet schema** | [`sentience/roaming/reflex/REFLEX_BRIDGE_24_7_ROAMING_ARCHITECTURE.md`](./sentience/roaming/reflex/REFLEX_BRIDGE_24_7_ROAMING_ARCHITECTURE.md)<br>[`sentience/roaming/reflex/REFLEX_BRIDGE_PACKET_SCHEMA_AND_WAKE_THRESHOLDS.md`](./sentience/roaming/reflex/REFLEX_BRIDGE_PACKET_SCHEMA_AND_WAKE_THRESHOLDS.md) | [`../todo/mid-scope/TODO_REFLEX_ROAMING_BRIDGE.md`](../todo/mid-scope/TODO_REFLEX_ROAMING_BRIDGE.md) | Started |
| **Runtime packaging (thin core vs blobs)** | [`../STORAGE_CONTRACT_V1.md`](../STORAGE_CONTRACT_V1.md) | — | Started |
| **Pipelines (Swarm shape, surfaces)** | [`pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`](./pipelines/IMAGING_PIPELINE_QUALITY_STACK.md) | [`../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`](../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md) | In progress |
| **Game Maker parent showcase operation** | [`../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`](../todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md) | parent tracker | In progress |

Add rows here whenever a new implementation doc appears under `implementations/` or `02-roadmap/`.

---

## How this ties to the “rant” (history in one paragraph)

Sprite work started as a **simple** todo (bounds + quality). Planning **ahead** for sprite **sheets** and **pipelines** surfaced missing **imaging inference** (diffusion graphs / ONNX imaging—not just text). That forced raising the bar to **`SPRITE_QUALITY_FLOOR.md`**, which is **not** ONNX-only: it assumes **primary diffusion** on device plus **ONNX sharpen/upscale** as **stages**, not a single graph. **`pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`** names **what each stage must do** and **which engine families** own it; **`LOCAL_MEDIA…`** remains the honest adapter/registry backlog.

---

## Changelog (this index)

| Date | Note |
|------|------|
| 2026-05-06 | Added combined Sprite Maker + Sprite Sheet pipeline row and dedicated mid-scope todo bridge (single-project flow). |
| 2026-05-07 | Added Creations Persona Rig Test pipeline row + dedicated mid-scope todo bridge. |
| 2026-05-07 | Split portrait autogen bridge to Persona Rig test todo (no longer “same todo until split”). |
| 2026-05-06 | Initial index: checklist, links to imaging + pipeline stack + mid-scope todo, narrative glue for sprite→pipeline→inference split. |
| 2026-05-06 | Removed README dependencies; added Game Maker high-scope parent operation row and pipeline/runtime link updates. |
| 2026-05-06 | Added FOMM (Qualcomm ONNX) engine inference plan row (`model-hub/fomm`) bridged to Sprite Maker todo. |
| 2026-05-06 | Added ONNX runtime plan row and fixed storage contract link after doc move. |
| 2026-05-06 | Added voice runtime parity row with code-verified plan doc and parent Game Maker linkage. |
| 2026-05-06 | Added dedicated voice+music workforce pipeline row + mid-scope todo bridge. |
| 2026-05-06 | Split voice runtime into per-engine docs (Kokoro/Cosy/XTTS) and pointed mixed workflow to `pipelines/`. |
| 2026-05-06 | Added Kitten/VITS/cloud provider voice rows and linked them to Game Maker parent checklist. |
| 2026-05-06 | Added todo bridges for Bond fixes, Resona unification, and Reflex roaming docs so implementation lanes are tracked. |
| 2026-05-06 | Added shelved expanded-voice todo bridge (Cosy/XTTS/VITS/cloud + umbrella) to keep non-mobile lanes tracked. |
| 2026-05-06 | Added `TODO_COVERAGE_REPORT.md` for repeatable implementation↔todo path coverage checks. |
| 2026-05-06 | Linked `DOC_PROGRESS_SNAPSHOT.md` + `Generate-DocProgressReport.ps1` for staging/operations roll-ups and checkbox counts. |
| 2026-05-06 | Added MediaPipe engine inference row + dedicated mid-scope todo bridge for local media split phase. |
| 2026-05-06 | Added GGUF engine inference row + dedicated mid-scope todo bridge for model-family split. |
| 2026-05-06 | Added LiteRT and NCNN engine inference rows + dedicated mid-scope todo bridges. |
| 2026-05-06 | Added ExecuTorch, MNN, and QNN/SNPE engine inference rows + dedicated mid-scope todo bridges. |
| 2026-05-06 | Added FLUX generation imaging row + dedicated mid-scope todo bridge for generation-side planning split. |
| 2026-05-06 | Added ONNX generation imaging row + dedicated mid-scope todo bridge for generation-side planning split. |
| 2026-05-06 | Added music generation + Creations music pipeline rows with one shared mid-scope todo bridge. |
| 2026-05-06 | Added text role strategy + ANIKAI handover orchestration rows with one shared mid-scope todo bridge. |
| 2026-05-06 | Replaced legacy local-media anti-drift row with dedicated runtime guardrails/placement todo bridge. |
