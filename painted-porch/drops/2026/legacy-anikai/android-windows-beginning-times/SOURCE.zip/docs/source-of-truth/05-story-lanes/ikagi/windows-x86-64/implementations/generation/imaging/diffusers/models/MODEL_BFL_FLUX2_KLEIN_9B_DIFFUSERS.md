# Model sheet — FLUX.2 Klein 9B (BFL Diffusers)

| Field | Value |
|-------|-------|
| **HF** | [black-forest-labs/FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B) |

Official full bundle. Optional uncensored encoder swap: [`../../gguf/models/MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md`](../../gguf/models/MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md). GGUF path: [`../../gguf/models/MODEL_BFL_FLUX2_KLEIN_9B.md`](../../gguf/models/MODEL_BFL_FLUX2_KLEIN_9B.md).
