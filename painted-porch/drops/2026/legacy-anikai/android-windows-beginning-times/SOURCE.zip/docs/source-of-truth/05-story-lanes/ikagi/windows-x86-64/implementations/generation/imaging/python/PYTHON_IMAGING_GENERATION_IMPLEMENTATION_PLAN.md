# Python imaging sidecars (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-20 |

## Purpose

Track **Python / PyTorch subprocess** work that is **imaging-adjacent** but **not** the Diffusers txt2img manifest (`media-python/run_diffusers_image.py`) and **not** GGUF `sd.exe`.

Primary candidate on desktop: **PersonaLive** — portrait animation driven by reference still + driving frames (webcam, file, or synthesized rig).

**Lane index:** [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)

**Diffusers still-image path (FHDR, Shuttle, …):** [`../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)

**PersonaLive engine plan (weights, IPC, VRAM):** [`../../../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Motion-sense product / About:** [`../../../companion-surface/DESKTOP_WORKSHOP_STATE.md`](../../../companion-surface/DESKTOP_WORKSHOP_STATE.md) · todo [`../../../todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md`](../../../todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md)

---

## Folder layout (this lane)

| Path | Role |
|------|------|
| `python/PYTHON_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md` | This file |
| `python/models/` | Per-sidecar sheets (e.g. PersonaLive pack layout) when bring-up starts |

**GGUF per-repo sheets** stay under [`../gguf/models/`](../gguf/models/) — do not duplicate DiT/encoder docs here.

---

## PersonaLive vs other Python

| Sidecar | UX surface | Doc owner |
|---------|------------|-----------|
| **PersonaLive** | Sentience → Motion-sense · portrait stream | Engine plan + future `python/models/MODEL_PERSONALIVE.md` |
| **Diffusers image** | Media Magic txt2img presets | [`../diffusers/`](../diffusers/) |
| **Media-python music** | Generating → Audio | `generation/audio/` lane |

PersonaLive does **not** ingest phonemes directly; Anikai supplies **driving frames** (see engine plan § driver synthesizer).

---

## Desktop wiring (target)

| Artifact | Path / note |
|----------|-------------|
| Motion registry | `assets/about-guide/motion-sentience-registry.json` |
| Runtime pack row | Settings → Device → Software — Python / PersonaLive pack (planned) |
| Sidecar entry | TBD under `anikai-desktop/` (mirror `media-python/` staging pattern) |

---

## Adoption checklist (PersonaLive)

1. Add `python/models/MODEL_PERSONALIVE.md` with weight paths and pack folder layout.  
2. Register **Motion-sense** catalogue row (not generic ONNX imaging table).  
3. Tick motion todo P0 items in [`TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md`](../../../todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial Python imaging sidecar lane; PersonaLive as primary; folder mirrors gguf/onnx taxonomy. |
