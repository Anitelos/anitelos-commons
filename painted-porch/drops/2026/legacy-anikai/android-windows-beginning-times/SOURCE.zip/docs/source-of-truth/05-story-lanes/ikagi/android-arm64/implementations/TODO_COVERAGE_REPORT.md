# Android arm64 — implementation ↔ todo coverage

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Operational (check procedure) |
| **Last reviewed** | 2026-05-06 |

**Purpose:** a **repeatable** check that every `implementations/**/*.md` “work doc” is referenced from at least one file under `todo/`, so folder moves and new docs do not leave orphan plans.

**Not covered here:** the human **operations board** in [`OPERATIONS_INDEX.md`](./OPERATIONS_INDEX.md) (topic rows and staging). This report is only the **mechanical** substring link from implementation paths into todo text.

**Related:** [`DOC_PROGRESS_SNAPSHOT.md`](./DOC_PROGRESS_SNAPSHOT.md) rolls up **Doc staging** / **Operations** and counts **open vs done** markdown checkboxes per implementation and todo file (regenerate via [`../scripts/Generate-DocProgressReport.ps1`](../scripts/Generate-DocProgressReport.ps1)).

---

## Rule (mechanical)

1. **Scope — implementation markdown files** under  
   `docs/source-of-truth/05-story-lanes/ikagi/android-arm64/implementations/`
2. **Exclude** (meta / index, not “owned” implementation plans):
   - `OPERATIONS_INDEX.md`
   - `DOC_STATUS_HEADER.md`
   - `README.md` (any path)
   - `TODO_COVERAGE_REPORT.md` (this file)
   - `DOC_PROGRESS_SNAPSHOT.md` (generated digest; do not require a todo backlink)
3. For each remaining `*.md`, the path **relative to `implementations/`** (forward slashes) must appear as a **substring** in the **concatenated text** of every `*.md` under `todo/`.

If the script prints **no lines after `gap_count`**, coverage is **100%** for the current tree.

---

## How to re-run (PowerShell)

From the repo root, or adjust `$implRoot` / `$todoRoot` to your machine:

```powershell
$implRoot = "docs/source-of-truth/05-story-lanes/ikagi/android-arm64/implementations"
$todoRoot = "docs/source-of-truth/05-story-lanes/ikagi/android-arm64/todo"
$repo     = "c:\Users\shino\Documents\New"  # set to your clone root
Push-Location $repo
$todoText = (Get-ChildItem $todoRoot -Recurse -Filter "*.md" | ForEach-Object { Get-Content $_.FullName -Raw }) -join "`n"
$impl = Get-ChildItem $implRoot -Recurse -Filter "*.md" | Where-Object {
  $_.Name -notin @("OPERATIONS_INDEX.md","DOC_STATUS_HEADER.md","README.md","TODO_COVERAGE_REPORT.md","DOC_PROGRESS_SNAPSHOT.md")
}
$gaps = foreach ($f in $impl) {
  $rel = $f.FullName.Substring((Resolve-Path $implRoot).Path.Length + 1).Replace("\", "/")
  if ($todoText -notmatch [regex]::Escape($rel)) { $rel }
}
"implementation_md_count=$($impl.Count)"
"gap_count=$($gaps.Count)"
$gaps
Pop-Location
```

**Pass:** `gap_count=0` and no paths listed.

---

## Doc progress + checkbox snapshot (run after big doc edits)

Same repo root as above. Regenerates [`DOC_PROGRESS_SNAPSHOT.md`](./DOC_PROGRESS_SNAPSHOT.md) (roll-ups, per-file open/done counts, and open-checkbox drill-down).

**Full digest (includes long drill-down lists):**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File docs/source-of-truth/05-story-lanes/ikagi/android-arm64/scripts/Generate-DocProgressReport.ps1
```

**Counts and roll-ups only (skip verbatim open-checkbox lists):**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File docs/source-of-truth/05-story-lanes/ikagi/android-arm64/scripts/Generate-DocProgressReport.ps1 -NoDrilldown
```

---

## Last snapshot (update when you re-run)

| Date (UTC) | `implementation_md_count` | `gap_count` | Notes |
|------------|---------------------------|-------------|--------|
| 2026-05-06 | 17 | 0 | All scoped implementation paths referenced from `todo/`. |

---

## Changelog (this report)

| Date | Note |
|------|------|
| 2026-05-06 | Initial report: rule, PowerShell check, first snapshot. |
| 2026-05-06 | Exclude generated `DOC_PROGRESS_SNAPSHOT.md` from mechanical coverage; link to checkbox roll-up generator. |
| 2026-05-06 | Added copy-paste commands for `Generate-DocProgressReport.ps1` (with `-NoDrilldown` variant). |
