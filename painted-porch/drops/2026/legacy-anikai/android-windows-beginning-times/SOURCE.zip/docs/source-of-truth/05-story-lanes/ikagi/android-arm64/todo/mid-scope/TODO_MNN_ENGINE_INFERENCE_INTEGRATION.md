# TODO — MNN engine inference integration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Track MNN as a wildcard performance lane for device-adaptive mobile inference.
- Convert runtime mention into testable adapter/session work.
- Keep auto-tuning and fallback behavior explicit per device class.

---

## Checklist (working)

- [ ] Finalize MNN adapter IDs and manifest schema for model hub.
- [ ] Implement runtime tuning policy + timeout/fallback behavior.
- [ ] Deliver one operational helper pack end-to-end.
- [ ] Wire one specialist lane to MNN adapter resolution.
- [ ] Validate lifecycle, cancellation, and repeat-run stability.
- [ ] Ensure local failure states remain explicit and honest.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created MNN inference integration todo during runtime-family expansion pass. |
