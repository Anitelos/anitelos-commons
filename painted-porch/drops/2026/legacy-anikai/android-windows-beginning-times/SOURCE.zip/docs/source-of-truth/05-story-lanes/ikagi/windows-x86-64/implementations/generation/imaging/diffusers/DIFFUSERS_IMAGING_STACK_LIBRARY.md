# Diffusers imaging stack library (Windows x86-64)

| Field | Value |
|-------|-------|
| **Parent plan** | [`DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) |
| **Lane index** | [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md) |
| **Desktop presets** | `anikai-desktop/config/media-models.json` |

Curated **Diffusers folder trees** (`model_index.json` + subfolders) for users who prefer Python `FluxPipeline` / `DiffusionPipeline` over native GGUF. Each row should get a sheet under [`models/`](./models/) when adoption starts.

---

## Use-case map

| Use case | Recommended stack | Why Diffusers |
|----------|-------------------|---------------|
| **General txt2img / img2img** | FLUX.1 Dev (BFL) | Default sprite / concept art primary when GGUF is not assigned |
| **Fast aesthetic stills** | Shuttle 3.1 Aesthetic | Strong style prior; also available as GGUF |
| **Uncensored FLUX-class** | FHDR Uncensored (kpsss34) | Shipped desktop preset `flux_fhdr_uncensored_kpsss34` |
| **Official FLUX.2 Klein** | FLUX.2-klein-9B (BFL) | Full bundle before optional encoder swap |
| **CN/EN prompt-heavy** | ERNIE-Image (Baidu) | Native text encoder layout |
| **Multi-weight experiments** | BFL klein + ponpoke encoder | Phase-2 swap documented on GGUF side; Diffusers uses full tree |

**Cross-platform:** Android sprite routes reference the same HF ids — see [`../../../../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../../../../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md).

---

## Stack registry (catalogue targets)

| Stack id | HF / preset | Status | Sheet |
|----------|-------------|--------|-------|
| `fhdr-diffusers` | [kpsss34/FHDR_Uncensored](https://huggingface.co/kpsss34/FHDR_Uncensored) | shipped | [`models/MODEL_KPSSS34_FHDR_UNCENSORED.md`](./models/MODEL_KPSSS34_FHDR_UNCENSORED.md) |
| `shuttle-31-diffusers` | [shuttleai/shuttle-3.1-aesthetic](https://huggingface.co/shuttleai/shuttle-3.1-aesthetic) | planned | [`models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC_DIFFUSERS.md`](./models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC_DIFFUSERS.md) |
| `flux2-klein-bfl-diffusers` | [FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B) | planned | [`models/MODEL_BFL_FLUX2_KLEIN_9B_DIFFUSERS.md`](./models/MODEL_BFL_FLUX2_KLEIN_9B_DIFFUSERS.md) |
| `flux1-dev-bfl-diffusers` | [FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev) | planned | [`models/MODEL_BFL_FLUX1_DEV_DIFFUSERS.md`](./models/MODEL_BFL_FLUX1_DEV_DIFFUSERS.md) |
| `ernie-image-baidu-diffusers` | [baidu/ERNIE-Image](https://huggingface.co/baidu/ERNIE-Image) | planned | [`models/MODEL_BAIDU_ERNIE_IMAGE_DIFFUSERS.md`](./models/MODEL_BAIDU_ERNIE_IMAGE_DIFFUSERS.md) |

---

## Folder layout (all presets)

```
models/diffusers/<preset-id>/
  model_index.json
  transformer/   # or unet/ per pipeline class
  vae/
  text_encoder/
  text_encoder_2/   # FLUX.1 / SDXL-class only
```

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial stack library; ties to sprite / portrait Android plans and About catalogue rows. |
