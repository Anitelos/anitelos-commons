# What is ANIKAI on Windows?

**Lane:** Ikagi — `windows-x86-64`  
**Intent:** one place to anchor the *story* before implementation notes pile up. This is the “why and what,” not the build checklist.

---

## In one sentence

**ANIKAI on Windows is a sovereign local workshop** — one app for downloads, runtimes, models, **Media Magic** creation, and companions — so people get convenience without subscription sites or repo archaeology, while the community can keep plugging in engines and pipelines on the groundwork you ship.

---

## Current build focus (honest)

| Priority now | Later (same app, different audience) |
|--------------|--------------------------------------|
| **Media Magic** — quick Get → generate → post/preprocess for image, music, video, ONNX lanes | **Playground** — node graphs for pipeline authors |
| **Every inference family runs** at least once (representative preset per family, not every weight) | **Workshop Terminal** — logcat + npm dev checks for creators ([`implementations/the-terminal/`](implementations/the-terminal/)) |
| **Runtime packs** — one-time install, no “set up Python yourself” | Hosted-clone parity (Suno-class, Pixel Lab-class) as **local plug-and-play**, not rent |

The product hook is **“almost every AI inference on PC, in one place, actually working”** — not a boast about model count, but **convenience for everyone** and **extensibility for builders**.

**Media Magic deep dive:** [`implementations/companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](implementations/companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md)

**Composable paths (Comfy vs curated, expert toggles):** [`implementations/pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md`](implementations/pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md) — why today feels **hardcoded**, and how **Playground + lane contracts + Material-Instance-style overrides** (not a literal shader editor) are the north star.

---

## Curated today, composable tomorrow (builder tension)

Recent registry work (**one stack / GGUF / Diffusers / ONNX / … per family**) is the **vocabulary** pipelines will use. It is not yet **Comfy-class mix-and-match**: backends are wired through **known handlers and tabs**, not user-adjustable graph nodes or expert path toggles.

| Today (intentional) | North star (same app) |
|---------------------|------------------------|
| **Tested stacks**, Get pack, Media Magic presets | **Lane contracts** — connect only what types and readiness allow |
| Linear **Record → Pipelines → Run** | **Expert mode** — enable/disable stages and overrides on a saved graph (UE *Material Instance* metaphor) |
| **Playground** spikes (Rete) | Full **blueprint** density — scripts, models, terminal, agents on one canvas |
| Restart to pick up staging / `.py` changes | **Reload media worker**; chat/companion stay up (later) |

Comfy wins on **free wiring**; Anikai wins on **sovereign install, packs, and teaching UX** — the product bet is to add composition **without** becoming an unmaintainable generic runtime. See the composable-paths doc for phases **A–E** (schema toggles → job API → Playground → community graphs).

---

## The problem it refuses to ignore

People already stitch together **persistent session tools**, **repeatable automations**, and **multi-agent / tool-heavy setups** across several apps. That works for experts; it is hostile to everyone else.

ANIKAI does not try to clone any single product. It tries to make three primitives obvious:

1. **Who runs** (which model, which persona, which sub-agent).
2. **What data crosses the boundary** (files, screen regions, URLs, handover tokens).
3. **Where the user watches it happen** (chat thread, run log / timeline, Playground graph, optional “planning board” view).

Windows is where that density **fits the room**: overlay shell, independent panels, multi-monitor, richer debugging, and room for blueprint-style editors that phones fight.

**Long-term shape:** pinching-money hosted tools (quick image/music sites, broken piecemeal APIs) become **optional** — the same flows run **on your PC**, wired through Anikai’s registry and runtime packs. Shard pairing, multi-pack downloads, and “throw another engine at it” composition are **features of the workshop**, not a weekend git ritual.

---

## Sister lane vs Android (docs only)

The **folder layout** next to [`../android-arm64/`](../android-arm64/) is intentionally similar so you always know *where* engine, pipeline, and sentience notes belong. **Content is not shared by default:** each platform gets **fresh implementation and todo markdown** when you are ready. Optional links between lanes (or from the app) come later, not as a standing dependency.

---

## Windows sequencing: Media Magic first (local only)

On Android, long stretches of **background-only** work without visible payoff was draining. On PC the same lesson applies: **lead with something people can click and see** — **Media Magic** (panel) and chat tools — before expecting anyone to love a log terminal or a blueprint editor.

**Hard rule for this phase:** **local inference only** — **no cloud calls and no external services** (no remote APIs, no hosted model endpoints). Everything runs on the machine you control.

**First milestone (directional):** **Media Magic** delivers the loop non-engineers expect:

1. **Quick Get** — Hugging Face (or registry) download without folder hunting ([`implementations/anikai-agent-workflows/`](implementations/anikai-agent-workflows/) HF flow).
2. **Generate** — pick family tab, prompt, see output.
3. **Post / preprocess** — the “whole slew” of ops (upscale, depth, pose, **mask** / Kontext-style inpaint, etc.) like today’s image row.
4. Repeat for **music**, **video**, and ONNX stacks as each family gets a smoke + preset.

Chat and companions **reuse the same engines** — typing, mic, or PersonaLive-style facetime later — so “ask for an edit” and “click Generate” are one workshop, not two products.

**North star (not the first milestone):** **Playground** is where **creators** download **any** model type and wire **nodes and stacks**—Flux-class GGUF, tiny ONNX imaging, audio, video, control, whatever fits the idea. **Media Magic** is where **everyone else** lives first.

**Model strategy (high level):**

- **No locked “main” LM.** Chat uses a **small** worker where it fits VRAM; **Media Magic** uses **specialists per tab**. See [`implementations/generation/local-multimodal-chat/PROOF_RUN_PHASE1_CHAT_MEDIA.md`](./implementations/generation/local-multimodal-chat/PROOF_RUN_PHASE1_CHAT_MEDIA.md) for an honest generative vs VLM split — demo, not product center.
- **Every family must run in Anikai** — GGUF image, ONNX imaging, MIDI/audio, video generation, voice, motion/PersonaLive, etc. — via **runtime packages** and at least one **representative** preset per family (Flux-class imaging is the template). **Not every model or weight variant** — you cannot ship the whole Hugging Face catalog; you **can** ship “this family works here.”
- **Runtime packs break the stack into installable parts** — one-time **Check runtimes** / stage scripts, not “clone five repos and pip install.” Models download through guided **Get**; sideloads remain welcome for power users. See [`implementations/runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](implementations/runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md).
- **Companion as anatomy, not one oracle (sentience layer).** Split roles over time: **STT** / **TTS** (e.g. **Kokoro 8** voice lane), conversation model, scheduler, orchestrator, vision/affect — reuse Android **emotion, mood, bonds, Soul Meridian** ideas. **PersonaLive** facetime chat is documented under [`implementations/engine-inference/model-hub/personalive/`](implementations/engine-inference/model-hub/personalive/). User can **talk** for image/music/video/edits without living in Media Magic panels.
- **Video** stays its own lane for true **generation** ([`implementations/generation/video/local-video-generation/`](implementations/generation/video/local-video-generation/)) so motion stacks do not collapse into “the chat LM must do it all.”

Playgrounds, Soul Meridian persistence, and creator-facing terminal tooling remain **on the roadmap**; they **do not block** “I got media back without learning local AI for three months.”

---

## What you get as a user (north star)

- **Media Magic as the front door** — stock-style creation (image, music, video, edits) without opening terminals or config folders; **Get → Generate → post/preprocess** is the default story.
- **Download and configure models** through flows that teach as they go—even gnarly topics (quantization, context limits, multimodal stacks) get **progressive disclosure**, not a wall of jargon on day one.
- **Chat and companions** for people who want **conversation**, voice, emotion, and “just ask” edits — same engines underneath, not a separate subscription app.
- **Chat stays a spine for setup and sentience.** The companion can propose downloads, compare options, walk pipeline steps, and later pair with **screen context** (what you agree to share) so setup feels collaborative, not lonely.
- **Pipelines** (panel) + **Playground** (future node canvas): saved **pipeline schemas** you record in Media Magic or compose later. Today: **Record / Stop** in the Media Magic header captures mask → main → post steps; **Pipelines** lists saved flows, assigns source paths, and **Run pipeline** replays linearly with per-step progress. Later: full **node graph** editor (Comfy / UE Blueprint lineage) with **chat-native authoring** (describe → structure → refine), plus **expert toggles** on the same schema (stage on/off, path overrides, fallback routes) before every user needs a full graph — [`implementations/pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md`](implementations/pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md).
- **Simple vs detailed graph UI** (same pipeline, two densities):  
  - **Simple view:** stepped labels (`1`, `2`, children `1a`, siblings `1b`, deep branches `12b`) so you read the story without zooming.  
  - **Detailed view:** full pins, types, and in/out labels like a blueprint.  
  - **Step inspector:** selecting a step shows **purpose, connections, and pin semantics** in plain language.
- **Image weaving** (Media Magic mode **Image weaving**): layer compositor before **bake save** in a pipeline — **layers** (left), **preview** (center), **layer settings** (right), **Recent generations** (below, shared with Standard). Starts empty; drag or double-click recent thumbs to add layers. Images: `.png`, `.jpg`, `.webp`, `.gif`, `.bmp`, `.avif`.
- **Video weaving** (Media Magic **Video → Video weaving**): track tree + ShaderToy **shader preview** (no runtime pack — WebGL2 in Electron). Clips, stills, `.glsl` / `.frag` / …; channel groups; **Weave shader** + chat `generate_shader`; GLSL errors in **media console**. Direction: [`implementations/pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md`](implementations/pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md).
- **Reusable subgraphs:** highlight a region → **turn into a named function** → drop elsewhere later (composition over one-off spaghetti).
- **Parallel “plan surface”** (future-facing): a floating control could flip to an AI-maintained **board-style** view—think Miro-like—where the system **documents intent**, reuses assets (pins, snippets, screenshots), and keeps a **zoomable playground** for strategy while the executable graph stays clean.
- **Automation and sentience** grow *from* Playgrounds: security cycles, small agents, website helpers, roaming policies—same composition language, different deployment targets (documented later in this lane).

### Companion-first workshop (later — direction, not milestone)

The long-term shape is that the **companion exposes the full ANIKAI capability inventory** — not only media. A user should be able to **author and run pipelines from chat** (with the companion and user co-editing) without opening Media Magic for every step. That includes:

- **Media lanes** (mask, generate, post, image weaving, video weaving, bake) wired as pipeline steps the companion can propose and run.
- **Non-media packs** when installed — e.g. **C++ / VS toolchain pack** (user downloads from Visual Studio; ANIKAI registers probes and templates) so companions can help **create and extend the app from within**, not only consume models.
- **Backup & restore** — snapshot installs, runtime packs, `ANIKAI_HOME` files, and UI defaults; refresh or repair without manual folder surgery. Spec: [`implementations/runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](implementations/runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) (backup section, planned).
- **ANIKAI Modders scan** (separate external app, later) — deep integrity pass over install + home trees (size, count, name, content hash beyond a single SHA-256 where needed); report **changed / missing** files; offer **repair** (replace stock files, remove bad mods) and optional **backup of user mods and creations**.

Pipeline + weaving contracts: [`implementations/pipelines/IMAGING_PIPELINE_RECORD_PLAYGROUND.md`](implementations/pipelines/IMAGING_PIPELINE_RECORD_PLAYGROUND.md), [`implementations/pipelines/PLAYGROUND_NODE_EDITOR_DIRECTION.md`](implementations/pipelines/PLAYGROUND_NODE_EDITOR_DIRECTION.md), [`implementations/pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md`](implementations/pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md).

---

## Shell shape (desktop widget mental model)

The Windows track assumes an **always-available overlay**: chat visible, a **dock** of capabilities beside it, and **separate panel windows** for depth (companion, models, Playground, automation) so nothing collapses into an impossible single pane. **Magnet panels** (planned) let power users stick those windows into **clusters** that move together — see [`implementations/companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](implementations/companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md).

That matches the “Building ANIKAI Desktop Widget” trajectory: **prove the nervous system in UI** (persistence, resize, multi-window, blur/glass) **before** every inference engine is final—so inference has somewhere to land.

---

## Personas are not Swarm

**Personas** (multiple “souls” in the product sense) are how **threads feel different**: tone, goals, journals, future voice, and **individual documentation**—even when they share one backbone model. They are **not** the same as a **Swarm** (coordinated multi-agent roles with explicit harness and visibility).

Later, a persona may **own** its own sub-agent structure and app control policies; that is still **orchestration + consent**, not “ten bots with no owner.”

---

## Groups today, friends later

Two kinds of “group” sit in this lane, and only one of them is in scope today.

**Groups today (in scope) — *companion* groups.** A user can run more than one companion at a time on PC, and ANIKAI can present them as a **group** with a **manager companion** (specialty `manager` — see [`implementations/anikai-agent-workflows/execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](implementations/anikai-agent-workflows/execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md)) that delegates work across teammates. The PC has the **VRAM, cores, and screen real estate** to make that feel honest — multiple specialists awake, the manager watching, the user dropping into any of them. Current build work feeds directly into this: Check / Repair runtimes, sidecar reuse via `_shared/`, pack-aware downloads, Conversation paths, and the Pipelines surface are all primitives a group of companions needs in order to **actually divide labor on one machine**.

**Groups later (out of scope today) — *people* groups.** Multi-user / friend-to-friend collaboration on PC is on the long horizon, not the current build. It is named here so the doc is not silent on it, not because it is near. When the time comes it will need its own honest answer for **secure invite paths, identity, transport, and what crosses the boundary** — and that work is **far from desktop scope right now**. Phone-side companions joining a PC group as limited federation nodes belongs to the same later wave.

**The IDE / workspace direction is the long shape.** As Pipelines, Conversation paths, and live preview surfaces mature, the goal is for ANIKAI to gradually **absorb jobs people currently leave the app to do** — config edits, pipeline graphs, media composition, runtime tuning — by making the in-app option the obvious one for work that already happens inside a chat conversation. **No promise on timeline.** This is direction, not roadmap.

**Right now the build stays local-first and small on purpose:** the current in-app TODO line (HF → ANIKAI download flow Slice 2, Conversation paths Slice A, Pipelines panel) finishes before any of the rows above are opened.

---

## Models panel (visual catalog)

Models and packs are not only rows in a table: they can appear as **icons in a spatial canvas**, **grouped by selection**, **named in the UI** independently of filenames, with a **Hugging Face** entry point at the top. Onboarding copy for “how to pick your first model” can arrive in a later doc; the vision here is: **spatial + legible + teachable**.

---

## Relationship to Soul Meridian and mobile

- **Soul Meridian** (long-horizon memory, taste, continuity) is a **later persistence layer**, not a prerequisite for the Windows shell to be useful.
- **Mobile** stays the **honest companion surface**: fewer panels, same manifest / readiness / handover *ideas* underneath—without demanding the full Playground editor on a phone to ship value.

---

## Game / sprite pressure test

Local inference and imaging loops (e.g. sprite tooling) remain a **valid stress test** for engines and UX, as long as the **full Swarm / Playground surface** is not a gate for shipping a tight creative loop.

See also: [`GAME_MAKER_WINDOWS_X64_DIRECTION.md`](./GAME_MAKER_WINDOWS_X64_DIRECTION.md).

---

## Principles we keep saying out loud

1. **Desktop-first for agent-world density**; mobile second for the same story, smaller stage.  
2. **Re-sequence, don’t shame the scope**—the platform shape is multi-year; the mistake is proving all of it on the smallest screen first.  
3. **Evidence over vibes:** one multi-step run with visible stages (even stubbed) beats a hundred architecture paragraphs.  
4. **Drag-and-drop visual bias** for panels over time—complexity appears as mastery grows, not on install.

---

## Where this folder lane goes next

This directory uses the **same top-level buckets** as **`android-arm64/`** (`todo`, `implementations`, `complete`, `os-quirks`, `scripts`) and the same **implementation subfolder style**—a **sibling layout**, not a shared doc tree. **Implementation plans and TODO markdown files** appear here when you promote work; they are **Windows-written**, not copies of Android files.

When the overlay drawing exists, add a short **UI contract** sibling doc (panels, z-order, persistence rules, mobile-deferred items)—so the idea stops floating.

---

## Who builds what (two audiences, one app)

| Audience | Primary surface | What “done” means |
|----------|---------------|-------------------|
| **Most users** | **Media Magic**, chat, companions | Quick Get, generate, hear/see result, light post-process; optional voice/mic later |
| **Creators / pipeline authors** | **Playground**, registry docs, terminal dev checks (future) | Compose engines, debug runs, extend packs — community keeps adding cool things |

You lay **groundwork** (registry, runtime packs, family smokes, Media Magic tabs); the community can extend without re-breaking the sovereign “one app” story.

---

## Companion notes (outside repo)

**Workshop state (living map):** [`implementations/anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md`](implementations/anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md) — Sentience catalogues, Anikai Registry, runtime probes, shell/magnets, segment chat, **Media Magic lanes**, execution-agent tracks.

**Media Magic vision:** [`implementations/companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](implementations/companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md)

Early shell decisions and chat exports also live in your local scratchpad: `c:\Users\shino\Desktop\Building Anikai Desktop Widget.md`. Promote anything stable from there into `implementations/` or `todo/` in this lane when it stops moving.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-06-02 | **Composable paths** section + link: Comfy vs curated lanes, expert/Playground direction, registry-as-vocabulary |
| 2026-05-22 | Media Magic as build center; every-family-not-every-weight; runtime packs; sovereign plug-and-play vision; creator vs user audiences; terminal deferred |
| 2026-05-22 | Pipelines Record/Stop + Image mix layout labels; companion-first inventory + backup/modders-scan direction |
