# TODO — QNN/SNPE engine inference integration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Track Snapdragon-targeted acceleration lane as a first-class ANIKAI engine family.
- Enable low-thermal always-on helper behavior where hardware supports it.
- Enforce compatibility probes and explicit fallback for unsupported devices.

---

## Checklist (working)

- [ ] Implement chipset/runtime compatibility probe path.
- [ ] Register QNN/SNPE adapter family and manifest schema requirements.
- [ ] Deliver one operational always-on helper lane on supported hardware.
- [ ] Define fallback precedence for unsupported devices (local runtime only).
- [ ] Wire capability-gated UI reveal behavior to actual runtime availability.
- [ ] Validate lifecycle/thermal stability for long-running helper scenarios.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created QNN/SNPE inference integration todo during runtime-family expansion pass. |
