# Doc division backlog (add as we go)

Purpose: when splitting **`docs/source-of-truth`** into clearer homes (including `05-story-lanes/`), use this list so nothing obvious from recent work gets dropped. **Not authoritative execution order**—just a reminder tray.

## Already anchored elsewhere (do not duplicate—link)

| Topic | Canonical place today |
|-------|------------------------|
| Local image/audio/video adapters, GGUF diffusion handoff, capability packs sketch | `02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md` |
| Runtime contract, lanes, placement, curiosity | `Anikai App/.../ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md` |
| Experience / companion philosophy | `ABOUT_SYSTEM.md` |
| Sprint checklist (world readiness) | `02-roadmap/ANIKAI_7_DAY_WORLD_READINESS_TODO.md` |
| Sprite floor, portrait contracts | `02-roadmap/SPRITE_QUALITY_FLOOR.md`, related roadmap files |

## Story-lane homes (fill when you divide)

| Topic | Suggested lane under `05-story-lanes/` |
|-------|------------------------------------------|
| Pipeline mechanics & how Swarm shapes surfaces | `ikagi/android-arm64/implementations/pipelines/` — **`IMAGING_PIPELINE_QUALITY_STACK.md`** for stage/engine roles |
| Doc ↔ todo checklist (Android implementations) | `ikagi/android-arm64/implementations/OPERATIONS_INDEX.md` |
| Coded core vs JSON vs downloadable runtimes | `ikagi/android-arm64/implementations/runtime-shape/` |
| Cross-device soul continuity | `anima-bridge/` |
| Community / hosting | `community/` |
| IP / risk | `anikai-ip/` + `android-arm64/os-quirks/ip-and-risk-log/` |

## Gaps to watch (from recent threads—not necessarily missing docs, but easy to scatter)

- **Native diffusion next steps:** device log → canonical decode → img2img → tuning plumbed into JNI—keep **one** execution pointer in the media log; use `todo/` here for scratch.  
- **7-day sprint “honesty” rule:** Day notes that touch pixels/audio must stay aligned with the media log—when dividing docs, preserve **one** anti-drift path for “demo claims vs executor.”  
- **Turbo quant / MoE expert flags:** implementation detail belongs catalogs + runtime log when landed; story intent can start in `engine-inference/model-hub/gguf/`.  
- **Windows/Linux tracks:** placeholders exist under `ikagi/`—populate when bridge/desktop docs split out of Android-centric notes.

## Rule

If there is **no** section yet, **add the folder + README when the topic earns its first note**—per your “section as we go” approach.
