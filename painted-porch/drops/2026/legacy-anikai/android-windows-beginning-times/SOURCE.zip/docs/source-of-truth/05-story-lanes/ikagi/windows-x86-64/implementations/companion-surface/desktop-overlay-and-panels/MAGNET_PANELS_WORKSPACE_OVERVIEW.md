# Magnet panels — workspace overview (Windows x86-64)


| Field             | Value                                                   |
| ----------------- | ------------------------------------------------------- |
| **Doc staging**   | Started                                                 |
| **Operations**    | **Project tree M0 shipped**; drag-magnet M0 **shipped** |
| **Last reviewed** | 2026-05-20                                              |


**Workshop context:** `[../DESKTOP_WORKSHOP_STATE.md](../DESKTOP_WORKSHOP_STATE.md)`

**Implementation plan:** `[MAGNET_PANELS_WORKSPACE_IMPLEMENTATION_PLAN.md](./MAGNET_PANELS_WORKSPACE_IMPLEMENTATION_PLAN.md)`

**Todo:** `[../../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md](../../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md)`

**Project tree (shipped, separate HWND):** `[PROJECT_WORKSPACE_TREE.md](./PROJECT_WORKSPACE_TREE.md)` — not the same as drag-magnet Settings/Models.

**Doc index:** `[../../WINDOWS_DESKTOP_INDEX.md](../../WINDOWS_DESKTOP_INDEX.md)`

---

## One sentence

**Magnet panels** let power users **stick** floating tool windows (Settings, Models, Companion, Media Magic, future Playground) to the **chat shell** or to **each other**, so clusters move together like the dock — without cramming everything into one pane.

---

## Audience (honest)


| Audience                           | Fit                                                                      |
| ---------------------------------- | ------------------------------------------------------------------------ |
| **Power users / workspace lovers** | Primary — this feature is *for* them.                                    |
| **Everyday Joe**                   | Not yet — multi-window + magnets assume tolerance for HWND choreography. |


This does **not** replace the dock. The dock is the **fixed** capability strip on the chat edge. Magnets are **optional** links you create by dragging.

---

## Mental model

```mermaid
flowchart TB
  subgraph cluster["Cluster (example)"]
    Chat["Chat — anchor"]
    Chat --> Dock["Dock — built-in satellite"]
    Chat --> S["Settings — satellite"]
    Chat --> M["Models — satellite"]
    M --> P["Future: panel-on-panel"]
  end
```



Three ideas:

1. **Anchor** — the window you drop *onto* (chat or an already-linked panel). Gets a **highlighted border** while it is the magnet target / drag handle for the cluster.
2. **Satellite** — the window you dragged *from* free-floating. **Follows** the anchor when the anchor moves (same class of behavior as dock ↔ chat today).
3. **Link** — a logical record in the main process: `{ anchorId, satelliteId, offset }`. **Not** Electron `parent:` (see plan).

**Detach:** drag the **satellite** by its title bar (or explicit unmagnet control) → link removed; satellite stays where you left it.

**Do not** globally snap every open panel when chat moves — only **linked** satellites follow.

---

## Rules (v1 — lock these before code)


| #   | Rule                                                                                                                                                                 |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| R1  | **Drop target = anchor.** Dragged window = satellite.                                                                                                                |
| R2  | Anchor window shows **highlight border** when it has satellites (or when hover-magnet is armed).                                                                     |
| R3  | Moving **anchor** moves all its satellites preserving **offset**.                                                                                                    |
| R4  | Moving **satellite** alone **breaks** the link (unless we add a modifier later).                                                                                     |
| R5  | Multiple satellites per anchor allowed (e.g. Settings + Models on chat).                                                                                             |
| R6  | **Panel → panel** link: satellite of satellite; moving parent anchor propagates whole subtree (phase 2).                                                             |
| R7  | **Z-order:** chat focus raises chat above *inactive* satellites; focused satellite can raise above chat; never use Win32 child-of-parent for panels (breaks clicks). |


---

## What already exists (desktop today)


| Piece                                    | Status      | Code / doc                                                   |
| ---------------------------------------- | ----------- | ------------------------------------------------------------ |
| Chat + dock separate HWNDs               | Shipped     | `main.js` — `syncDockPosition()`                             |
| Panels as separate HWNDs                 | Shipped     | `main.js` — `createAndRegisterPanel()`                       |
| Open placement (most space L/R)          | Shipped     | `computePanelOrigin()`                                       |
| Detached companion chat + magnet re-dock | Shipped     | `renderer.js`, `WORKFORCE_AND_ORCHESTRATION_VISION.md` §7.1b |
| Panel follow chat on every move          | **Removed** | Was `syncOpenPanelPositions()` — magnets are opt-in only     |


---

## Relation to “plug and play” and pipelinespersona-1779458765505

- **Magnets** solve **spatial** workspace — arranging many panels while you work.
- **Model hub / runtime packs** solve **what runs** — GGUF, ONNX, whisper, Python, MIDI, etc.
- **Pipelines / Playground** benefit later when a graph editor panel can magnet to Media or Chat — same link machinery.

Pipelines do not require magnets to ship; magnets make multi-panel pipeline editing tolerable on one monitor.

---

## Phases (summary)


| Phase       | User-visible                                                                                                         |
| ----------- | -------------------------------------------------------------------------------------------------------------------- |
| **M0**      | Magnet **panel → chat** only; follow on anchor move; detach on satellite drag                                        |
| **Tree M0** | **Shipped** — dedicated workspace satellite + left rail (`[PROJECT_WORKSPACE_TREE.md](./PROJECT_WORKSPACE_TREE.md)`) |
| **M1**      | Highlight border + shared “follow controller” with dock                                                              |
| **M2**      | Magnet **panel → panel** (one chain level)                                                                           |
| **M3**      | Power-user workspace extensions (see plan § Power-user extensions — TBD)                                             |


---

## Open product questions

1. **Magnet trigger** — release-overlap vs edge snap zone vs modifier key (Alt)?
2. **Default offset** — flush right (today) vs remember last edge per anchor?
3. **Resize anchor** — satellites keep fixed offset (may clip) vs reflow stack?
4. **Persist layout** — restore links on relaunch? (defer)

---

## See also

- `[WHAT_IS_ANIKAI_ON_WINDOWS.md](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)` — shell shape
- `[RUNTIME_PACKS_AND_INSTALLER.md](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md)` — engines behind the panels
- Android handover: `[../../../../android-arm64/implementations/anikai-handover/SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md](../../../../android-arm64/implementations/anikai-handover/SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md)` — unrelated to HWND, same “slot” discipline for models

