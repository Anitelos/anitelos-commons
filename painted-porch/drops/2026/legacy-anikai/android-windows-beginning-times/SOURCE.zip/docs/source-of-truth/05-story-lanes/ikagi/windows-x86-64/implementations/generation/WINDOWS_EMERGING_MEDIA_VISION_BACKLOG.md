# Windows — emerging media & vision backlog (watch list)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started (evaluation only) |
| **Last reviewed** | 2026-05-22 |
| **Source** | User notes + Desktop `ai news.txt` transcript (week-of roundup; not in repo — verify licenses/VRAM before pack rows). |

Purpose: capture **models and papers** worth tracking for Anikai Windows **without** committing implementation. When a row graduates, add a `MODEL_*` or `PACK_*` doc under `generation/` or `runtime-shape/packs/` and wire probes + Media Magic / Sentience surfaces.

**Not in scope:** replacing current sprite Kontext path, cloud-only APIs as “local success,” or shipping every item below.

---

## Priority lens (Anikai-specific)

| Priority | Why |
|----------|-----|
| **P0 — Sentience / security footage** | Fast **video → structured events + timestamps** on consumer GPU; complements desktop copilot and future “review this clip” flows. |
| **P1 — Sprite / Media Magic quality** | Higher-fidelity **pixel-space** diffusion or alignment methods that improve stills without “success by downsizing.” |
| **P2 — 3D ingest** | **Image → 3D** for props/characters (game pipeline, preview in Creations) — LiTo-class. |
| **P3 — Video product** | Unified edit/generate/understand video; **guided** video (sketch + ref + prompt) when weights ship. |
| **P4 — Adjacent** | Translation (HY-MT2), music (Stable Audio 3), fashion try-on — useful but not core sprite/sentience blockers. |

---

## Backlog table

| Id | Name | What it does | Local / code status (May 2026) | Rough hardware | Anikai fit | Links |
|----|------|--------------|--------------------------------|----------------|------------|-------|
| **marlin-2b** | **Marlin 2B** | Video understanding: scene captions, **timestamped events**, “when did X happen” (e.g. gunfight window). ~2B params, Qwen3.5-2B lineage; **&lt;6 GB** total cited. | Weights + run instructions advertised open | Low–mid GPU | **Sentience vision** — security footage, clip search, moderation, dataset labeling; pair with screen-agent / file-drop review UX | HF / project pages from roundup |
| **qwen-realtime-vlm** | **Qwen real-time multimodal vision** (user watch) | Streaming / low-latency vision+language (product hype; **not** in our local registry yet). | **Not local yet** (user) | TBD | Live companion sight, camera loop, “what changed on screen” — probe when HF pack exists | Track Qwen release notes |
| **lance-3b** | **Lance** (ByteDance) | Unified **image + video**: txt2video, video edit (multi-turn), txt2img, image edit, VQA on video. “Nano-banana for video” positioning. | Code released; **~40 GB VRAM** cited for local run | High-end GPU | Media Magic **video** lane; edit-in-place on generations; **not** sprite-first | Project repo from video roundup |
| **lito** | **LiTo** (Apple) | **Image → 3D** with **surface light field** tokenization — view-dependent appearance (reflections), not just mesh shell. | Code + train scripts on project site | Mid–high GPU (verify README) | Creations **3D preview**, asset handoff to engines; compare to Trellis-class | [apple.github.io/ml-lito](https://apple.github.io/ml-lito/) |
| **cog-omnicontrol** | **CogOmniControl** | **ControlNet-for-video**: sketch / pose / line-art animation + reference image + prompt → faithful clip. | **Paper only** — no public weights yet | N/A | Directed gameplay trailers, sprite-to-motion ads, **Playground** graph when released | Paper / demo site |
| **flash-grpo** | **Flash GRPO** | Training **alignment** for video diffusion (human-preference quality) — faster than full-trajectory GRPO. | GitHub train/run released | Training GPU heavy | Improves **downstream** video generators we already host — not a user-facing button by itself | Repo from roundup |
| **l2p** | **L2P** | **Pixel-space** diffusion (no VAE latent); strong detail; **1K** model ~**20 GB**; 4K/8K claims for future weights. | **1K model out**; higher-res pending | Mid–high GPU | Media Magic **primary still** candidate; may beat latent mush for Floor A–D | Project page from roundup |
| **pano-world** | **PanoWorld** | Floor plan + style ref → **consistent multi-room 3D panorama tour** (VR/real-estate style memory). | **Coming soon** (no weights yet) | TBD | Architecture viz, level-design mood boards — separate from sprite NESW | Project page |
| **stable-audio-3** | **Stable Audio 3** | Open **music / SFX** generation; small/medium weights; inpainting/extend; LoRA docs. Medium ~**10 GB** cited. | HF weights for open tiers | Consumer GPU | Media Magic **Audio** / Creations music; extends existing Stability relationship | Stability HF repos |
| **hy-mt2** | **HY-MT2** (Tencent) | Instruction-following **translation** (33 langs); preserves JSON/UI placeholders; MoE 30B active ~3B; **1.8B ~4 GB**. | Released + GGUF/FP8 variants cited | 1.8B on most GPUs | Companion + pipeline **localization**; app string / subtitle tools | Tencent open release |
| **fashion-chameleon** | **Fashion Chameleon** (Alibaba) | **Real-time** video try-on: switch garments during motion (~24 FPS single GPU claimed). | Code **planned** release | Single GPU | E-com / fashion vertical — not core Anikai | GitHub “coming” |

---

## User-called workflows (map to rows)

| User intent | Backlog ids | Notes |
|-------------|-------------|-------|
| Sentience scans **security footage** quickly | **marlin-2b**, later **qwen-realtime-vlm** | Marlin is the near-term open, small-VLM bet; structure events → SQLite / timeline UI. |
| **Text / image → 3D** assets | **lito** | LiTo from [Apple ML LiTo](https://apple.github.io/ml-lito/); evaluate mesh/export formats vs game ingest. |
| **Reference + control** video (sketch/pose drives output) | **cog-omnicontrol** | Wait for weights; mirror in Playground as control edges + ref image nodes. |
| Better **still** quality for sprites | **l2p**, existing **Kontext Diffusers** | L2P is pixel-native; Kontext remains current shipped path in Games sprite. |
| “Great new media models” from video roundup | **lance-3b**, **flash-grpo**, **stable-audio-3** | Lance = unified AV; Flash GRPO = trainer for video quality; Stable Audio = audio lane. |

---

## Evaluation checklist (before any row → pack)

1. **License** — commercial / redistribution OK for Anikai bundles?
2. **VRAM envelope** — honest min spec on RTX 3060–4090 class; no silent 40 GB surprise.
3. **Runner** — Diffusers script vs ONNX vs GGUF vs custom CUDA — fits [`PACK_CUDA`](../../runtime-shape/packs/PACK_CUDA.md) / existing IPC?
4. **Surface** — Media Magic step, Sentience probe, or Playground node only?
5. **Metadata** — `modelRef`, stage timings, failure codes (same discipline as sprite generate).
6. **Android parity** — optional; Windows lane may ship first.

---

## Related

- [`../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md) — current shipped sprite steps.
- [`./imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](./imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) — success contract for stills.
- [`../generation/motion/MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md`](../generation/motion/MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md) — sight/motion families.
- [`../anikai-agent-workflows/execution-agent/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../anikai-agent-workflows/execution-agent/DESKTOP_COPILOT_AND_SCREEN_AGENT.md) — perception loop.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial watch list from user `ai news.txt` + LiTo / Qwen realtime / guided-video notes. |
