# Todo (active drift)

**Scope:** current thinking, scoped by effort. This is the **bridge** while `implementations/` holds stable design text.

| Subfolder | Use |
|-----------|-----|
| `low-scope/` | hours–a day |
| `mid-scope/` | days–a week |
| `high-scope/` | multi-week / architectural |
| `shelved/` | paused on purpose—easy to scan when you return |

**When to open:** you have bullets, not prose contracts yet.
