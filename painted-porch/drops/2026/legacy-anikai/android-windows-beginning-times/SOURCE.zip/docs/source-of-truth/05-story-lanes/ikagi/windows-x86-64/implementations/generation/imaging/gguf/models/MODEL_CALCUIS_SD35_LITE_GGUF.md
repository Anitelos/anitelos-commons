# Model sheet — SD 3.5 Lite 2B (calcuis GGUF)

| Field | Value |
|-------|-------|
| **Pack family** | `sd3_clip_stack` |
| **DiT** | [calcuis/sd3.5-lite-gguf](https://huggingface.co/calcuis/sd3.5-lite-gguf) |
| **VAE (Get pack)** | Pig VAE `vae/diffusion_pytorch_model.safetensors` from [calcuis/sd3.5-large-gguf](https://huggingface.co/calcuis/sd3.5-large-gguf) |
| **Encoders (Get pack)** | `clip_l.safetensors` · `clip_g.safetensors` · `t5xxl_fp8_e4m3fn.safetensors` from calcuis large repo — downloaded into `sd35-lite-calcuis/` when missing |

**Get pack (5 files):** lite DiT GGUF + pig VAE + clip stack. Preflight scans `sd35-lite-calcuis/`, other pack folders, and `_shared/` — reuses encoders from a large pack install without assuming you already ran large Get pack.
