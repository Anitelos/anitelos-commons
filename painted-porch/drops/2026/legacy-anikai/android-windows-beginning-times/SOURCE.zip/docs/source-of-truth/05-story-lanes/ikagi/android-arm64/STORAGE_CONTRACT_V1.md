# Storage Contract v1

Status: Draft for implementation lock; thread/checklist backlog lives in `BOND_STORE_ISSUES_AND_FIXES_PLAN.md` (historical filename; Bond Store UI retired).
Owner: ANIKAI core product/runtime.
Date: 2026-05-01

## Purpose

Define one canonical storage layout and ownership model so Bond Store, Resona, Audit, and runtime systems stop writing to overlapping or unclear destinations.

This contract is implementation-facing and should be treated as the source of truth for file destinations, retention, and UI storage reporting.

**Cross-ref:** shipped slices and checklist status — `docs/source-of-truth/02-roadmap/BOND_STORE_ISSUES_AND_FIXES_PLAN.md` (**Progress log**). Runtime companion behavior — `Anikai App/src/main/java/com/anikai/ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md` (**Canonical storage and workspace drops**).

## Core principles

- Keep runtime-critical chat and memory source-of-truth in database layers.
- Use files for artifacts, exports, mirrors, and attachment payloads.
- Keep raw life telemetry internal/private by default.
- Keep user-facing folder names aligned with app language.
- Minimize top-level folder count.
- Avoid one giant unbounded text file for live continuity.

## Canonical top-level layout

Root: `ANIKAI/`

- `Models/`
- `Resona/`
- `BondStore/`
- `Audit/`
- `Backups/`
- `Profiles/` (kept top-level for now; can be revisited later)

Removed/renamed top-level roots:

- `Projects/` -> merged into `Resona/`
- `ResonaCoLab/` -> merged/renamed to `Resona/`
- `BondQueries/` -> `BondStore/Exports/`
- `DropBox/` -> removed (replaced by project-scoped inbox and BondStore content)
- `LogcatReport/` -> `Audit/Logs/`
- `Archive/` (raw) -> internal private storage only
- `Knowledge/` -> `BondStore/Knowledge/`
- `Voices/` -> `Models/Voices/`

## Canonical folder tree

```text
ANIKAI/
  Models/
    Companion/
    Reflex/
    Swarm/
    Voices/
      expressive/
  Resona/
    SoloProjects/
      <project-id-or-name>/
        technical_manual.md
        context/
          dated_logs/
          snapshots/
        inbox_drop/
          files/
          reports/
    ColabProjects/
      <space-id>/
        space.json
        snapshots/
  BondStore/
    Journal/
    Knowledge/
    Content/
      files/
      images/
      audio/
      video/
      refs/
    Exports/
  Audit/
    Logs/
    Exports/
  Backups/
  Profiles/
```

## Ownership and write policy

- `Models/*`
  - Owner: model/runtime installers and loaders.
  - Content: model assets, expressive voice packs.

- `Resona/SoloProjects/<project>/inbox_drop/*`
  - Owner: Inbox Drop pipeline for that project only.
  - Rule: Inbox Drop is project-scoped. Summaries/reports stay in the same project folder.

- `BondStore/Content/*`
  - Owner: life-thread attachment ingestion.
  - Rule: file drops from life chat land here, not in project inbox.

- `BondStore/Journal/*`
  - Owner: Bond Store journal export/mirror logic.
  - Rule: condensed outputs may be mirrored here as files, but canonical journal source remains DB unless explicitly migrated.

- `BondStore/Knowledge/*`
  - Owner: bonded-learning distillation.
  - Rule: knowledge captured through companion relationship belongs here.

- `BondStore/Exports/*`
  - Owner: topic/thread/journal exporters.
  - Rule: user-readable exports only; do not treat as runtime source.

- `Audit/Logs/*`
  - Owner: diagnostics and crash/logcat capture.
  - Rule: operational logs only.

- `Backups/*`
  - Owner: DB backup/export tooling.

- `Profiles/*`
  - Owner: profile portrait/media generation.

## Internal/private storage contract

These do not live under external `ANIKAI/`:

- Raw life archive logs (private app files).
- Context archive chunks (private app files).
- Active model staging (no-backup internal).
- Runtime cache/transient media (cache dirs).

Rationale: privacy, performance, bounded cleanup, and avoiding user-visible noise.

## Life continuity and long-range performance

Do not implement life continuity as one huge markdown file.

Required behavior:

- Live continuity source is DB-backed thread history.
- UI uses paged/cursor loading (windowed retrieval).
- Off-screen windows are released from memory.
- Scrolling far back rehydrates older windows by cursor/date range.
- Scrolling back to present unloads stale windows.

Optional file mirrors:

- Daily markdown snapshots (`dd-mm-yyyy.md`) for export/audit readability.
- Mirror files are not runtime chat authority.

## Attachment handling contract

For life chat attachments:

- Store original under `BondStore/Content/<type>/`.
- Store lightweight derivative metadata for fast recall:
  - image thumbnail / OCR text
  - document excerpt
  - audio/video quick descriptors
- Optionally store cold-storage compressed package for large artifacts.
- Runtime recall uses metadata + pointer, not full binary scan.

For project attachments:

- Store under `Resona/SoloProjects/<project>/inbox_drop/files/`.
- Write summarizer output under `inbox_drop/reports/`.

## Retention and cleanup (v1)

- Raw life archive (internal): default 7 days, early delete allowed after successful condensation.
- BondStore content attachments: policy-driven; no silent destructive deletion without user policy.
- Audit logs: bounded retention policy with user override in Audit.
- Cache/transient media: aggressive cleanup allowed.

## Data tab integration requirements

Audit/Data surfaces must show:

- Folder/group storage usage by canonical section (`Models`, `Resona`, `BondStore`, `Audit`, `Backups`, `Profiles`).
- Internal private buckets (`context archive`, `raw archive`, `cache`, `db`) as linked system buckets.
- Tap-through navigation:
  - from home/status chips -> Data tab
  - from Data tab -> adjust/cleanup/view actions per bucket.

Permission and destructive-action rules:

- Internal buckets are view-only by default from Data tab.
- Exception: `context archive` (context chunks) can be user-adjusted from Data tab controls.
- Other internal buckets are untouchable except through explicit reset-state flows.

## Home storage status requirements

Home hero/data-status surface must evolve from single lump-sum context display to dynamic bucketed telemetry.

Required behavior:

- Show per-bucket live usage chips/cards (same canonical groups used in Data tab).
- Include both external folders and internal private buckets.
- Allow drill-down from each chip into the Data tab section filter.
- Refresh usage values periodically and on major write/delete operations.
- Avoid heavy synchronous scans on UI thread (background sampling with cached last snapshot).

## Reset-state safety contract

The existing reset-state control in User Access is a high-impact action and must include hard safety rails.

Required behavior:

- Present a high-visibility warning explaining that reset affects most storage areas and cannot be trivially undone.
- Offer optional pre-reset backup before confirmation.
- Backup option must be explicit and user-selectable (not forced, not hidden).
- Confirm final action with a second acknowledgement step.
- Report clear post-reset outcome summary (what was cleared, what was preserved).

## Migration map (old -> new)

- `ANIKAI/Projects/*` -> `ANIKAI/Resona/SoloProjects/*`
- `ANIKAI/ResonaCoLab/ProjectSpaces/*` -> `ANIKAI/Resona/ColabProjects/*`
- `ANIKAI/BondQueries/*` -> `ANIKAI/BondStore/Exports/*`
- `ANIKAI/Knowledge/*` -> `ANIKAI/BondStore/Knowledge/*`
- `ANIKAI/Voices/*` -> `ANIKAI/Models/Voices/*`
- `ANIKAI/LogcatReport/*` -> `ANIKAI/Audit/Logs/*`
- `ANIKAI/DropBox/*`:
  - project-scoped artifacts -> `ANIKAI/Resona/SoloProjects/<project>/inbox_drop/*`
  - life chat artifacts -> `ANIKAI/BondStore/Content/*`
- external raw archive -> internal private raw archive location

## Non-goals in this contract

- Full DB schema redesign.
- UI redesign details outside storage observability requirements.
- Legacy data migration guarantees for old test data.

## Stage 5 acceptance checklist

- All storage writers use canonical destinations above.
- No new writes to deprecated roots (`DropBox`, `BondQueries`, top-level `Projects`, top-level `ResonaCoLab`, top-level `Knowledge`, top-level `Voices`, top-level `LogcatReport`).
- Raw archive writes are private/internal.
- Data tab reports canonical bucket usage and linked internal buckets.
- Home hero shows dynamic per-bucket storage status (not a single lump sum).
- Internal buckets are non-destructive by default; only context chunks are user-adjustable outside reset.
- Reset-state flow includes fat warning + optional backup + final confirmation.
- Life thread remains smooth under long history via paged loading.
- Export and mirror files are clearly marked non-canonical.
