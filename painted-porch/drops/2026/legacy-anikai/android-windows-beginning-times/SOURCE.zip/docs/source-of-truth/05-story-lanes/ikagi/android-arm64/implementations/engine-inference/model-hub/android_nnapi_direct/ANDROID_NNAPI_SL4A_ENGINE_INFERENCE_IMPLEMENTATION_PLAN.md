# Android NNAPI / SL4A direct engine inference implementation plan

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: document a potential **direct Neural Networks API (NNAPI)** integration lane (including **SL4A** / driver extensions where relevant), distinct from “NNAPI used indirectly” via ONNX Runtime or LiteRT delegates. Direct NNAPI is for custom compilation graphs, operator coverage gaps, or vendor-specific extensions when justified.

---

## Scope

This file covers:

- NNAPI `Compilation` / `Execution` paths for supported subgraphs,
- device delegation discovery (`getDevices`), FP16/INT8 policy,
- explicit comparison vs existing ONNX Runtime NNAPI EP (avoid duplicate stacks).

This file does **not** promise coverage parity with full PyTorch/ONNX graphs; many models fail NNAPI compilation without ops splits.

---

## Role model (single truth)

| Direct NNAPI lane | Ownership |
|-------------------|-----------|
| Micro-model / sliced subgraph | Candidate for hot-path helpers. |
| Full LLM | Generally out of scope for raw NNAPI. |
| Fallback when ORT NNAPI EP misbehaves | Possible diagnostic/advanced lane. |

---

## Android implementation plan (stub checklist)

- [ ] Decide whether ANIKAI ever needs NNAPI beyond ORT/LiteRT delegates.
- [ ] If yes: JNI wrapper, buffer lifecycle, async execution, error taxonomy.
- [ ] Adapter id `android_nnapi_direct` + strict capability flags.
- [ ] Document overlap policy with [`../onnx/`](../onnx/) ONNX Runtime stack.

---

## Open decisions

- whether to invest in NNAPI compilation pipeline vs focusing on QNN/NeuroPilot vendor SDKs,
- minimum Android API and NNAPI feature level targets.

---

## Linked docs

- [`../onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](../onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md)
- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub for direct NNAPI/SL4A lane vs delegate-based stacks. |
