# OS quirks (Android)

**Scope:** behaviors that are not “your bug” but still shape UX or inference (battery, thermal, vendor kills, storage paths).

**Subfolders:**

- [`device-oem-mismatch/`](./device-oem-mismatch/) — concrete mismatches and patch ideas (feeds the OEM register over time).
- [`ip-and-risk-log/`](./ip-and-risk-log/) — things to document for legal/safety posture tied to device reality (distinct from pure engineering quirks).

**When to open:** something worked on a Pixel but not on $OEM, or a policy question intersects hardware.
