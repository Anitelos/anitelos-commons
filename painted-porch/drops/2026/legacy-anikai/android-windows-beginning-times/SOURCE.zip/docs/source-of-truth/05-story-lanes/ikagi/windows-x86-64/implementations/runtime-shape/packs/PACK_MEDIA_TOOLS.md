# Media tools runtime pack (ffmpeg)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.media.tools` |
| **Tier** | shipped |
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-22 |

**Purpose:** ffmpeg/ffprobe for video weave bake, mux audio, posters, duration probe, future ASR strip from video.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

Static ffmpeg Windows x64 build; pin version in manifest.

## Staging path

`desktop-data/runtime-packs/media.tools/`

## Unlocks (no model weights)

video-mux, weave-bake, poster-frame, audio-extract

## Verification smoke

ffmpeg -version; extract 1s wav from test mp4.

## Pipeline wiring

| Step | Status |
|------|--------|
| `npm run stage-media-tools` | **shipped** |
| Probe `mediaFfmpeg.probeMediaToolsPack()` | **shipped** |
| Settings → Check runtimes card | **shipped** |
| Video weave bake / mux IPC | planned |

```bash
cd anikai-desktop
npm run stage-media-tools
npm run smoke-media-tools
```

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Promoted to **shipped** tier in catalogue; `stage-media-tools` + probe on Software tab |
| 2026-05-22 | Initial pack plan |
