# Model sheet — Wan video GGUF (future lane)

| Field | Value |
|-------|-------|
| **Doc staging** | Stub |
| **Operations** | Future (video) |
| **Last reviewed** | 2026-05-18 |

## HF / engine

- sd.cpp: `vendor/stable-diffusion.cpp/docs/wan.md`  
- Video generation — **not** in current still-image GGUF slice.

## Anikai

Track under a future **video generation** lane when music/video work starts. Do not route through `runImageGenerationMain`.

## Links

- [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Stub to avoid misrouting Wan weights into image IPC. |
