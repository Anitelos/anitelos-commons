# ExecuTorch engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define ExecuTorch as ANIKAI's PyTorch-to-edge inference lane so research-first model families can land on-device with explicit capability contracts, device gating, and app lane ownership.

---

## Scope

This file covers ExecuTorch for:

- running PyTorch-family exports on Android without forcing ONNX as the only bridge,
- optional NPU-optimized delegate/provider paths where supported by device vendors,
- specialist helper/model lanes that need direct PyTorch ecosystem compatibility,
- capability-pack integration in ANIKAI model hub and Swarm routing.

This file does **not** replace:

- generation quality goals in `generation/`,
- multi-stage choreography in `pipelines/`,
- anti-drift history in `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`.

---

## Why this runtime matters for ANIKAI

ExecuTorch is the practical "new-model intake" lane for families that ship PyTorch-first. It helps ANIKAI absorb newer model capabilities faster while still enforcing local-first runtime truth.

ANIKAI value:

- faster path from PyTorch-native research to on-device runtime,
- improved chance of hardware acceleration on newer mobile NPUs,
- strong fit for "malleable sentient OS" model-capability expansion.

Rule: model file is never enough. ExecuTorch lane becomes real only after adapter + manifest + backend init + output schema pass.

---

## Role model (single truth)

| ExecuTorch lane | Ownership |
|------------------|-----------|
| **Companion primary text** | Optional, only when quality/latency bar is proven for target class. |
| **Vision/audio helper packs** | Strong candidate role for PyTorch-native helper models. |
| **Specialist Swarm jobs** | Allowed when capability flags and pass criteria are met. |
| **Generative media primary** | Allowed only when explicitly validated and documented in generation contracts. |

---

## Android implementation plan (runtime + backend)

### 1) Packaging and backend policy

- define artifact conversion/import policy for ExecuTorch-compatible assets,
- declare backend preference order by device class,
- expose backend fallback and failure reasons in diagnostics.

### 2) Adapter/session checklist

- [ ] ExecuTorch adapter family added to model hub runtime registry.
- [ ] Session init verifies tensor signatures and expected output schema.
- [ ] Backend/provider selection is deterministic and logged.
- [ ] Lifecycle/cancellation behavior is stable under repeated execution.
- [ ] Fail/degraded states are explicit in UX and logs.

### 3) Capability manifest contract

Each ExecuTorch row includes:

- adapter id and task family,
- expected model format/version constraints,
- input/output contracts and artifact schema,
- backend hints by device class,
- lane eligibility + preset mapping.

---

## App integration map

### A) Model hub ("malleable UI" fit)

- show `ExecuTorch` engine badge with capability badges and host source,
- reveal runtime controls only when compatible packs exist (sensory gating principle),
- keep role count (`xN`) visible for pack reuse across lanes.

### B) Swarm/pipeline integration

- bind ExecuTorch adapters to specialist lane ids where they fit,
- enforce explicit adapter resolution (no silent substitution),
- support pipeline-callable use where schema contracts are stable.

### C) Curiosity/sentience surfaces

- allow ExecuTorch packs to power optional See/Touch/Hear helper lanes,
- maintain strict local-vs-cloud labeling for user trust.

---

## Phased delivery

### Phase 0 - schema + intake

- establish ExecuTorch manifest fields and adapter scaffolding,
- define conversion/import checklist for candidate models.

### Phase 1 - first operational pack

- ship one helper pack end-to-end with validated output artifact.

### Phase 2 - backend hardening

- stabilize backend selection/fallback and device gating.

### Phase 3 - ecosystem expansion

- add more PyTorch-family packs with capability-pack discipline and UI gating.

---

## Verification gates (before "operational" claim)

- one ExecuTorch pack executes reliably on target devices,
- output artifact/schema is consumed by ANIKAI lane contract,
- backend fallback is deterministic and observable,
- no hidden cloud substitution for failed local execution.

---

## Open decisions

- first operational pack target for Android arm64,
- backend policy defaults for mid-tier vs flagship devices,
- minimum bar for companion-lane viability.

---

## Linked todos

- `todo/mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through model-family maturity)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial ExecuTorch engine inference implementation plan added for model-family expansion. |
