# Media runtime layout (target)

| Field | Value |
|-------|-------|
| **Status** | Planning — safe to adopt on next full re-stage |
| **Related** | [`RUNTIME_PACKS_AND_INSTALLER.md`](./RUNTIME_PACKS_AND_INSTALLER.md), [`../generation/lance/LANCE_MULTIMODAL_INDEX.md`](../generation/lance/LANCE_MULTIMODAL_INDEX.md) |

## Goal

Reduce duplicate CUDA/PyTorch trees on disk while keeping **separate pip environments** where upstream pins conflict (Lance numpy 1.23.5 vs media-python numpy 2.x, PersonaLive torch 2.1, etc.).

## Target folder shape

```text
resources/media-runtime/          # logical “Media” runtime product (packaging only)
  python/
    media/venv/                   # pack id: python.media — Diffusers, voice, compose
    engines/
      lance/engine/               # ByteDance clone — no venv colocated when WSL-only
      lito/engine/
      personalive/engine/
  wsl/
    lance/wsl-venv/               # pack id: lance.runtime.wsl — canonical on Windows
    lito/engine/.pixi/             # pack id: lito.runtime.wsl
  manifests/                      # pack.manifest.json per logical pack id
```

**Weights** stay under `%ANIKAI_HOME%/models/` (never inside runtime packs).

## What merges vs what does not

| Merge | Feasible? | Notes |
|-------|-----------|--------|
| **Folder layout** (`python/` + `wsl/` under one parent) | Yes | Renames paths in `specialist-runtime-packs.js`, `package.json` `extraResources`, staging scripts; re-run `npm run stage-*` so manifests get fresh absolute paths. |
| **One pip venv for Lance + media-python + LiTo + PersonaLive** | No | Conflicting torch (2.1 / 2.8 / 2.12), numpy (1.23.5 vs 2.x), diffusers, flash-attn ABI. |
| **Lance `venv` + `wsl-venv` on maintainer machine** | Dedup for **shipping** | Consumer Windows builds can ship **WSL-only** Lance runtime; drop Windows `venv` when flash-attn path is WSL-only. Saves ~3–6 GB. |
| **LiTo Windows `venv` + WSL pixi** | Dedup for **shipping** | Canonical path is WSL pixi; optional drop Win minimal venv from installer. |

## Pack IDs (unchanged logically)

- `python.media` — shared Diffusers/voice venv  
- `lance.runtime.win` / `lance.runtime.wsl` — specialist; engines stay lane-specific  
- `lito.runtime.wsl` — pixi env under engine  

## Post-1.0 audit rule

Before adding a new specialist lane, declare:

1. `requires: ["python.media"]` **or** a new specialist pack id  
2. Whether weights are HF, GGUF, or ONNX (model pack only)  
3. Whether Windows needs a native venv, WSL-only, or both  

Avoid a third full torch+cu126 copy unless pins align with an existing env.

## Lance weight variants (model packs)

| Stack id | Format | Runtime |
|----------|--------|---------|
| `lance-3b-unified` | HF safetensors | `lance.runtime.*` + flash-attn |
| `lance-3b-gguf` | [samuelchristlie/Lance-GGUF](https://huggingface.co/samuelchristlie/Lance-GGUF) image + video quants | Experimental runner; **not** `sd.exe` / Wan GGUF |

GGUF weights do **not** remove the need for a future Lance GGUF inference runtime; they are not served by the GGUF Core (`llama-completion` / `sd.exe`) stack today.
