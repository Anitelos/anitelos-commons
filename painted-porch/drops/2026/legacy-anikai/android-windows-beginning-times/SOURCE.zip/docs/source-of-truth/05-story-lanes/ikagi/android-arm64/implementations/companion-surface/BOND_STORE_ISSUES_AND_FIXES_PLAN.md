# Bond Store Issues and Fixes Plan

Status: **Living roadmap** — title is historical; Bond Store **UI** is retired in favor of Soul Meridian (Memories, metrics) and related surfaces. This file remains the **engineering checklist**, progress log, and issue inventory until phases are folded elsewhere.
Owner: ANIKAI core product/runtime.
Date: 2026-05-01

### Product framing refresh (thread types, 2026)

Implementation still uses `LIFE` / `PROJECT` / `LOBBY` in code, but the **user-facing model** is tightening to:

1. **Life** — one continuous default thread; returning to the app lands here (WhatsApp-style home lane).
2. **Project work** — Resona-scoped threads; treated as **sessions** (not a third “kind” of chat product). UX gap to close: explicit **Open recent projects** / **Open projects** so users are not stranded after leaving a project session.
3. **Lobby** — project-aligned **group / P2P** layer (same project thread family, online peers). Think “project threads + collaboration,” not a separate third mental model for solo users.

Older sections that recommend Bond Store as a **dedicated full screen** are **superseded**; keep the **data and handoff rules** (snapshots, life↔project summaries, attachment sinks) as authoritative. When this checklist is empty, consider renaming to `MEMORY_THREAD_ROADMAP.md` and updating cross-links from `STORAGE_CONTRACT_V1.md`.

## Progress log (2026-05-01 tranche — shipped)

Use this as the honest shipped list. Long-range checklists (**Bond Store implementation checklist**, **Audit implementation checklist**) remain authoritative for unfinished work.

### Progress log (2026-05-01 — Bond checklist §0 / §3 / §1 partial)

- **§0:** `bondMemoryBoundaryRolloutEnabled` on `anikai_settings` (v85); debug log tag `AnikaiDbRepo` on repository singleton creation; DAO TODO for §2 route audit.
- **§3:** `AnikaiDatabase.repository()` returns a single cached `AnikaiRepository` per DB instance.
- **§1:** `repairActiveLifeSingletonInvariant()` + cold-start invocation from `AnikaiApplication`; `getActiveLifeThreadsAll` query.

### Progress log (2026-05-01 — follow-up: §2 / §4 / tests)

- **§2 / §4:** `BondThreadHandoffRoutes` (KDoc map) + controller comment; verified life→project `life_snapshot_anchor` event and project→life summary line on lobby exit; forge `PublicForgeService.saveLifeSnapshot` documented as parallel path.
- **§1 / §3 tests:** `BondStoreLifeRepair` pure planner + JVM tests; Robolectric in-memory Room tests for repository singleton and repair read-after-write (`BondStoreRobolectricPersistenceTest`).
- **Test classpath:** `kotlin-test-junit` (2.3.21) for `kotlin.test` on unit test JVM; `androidx.test:core` + Robolectric 4.13.

### Documentation (locked or updated)

| Deliverable | Location |
|-------------|----------|
| Canonical on-disk layout, migration map, ownership | `docs/source-of-truth/02-roadmap/STORAGE_CONTRACT_V1.md` |
| Runtime contract: chat vs deferred inbox, thread attaches, coordinator hints | `Anikai App/.../ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md` (Living status; **Canonical storage and workspace drops**; expanded deferred inbox section) |

### Companion / continuity (related slices)

- **Carryover narration (Stage 4):** companion-voiced status after replay ingest / cortex push (`CompanionCarryoverNarrator`, `AnikaiRepository.emitCarryoverStatus`, roaming notifier when room ≠ active).

### Runtime / storage code (representative)

- **`NeuralFoundry`:** Canonical `ANIKAI/` tree (BondStore, Resona, Audit, Models/Voices, …); `getAnikaiRootDir()`; `ensureLobbyRoomChatIncomingDir()`; one-time **`migrateLegacyCanonicalStorage`** for legacy top-level folders.
- **`WorkspaceDropSources`:** classifies `workspace_drops.source` — chat-only vs deferred-review eligibility.
- **`WorkspaceInboxCoordinator`:** queues workspace review only for non-chat sources; **`maintainChatDropRetention`** archives excess/old **`NEW`** chat-only drops.
- **`ProjectThreadAttachmentSink`:** lobby/project thread attaches → Co-Lab dir / linked SAF `chat_incoming` / Resona fallback; status line for companion strip.
- **`CompanionQueryPipelineCoordinator`:** **`attachmentCoordinatorHint`** (model context only, not persisted as user line).
- **User Access:** explainer dialog on linked-folder scope (read vs future write posture); full reset flow with optional DB backup export + acknowledgement gate (`UserAccessPanel`).
- **Audit → Data tab:** IDE-style external tree (ANIKAI + linked roots), internal bucket cards, deletion rules; nested-scroll fix.
- **Home console:** dynamic storage bucket labels as rotating chips (`HomeScreenBinder` / hero pack).

### Explicitly **not** claimed here

- Unified search/jump API, full carryover **failure-retry** automation, removal of temporary diagnostics — still open per phases below. LIFE repair + repository singleton are partially implemented and tested (see progress logs).

---

## Why this exists

Bond Store, memory layering, and audit responsibilities have drifted over time. The system works in parts, but boundaries are blurry and behavior feels inconsistent in UI and continuity.

This document defines:

- Current problems
- Probable root causes
- Proposed architecture decisions
- Implementation sequence
- Validation checklist

Goal: clean Bond Store first, then fix Audit, then return to pipeline testing.

## Product model decision (Life vs Projects vs Lobby)

Adopt a three-lane thread model:

1. Life thread (single continuous thread)
   - One primary everyday relationship thread
   - WhatsApp-like continuity until deleted/reset by user

2. Project threads (many)
   - Scoped per project, research, or idea lane
   - Separate from life thread to prevent contamination

3. Lobby rooms (many, group collaboration)
   - Multi-peer rooms per project or team context
   - Collaboration state stays isolated per room

Context handoff rule:

- Enter project: create a concise life snapshot for project bootstrap.
- Exit project or at checkpoints: write a summary delta back to life continuity.

## UX container decision (Modal vs Screen)

**Superseded (UI):** Bond Store is no longer a dedicated settings screen; high-volume memory UX lives under **Soul Meridian / User Access / Resona entry points** instead. The bullets below still describe **density and navigation** constraints; apply them to whichever surface hosts thread search, snapshots, and restore.

~~Recommendation: keep Bond Store as a dedicated screen/window, not a major modal.~~

Reasoning (still valid for the *workloads*, not the old screen name):

- Bond Store carries high-volume data (threads, search, memory views, snapshots).
- Long-running navigation patterns (jump thread, filter, inspect, restore) are screen-native, not modal-native.
- Meridian is already dense and should not absorb full memory operations.
- User Access can link to Bond Store entry points, but should not host full Bond Store UI.

Use modals only for focused actions:

- Create thread
- Confirm merge/delete
- Snapshot import/export
- Short metadata edits

## Current issue inventory

### A) Layering and ownership confusion

- Multiple persistence paths represent "memory" in parallel:
  - Room-backed Bond/Audit entities
  - Structured JSON stores/adapters
  - Context archive logs
  - Life archive raw logs
- Bond Store appears to be both runtime source and derived memory surface.
- Similar concepts exist in multiple modules with unclear authority.

Impact:

- Hard to predict which source is canonical.
- Inconsistent behavior during recalls/search/summaries.
- High bug risk during refactors.

### B) Wiring inconsistency

- Core paths are wired, but some memory/sync components appear weakly wired or stale.
- Ad hoc repository creation exists in multiple runtime locations instead of one app-scoped source.

Impact:

- Potential state divergence and hidden behavior differences.
- More difficult debugging and thermal/perf tracking.

### C) Thread model not fully explicit in storage/API

- User intent is clear (Life + Projects + Lobby), but current data model and route semantics appear mixed.
- Cross-thread carryover behavior is not strongly standardized.

Impact:

- Continuity may feel inconsistent.
- Project data can leak into life context or vice versa.

### D) Search and thread-jump ergonomics are fragile

- Current UX does not consistently match modern chat/workspace expectations.
- Discovery and navigation feel old compared with rest of app polish.

Impact:

- Perceived product quality drop.
- Slower user operations and trust erosion.

### E) Audit coupling and noise

- Audit has mixed responsibilities and may be too tightly coupled to current memory layers.
- Event streams are noisy and not clearly separated by concern.

Impact:

- Hard to interpret what happened and why.
- Delays confidence in runtime diagnostics.

## Root cause summary

1. System evolved feature-first without a stable memory boundary contract.
2. Legacy compatibility layers were retained while new paths were added.
3. Canonical source-of-truth per memory concern was not strictly enforced.
4. UI and data contracts drifted at different speeds.

## Target architecture (clean boundary model)

### 1) Canonical thread store

Define one authoritative thread/message layer:

- Thread types: LIFE, PROJECT, LOBBY
- Message/event entities keyed by thread id
- Strong thread metadata: lifecycle state, participants, project id/lobby id, checkpoints
- LIFE is the main thread over everything else (single always-on continuity lane).
- PROJECT entry points are constrained to Resona, companion pill swipe-up action, or companion-assisted switch.

### 2) Memory as derived layer

Bond memory should be derived/promoted from thread events, not replace thread storage.

Suggested conceptual layers:

- Episodic: recent turn-level continuity
- Semantic: extracted stable facts/preferences
- Project memory: decisions, milestones, artifacts

### 3) Deterministic carryover contracts

- Life -> Project bootstrap summary contract
- Project -> Life delta summary contract
- Lobby -> Project/Life optional summary contract
- Snapshot behavior is automatic by default (no manual-only mirror dependency).

### 4) App-scoped repository discipline

- Use one app-scoped memory repository instance.
- Remove ad hoc constructor calls in runtime workers/managers where possible.
- Clarification: this is not "DB singleton vs service business logic". It means one shared memory repository/service instance per app process so all flows read/write the same state.

### 5) Audit as append-only operational ledger

- Keep event log immutable and typed.
- Audit UI becomes filtered/projection views over the same event stream.
- Do not reuse audit tables as ad hoc UI state.

## Implementation plan (safe-first sequence)

### Phase 0: Inventory and freeze (today)

- Finalize this doc and lock decisions.
- Add code comments/TODO tags at known hot spots.
- Avoid new memory feature additions until boundary cleanup starts.

Exit criteria:

- Team agreement on canonical store and thread model.

### Phase 1: Thread model normalization

- Introduce/confirm explicit thread type enum and metadata contract.
- Ensure one active LIFE thread policy.
- Confirm PROJECT and LOBBY thread creation paths and identifiers.

Exit criteria:

- Thread routes map 1:1 to thread types and IDs.

### Phase 2: Repository unification

- Route memory reads/writes through app-scoped repository provider.
- Remove duplicated repository instantiations in runtime flow.
- Add small diagnostics around repository source usage.

Exit criteria:

- Single repository path used in all main runtime call sites.

### Phase 3: Search + jump UX cleanup

- Implement consistent thread index/search API across LIFE/PROJECT/LOBBY.
- Expose predictable jump behavior with recent/history/favorites.
- Keep large operations in screen-based Bond Store UI.

Exit criteria:

- Jump + search parity with expected chat/workspace app behavior.

### Phase 4: Carryover + summary contracts

- Implement deterministic handoff summaries between thread types.
- Add user-visible checkpoint/snapshot cues.
- Validate no accidental context bleed.

Exit criteria:

- Reproducible and inspectable cross-thread summaries.

### Phase 5: Audit separation pass

- Re-scope audit around event provenance and operational tracing.
- Remove incidental coupling with UI memory state.
- Keep audit fixes after Bond Store cleanup per user plan.

Exit criteria:

- Audit explains behavior cleanly with low noise.

## High-priority fixes list (ordered)

1. Enforce app-scoped memory repository usage everywhere.
2. Normalize LIFE/PROJECT/LOBBY thread identity and routing contracts.
3. Designate canonical source for thread data; demote others to derived/export.
4. Rebuild thread search/jump around unified thread index API.
5. Add explicit carryover summary contracts and tests.

## Risk register

- Data migration risk when changing canonical source.
- Legacy path breakage due to hidden connector dependencies.
- Performance regression if indexing/search not batched/cached.
- Behavioral drift during summary contract rollout.

Mitigations:

- Feature flags per phase.
- Incremental migrations with adapters.
- Snapshot test fixtures for thread transitions.
- Runtime telemetry around search latency and summary generation.

## Validation checklist

- Life thread persists as single continuous lane until user deletes/resets.
- Project threads stay isolated from life by default.
- Lobby rooms do not leak context into unrelated threads.
- Thread jump/search works across all thread types with stable results.
- Enter/exit project generates expected summary artifacts.
- Audit events clearly show origin and action without ambiguity.
- No duplicate repository instantiation in hot runtime paths.
- Automatic snapshot behavior is observable and reliable during thread transitions.
- Raw archive retention enforces bounded storage and expected cleanup windows.

## Decisions locked from review

1. LIFE thread is the main continuous thread and should be treated as primary continuity lane.
2. PROJECT thread entry is through Resona, companion pill swipe-up, or companion-assisted switch suggestions.
3. Snapshots are automatic and should remain automatic by default.
4. Current-user data migration is not a blocker for this cleanup phase (testing-first environment).
5. Memory belongs to Bond Store domain; Audit is operational/compliance history and should not hold conversational thread content.
6. Audit can record schedule/ritual execution as logs, while schedules/ritual definitions and companion diary/journal remain in Bond Store.
7. Companion should have read access to relevant operational logs for assistive context and prevention/help guidance.

## Open questions for revision (remaining)

1. Singleton enforcement detail: hard DB invariant, service policy, or both.
2. Raw life/context archive retention final contract:
   - target: 7-day retention
   - early delete if condensed successfully
   - fallback behavior when condensation fails
3. Storage caps and deletion policy for short-term memory buffers (currently targeting 1 GB cap).
4. Long-term memory inclusion policy (preferences, birthdays/recurrences, permissions/authority history) and guardrails.
5. Which analytics/telemetry are required before Phase 5 audit cleanup.

## Immediate next step

Review this plan, revise terminology and boundaries, then convert each phase into concrete implementation tasks and execute in order.

## Bond Store implementation checklist

Use this as the main execution order. Do not start Audit refactor until Bond Store checklist is complete and stable.

### 0) Prep and guardrails

- [x] Add feature flag(s) for memory boundary transition points.
- [x] Add temporary diagnostics for repository source identity in key runtime call sites.
- [x] Mark known legacy files with TODO tags and target removal criteria.
- [ ] Snapshot current behavior (manual smoke notes + baseline screenshots).

### 1) LIFE thread authority and singleton enforcement

- [x] Define LIFE thread invariant in service layer (single active life thread policy).
- [x] Add DB-level invariant/constraint for LIFE thread singleton semantics.
- [x] Add defensive repair logic if duplicate LIFE threads are discovered.
- [x] Add tests for singleton behavior (creation, restore, reset, delete/recreate).

### 2) Thread type normalization (LIFE / PROJECT / LOBBY)

- [x] Confirm thread type enum + metadata contract.
- [x] Verify route-to-thread mapping is 1:1 and deterministic.
- [x] Enforce project entry points (documented in `BondThreadHandoffRoutes`; wiring uses `AnikaiRepository.openLobbyRoom`):
  - [x] Resona / deferred workspace / lobby shell
  - [x] Companion pill utility strip → Project threads → `openProjectThread`
  - [x] Companion-assisted rename / forge exit flows
- [ ] Validate lobby room thread isolation behavior.

### 3) Repository unification

- [x] Replace ad hoc memory repository instantiation with app-scoped provider usage.
- [x] Remove duplicate constructors in hot runtime/worker paths.
- [x] Ensure all primary write paths use the same repository seam.
- [x] Add regression test for consistent read-after-write across flows.

### 4) Snapshot and carryover contracts

- [x] Verify automatic snapshot trigger on Life -> Project transitions.
- [x] Verify Project -> Life delta summary write-back behavior.
- [ ] Define failure handling (retry/backoff/user-visible status) if snapshot generation fails.
- [ ] Add tests for deterministic summary artifact generation.

### 5) Memory layer boundary cleanup

- [ ] Mark one canonical thread/message source of truth.
- [ ] Demote secondary stores to derived/cache/export roles.
- [ ] Remove or quarantine duplicate overlap paths.
- [ ] Document ownership boundaries:
  - [x] Bond Store memory ownership — described under **Ownership and write policy** in `STORAGE_CONTRACT_V1.md` (runtime file roots + BondStore dirs).
  - [x] Archive ownership — raw life/context archive internal-only + condensed narrative in contract; internal raw paths wired in runtime (`LifeArchiveManager` / contract).
  - [x] Audit ownership — `Audit/Logs`, operational logs vs Bond Store; same contract + runtime spec **Canonical storage and workspace drops**.

### 6) Search and jump UX cleanup

- [ ] Build/normalize unified thread index API.
- [ ] Implement reliable thread search (LIFE/PROJECT/LOBBY).
- [ ] Implement jump behavior (recent/history/favorites).
- [ ] Validate performance under realistic thread counts.

### 7) Archive retention and storage controls

- [ ] Enforce raw archive retention target (7 days).
- [ ] Delete raw entries early once condensation succeeds.
- [ ] Define fallback retention for condensation failure.
- [ ] Enforce short-term storage cap policy (target 1 GB).
- [ ] Add telemetry for archive size growth and cleanup success rate.

### 8) Domain placement verification (must-pass)

- [ ] Confirm schedules/ritual definitions remain in Bond Store domain.
- [ ] Confirm companion diary/journal remains in Bond Store domain.
- [x] Confirm conversational thread content is not stored in Audit domain — **contract reaffirmed** (Audit = operational/logs; threads remain Room/chat entities). Ongoing code audit still recommended before closing phase.
- [ ] Confirm schedule/ritual execution events can still emit log events to Audit.

### 9) Validation and ship gate

- [ ] Run full smoke across: life continuity, project switch, lobby isolation, search/jump, snapshot carryover.
- [ ] Run thermal/perf spot check for memory-related screens.
- [ ] Remove temporary diagnostics and close TODO tags.
- [x] Update docs with final architecture deltas — **partial:** `STORAGE_CONTRACT_V1.md`, `ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md`, and this **Progress log** reflect storage/workspace/inbox/thread-attach behavior (May 2026). Full “final” delta awaits remaining Bond Store phases.

## Audit implementation checklist (after Bond Store)

Audit is second pass. Keep it focused on operational traceability, not conversational memory ownership.

### Progress note (2026-05-01)

- **Audit → Data tab (partial):** external storage tree (ANIKAI + linked access), internal bucket cards, memory governance, safer deletion rules, nested-scroll fix — **does not** satisfy **section C** unified feed below; full audit UI refactor remains scheduled after Bond Store checklist.

### A) Scope lock

- [ ] Lock audit scope to operational/compliance events only.
- [ ] Confirm exclusions: conversational thread bodies, bond diary content, ritual definitions.
- [ ] Confirm inclusions: automation actions, guardian force actions, access/authority history, schedule/ritual execution logs.

### B) Event model normalization

- [ ] Define/confirm typed audit event schema (type, actor, source, timestamp, payload).
- [ ] Add normalized event categories and severity levels.
- [ ] Ensure append-only event policy for primary audit ledger.
- [ ] Add migration/adapter for legacy event rows if needed.

### C) UI cleanup (single feed + filters)

- [ ] Build one unified audit feed.
- [ ] Add filter chips by category/type.
- [ ] Add filter chip or controls for time windows.
- [ ] Add detail view for event payload/provenance.
- [ ] Ensure empty/loading/error states are clear and lightweight.

### D) Companion awareness integration

- [ ] Define safe read contract for companion access to audit summaries.
- [ ] Expose summarized/permission-safe operational history for companion assistance.
- [ ] Ensure privacy/authority gates are respected for sensitive logs.

### E) Reliability and observability

- [ ] Add tests for event write/read/filter correctness.
- [ ] Add tests for audit feed ordering and pagination stability.
- [ ] Add telemetry for dropped events, parse failures, and filter latency.
- [ ] Validate that audit queries do not regress app responsiveness.

### F) Audit completion gate

- [ ] Verify no Bond Store conversational memory flows depend on Audit tables.
- [ ] Verify audit feed is understandable for user troubleshooting.
- [ ] Update docs and close remaining audit TODOs.

## Memory Engine Contract v1

This section is the no-regret baseline for memory behavior during and after Bond Store cleanup.

### 1) Ownership and boundaries

- Bond Store memory domain owns:
  - LIFE/PROJECT/LOBBY conversational thread memory
  - companion diary/journal entries
  - schedules and rituals (definitions, states, relationship context)
- Audit domain owns:
  - operational/compliance logs
  - automation execution history
  - guardian/access/authority action history
  - schedule/ritual execution logs as events only (not schedule/ritual definitions)
- Rule: Audit never becomes the source of conversational memory retrieval.

### 2) Retrieval stack (priority order)

At response time, memory retrieval should follow this order:

1. Recency window (exact, uncompressed recent context)
2. Thread-scoped episodic summaries (compressed checkpoints for current thread)
3. Long-term semantic memory (stable facts/preferences)
4. Optional cross-thread carryover summary (if user switched contexts)

Hard limits:

- Retrieve top-K relevant items only per tier (no full-history dumps).
- Use relevance scoring + recency weighting + thread scope constraints.
- Stop retrieval once budget is reached (token/latency guard).

### 3) Thread scope and carryover policy

- LIFE thread is primary continuity lane.
- PROJECT and LOBBY are scoped by default; no implicit bleed into LIFE.
- Cross-thread carryover is explicit and summarized:
  - Life -> Project: bootstrap summary
  - Project -> Life: delta/progress summary
  - Lobby -> Project/Life: optional summary based on relevance and permissions

### 4) Retention and storage policy

- Raw life/context archives:
  - target retention: 7 days maximum
  - early delete allowed after successful condensation
- Condensed summaries:
  - retained as bounded episodic artifacts per thread
- Short-term memory store:
  - capped target budget: 1 GB
  - enforce cleanup/eviction when cap threshold is hit
- Long-term memory:
  - keep durable user preferences and stable facts (birthdays/recurrences/permissions-authority context) with provenance.

### 5) Condensation contract

Condensation jobs must produce:

- Source range (time/thread window)
- Summary text artifact
- Key extracted facts/preferences (if confidence threshold met)
- Status metadata (success/failure/retry count)

On success:

- mark source raw range as condensed
- delete eligible raw fragments per retention policy

On failure:

- keep raw source until retry window expires
- emit audit event for failure with reason and retry plan

### 6) Service and singleton policy

- Use one app-scoped memory repository/service instance for all read/write flows.
- Enforce singleton via both:
  - service policy (single active LIFE thread logic)
  - DB constraint/invariant (defensive guardrail)
- No ad hoc repository instantiation in runtime hot paths.

### 7) Safety and correctness constraints

- Every memory artifact has provenance:
  - origin thread id
  - source event range
  - timestamp
  - condensation version
- Memory writes are idempotent where possible.
- Retrieval must be deterministic for same inputs under same store state (within expected ranking tolerance).

### 8) Performance targets (initial)

- Retrieval latency target: keep within interactive chat budget.
- Bounded per-turn retrieval count and token budget.
- Background condensation should not block foreground chat.
- Archive cleanup must run incrementally (avoid heavy burst deletions).

### 9) Observability contract

Track at minimum:

- retrieval tier hit rates (recency/episodic/semantic/carryover)
- condensation success/failure counts
- raw archive size over time
- cleanup execution outcomes
- top retrieval latency percentiles

### 10) Change control

Before adding new memory features:

- map feature to one existing tier or create a new tier explicitly
- define ownership (Bond Store vs Audit)
- define retention and failure behavior
- add validation checklist entries and telemetry hooks



