# Magnet panels — workspace implementation plan (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | M0 shipped |
| **Last reviewed** | 2026-05-20 |

**Overview:** [`MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](./MAGNET_PANELS_WORKSPACE_OVERVIEW.md)

**Todo:** [`../../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md`](../../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md)

---

## Goal

Give power users a **composable floating workspace**: magnet any panel window to **chat** or to **another panel**, drag the **anchor** to move the whole cluster, drag a **satellite** to break away — same *feel* as the dock following chat, generalized.

Success looks like:

- User opens Chat + Settings + Models, magnets both to chat, drags chat once → all three move together.
- User drags Settings title bar away → Settings unlinks; Models still linked to chat.
- No regression: free-floating panels never follow chat unless linked.
- No Win32 parent/child on panel `BrowserWindow` (preserves click-through on chat).

---

## Non-goals (v1)

- Saved workspace layouts across app restart (defer).
- Magnet inside panel *content* (only top-level Electron windows).
- Replacing the dock with magnets (dock stays special-case).
- In-window docking like VS Code (single HWND split panes) — future different project.

---

## Terminology

| Term | Id in main | Meaning |
|------|------------|---------|
| **Chat anchor** | `main` | Main `BrowserWindow` (chat shell). |
| **Panel anchor** | `settings`, `models`, … | Any panel id in `panels{}` map. |
| **Satellite** | same ids | Window that was dragged onto an anchor; follows anchor. |
| **Link** | — | `{ anchorKind, anchorId, satelliteId, offsetX, offsetY }` |
| **Dock** | — | Built-in satellite of `main`; fixed left edge; not user-removable link. |

---

## Architecture

### Logical links only (not Electron `parent:`)

On Windows, `BrowserWindow` with `parent: mainWindow` forces the child **above** the parent in Z-order and broke chat clicks. Magnets must use:

1. **Link table** in `main.js` (or `main-process/window-magnet-registry.js`).
2. **`setBounds` sync** when anchor moves/resizes — same pattern as `syncDockPosition()`.
3. **Renderer chrome** for highlight border via IPC (`magnet:anchor-state`).

```text
┌─────────────┐     link      ┌──────────────┐
│ Chat anchor │◄──────────────│ Settings sat │
└──────┬──────┘               └──────────────┘
       │ link
       ▼
┌──────────────┐
│ Models sat   │
└──────────────┘
```

### Data model (v1)

```json
{
  "version": 1,
  "links": [
    {
      "satelliteId": "settings",
      "anchor": { "kind": "main" },
      "offset": { "x": 10, "y": 0 }
    }
  ]
}
```

- `offset` — satellite top-left relative to anchor top-left at link time (or anchor right-edge + gap for default).
- `anchor.kind`: `main` | `panel`.
- Max one anchor per satellite (tree edges point **toward** root chat).

### Follow controller (unify with dock)

| Event | Action |
|-------|--------|
| `mainWindow` `move` / `resize` | `syncDockPosition()` + `syncMagnetFollowers('main')` |
| Panel anchor `move` / `resize` | `syncMagnetFollowers(panelId)` for satellites linked to that panel |
| Satellite `move` (user drag) | If movement &gt; threshold → **unlink** satellite; else ignore programmatic sets |

**Threshold:** e.g. 8px movement while satellite is focused → detach (avoids accidental unlink on programmatic sync).

### Z-order (align with 2026-05 panel stack fix)

Reuse `raiseAnikaiFloatingZOrder(topWin)` policy:

- Focus **chat** → chat above inactive satellites; dock below chat.
- Focus **panel** → that panel on top; chat above other inactive panels.
- Do **not** pass `main` as generic `topWin` on every main `move` (was re-stacking all panels above chat).

Document in code beside `raiseAnikaiFloatingZOrder`.

---

## UX specification

### Creating a link (magnetize)

**M0 proposal:** on panel drag end, if panel bounds overlap **magnet zone** of a target:

| Target | Zone |
|--------|------|
| Chat | Right edge strip (e.g. 24px) + optional left strip when space-left &gt; space-right |
| Panel (M2) | Same edge strips on panel HWND |

Alternative later: hold **Alt** while releasing to magnet anywhere on target chrome.

**Feedback:**

- Target anchor border → accent glow (`--accent-primary`) while zone armed.
- Brief snap animation optional (defer).

### Anchor highlight

While a window is an **anchor** with ≥1 satellite:

- Send IPC → panel/chat renderer adds class `anikai-magnet-anchor` on root (`body.anikai-panel-root` / chat shell).
- CSS: 2px outer ring, pointer-events none.

### Detach

| Gesture | Result |
|---------|--------|
| Drag **satellite** header | Remove link; satellite stays at release position |
| Context menu “Unmagnet” (M1) | Same |
| Close satellite window | Remove all links involving that id |

### Dock relationship

| Property | Dock | User magnet |
|----------|------|-------------|
| Anchor | Always `main` | User-chosen |
| Edge | Always left of chat | User-chosen side at link time |
| Removable | No | Yes |
| Implementation | `syncDockPosition` | `syncMagnetFollowers` (shared math) |

Extract shared helper:

```js
// pseudo
function placeSatelliteBesideAnchor(anchorBounds, satelliteW, satelliteH, side, gap) → { x, y }
```

---

## Chain: panel → panel (phase 2)

Example: Models magneted to Settings; Settings magneted to Chat.

| User moves | Followers |
|------------|-----------|
| Chat | Settings + Models (transitive) |
| Settings (highlighted anchor for Models only) | Models only |
| Models (satellite) | Detach Models only |

**Propagation:** depth-first from chat on anchor move; each node stores offset to its anchor parent.

Cycle prevention: reject magnet if it would create a cycle (satellite cannot magnet to its own descendant).

---

## IPC / preload surface (sketch)

| Channel | Direction | Payload |
|---------|-----------|---------|
| `magnet:get-links` | invoke | `{ links }` |
| `magnet:link` | invoke | `{ satelliteId, anchor, offset }` |
| `magnet:unlink` | invoke | `{ satelliteId }` |
| `magnet:anchor-highlight` | send → renderers | `{ windowId, active: bool, role: 'anchor'|'satellite' }` |
| `magnet:drag-ended` | send main ← renderer | `{ panelId, bounds }` for hit-test |

Renderer (panel mode): on `pointerup` in header drag region, report bounds for magnet hit-test.

---

## Implementation slices

### Slice M0 — Panel → chat only

- [x] `window-magnet-registry.js` — link table CRUD
- [x] `syncMagnetFollowers(anchorId)` on main move/resize only
- [x] Hit-test on panel window move end → create link to main
- [x] Detach on satellite user move (&gt; threshold)
- [x] No change to free-floating panel open position (`computePanelOrigin` stays initial only)

**Smoke test:** Open Settings, drag onto chat right edge, drag chat → Settings follows; drag Settings header → unlink.

### Slice M1 — Visual polish + dock unify

- [ ] `anikai-magnet-anchor` CSS on chat + panels
- [ ] Shared `placeSatelliteBesideAnchor` for dock + magnets
- [ ] Optional header button “Magnet to chat” / “Unmagnet”
- [ ] `magnet:anchor-highlight` IPC

### Slice M2 — Panel → panel chains

- [ ] Transitive follow on move
- [ ] Cycle detection
- [ ] Highlight shows anchor vs satellite roles differently (optional: dashed vs solid)

### Slice M3 — Power-user extensions (placeholder)

> **Not yet specified in product chat** — fill this section when the “power user bit” is written down. Likely topics: saved layouts, workspace presets, Playground magnet, multi-monitor anchor roots.

| Idea slot | Notes |
|-----------|-------|
| **Workspace preset** | Named cluster: chat + which panels magneted |
| **Playground / pipeline panel** | Magnet graph editor beside Media Magic |
| **Snap grid / align** | Satellites align vertical stack on anchor edge |
| **TBD** | _User to supply_ |

---

## Files (expected touch)

| Area | Files |
|------|-------|
| Main process | `main.js`, new `main-process/window-magnet-registry.js` |
| Preload | `preload.js` — magnet IPC |
| Panel chrome | `components/panels.js` — drag end, header class |
| Chat shell | `components/chat.js` or `styles/chat.css` — anchor ring |
| Styles | `styles/panels.css`, `styles/chat.css` |
| Docs | this folder |

---

## Risks and mitigations

| Risk | Mitigation |
|------|------------|
| Accidental magnet | Require edge overlap or modifier key |
| Programmatic move detaches satellite | Ignore unlink when `__anikaiSyncMove` flag set |
| Z-order fights | Keep logical links; documented raise policy |
| Multi-monitor DPI | Use screen coords from `getBounds()` like dock |
| Drift from feature creep | Ship M0 before M2; todo checklist gates slices |

---

## Relation to Android

Android does not ship multi-HWND magnets. This plan is **Windows desktop overlay only**. Conceptually similar to “companion detach / re-dock” on mobile (see workforce vision) but implemented as independent Electron windows.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial plan from product discussion (magnet panels, power-user workspace). |
| 2026-05-20 | M0 shipped: registry, main move sync, drag-end magnetize, detach threshold, preload IPC, `smoke-magnet-panels.cjs`. |
