# Workforce, specialties, and group session choreography (Desktop vision)

| Field | Value |
|-------|-------|
| **Doc staging** | **Complete (vision)** — ready for phased implementation & doc review |
| **Operations** | W5a–W7 + E+.4 + solo detach ownership implemented |
| **Last reviewed** | 2026-05-18 |

**Purpose:** Single coherent design for **specialised companions** (per-model stacks, crafts, delegation), **group session choreography** (planning/discussion hats), **capability visibility**, **context boundaries**, and **journals** — without conflating persona, solo identity, and group-only behavior.

**Canonical role tables (link, do not duplicate):** [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) · [`ROLES_INDEX.md`](ROLES_INDEX.md) · Familiars: [`Familiars/FAMILIAR_ROLES.md`](Familiars/FAMILIAR_ROLES.md)

**Related:**

- [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) — segment loop, tools, vision captions (execution layer)
- [`COMPANION_MEDIA_LIBRARY.md`](COMPANION_MEDIA_LIBRARY.md) — per-companion kept files, vision captions, library prompt injection
- [`group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) — round-robin, plan MD, residency
- [`LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) — E+ `llama-server`, voice later
- [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](DESKTOP_COPILOT_AND_SCREEN_AGENT.md) — screen see/act, one system copilot (after E+)
- [`../generation/imaging/IMAGING_GENERATION_INDEX.md`](../generation/imaging/IMAGING_GENERATION_INDEX.md) — Diffusers presets, GGUF `sd.exe`, Media Magic parity for W5a presets
- **User guide (later):** §15 outline; full how-to ships with W2/W3 UI

**Code today:** Per-thread **session roles** in `group-threads/<id>/thread.json` (W3); **`specialty`** on companion JSON + catalog (W4); **capability map v2** in planning prompt (W4). **Capability breakdown UI (W2):** solo avatar → profile dialog; group Members → expand per mate + roster/hub footer (`companion-capability-breakdown.js`, `companion-capability-map.js`, `chat.js`).

---

## 1. One sentence

Each companion is a **specialist** with their own models and persona; in **solo** they plan and coordinate others in **first person** (“I handed this to …”) via the segment loop; in **groups** they wear a **session role** for planning/discussion only; a **Manager** specialty is the automation switch for autonomous orchestration later; everyone shares a live **capability map** (roster + hub + global skills).

---

## 2. Three layers (do not merge)

| Layer | User-facing name (proposed) | Stored where | Drives |
|-------|----------------------------|--------------|--------|
| **Persona** | Persona | Companion: voice, bio, presentation gender, pulse, role pack | How they *sound* and relate — **not** routing |
| **Specialty** | **Specialty** / **Craft** | Companion: `specialty` (catalog ~20) | *What job they do* — solo identity, delegation targets, manager routing |
| **Group session role** | **In this group** / **Session role** | **Per group thread** membership (not global persona) | Round order hints, plan capture, critic, **Lead last** — **group planning & discussion only** |

```mermaid
flowchart TB
  subgraph companion [Companion record]
    P[Persona]
    S[Specialty / craft]
    MS[Model slots + inferencePolicy]
  end
  subgraph groupThread [Group thread only]
    SR[Session role per member]
    PLAN[Plan draft + cycle transcript]
  end
  Solo[Solo chat] --> P
  Solo --> S
  Solo --> MS
  Group[Group chat] --> P
  Group --> S
  Group --> SR
  Group --> PLAN
```

**Why separate group session role from specialty:** A musician can be `note_taker` in Project A and `teammate` in Project B. Their craft stays musician; the **hat** changes per group thread.

**Code migration note:** Today `groupRole` lives on the companion row (`GroupRolePolicy`). **Target:** `sessionRole` on each member in `group-threads/<id>/thread.json` (or `members.json`). Companion editor **solo** fields show specialty only; **group invite / members** UI assigns session role per thread.

---

## 3. Specialty catalog (craft) — persistent identity

**~20 specialties** (expandable), e.g.:

| Specialty id | Label | Typical model slots |
|--------------|-------|---------------------|
| `image_artist` | Image artist | chat, media (text-to-image, img2img), vision |
| `video_creator` | Video creator | chat, media (video gen), vision |
| `musician` | Musician | chat, audio / media |
| `programmer` | Programmer | chat, automation; candidate **desktop copilot** specialty |
| `financier` | Financier | chat |
| `writer` | Writer | chat |
| `manager` | **Manager** | chat (+ full roster visibility) |
| … | … | … |

**Manager specialty** — canonical summary (vs group **Lead** session role): [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) § Manager.

**Secondary model priority (later):** Primary chat GGUF on companion; **secondary** slot when a step needs a different capability (code vs vision). Queue priority below primary; documented in Phase E+ / handover plans.

---

## 4. Group session roles — choreography (8 + Lead behavior)

**Only in group threads.** Used for planning, discussion, plan MD, round-robin — **not** for solo chat prompts.

| Session role id | Label | Choreography |
|-----------------|-------|----------------|
| `teammate` | Teammate | Default contributor; builds on others |
| `planner` | Planner | Structure, steps, trade-offs |
| `critic` | Critic | Challenge assumptions, gaps |
| `note_taker` | Note-taker | Authoritative plan draft + open questions |
| `archivist` | Archivist | Pointers, prior decisions (retrieval later) |
| `facilitator` | Facilitator | Keeps discussion on topic / timeboxes (optional v1) |
| `opener` | Opener | Speaks **first** in a round when assigned |
| `lead` | **Lead** | Speaks **last** in round order; synthesizes pros/cons/agreements; recommends next step — **user must give go-ahead** or keep refining (no silent plan lock) |

**Lead turn order:** Implementation = sort round so **`lead` is always last** index (after opener/teammate/planner/critic/note_taker as configured). Lead reply is the “final say” for that cycle, not a veto — user retains **Continue / Revise / Lock** (existing end-of-cycle UX).

**Shipped (W6):** `opener`, `facilitator`, and `lead` in `GroupRolePolicy`; round sort (lead last, opener first); Lead/Opener-specific group-turn prompts; end-of-cycle hint when Lead spoke last; Members UI round-order badges.

**Renaming in UI copy:** Avoid “group focus” in user docs — use **Session role** or **In this group**.

---

## 5. Capability visibility (single place, not scattered)

### 5.1 Solo chat

**Shipped (W2):** click the **header avatar / identity** → **Profile and capabilities** dialog (`#chatCompanionProfileOverlay`). Summary line in the hero; body rendered by `CompanionCapabilityBreakdown.formatBreakdownHtml` (mode `solo`):

- **Persona** bio (from persona pack / pulses)
- **Text inference** policy summary
- **Model slots:** chat, mmproj, media, vision, audio, automation, queue + custom capability slots
- **Toolkit skills** + v1 **toolkit map** (creative / vision / automation from `companions:get-capability-map`)
- **Projects involved in** + **media library** list (companion-kept files)

**Not in v1 UI (later W5a):**

- Optional inline **header strip** (collapsed chips) — dialog remains the primary surface today

User can ask “girl on a bridge…” when slots/skills show media (or after W5a, when roster/hub delegation is wired in prompts).

### 5.2 Group — members / invite screen

**Shipped (W2 + partial W3):** group header avatar stack → **members editor**; each row has **▾ expand** with the same breakdown schema (mode `group`): focus/role, session role (companion default `groupRole` today), model slots, toolkit skills/map.

**Shipped (W3):** **Session role** dropdown per member (stored in `group-threads/<id>/thread.json` → `members[]`). On first load, migrates from companion `groupRole` default. Round-robin uses per-thread roles; **Lead** speaks last.

**Shipped (W4):** **Specialty** badge on each member card header; **roster + hub** footer on Members panel (`companion-capability-map.js` v2 → planning prompt JSON).

Persona editor: no session role control — assign roles only in chat **Members** dialog.

---

## 6. Shared world model (capability map v2)

Any planner (artist, manager, …) should eventually see in prompt/tooling:

| Block | Content |
|-------|---------|
| **Self** | My specialty, my slots, my settings |
| **Roster** | Each companion: id, display name, specialty, session role (this group), media/task types |
| **Hub** | Unassigned models + task types (“grab from hub”) |
| **Skills** | Global skill ids (same for all) |

**Skills are global.** **Media/generation types come from assigned models**, not from specialty alone (specialty suggests defaults, user assigns slots).

**User-directed delegation (W5 / W5a):** Spoken-to companion plans in thought; `<tool>` / job queue hands work to another companion id; **first-person** handoffs in reply (“I handed this to Rose”); journal entry on receiver (§8). Media pixels: **§17**.

### 6.1 Capability map v2 (target JSON shape)

Ships with **W4** (schema) and **W5a.1** (injected into planning prompt). **`buildCompanionCapabilityMap`** in `main.js` + `main-process/companion-capability-map.js` returns v2 (`self`, `roster`, `hub`) plus legacy v1 fields for breakdown UI.

```json
{
  "self": {
    "companionId": "uuid",
    "name": "Joe",
    "specialty": "image_artist",
    "sessionRole": null,
    "slots": {
      "chat": { "label": "Gemma-3-12B", "taskTypes": ["text-generation"] },
      "media": { "label": "preset:shuttle-31", "taskTypes": ["text-to-image", "image-to-image"] },
      "vision": { "label": "mmproj-…", "taskTypes": ["image-text-to-text"] }
    },
    "inference": { "reasoning": 0.85, "temperature": 0.7 }
  },
  "roster": [
    {
      "companionId": "uuid-rose",
      "name": "Rose",
      "specialty": "image_artist",
      "sessionRole": "teammate",
      "mediaReady": true,
      "mediaTaskTypes": ["text-to-image"],
      "reasoning": 0.9
    }
  ],
  "hub": {
    "unassigned": [
      { "modelRef": "preset:flux-schnell", "taskTypes": ["text-to-image"], "label": "Flux Schnell (unassigned)" }
    ]
  },
  "skills": [
    { "id": "get_local_time", "available": true },
    { "id": "get_group_plan", "available": true }
  ]
}
```

**Rules:**

- `roster` = thread members in group; in solo, optional “known companions” subset (settings cap, e.g. 12) so delegation can name Rose without a group thread.
- `hub.unassigned` = models in library with **no** companion `modelSlots.*` assignment (read from disk index + hub manifest).
- `mediaReady` = media slot set **and** `media:get-readiness` would return `ready` for preview route.
- Group media routing (§17.6) sorts `roster` by `reasoning` desc, then `mediaTaskTypes` match.

---

## 7. Context, KV, and leaving a thread

### 7.1 Principles

| Context | What carries | What drops |
|---------|--------------|------------|
| **Solo thread** | Recent chat, companion journal pointers, capability map | **Session role** (N/A) |
| **Group thread A** | Cycle transcript, plan draft, session roles **for A only** | — |
| **Group thread B** | Fresh session roles for B; no plan from A unless user copies | Roles from A |
| **Solo after group** | Light **recent chat** memory OK; **no** group plan/cycle in prompt unless user @ group or explicit carry | **Session role** + group cycle |

**KV / warm session (Phase E+, E+.4 shipped):** **Per-thread** server session keys: `solo:<companionId>`, `group:<groupId>:<companionId>`. Switching thread should not bleed group KV into solo. Enable **Session rollover** on the companion for warm `id_slot` reuse (`InferenceSessionKey` + `inference-session-slots.js`).

### 7.1b Solo thread ownership (one surface per companion)

**Rule:** Each companion has **at most one solo chat surface** at a time — either on the **main thread rail** or in a **detached window**, never both.

| Surface | Solo tab on main rail | Chat transcript | KV key (when rollover on) |
|---------|----------------------|-----------------|---------------------------|
| **Main** | Yes — source of truth for “at home” | `localStorage` session per `companionId` | `solo:<companionId>` |
| **Detached** | **No** — tab removed from rail while detached | Same session id (not duplicated) | `solo:<companionId>` (same key; only one window active) |
| **Group (⌗)** | Group tab only; member solo tabs unchanged | Group thread + per-member session roles | `group:<groupId>:<companionId>` |

**Detach:** Drag a companion tab off the main window → opens detached chat; tab **leaves** the main rail; if that companion was active on main, main switches to another on-rail solo companion (or clears solo if none). **Re-dock:** Magnet on detached window (or re-dock all) → window closes; tab **returns** on main rail; main opens that companion.

**Not parallel solo threads:** Detached is a **move**, not a second thread. `maxParallelInferences` (E+.3b) applies to **different companions** thinking at once, not the same companion on main + detached.

**Single tab on main:** When only one companion is on the main rail, keep that tab visible (do not hide the rail or inject a duplicate tab entry on detach/re-dock).

**Code:** `chat.js` — `getMainRailSoloCompanions()`, `onCompanionDetached` / `onCompanionRedocked`, `syncDetachedCompanionIds()`; detached body class `anikai-detached-chat` hides the multi-companion rail in the popup.

### 7.2 User warnings (required UX)

When a companion **leaves** a context switch, confirm if they had active group state:

- Start **new group** / switch group thread
- Jump to **solo** with same companion who was in a group round
- Remove companion from group

**Copy (draft):** “{Name} will drop this group’s live planning context (session role, round state). Recent chat and saved plan files remain. Continue?”

After confirm: drop session role from active prompt context; optional journal line (“left Project X group session”).

### 7.3 What we do not require in v1

- Full KV transplant solo ↔ group
- Automatic plan carry to solo without user action

---

## 8. Journals (companion journey + audit fantasy)

**Per-companion journal** (`journal/<companionId>/`) — user-visible over time:

- Project notes, preferences learned, solo milestones
- **Handoff entries (off-screen / async):** e.g. “Joe (image artist) asked me to create a 3s clip of the bridge shot — started 16 May.”
- Links to artifacts (paths, previews) when media pipeline exists

**Feeds planning later:** companions “remember” user taste across threads without inventing group facts in solo prompts (journal summaries injected with strict anti-fabrication rules).

**Fantasy audit:** User can read how work moved between specialists even when UI showed one spokesperson.

---

## 9. Two orchestration modes

| Mode | Trigger | Who coordinates | User experience |
|------|---------|-----------------|-----------------|
| **User-directed** | User messages one specialty | That companion (segment loop + future job pass) | Plans, **first-person** handoffs (“I handed this to …”), previews, per-segment streaming |
| **Manager autonomous** | Manager specialty + automation enabled (later) | Manager companion | Rolling assign → report back → replan; scheduler/spreadsheet/vision-on-work |

Manager is **not** redundant: specialists coordinate **while you watch**; Manager runs **when you are not steering each step**.

---

## 10. Worked scenario (user-directed, solo → workforce fantasy)

**User → Image artist (specialty):**  
“Generate a girl on a bridge eating an apple, then a 3s clip of her biting and looking into the distance, then atmospheric mood sound when traffic noise stops on the bite.”

1. Artist reads **self + roster + hub** map; replies with **plan** (who: self, video creator, musician; what’s missing).
2. Missing video model → honest gap + optional hub recommendation (search later).
3. Artist generates still → **preview** + short description.
4. Passes clip job to video creator (“I handed the clip to **Mia** …”); journal entry on video companion.
5. Video creator completes → artist (or system) previews, passes SFX to musician.
6. If model **unassigned** from hub: “I used an unassigned flux-from-hub slot for …”

**Voice:** the speaking companion uses **first person** for handoffs in the reply channel — e.g. “I handed this to Rose” / “I’m routing this through my image slot” — while the thought channel may still name targets in structured `<tool/>` tags.

**Same mechanics** as B1–B3 segments + B2 skills today; **media handoff** (self slot, roster, hub) is specified in **§17** and ships in **W5a** slices — not the star-button shortcut alone.

---

## 11. Pipeline panel (later) — saved schemas

Allow exporting a **pipeline schema** (JSON) from a completed user-directed flow:

- Steps: `{ specialty | companionId, mediaTask, inputs, delegatePolicy }`
- Segment/tag conventions
- Re-run / edit in **pipeline panel** area

Does not block E+ or capability UI; defines target interchange format early.

---

## 12. Compute federation & placement (solo multi-chat + future LAN)

**Goal:** companions and models can run on **this PC**, **another GPU box**, or **CPU-only** — without forking the product per machine. Aligns with Android **shared model pool + capability registry**; desktop adds **compute nodes** and **placement policy**.

### 12.1 Concepts

| Term | Meaning |
|------|---------|
| **Compute node** | A host that exposes inference (local `llama-server`, future thin **ANIKAI node agent**, or cloud API) |
| **Placement** | Per companion or per model: where weights run (`local-gpu`, `local-cpu`, `node:<id>`) |
| **Resident** | Weights hot on a node (mmap in RAM and/or VRAM pin) |
| **Parallel** | How many jobs that node (or global orchestrator) runs at once |

```mermaid
flowchart TB
  subgraph desk [Anikai Desktop - orchestrator]
    UI[Detached solo chats]
    Q[Job queue + guards]
  end

  subgraph local [Local node]
    L1[llama-server :17888]
    L2[llama-server :17889]
  end

  subgraph lan [Future LAN nodes]
    N1[Office PC - 2x 5090]
    N2[Laptop - CPU only]
  end

  UI --> Q
  Q --> L1
  Q --> L2
  Q -->|HTTP / gRPC| N1
  Q -->|HTTP / gRPC| N2
```

### 12.2 Placement dimensions (later settings / companion JSON)

| Field | Example | Notes |
|-------|---------|--------|
| `computeNodeId` | `local` \| `studio-5090` | Routes queue to node registry |
| `nGpuLayers` | `24` | Partial GPU on large RAM machines |
| `contextCap` | `8192` \| `16384` | KV budget per companion |
| `quantProfile` | `Q4_K_M` \| `turbo` | User-facing preset |
| `preferMmap` | `true` | Many weights resident in RAM without full VRAM duplicate |

**mmap + turbo quant:** increase **resident count** in system RAM; GPU runs **active** slots. Bridged **multi-GPU** (e.g. two 5090s) = **one node, multiple GPUs** → multiple servers/ports or vendor-specific device ids when the stack supports it.

### 12.3 Solo multi-chat (product)

- **Detached windows** (`chat:detach`) = one UI per `companionId` (desktop **today**).
- **Parallelism** = `maxParallelInferences` (global or solo override), bounded by RAM/VRAM guards — see group plan §7.
- **Group** remains **round-robin** (`groupParallelLimit: 1`); do not parallelise speakers in one cycle.
- **Streams** must target the correct window (`companionId` + job id) when multiple jobs run.

### 12.4 Federation v0 (soon-ish direction)

Minimal path without full mesh sync:

1. Second machine runs **`llama-server`** (+ optional node agent exposing health + model list).
2. Desktop **Settings → Compute nodes** → Add URL, trust token, label.
3. Companion editor → **Run on node:** `studio-5090`.
4. Orchestrator forwards `gguf:completion` to remote HTTP; streams back to the same detached chat.

**Not in v0:** automatic model sync, load balancing, failover — document as later.

### 12.5 Android parity

| Android | Desktop target |
|---------|----------------|
| `swarmConfig.parallelLimit` | `maxParallelInferences` |
| `DynamicComputeBudgetCoordinator` | Future **dynamic thread budget** (CPU threads per phase) |
| `createCompanionThread` (lobby room) | Detached solo chat + thread storage (separate histories) |
| Isolated swarm sessions | Per-companion server session keys (E+.4) |

---

## 13. Implementation phasing (recommended)

| Phase | Deliverable |
|-------|-------------|
| **W1** | This doc + rename in UI copy (specialty vs session role); user-guide outline |
| **W2** | Solo **capability breakdown** in chat/header — **done (core):** avatar profile dialog + group member expand; remaining: specialty label, map v2 roster/hub, optional header strip |
| **W3** | Group **members/invite** expand cards + session role per thread — **done** (`thread.json` `members[]`, Members dialog, lead last in round) |
| **W4** | `specialty` catalog (~20) on companion — **done:** catalog + Companion editor + persona preview + capability map v2 (roster/hub in prompt + Members UI) |
| **W5** | User-directed cross-companion jobs + journal handoff lines |
| **W5a** | **Media handoff** (§17): segment tools, presets, delegation, vision review — can start after W4 **partial** (roster in prompt) |
| **W6** | Lead last in round-robin + session role `lead` in policy |
| **W7** | Manager specialty → automation hooks (scheduler, etc.) |
| **E+** | Per-thread KV / `llama-server` (underpins W5–W7); **E+.3b** solo parallel chats done |

**Thought/reply B1–B3:** done — execution engine for one companion per turn.  
**Authoritative build order:** §18 (do not skip W5a slices out of order once started).

---

## 14. Open decisions (minor — can finalize during W3)

| # | Question | Proposed default |
|---|----------|------------------|
| 1 | Rename code `groupRole` → `sessionRole` everywhere? | Yes on thread membership; deprecate global `groupRole` on companion |
| 2 | `facilitator` / `opener` in v1? | Ship **lead** + existing 5 first; add facilitator/opener when round UI needs them |
| 3 | Lead can also be note_taker? | Prefer **one session role per member**; if dual needed, combine hints in policy for `lead` + plan capture on lock only |
| 4 | Solo capability panel location | **Done:** header avatar → profile dialog. Session role UI only in group Members dialog (not companion editor). |

---

## 15. User guide outline (how-to, later)

1. **Specialty / craft** — what it is, catalog table, assigning in companion editor  
2. **Persona** — flavor vs specialty (examples)  
3. **Session role** — only in groups; table of 8 roles; Lead speaks last; user go-ahead  
4. **Solo chat** — reading capabilities; asking for media; delegation in **first person** (“I handed this to …”) with thought-channel tools  
5. **Group invite** — picking members, roles, expand capabilities  
6. **Manager** — when to use; automation vs talking to a craft directly  
7. **Leaving a thread** — what context is lost / kept; journals  
8. **Pipeline panel** — save and rerun workflows (when shipped)  
9. **Images in chat** — natural-language ask → thought plan → preview → optional full quality → vision review (§17)

---

## 16. Success checks

- User can explain difference between **specialty**, **persona**, and **session role** without reading code.
- Group members screen shows **everyone’s capabilities** in one place (expand).
- Switching solo ↔ group does **not** silently inject wrong plan/cycle; warning shown.
- Lead speaks **last**; user must **continue/revise/lock** — no autonomous lock from Lead alone (until Manager automation mode).
- Manager specialty documented as **automation lead**, not duplicate of image artist coordinating a task.
- User asks for an image in chat → reasoning companion **plans in thought**, emits `<tool/>`, streams reply segments; preview at ~1024; optional vision **review** when mmproj equipped.
- Group image task routes to the **best eligible speaker** (highest reason param + matching media task type) before generic round-robin.

---

## 17. Media generation handoff (W5a)

**Goal:** the **chat/reasoning** companion orchestrates still (and later video/audio) generation. It shapes the prompt, picks **self media slot**, **roster delegate**, or **hub unassigned** model, runs through the **segment loop** (stream thought/reply per segment when needed), and optionally **reviews** the result with vision/mmproj.

This replaces “star button → `generateImage` on **chat** slot, bypass thought pipeline” as the **primary** path. The star control may remain as a power-user shortcut until W5a.2 lands.

### 17.1 Code today vs target

| Area | Today | Target (W5a) |
|------|--------|----------------|
| Chat image | `_generationMode === 'image'` → `generateImage({ modelRef: chatSlot })` — skips segment loop | `<tool name="generate_image" …/>` or `delegate_media` inside `runGgufThoughtTurn` |
| Model slot | Uses **chat** slot for star path | Uses **`modelSlots.media`** (Diffusers `preset:*` or `.gguf`); chat slot stays reasoning-only |
| `{{media:generate}}` in reply | Stub in `checkAiMessageForCommands` | Retired or aliased to same tool executor |
| Capability map | `buildCompanionCapabilityMap` — self slots only | **v2:** `self`, `roster[]`, `hub.unassigned[]`, `mediaTasks[]` per companion |
| Cross-companion | Not wired | `delegate_media` + journal line + first-person reply |
| Group order | Round-robin / mention | **Media intent** → sort eligible members (§17.6) then existing policy |
| Post-gen review | B3 micro-captions on tool **paths** | `media_review` segment when mmproj on **acting** companion (or delegator if policy says so) |
| Presets | Media Magic panel + `listImagePresets` | Default **preview** profile (~1024, fewer steps); `quality="full"` escalates via clarify segment |

### 17.2 Resolution order (who runs the pixels)

When the **speaking** companion (reasoning model) decides generation is needed:

1. **Self — media slot assigned**  
   - If `modelSlots.media` resolves to an image-capable entry (`taskTypes` includes `text-to-image` and/or `image-to-image` as needed), hand off to that slot on **this** companion.  
   - Reply (first person): “I’m sending this through my image model …”

2. **Roster — another companion has media**  
   - Scan **thread roster** (group members or solo “known companions” from capability map v2).  
   - Pick best match: has media slot + task type fits user intent (txt2img vs img2img).  
   - Emit `delegate_media` with `targetCompanionId` / `targetName`.  
   - Reply: “I handed this to **Rose** …” (first person; Rose may take the next group turn or run async job — see 17.5).

3. **Hub — unassigned library model**  
   - If no roster member has a suitable assigned model, query hub for **unassigned** models matching `mediaKind` + task (catalog / `hf-task-types`).  
   - Use a **preset** mapping (Media Magic / `listImagePresets`) for that architecture; note in thought + reply that the run used an **unassigned** hub model (user can assign later in Models panel).

4. **Gap**  
   - `<uncertain/>` or `<clarify>`: missing pack, Python route, or `sd.exe`; offer install path or lower quality preview if partial readiness (`media:get-readiness`).

```mermaid
flowchart TD
  intent[User wants image / edit]
  think[Reasoning companion thought segment]
  self{Self media slot ready?}
  roster{Roster member with media + task?}
  hub{Hub unassigned + preset?}
  run[IPC media:generate-image]
  reply[Reply segment stream + attachment]
  review{mmproj on actor?}
  cap[Vision review one-liner]

  intent --> think
  think --> self
  self -->|yes| run
  self -->|no| roster
  roster -->|yes| run
  roster -->|no| hub
  hub -->|yes| run
  hub -->|no| clarify[clarify / uncertain]
  run --> reply
  reply --> review
  review -->|yes| cap
  review -->|no| done[Done]
  cap --> done
```

### 17.3 Segment tools (thought channel)

Extend B1 `<tool/>` vocabulary (names are canonical; aliases in executor):

| Tool | Purpose | Key attributes |
|------|---------|----------------|
| `generate_image` | Self handoff to `modelSlots.media` | `prompt` (model-shaped), `quality="preview"\|"full"`, optional `styleId`, `seed`, `width`, `height`, `steps` |
| `delegate_media` | Cross-companion job | `targetCompanionId`, `prompt`, `quality`, `mediaTask` (`text-to-image` \| `image-to-image`), optional `sourceImagePath` from turn media |
| `media_review` | Post-gen vision (optional segment) | `imagePath`, `question` (default: short aesthetic / match-to-brief) |

**Prompt shaping:** the reasoning model **must** pass a distilled `prompt` attribute (and negative prompt later if needed). Raw user text is input to thought only — not copied verbatim to Diffusers/`sd.exe` unless the model chooses to.

**Quality walkthrough:** default `quality="preview"` (~1024, preset-specific steps from Media Magic). If the user asks for higher fidelity in chat, the next thought segment may emit `quality="full"` or explicit `width`/`height`/`steps` and a `<clarify>` estimating time/VRAM — stream reply per segment so the user sees progress (“Starting a higher-res pass …”).

**Preset binding:** map `modelRef` / `preset:id` to rows from `media:list-image-presets` (same source as Media Magic). GGUF image models use `SdGgufImageProfiles` with a **preview** profile (1024-class) as default CLI args; full quality merges user/tool overrides.

**Example thought fragments (illustrative):**

```xml
<tool name="generate_image" prompt="young woman on a wooden bridge at dusk, biting a red apple, soft cinematic light" quality="preview"/>
```

```xml
<tool name="delegate_media" targetCompanionId="uuid-rose" targetName="Rose" mediaTask="text-to-image" prompt="…" quality="preview"/>
```

```xml
<tool name="media_review" imagePath="C:/Users/…/generated-media/…/preview.png" question="Does this match the bridge-and-apple brief?"/>
```

### 17.4 IPC and residency

- Executor lives in **renderer** `executeThoughtSegmentTools` (media tools) + **main** `media:generate-image` / `runImageGenerationMain` (existing).  
- Generation should respect **model residency** queue where possible: media job may **swap** chat model out temporarily; document soft guard (user RAM/VRAM) — same as today’s Media Magic panel.  
- `surface: 'chat'` + `companionId` + `jobId` for attachment path under companion media library.  
- Journal (W5): append v1 handoff record on **target** companion (`journal/<id>/handoffs.jsonl`) for `delegate_media` and `delegate_task`; Companion panel **Journal** tab lists recent lines; planning prompt injects recent handoffs (anti-fabrication).

### 17.5 Solo vs group behavior

| Context | Behavior |
|---------|----------|
| **Solo** | Speaking companion runs full segment loop; tools synchronous before final reply segment unless `maxParallelInferences` allows detached job (later). |
| **Group** | **Media intent** detected (user message, `@mention`, or plan step) → **pre-select acting companion** (17.6) → that companion’s thought loop runs tools; others may comment after in round-robin. Delegation does **not** require the target to speak in the same cycle if job is async — but reply from **delegator** still says “I handed this to Rose” and Rose’s result attaches when complete (queue UI: “Waiting for Rose …”). |

### 17.6 Group: pick the media actor first

Before normal round-robin for an image/media turn:

1. Build eligible set: thread members with **media slot** (or hub fallback policy) and `taskTypes` matching intent.  
2. Score by **`reasoning` inference param** (higher first) — same knob as Persona / companion policy (`companion-text-inference` / per-model runtime).  
3. Tie-break: specialty match (`image_artist`, etc. when W4 ships) → session role not blocking → stable member order.  
4. If **txt2img** vs **img2img**: filter by catalog task type; companion with **both** ranks above txt2img-only when user attached a reference image (`turnMedia` / library pick).  
5. Selected companion becomes **acting speaker** for that turn (may differ from user’s @mention target if mention is delegator only — policy: explicit `@Rose generate this` forces Rose).

**Not** parallel speakers in one group cycle — only one media job actor per intent (aligns with `groupParallelLimit: 1`).

### 17.7 Reply voice and streaming

- **First person** in reply: “I’ll generate …”, “I handed this to Rose”, “I pulled an unassigned Flux pack from the library …”.  
- **Third person** reserved for narrating *other* companions’ completed work when the user did not address the delegator (“Rose finished the still — here it is”) — optional, not required for handoffs.  
- Stream **reply segments** when a tool run is long (preview submitted, upscale running): thought may show `<done/>` for planning while reply streams status lines before attachment message.

### 17.8 Implementation slices (W5a)

| Slice | Deliverable | Depends on |
|-------|-------------|------------|
| **W5a.0** | This §17 + capability map v2 **shape** in doc/prompt stub | W4 partial |
| **W5a.1** | `resolveMediaSlotFor(companionId)` + readiness in prompt; expose roster/hub summary in planning prompt | W4 partial |
| **W5a.2** | `generate_image` tool → `media:generate-image` on **media** slot; preview preset; star mode deprecated in UI copy | W5a.1 |
| **W5a.3** | `delegate_media` + journal stub + queue label “Waiting for {name}”; first-person reply contract in shaper | W5a.2, W5 |
| **W5a.4** | Group media-intent routing (17.6) in `runGroupRoundRobin` | W5a.2, W3 helpful |
| **W5a.5** | `media_review` + B3-style caption after attachment | mmproj slot |
| **W5a.6** | `quality=full` clarify path + user-facing step estimate | Media Magic parity |

**Code anchors:** `chat.js` (`executeThoughtSegmentTools`, `runGgufThoughtTurn`, `sendMessage`), `main.js` (`buildCompanionCapabilityMap`, `media:generate-image`), `gguf-completion.js` (`runImageGenerationMain`), `media-diffusers-image.js` (presets), `thought-segment-tags.js`, `gguf-prompt-shaper.js` (handoff voice), `companion-skills.js` (optional alias registration).

### 17.9 Acceptance checks (W5a)

- Image artist with **media** slot: user asks in natural language → thought shows plan + `<tool name="generate_image" prompt="…"/>` → chat shows preview attachment without using star mode.  
- Companion **without** media slot but Rose has one → reply includes “I handed this to Rose” and job runs on Rose’s slot.  
- No assigned model anywhere → hub unassigned + explicit mention in reply; still produces preview if readiness ok.  
- User says “higher quality” → second segment escalates preset/steps with streamed status.  
- Group with two image-capable members → higher **reason** param acts first for a generic “draw …” message.  
- After gen, mmproj equipped → one short **review** line in reply or thought footer.

---

## 18. Implementation order (authoritative)

Build in this sequence unless a row explicitly allows parallel work. **E+** engine slices can continue alongside workforce UI when they do not change the same files.

| Step | Phase | Outcome | Blocks |
|------|-------|---------|--------|
| 0 | **B1–B3** | Segment loop, skills, vision micro-captions | — (done) |
| 1 | **W1** | Doc + UI copy (“specialty” vs “session role”) | — (this doc) |
| 2 | **W2** | ~~Solo capability breakdown~~ **done (core)** — avatar profile dialog + group expand | W4 adds specialty + map v2 in same UI |
| 3 | **W3** | ~~Group members + sessionRole~~ **done** | W5a.4 |
| 4 | **W4** | ~~`specialty` catalog + capability map v2~~ **done** | W5a.1 uses roster/hub in media routing |
| 5 | **W5a.0** | ~~§17 + prompt tool vocabulary~~ **done** (`behavior-contract`, `companion-media-resolution`) | W5a.1 |
| 6 | **W5a.1** | ~~`resolveMediaHandoff` + readiness in prompt~~ **done** | W5a.2 |
| 7 | **W5a.2** | ~~`generate_image` / `delegate_media` on **media** slot~~ **done** | W5a.3–6 |
| 8 | **W5a.3** | ~~journal stub + queue “Waiting for …”~~ **done** | W5 |
| 9 | **W5a.4** | ~~Group media-actor pick (§17.6)~~ **done** | — |
| 10 | **W5a.5** | ~~`media_review` + caption in reply~~ **done** | — |
| 11 | **W5a.6** | ~~`quality=full` clarify gate + step estimate in continuation~~ **done** | — |
| 12 | **W5** | ~~General cross-companion jobs + journal handoff format~~ **done** | W7 |
| 13 | **W6** | ~~Lead speaks last + opener/facilitator roles + closing-turn prompts~~ **done** | — |
| 14 | **W7** | ~~Manager → automation hooks (policy, queue, enqueue_job / schedule_followup, Automation panel)~~ **done** | — |
| — | **E+.3b** | Solo `maxParallelInferences` | done |
| — | **E+.4** | ~~Per-thread KV session keys (<code>solo:</code> / <code>group:</code> + session rollover slots)~~ **done** | — |
| — | **E+.3b+** | ~~Solo detach ownership (one rail tab per companion; detach moves off main)~~ **done** | — |

**Star-button image mode:** keep until **W5a.2** ships; then mark deprecated in UI and docs.

---

## 19. Doc review checklist (before you test code)

Use this to validate the **design** only. Implementation tests live in §16 and §17.9 per phase.

| # | Question | § |
|---|----------|---|
| 1 | Can you explain **persona** vs **specialty** vs **session role** in one sentence each? | 2–4 |
| 2 | Is **Manager** clearly “automation lead later,” not the same as an image artist coordinating a task? | 3, 9 |
| 3 | In solo, does delegation sound like **you** (“I handed …”), not a narrator? | 1, 9, 17.7 |
| 4 | For an image ask, is the path **reasoning → media slot → preset preview → optional full → optional review** clear? | 17 |
| 5 | If Joe has no media model but Rose does, is roster delegation obvious? | 17.2 |
| 6 | If nobody has a model, is **hub unassigned** + user-visible mention documented? | 17.2 |
| 7 | In groups, who runs pixels when two companions have image models? | 17.6 |
| 8 | Does leaving a group thread warn about dropped **session role** but kept plan files? | 7.2 |
| 11 | Is detach a **move** (off main rail), not a second solo thread for the same companion? | 7.1b |
| 9 | Is build order **W2 → W3 → W4 → W5a.* → W5 → W6 → W7** acceptable? | 18 |
| 10 | Any open decision in §14 you want changed before W3? | 14 |

**When implementation starts:** after each row in §18, run that phase’s acceptance checks (§16 global + §17.9 for W5a). Do not expect §16/§17.9 behavior in the app until the matching slice lands.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-16 | Initial vision: specialty, session roles, capability map, journals, W1–W7 phasing. |
| 2026-05-18 | §12 compute federation & placement: solo `maxParallelInferences`, detached chats, LAN nodes, mmap/KV; Android swarm parity table; section renumber 13–16. |
| 2026-05-18 | Link [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](DESKTOP_COPILOT_AND_SCREEN_AGENT.md); `programmer` specialty note for system copilot. |
| 2026-05-18 | §17 **Media generation handoff (W5a)**: self/roster/hub resolution, segment tools, preview presets, first-person delegation, group media-actor ordering, vision review; phasing W5a; E+.3b noted done. |
| 2026-05-18 | Doc marked **complete (vision)**; §6.1 capability map v2 JSON; §18 implementation order; §19 doc review checklist; voice/copy consistency (first person). |
| 2026-05-18 | **W2 core shipped:** §5 notes avatar profile dialog + group member expand (`companion-capability-breakdown.js`); phasing table updated. |
| 2026-05-18 | **W3 shipped:** `thread.json` `members[]` + session role UI; IPC load/save; infer context + lead-last round order. |
| 2026-05-18 | **W4 shipped:** `specialty` catalog + Companion editor; persona preview from role packs; capability map v2 (`self`/`roster`/`hub`) in `companions:get-capability-map`; Members specialty badge + roster/hub footer. |
| 2026-05-18 | **W5a.0–W5a.2 shipped:** media handoff tools in thought loop (`generate_image`, `delegate_media`, `media_review` stub); `CompanionMediaResolution` + `companions:resolve-media`; preview quality; chat attachments; star labeled legacy. |
| 2026-05-16 | **W5a.3–W5a.6 shipped:** delegate queue UI; group media-actor reorder; `media_review` tool; `quality=full` clarify gate + continuation hints. |
| 2026-05-16 | **W5 shipped:** `delegate_task` tool; journal v1 format + list/prompt IPC; Companion Journal tab; media handoffs use full journal records. |
| 2026-05-16 | **W6 shipped:** Lead-last prompts, opener/facilitator session roles, round-order UI, end-of-cycle Lead copy. |
| 2026-05-16 | **W7 shipped:** `automationPolicy` on manager companions; `workforce-automation` queue; `enqueue_job` / `schedule_followup` tools; Automation panel + IPC. |
| 2026-05-16 | **E+.4 shipped:** `InferenceSessionKey` (`solo:` / `group:`); completion payloads + `id_slot` rollover; group→solo context-leave confirm. |
| 2026-05-16 | **Solo detach ownership:** §7.1b — one solo surface per companion; detached removes main-rail tab; re-dock restores; no parallel same-companion threads. |
