# Media libvips runtime pack

| Field | Value |
|-------|-------|
| **Pack id** | `pack.media.libvips` |
| **Tier** | A |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Fast image resize/crop/EXIF and weave bake without spinning Python.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

libvips Windows binary or sharp-native prebuild — pick one in manifest.

## Staging path

`desktop-data/runtime-packs/media.libvips/`

## Unlocks (no model weights)

fast-thumbs, weave-bake-png, exif-rotate

## Verification smoke

Resize 4K PNG to 512 in benchmark.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
