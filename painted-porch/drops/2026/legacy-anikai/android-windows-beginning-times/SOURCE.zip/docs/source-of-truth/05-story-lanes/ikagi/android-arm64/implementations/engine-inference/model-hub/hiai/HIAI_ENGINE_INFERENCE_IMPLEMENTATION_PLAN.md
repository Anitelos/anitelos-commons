# Huawei HiAI engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: document a potential **HiAI (Kirin)** inference lane for regional devices and legacy Huawei hardware where Google Play services patterns differ. Most global Play-distributed builds may never ship this; the doc exists for completeness and future fork/store variants.

---

## Scope

This file covers HiAI for:

- Kirin NPU paths where HiAI SDK is applicable,
- explicit policy gates (GMS vs HMS ecosystems, store constraints),
- manifest placeholders for HiAI model formats when/if pursued.

This file does **not** promise Play Store delivery or current Huawei device support.

---

## Role model (single truth)

| HiAI lane | Ownership |
|-----------|-----------|
| Regional specialist helper | Possible for targeted distributions. |
| Default global lane | No. |

---

## Android implementation plan (stub checklist)

- [ ] Legal/store policy review before any integration work.
- [ ] HiAI SDK availability matrix by device generation.
- [ ] Adapter id `hiai` + stub registry entry.
- [ ] Sandboxed evaluation devices only.

---

## Open decisions

- whether ANIKAI maintains any HMS-specific flavor,
- model conversion pipeline from ONNX/TFLite to HiAI formats if required.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for Huawei HiAI / Kirin (regional/future). |
