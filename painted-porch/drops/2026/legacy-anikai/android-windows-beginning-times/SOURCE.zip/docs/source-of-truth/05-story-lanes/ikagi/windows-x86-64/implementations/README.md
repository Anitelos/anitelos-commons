# Windows (x86-64) — `implementations/`

**Purpose:** stable parking for Windows desktop plans—schemas, engine notes, UI contracts, pipeline shapes—once you promote them from chat or experiments.

**Doc index (tighten):** [`WINDOWS_DESKTOP_INDEX.md`](WINDOWS_DESKTOP_INDEX.md) — roles, familiars, project tree, manager, magnets.

## Layout vs Android

Folder names mostly follow the same **taxonomy** as [`../../android-arm64/implementations/`](../../android-arm64/implementations/) so you always know *where a topic belongs* (engines, generation lanes, sentience, pipelines, etc.). The Android tree is **optional reference only**: same broad use cases, **not** a mandate to match UX, UI, or sequencing.

Windows is expected to diverge in **surface design** (overlay, panels, chat-first local gen) while reusing the same *categories* of work where it helps.

## Windows-first stubs (empty until plans land)

| Folder | Intent |
|--------|--------|
| `companion-surface/desktop-overlay-and-panels/` | Shell HWNDs, model paths, **project tree M0** ([`PROJECT_WORKSPACE_TREE.md`](./companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md)), drag-magnet plans ([`MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](./companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md)). Todo: [`TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md`](../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md). |
| `anikai-agent-workflows/` | Chat/workforce/execution-agent/Familiars — **canonical** workshop index: [`DESKTOP_WORKSHOP_STATE.md`](./anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md), roles: [`execution-agent/ROLES_INDEX.md`](./anikai-agent-workflows/execution-agent/ROLES_INDEX.md). |
| `anikai-agent-workflows/group-chat-mate-network/` | Group chat, session roles, residency — [`GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](./anikai-agent-workflows/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md). Todo: [`TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md`](../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md). |
| `anikai-agent-workflows/execution-agent/` | Sandbox, agentic loop, blackboard — [`COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](./anikai-agent-workflows/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md). Todo: [`TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md). |
| `companion-surface/DESKTOP_WORKSHOP_STATE.md` | Redirect → [`anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md`](./anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md). |
| `operations/` | Windows **docs ↔ todos** index: [`OPERATIONS_INDEX.md`](./operations/OPERATIONS_INDEX.md). |
| `engine-inference/model-hub/` | Native/engine plans per **family**. **GGUF:** [`engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md). **ONNX:** [`engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](./engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md). Hub index: [`engine-inference/model-hub/MODEL_HUB_INDEX.md`](./engine-inference/model-hub/MODEL_HUB_INDEX.md). |
| `generation/text/` | Text lane **index** + per–model-type plans (e.g. GGUF): [`TEXT_GENERATION_LANE_INDEX.md`](./generation/text/TEXT_GENERATION_LANE_INDEX.md), [`gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](./generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md). Todos: [`../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md), [`../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md). |
| `generation/imaging/` | **Imaging lane index:** [`IMAGING_GENERATION_INDEX.md`](./generation/imaging/IMAGING_GENERATION_INDEX.md). GGUF sheets: [`gguf/models/`](./generation/imaging/gguf/models/). Plans: [`gguf/`](./generation/imaging/gguf/), [`diffusers/`](./generation/imaging/diffusers/), [`onnx/`](./generation/imaging/onnx/), [`python/`](./generation/imaging/python/) (PersonaLive sidecar). Todo: [`../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md`](../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md). |
| `generation/audio/music-sfx/gguf/` | GGUF music generation (lanes A/B/C): [`GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](./generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md). Todo: [`../todo/mid-scope/TODO_GGUF_MUSIC_DESKTOP.md`](../todo/mid-scope/TODO_GGUF_MUSIC_DESKTOP.md). |
| `local-only-policy/` | No cloud / no external services—enforcement and user-visible guarantees. |
| `generation/local-multimodal-chat/` | Disposable **chat → media** smoke test (UI + wiring); **not** a locked “main model” choice. Example stacks in [`PROOF_RUN_PHASE1_CHAT_MEDIA.md`](./generation/local-multimodal-chat/PROOF_RUN_PHASE1_CHAT_MEDIA.md). |
| `generation/video/local-video-generation/` | Separate local video path (often its own engine and VRAM profile). |
| `../todo/mid-scope/` | Checklists that **close the loop** with implementation docs (same pattern as Android `todo/`). |

## Filling this tree

Add `*_PLAN.md` or `*_CONTRACT.md` files inside the folder that matches the subject. Empty dirs hold `.gitkeep` only until then.
