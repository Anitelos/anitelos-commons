# Media Magic — Generation IA and designer lanes

| Field | Value |
|-------|-------|
| **Status** | Proposed product IA + UX contract |
| **Scope** | Image media lane information architecture and designer-mode outputs |
| **Audience** | Product, UX, prompt-system, and renderer implementers |

---

## Why this document exists

Media Magic's image lane has grown with useful but mixed modes.  
This doc defines a cleaner IA:

- **Generation** = primary creation desk.
- **Others** = curated/experimental lanes.
- Designer-focused contracts for **character/outfit/object/world** workflows.

The goal is to make:

1. 3D handoff (especially image->3D) cleaner and more reliable.
2. User intent clearer (create a character vs edit a composition).
3. Future "apply X to Y" flows predictable.

---

## IA proposal (Image media lane)

## Header level

- `Media: Image`
- `Mode: Generation | Image weaving | Others`

## Mode: Generation (primary)

Generation contains:

- `Standard` (existing broad text->image / img2img lane)
- `Character designer`
- `Outfit designer`
- `Prop/object designer`
- `Building designer`
- `Environment/biome designer`
- `Concept scene designer`
- `Planet designer` (later)

## Mode: Others (curated/experimental)

Others contains:

- `Still motions`
- `4-shot persona`
- `PersonaLive still`

Rationale: these are high-value but not the baseline "make a production asset" path.

---

## Core output rule for 3D readiness

When target use is 3D (LiTo/SHARP/TRELLIS pipeline prep), default output should bias toward:

- **single subject**
- **full-body or full-object framing**
- **plain white (or transparent) background**
- minimal background clutter

This improves object isolation and reduces cleanup before image->3D.

### Background handling policy

- Default: generate with white/clean backdrop instructions.
- Optional toggle: `Auto remove background` post-step.
- Auto-prompt helper should enforce solo-subject language when "3D-ready" is enabled.

---

## Designer lanes — contracts

Each designer lane should publish a clear output contract so users know what they get.

## 1) Character designer

### Primary intent

Design a hero/model/NPC/character for games, animation, video, fashion, or concept work.

### Default output

- full-body single character
- centered framing
- white/clean backdrop

### Optional output layouts

- **Single-sheet concept**: front + side + head close-up in one image.
- **Multi-view set**: separate outputs (front / side / close-up).
- **Pose mode**: neutral A/T-like stance for design readability.

### Future action

- `Apply outfit to character` (small guided i2i flow).

## 2) Outfit designer

### Primary intent

Generate fashion/outfit concepts independent from final character render.

### Default output

- no visible character identity by default
- mannequin / flat-lay / concept-board friendly composition

### Optional output layouts

- single outfit concept
- variant grid (multiple outfit variants)
- material/colorway variations

### Future action

- `Apply to character` when character reference is supplied.

## 3) Prop/object designer

### Primary intent

Generate weapons, tools, accessories, and standalone objects.

### Default output

- single object
- white/clean background
- silhouette-friendly framing

### Optional output layouts

- turntable-style multi-angle sheet
- exploded parts concept (later)

## 4) Building designer

### Primary intent

Generate architecture and structure concepts for games/worldbuilding.

### Default output

- single building focus
- controlled context (minimal scene clutter)

### Optional output layouts

- elevation sheet (front/side)
- mood variants (day/night/style)
- floor-plan guided style board (rooms + finishes)
- room-by-room look/theme variants for archviz handoff

## 5) Environment/biome designer

### Primary intent

Generate environment keyframes and biome direction.

### Default output

- one biome composition with strong focal hierarchy

### Optional output layouts

- biome variation board
- lighting/time-of-day board

## 6) Planet designer (later)

### Primary intent

Generate planetary concepts and astro-environment direction.

### Default output

- single planet read with atmosphere/surface cues

## 7) Concept scene designer

### Primary intent

Create rough sequential scene sketches that can be iterated shot-by-shot into production-ready references.

### Default output

- one rough concept still per shot
- framing/composition-first (not final polished render)
- prompt-guided continuity from previous scene still

### Timeline contract (required)

- every generated still can be dropped into a **scene timeline**
- each timeline card stores:
  - image path/id
  - scene prompt (must persist)
  - shot note / camera note
  - target duration
- timeline supports quick playback preview for timing checks (`Play/Pause`)
- timeline playback is also consumable from Video weaving

### Upgrade action

- `Promote shot to polished reference` for downstream video engines.

---

## Prompt-system guidance

Designer lanes should use lane-specific prompt templates:

- prepend lane intent ("character concept sheet", "outfit concept board", etc.)
- enforce subject count (`single`, unless user opts into multi-subject)
- include backdrop policy tokens for 3D-readiness modes
- keep style/genre controls shared across all generation lanes

---

## Apply flows (micro i2i windows)

Two explicit cross-lane actions:

- `Apply outfit -> character`
- `Apply prop -> character` (later)

Contract:

- user provides base reference + applied design reference
- lane outputs merged concept while preserving base silhouette priority
- stream stage logs into Media console

## Cross-tab handoff links (designer footer)

Each designer tab should expose footer links to "what next?" destinations:

- `Send to 3D -> LiTo`
- `Send to 3D -> SHARP`
- `Send to Video -> Fashion` (show as `Coming soon` until local-ready)
- `Send to Video -> Lance`
- `Send to Concept Timeline` (for scene sequencing)

These links are intent-preserving handoffs, not deep copies: destination tabs should open with source references pre-wired.

## Renderer activation policy (engine-aware)

- Designer tabs produce engine-ready references; they do not boot all renderers.
- Renderers initialize when user enters the destination engine tab.
- Some renderers can be shared (e.g., LiTo/TRELLIS class 3D viewers), but engine-specific surfaces are allowed when needed (e.g., archviz/panorama viewers).
- Handoff cards should state which destination engines are currently runnable vs coming soon.

---

## Interaction model (v1)

For each designer lane:

- left card: lane-specific prompt fields
- toggles: `3D-ready output`, `concept sheet`, `variants`
- shared generation controls: model/style/seed/steps
- output panel with quick actions: `Send to 3D`, `Use as ref`, `Apply to...`

### Designer footer (new)

Every designer panel ends with:

- handoff links to relevant Video and 3D tabs
- short explanation of what that destination engine is best at
- one-click "open destination with current output as reference"

---

## Dependencies and sequencing

Recommended implementation order:

1. IA rename/restructure: `Generation` + `Others`
2. Character designer v1 (single full-body clean background)
3. Outfit designer v1 (non-character concept output)
4. Apply outfit->character micro-flow
5. Multi-view concept sheet options
6. Remaining designers (prop/building/environment/planet)

Parallel prerequisite:

- complete in-app 3D viewport rendering so LiTo output is visible in-panel (not only file reveal).

Video-side prerequisite:

- split Video IA into:
  - **Specialist generation engines** (per-engine tabs like Lance/Fashion/CogOmni watch)
  - **Curated Anikai experiments**
  - **Video weaving** (mix/layer/final assembly)
- ensure reciprocal links back to relevant designer lanes.

---

## Relation to 3D lane

LiTo inference exists and returns `.ply` from in-app generate (WSL path).  
What remains for "full in-app 3D":

- viewport runtime integration (splat/mesh renderer)
- camera/orbit controls
- load/reload lifecycle and performance controls

Designer lanes in this doc should feed that pipeline with cleaner source images.

---

## Open questions

| # | Question |
|---|---|
| IA-Q1 | **Resolved:** `Standard` remains first under `Generation`. |
| IA-Q2 | **Resolved:** `Image weaving` is top-level (`Generation | Image weaving | Others`). |
| IA-Q3 | **Resolved:** `3D-ready output` defaults on for designers that link cleanly into engines; renderer startup is destination-engine driven. |
| IA-Q4 | **Resolved:** concept-sheet output is an optional toggle. |
| IA-Q5 | **Resolved:** timeline playback lives in Concept Scene Designer and is consumable from Video Weaving. |
| IA-Q6 | **Resolved:** `Send to Video -> Fashion` can be shown as `Coming soon` until runnable. |

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05-28 | Applied product decisions Q1-Q6: `Image weaving` moved to top-level mode, timeline play/pause + Video weaving handoff, and engine-aware renderer activation policy |
| 2026-05-28 | Added implementation handoff to phased execution doc: `MEDIA_MAGIC_PHASED_CREATIVE_FLOW_PLAN.md` |
| 2026-05-28 | Added Concept Scene Designer lane, timeline/prompt persistence contract, and cross-tab handoff footer links to 3D/Video destinations |
| 2026-05-28 | Initial draft: Generation/Others IA split, designer lane contracts, 3D-ready output policy, apply-flow direction |

