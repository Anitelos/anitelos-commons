# Composable paths & expert mode (direction)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Direction — captures a long-running product tension |
| **Last reviewed** | 2026-06-02 |
| **Status** | **Today = curated lanes; north star = mix-and-match where contracts allow** |

**Parent:** [`../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)

**Related:**

| Topic | Doc |
|-------|-----|
| Playground / Rete graph | [`./PLAYGROUND_NODE_EDITOR_DIRECTION.md`](./PLAYGROUND_NODE_EDITOR_DIRECTION.md) |
| Record → replay (linear pipelines) | [`./IMAGING_PIPELINE_RECORD_PLAYGROUND.md`](./IMAGING_PIPELINE_RECORD_PLAYGROUND.md) |
| Engine per pipeline stage | [`../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md) |
| Media Magic IA / designer lanes | [`../companion-surface/MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`](../companion-surface/MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md) |
| Runtime packs & staging | [`../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) |
| Chat tools without opening Media Magic | [`../anikai-agent-workflows/`](../anikai-agent-workflows/) |

---

## The tension (Comfy vs Anikai today)

**ComfyUI** (and similar node UIs) let users **wire arbitrary nodes** as long as **port types and runtime combos work**. The graph *is* the program; the backend is a bag of operators.

**Anikai today** is deliberately **curated**:

- **Families and formats** are first-class (`gguf`, `diffusers`, `onnx`, music lanes, video lanes, …) with registry rows, Get pack, and smoke-tested paths.
- **Media Magic** exposes **tabs, presets, and designer lanes** — not a free backend graph.
- **Main process** routes jobs through **known IPC handlers** (`media:generate-image`, pack download, Lance, specialist packs) rather than executing arbitrary user graphs.

That curation is **correct for phase 1** (“every family runs once, Get → generate works”). It is also a **felt flaw** for builders: you cannot yet **mix backends** the way Comfy allows, nor **toggle expert paths** without touching code or waiting for a registry rebuild.

This doc names that gap and the **target shape** — without pretending we should clone Comfy’s execution model wholesale.

---

## Metaphor: Unreal Material / Material Instance (not literal)

Reference images in workshop notes (multi-biome landscape material) illustrate **product language**, not a mandate to ship Unreal shaders inside Anikai.

| Unreal idea | Anikai analogue |
|-------------|-----------------|
| **Master material graph** | **Playground graph** or **pipeline schema** — nodes, wires, validation, run via Anikai runners |
| **Material Instance** | **Expert mode / path toggles** — same graph, **exposed parameters**: enable ocean layer, pick LoRA pack, secondary models folder, upscale pass on/off |
| **Parameter groups** (`0_3_Ocean_Layer`, biome blocks) | **Stage groups** in a pipeline: mask → generate → post → 3D prep — collapsible, override checkboxes |
| **Biome blend masks** | **Routing rules** — which engine runs when (e.g. “if Pixel3D pack missing → fallback diffusers mesh lane”) |

**Important:** chains are not **only** media. The same composition model should eventually wire:

- **Model refs** (GGUF, Diffusers preset, ONNX graph id)
- **Python / WSL scripts** (staged venv, `run_*.py` entrypoints)
- **Terminal / cmake / pack staging** nodes (creator-facing, not consumer-default)
- **Agent steps** (companion proposes graph edits; user approves)

Do not read “material instance” as “shader editor in Electron.” Read it as **structured overrides on a declared graph**.

---

## Three UI densities (same spine)

One **pipeline / job graph** in main process; multiple surfaces:

```text
┌─────────────────────────────────────────────────────────────┐
│  Lane contracts (registry + port types + readiness probes) │
└──────────────────────────────┬──────────────────────────────┘
                               │
       ┌───────────────────────┼───────────────────────┐
       ▼                       ▼                       ▼
 Media Magic            Expert / Pipelines         Playground
 (presets, tabs)        (toggles, linear replay)   (full graph)
       │                       │                       │
       └───────────────────────┴───────────────────────┘
                               │
                    Chat / companion tools
                    (orchestrate without opening panels)
```

| Density | User | What they edit |
|---------|------|----------------|
| **Media Magic** | Everyone | Prompt, refs, style, lane tab — **hidden graph** |
| **Expert / Pipelines** | Power user in-app | Step list + **per-step overrides** (paths, optional stages, engine pick within contract) |
| **Playground** | Pipeline author | **Nodes + pins**, subgraphs, validation errors before run |
| **Chat** | Everyone (later) | Natural language → proposed graph delta → run job API |

**Comfy-like freedom** lives at **Playground + contracts**, not at “random dropdown in Standard tab.”

---

## Lane contracts (how “mix and match” stays safe)

Comfy’s implicit rule: **if you can connect two sockets, the combo might run**. Anikai needs **explicit contracts** so convenience users do not brick installs:

1. **Port types** — image path, mask path, audio path, model ref, venv id, pack id, …
2. **Engine readiness** — stage fails fast with “install Lance pack” not a Python traceback in chat
3. **VRAM / residency policy** — graph runner respects queue and warm-pool rules
4. **Version pin** — graph saved with `builtFromAnikai: "x.y"` + optional mod id (community packs)

**Registry work in flight** (single stack / GGUF / Diffusers / …) is **layer 0** of contracts: stable **family × format × pack** identity before free wiring.

---

## What is hardcoded today (honest inventory)

| Area | Today | Becomes |
|------|--------|---------|
| Stack → UI tab / preset | Registry `testedStacks`, Media Magic routing | + user graphs referencing stack ids |
| Download file list | Get pack preflight (HF expand + catalogue) | + optional “bring your own” nodes with manual paths |
| Post-process chain | Fixed buttons / pipeline record steps | + toggleable stages in expert view |
| Companion tools | Small fixed set (`generate_image`, music handoff, …) | + tools generated from graph **exports** |
| Python entrypoints | Staged scripts per lane (`stage-media-python`, …) | + reload worker without full app restart (later) |
| Restart to evolve `.py` / venv | Whole Electron lifecycle | **Media worker** or pack reload boundary (later) |

None of this blocks **shipping Media Magic**; it explains why builders compare Anikai to Comfy and feel friction.

---

## Phased direction (fits current build)

| Phase | Deliverable | Composability unlocked |
|-------|-------------|------------------------|
| **Now** | Family loading, Get pack, lane smokes, linear pipeline record | Curated combos only |
| **A** | **Pipeline schema** as JSON with named stages + overrides (Pipelines panel) | Expert toggles without full graph UI |
| **B** | **Job API** surface-agnostic (chat, Magic, Playground same runner) | Companion runs pipelines headless |
| **C** | **Playground** typed nodes + validation ([`PLAYGROUND_NODE_EDITOR_DIRECTION.md`](./PLAYGROUND_NODE_EDITOR_DIRECTION.md)) | Comfy-class wiring inside contracts |
| **D** | **Subgraphs / functions** + community pack manifest | Reusable blocks, version pins |
| **E** | **Worker reload** for staging / script changes | Iterate packs without killing chat |

**Do not** jump to “full Comfy + Unreal + Blender in one graph” before **A–B** prove record → replay → chat run on one schema.

---

## Community & mods (same composition language)

Heavy community graphs will **not** merge cleanly across Anikai versions — that is acceptable if stated upfront:

- **Verifier** checks lane contracts and pack ids, not “every git repo on Earth.”
- **Branches** pin `builtFrom` + optional mod overlay; mainline updates are **opt-in merge**.
- **Chat/companion mods** (Cursor, external agents) stay separate from **media worker** mods — different risk profile.

Foundation you are laying: **sovereign local workshop** with **one registry vocabulary**; community extends **packs and graphs**, not scattered forks of `main.js`.

---

## Open questions (park here)

- **Expert mode surface:** Pipelines panel only, or per-tab “Advanced” in Media Magic mirroring same schema?
- **Instance vs graph storage:** one JSON file per pipeline, or split “master graph” + “instance overrides” like UE MI?
- **Script nodes:** inline `python -m …` with staged venv id, or only registered `main-process` adapters at first?
- **3D / Pixel3D-class lanes:** graph node that calls **headless** specialist IPC (chat drops images, never opens Media Magic) — confirm in [`../generation/`](../generation/) when lane exists.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-06-02 | Initial direction: Comfy vs curated lanes, UE MI/graph metaphor, three UI densities, lane contracts, phases, community note |
