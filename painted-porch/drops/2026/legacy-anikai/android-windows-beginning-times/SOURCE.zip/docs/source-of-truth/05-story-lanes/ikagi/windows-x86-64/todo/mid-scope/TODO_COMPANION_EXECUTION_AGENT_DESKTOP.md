# TODO — Companion execution & agent architecture (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Map:** [`../../implementations/companion-surface/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](../../implementations/companion-surface/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md)

---

## Track A — Sandbox & edits

- [ ] **A0** Workspace root + path validator; read-only file skills
- [ ] **A1** HITL approve/deny for shell; allowlist for read-only commands
- [ ] **A2** `.anikai/staging/` + diff UI + bake transaction
- [ ] **A3** SEARCH/REPLACE applier on staging
- [ ] **A4** Prompt-injection warning on `read_file` results

## Track B — Agentic loop & memory

- [ ] **B0** Scratchpad + TODO state file; controller hooks in segment loop
- [ ] **B0** UI task rail; strict final-only user bubble audit
- [ ] **B1** Context roller at 80% + micro-summaries
- [ ] **B2** Journal writer + cross-thread inject (align workforce journal paths)
- [ ] **B3** Optional “agent session” mode in settings

## Track C — Team blackboard (after E+)

- [ ] **C0** Blackboard schema + planning phase orchestrator
- [ ] **C1** Parallel draft + cross-review workers
- [ ] **C2** Drafting channel UI + Freeze & Approve
- [ ] **C3** DAG execution with per-task scratchpads
- [ ] **C4** Export approved plan to pipeline schema (workforce §11)

## Track D — Copilot (separate plan)

- [ ] See [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../../implementations/companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md) — share executor validator with Track A

## Regression / policy

- [ ] Local-first: no silent workspace upload
- [ ] Segment loop still works for users who never enable workspace tools
- [ ] Document staging path in About / Settings when feature ships

---

## Done when

- [ ] P0 + P1 (overview phases) complete for at least one dogfood workspace
- [ ] OPERATIONS_INDEX row added and kept current
