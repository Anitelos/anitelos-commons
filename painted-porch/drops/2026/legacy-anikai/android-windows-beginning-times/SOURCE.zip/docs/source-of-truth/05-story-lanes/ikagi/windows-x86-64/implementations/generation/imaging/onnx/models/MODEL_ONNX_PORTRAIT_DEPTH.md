# Model sheet — Portrait depth (ONNX)

| Field | Value |
|-------|-------|
| **Family** | `onnx_portrait_depth` |
| **Reference** | [onnx-community/depth-anything-v2-small](https://huggingface.co/onnx-community/depth-anything-v2-small) |

Optional depth hint beside persona hero still — Stage B in [`PORTRAIT_RIG_MOTION_STRATEGY.md`](../../../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md).
