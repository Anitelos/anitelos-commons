# Group chat & mate network — implementation plan (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-18 |

**Purpose:** durable design for **multi-companion group discussion** on Anikai Desktop—round-robin turns, `@solo` pings, **focus roles** with per-companion context policy, a **living project plan** (MD), and **global inference residency** (single vs multi-model) with RAM guards.

**Execution tracker:** [`../../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md`](../../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md)

**Operations index:** [`../../operations/OPERATIONS_INDEX.md`](../../operations/OPERATIONS_INDEX.md)

**Android reference (concepts, not UI parity):** [`../../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`](../../../../android-arm64/implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md), [`../../../../android-arm64/implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`](../../../../android-arm64/implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md)

**Code today (solo chat baseline):** `anikai-desktop/components/chat.js`, `gguf-prompt-shaper.js`, `thought-parse.js`, `main-process/gguf-completion.js`, companion JSON on disk.

**Thought / reply pipeline (target architecture):** [`../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md)

**Live voice / duplex (after thought-reply B1–B3, then E+):** [`../LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md)

**Workforce / specialty / session roles:** [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md)

---

## 1. Product intent

Users assign each companion a **text model** (Phi, Gemma, Qwen, …) and a **persona** (later). In **group mode**, companions discuss a shared project as **co-owners**, not as parallel assistants:

- They may **agree or disagree** with each other and with the user.
- Turn order is predictable (**creation order** default; optional **alphabetical** setting).
- **`@Name`** requests a **single** companion reply without running the full round.
- A **note-taker** (or planner-with-notes role) maintains authoritative **project plan** markdown so long threads do not drift.
- **Idea-only** groups stay chat-focused when no note-taker is present (user opt-in).

Target hardware class (validated against author machine): **Ryzen 7 9800X3D**, **~96 GB RAM**, **RTX 5080 (~16 GB VRAM)**. Design assumes **VRAM is tighter than RAM** for multi-model residency.

---

## 2. Modes of chat

| Mode | Trigger | Speakers | Output |
|------|---------|----------|--------|
| **Solo** | `@CompanionId` or `@DisplayName` prefix | One | Normal bubble + optional thought stream |
| **Group round** | Send without `@` | All members in **turn order**, one message each | Per-companion bubbles in sequence |
| **Plan lock** | User action after a round | Note-taker (if present) | Updates `project_plan.md` + short anchor refresh |

```mermaid
stateDiagram-v2
  direction LR
  [*] --> SoloThread
  [*] --> GroupThread
  SoloThread --> InferOne: @mention
  InferOne --> SoloThread
  GroupThread --> RoundRobin: user message
  RoundRobin --> AwaitingUser: cycle complete
  AwaitingUser --> RoundRobin: continue
  AwaitingUser --> PlanLock: user locks revision
  PlanLock --> NoteCommit: note-taker writes MD
  NoteCommit --> AwaitingUser
```

---

## 3. Session roles vs specialty (naming)

| Term in this doc (legacy) | Target name | Scope |
|---------------------------|-------------|--------|
| **Focus role** / `groupRole` | **Group session role** | **Per group thread** — planning, round-robin, plan MD only |
| *(new)* | **Specialty / craft** | **Per companion** — image artist, manager, musician, … |

See [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) for the full split (persona vs specialty vs session role), **Lead-last** turn order, members/invite capability cards, and migration off global `groupRole` on the companion row.

**UI target:** session role assigned in **group members / invite** screen; specialty in **companion editor** (solo identity).

---

## 3.1 Session roles (per companion in a group, not per GGUF file)

**Today:** roles are stored on the **companion record** (`groupRole`). **Target:** `sessionRole` per member on the **group thread** so the same companion can differ across projects.

The same `.gguf` on two companions can differ (critic vs note-taker).

| Role id | Label | Default `-c` | History policy | Plan anchor | Session KV rollover | Retrieval |
|---------|--------|--------------|----------------|-------------|---------------------|-----------|
| `teammate` | Teammate | 16384 | Sliding 3–6 turns, char cap | Light thread anchor | While active thread; idle unload | Off |
| `planner` | Planner | 24576 | Sliding + round partial | **Owns** plan draft | Same | Off |
| `critic` | Critic | 16384 | Sliding + round partial | Read plan draft | Same | Off |
| `note_taker` | Note-taker | 65536 | Sliding + rolling summary | **Authoritative** plan MD | **True rollover** while group open | Later |
| `archivist` | Archivist (later) | 8192 | Minimal | Pointer to store | Off | **On** |

**Policy fields (companion JSON v2 extension):**

```json
{
  "groupRole": "teammate",
  "contextPolicy": {
    "contextCap": 16384,
    "maxHistoryPairs": 4,
    "maxCharsPerSide": 600,
    "techniques": ["sliding_recent", "summary_anchor", "plan_focus"]
  },
  "inferencePolicy": {
    "preferSessionRollover": false,
    "predictTokensPlan": 512,
    "predictTokensReply": 384
  }
}
```

**Global inference** (user settings, not per companion): see §7.

**Anti-drift:** every group prompt includes a **Focus** block:

1. `thread_anchor` — one paragraph: what we're building.
2. `plan_draft` — current MD (truncated by char budget, not token-accurate yet).
3. `open_questions` — optional bullets from last cycle.

Long group history can exceed a role's cap; **the plan file is the source of truth**, not full replay.

---

## 4. Turn order & prompt contract

### 4.1 Order

- Default: **`companions[].createdAt` ascending** (first created speaks first).
- Setting: `groupTurnOrder: "creation" | "alphabetical"`.

### 4.2 What each speaker sees

| Block | Contents |
|-------|----------|
| System / role | Teammate voice; focus role behaviour |
| Focus | `thread_anchor` + `plan_draft` |
| Round context | User message + prior speakers **this cycle only** |
| Recent | Last N user/assistant pairs (global sliding window) |
| Capability map | On first turn / when changed (existing fingerprint) |
| Output contract | `<thought>`, `turn_mode`, `[End thinking]`; convo pass if `turn_mode: conversation` |

**Group turn instruction (speaker 2+):**

- Read the user question and what others already said **this round**.
- Treat the topic as **our** project; add, challenge, or refine.
- Disagreement is welcome; avoid repeating prior speakers.

### 4.3 End of cycle (UX)

After last speaker:

- **Continue discussing** — send another message to start a **new round** (no extra “another round” button).
- **Revise plan** (note-taker pass).
- **Lock plan** (user-approved snapshot + anchor update).

Optional future: **chair summary** (3 bullets: agreements, disagreements, next step) from note-taker or tiny model.

### 4.4 `@mention` parsing

- Regex: `@(\S+)` at start or after whitespace; match companion **display name** or **id** slug.
- If match found: **solo path** only; cancel pending round queue for that user message.
- If multiple `@`, define policy later (first match wins / error).

---

## 5. Context techniques (how they combine)

| Technique | Used where | Notes |
|-----------|------------|-------|
| **Sliding recent** | All roles | Desktop today: 3 pairs × 420 chars; group mode → raise to 4–6 × 600 |
| **Summary anchor** | All group threads | Short paragraph; note-taker refreshes on lock |
| **Plan focus block** | Group | Prevents drift beyond role cap |
| **Per-round partial replay** | Speakers B, C, … | Only current cycle transcripts |
| **Two-phase infer** | Solo + group | Planning `-no-cnv`; conversation `-cnv` + `--jinja` (Gemma); vision second pass with image |
| **Thought stream UI** | User setting | Split `<thought>` / `[End thinking]` in UI |
| **Confide in uncertainty** | Reply prompts | Honest beat when intent unclear (Android-aligned) |
| **True session rollover** | Note-taker only | Phase D; llama server / warm lane — not spawn-per-call |
| **Full replay** | Avoid | Export/debug only |
| **Retrieval** | Archivist / later | Project grep across journal |

**Gemma 131k context:** model card may advertise very large windows; product defaults stay **16k–64k** per role. Full window is opt-in power-user setting with VRAM warning.

---

## 6. Note-taker & project files

### 6.1 On-disk layout (per group thread)

```
ANIKAI_HOME/
  group-threads/
    <groupId>/
      thread.json          # members, turn index, settings
      anchor.md            # short living summary
      plan/
        draft.md           # authoritative plan (note-taker)
        revisions/         # optional locked snapshots
      journal/             # optional retrieval chunks (later)
```

### 6.2 Missing note-taker UX

When user opens group or sends first group message:

- If no companion has `groupRole` in (`note_taker`, `planner` with `capturesPlan: true`):
  - Banner: *No note-taker — chat-only, or add a companion with Note-taker role for a living plan.*
  - Actions: **Chat only** | **Open companion editor**

### 6.3 Note-taker model

- **2B instruct** acceptable for formatting bullets; **4B+** recommended for merging conflicting ideas.
- Role selects default; user can assign any GGUF.

---

## 7. Global inference residency

**Settings → Global inference** (extends existing pane):

| Setting | Type | Default | Meaning |
|---------|------|---------|---------|
| `residentMode` | `single` \| `multi` | `single` | How many **distinct GGUF paths** may stay **hot** (loaded / mmap’d) |
| `maxResidentModels` | 1–16+ (user) | 1 | Cap on **resident weights** — not a hard product maximum |
| `maxParallelInferences` | 1–8+ (user) | 1 | How many **completion jobs** may run **at the same time** (solo multi-chat) |
| `soloParallelLimit` | number | *inherits `maxParallelInferences`* | Optional override for **detached solo** chats only |
| `groupParallelLimit` | number | `1` | Group rounds stay **sequential** (round-robin sanity) |
| `idleUnloadMinutes` | number | 15 | Idle resident → unload server / mmap pin |
| `ramGuardPercent` | 80 | 80 | Pause new loads when system RAM high |
| `vramGuardPercent` | 85 | 85 | Pause new loads when GPU VRAM high |
| `orchestrationProfile` | `safe` \| `balanced` \| `experimental` | `balanced` | Suggested ceilings from hardware probe (Android `LaneRiskProfile` analogue) |

**Related:** [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) §12 (compute nodes / federation), [`../../operations/RUNTIME_PACKS_AND_INSTALLER.md`](../../operations/RUNTIME_PACKS_AND_INSTALLER.md).

### 7.1 Solo vs group — different concurrency rules

| Mode | UI today | Parallel jobs | Turn order | Product intent |
|------|----------|---------------|------------|----------------|
| **Solo** | Main rail **or** detached window per `companionId` (not both — see workforce §7.1b) | Up to **`maxParallelInferences`** across **different** companions | N/A | Several companions can “think” concurrently within RAM/VRAM guards |
| **Group** | One group thread | **`groupParallelLimit: 1`** per cycle | **Round-robin** sequential | Everyone gets a say; organised discussion |

**Android reference:** Sovereign Swarm **`parallelLimit`** applies to **specialist burst** missions (small models, isolated sessions), not four full solo companions. Desktop solo multi-chat is the analogue of that **limit knob**, applied to **full companion** inference. See Android [`ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../../../android-arm64/implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md) + `SovereignSwarmDispatcher`.

```mermaid
flowchart TB
  subgraph solo [Solo - detached chats]
    W1[Companion A]
    W2[Companion B]
    W3[Companion C]
    W4[Companion D]
  end

  subgraph sched [Scheduler]
    P[maxParallelInferences e.g. 3-4 on 96GB RAM class]
    Q[Queue overflow]
  end

  subgraph hot [E+.3 residents]
    S1[llama-server / slot - model A]
    S2[llama-server / slot - model B]
    SN[... up to maxResidentModels]
  end

  W1 --> sched
  W2 --> sched
  W3 --> sched
  W4 --> sched
  sched -->|up to P concurrent| hot
  sched --> Q

  subgraph group [Group - round robin]
    R[Turn 1] --> R2[Turn 2] --> R3[Turn 3]
  end
```

### 7.2 Two knobs (do not conflate)

| Knob | Question it answers | Example on 96 GB RAM + 16 GB VRAM class GPU |
|------|---------------------|---------------------------------------------|
| **`maxResidentModels`** | How many **different `.gguf` weights** stay warm? | mmap **6–10×** ~5 GB Q4 in RAM is feasible; **full GPU pin** for all at 16K is not |
| **`maxParallelInferences`** | How many **replies generate at once**? | **3–4** mixed (2 GPU + 2 CPU), or **2** full-GPU @ 16K — user-tunable |

**Weights vs KV:** file size (~5 GB for 8B Q4) is only **weights**. **16K context on GPU** adds **KV cache** in VRAM. Design must budget both. Future: **GGUF mmap** (many mappings in RAM), **turbo/smaller quants**, per-model **`nGpuLayers`** and **context cap** (placement — §16 in workforce doc).

**No fixed “max 2” in product:** `2` is a safe default for unknown laptops. Power users (e.g. **Ryzen 9800X3D, 96 GB RAM, RTX 5080**) raise ceilings in Settings; guards still protect runaway loads.

### 7.3 Behaviour (residency + queue)

- **Single resident mode:** one GGUF server slot hot at a time; lowest VRAM.
- **Multi resident mode:** up to N **distinct model paths**; LRU + idle unload; E+.3 = **N `llama-server` processes** on distinct ports (or shared RAM mmap + GPU swap policy).
- **Queue:** FIFO; jobs wait when `activeJobs >= maxParallelInferences` or guards block → UI shows **Queued** on the thread rail / header badge and **Waiting for {name}…** in the queue bar (who is ahead in the pool).
- **Same `.gguf` on two companions:** require **separate session keys** (`solo:<companionId>`) — never share one server session blindly (E+.4).
- **Manager / automation (later):** schedules jobs into the **same pool**; not a second GPU bypass.

**Code today:** `model-residency.js` — parallel solo pool (`maxParallelInferences`), serial group lane, multi `llama-server` residents (E+.3); thread-rail **Queued** badges + **Waiting for…** queue bar (E+.3b).

---

## 8. Orchestration architecture (main process)

New module: `main-process/group-orchestrator.js` (name TBD).

| Responsibility | Owner |
|----------------|--------|
| Parse `@mention` | orchestrator |
| Build prompt via `GgufPromptShaper` + group context loader | orchestrator |
| Enqueue turns | orchestrator |
| Call `ggufCompletionMain` | existing engine |
| Stream events to renderer | IPC: `group:turn-start`, `group:chunk`, `group:turn-end` |
| Persist plan / anchor | disk via `group-threads/` |

**Renderer:** new **group thread UI** (or extend `chat.js` with `threadMode: solo | group`).

```mermaid
flowchart TB
  subgraph UI [Renderer]
    Chat[chat.js / group panel]
  end
  subgraph Main [Main process]
    Orch[group-orchestrator]
    Queue[inference queue]
    GGUF[gguf-completion.js]
    Res[model residency manager]
  end
  Chat -->|IPC send| Orch
  Orch --> Res
  Orch --> Queue
  Queue --> GGUF
  GGUF -->|stream| Chat
```

---

## 9. Phased delivery

### Phase 0 — Done / in flight (solo baseline)

- [x] GGUF one-shot + streaming (`llama-completion`)
- [x] Thought tags + `[End thinking]` + thought stream UI toggle
- [x] Capability map prefix + fingerprint
- [x] Two-phase planning / conversation (text)
- [x] Vision planning + reply pass (mmproj)
- [x] Per-model runtime JSON (GPU layers, predictTokens)
- [x] Planning pass always passes `-c 8192` for Gemma text (`-no-cnv` path)

### Phase A — Companion role metadata & prompts

- [x] Extend companion schema: `groupRole`, `contextPolicy`, `capturesPlan`
- [x] Role dropdown in companion editor with defaults table (§3)
- [x] `buildGroupTurnPrompt({ speaker, cycleTranscript, ... })` in shaper
- [x] Raise sliding window defaults for group vs solo in settings
- [x] IPC: load/save companion role fields (`companions:load` / `save` via `sanitizeCompanionRow`)

### Phase B — Solo `@mention`

- [x] Parse `@` in composer; resolve companion
- [x] Solo infer path bypasses round-robin
- [x] UI hint: `@` autocomplete from group members

### Phase C — Group round-robin (chat-only)

- [x] `group-threads/` storage + thread membership UI
- [x] Turn order + sequential IPC events
- [x] Round partial transcript passed speaker to speaker
- [x] End-of-cycle UI (continue / revise / lock) without plan write
- [x] Missing note-taker banner (§6.2)
- [x] Orphan thread collision UX (resume / overwrite / incremented name) when reusing a display name

### Phase D — Plan focus & note-taker

- [x] `plan/draft.md` read/write
- [x] Plan focus block in every group prompt
- [x] Note-taker lock → revision snapshot + anchor refresh
- [ ] Optional chair summary pass
- [ ] Session rollover experiment for note-taker lane only

### Phase E — Global multi-resident models (policy layer)

- [x] Settings UI: single vs multi, N, guards
- [x] Residency manager in main process (`model-residency.js`)
- [x] Queue UI when model cold or RAM guard
- [x] LRU + idle unload (logical tracking; see Phase E+ for true hot weights)

**Current limitation (2026-05-15):** residency **queues and tracks** models but each inference still **spawns** `llama-completion` (cold load per call). Multi mode is **policy + FIFO**, not multiple GGUF weights kept in VRAM. Phase E+ closes that gap.

### Phase E+ — `llama-server` migration (true residency)

**Goal:** replace spawn-per-call with long-lived **`llama-server`** (or equivalent) processes so Phase E settings actually keep weights hot and amortize load cost across group rounds.

**Prerequisite:** Complete thought/reply pipeline **B1–B3** in [`../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) so server sessions align with segment/tool turns (not legacy `turn_mode` two-pass). E+ should implement the **unified contract + segment loop**, not reintroduce a forked architecture.

**Blocks (for scheduling):** Codacus-style live voice (semi-duplex) and full-duplex — see [`../LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md).

**Orthogonal to:** Diffusers / media imaging work — can ship on a separate branch or after group-chat merge.

| Slice | Scope | Outcome |
|-------|--------|---------|
| **E+.1** | Feature flag; text-only; single resident | One server process; `gguf:completion` routes to HTTP/local API instead of spawn — **shipped 2026-05-16** (`inferenceMode: server`, `llama-server-manager.js`; `llama-server` staged with `stage-llama-runtime` → `dist:full`) |
| **E+.2** | Wire `model-residency.js` to real processes | Load/unload/evict start/stop `llama-server`; queue waits for slot/load — **shipped 2026-05-18** (`model-residency.js` + `prepareServerForJob`, idle evict → `stopServer`) |
| **E+.3** | Multi-resident + idle timeout | Up to N distinct model paths; N `llama-server` instances (ports 17888+); LRU + idle unload — **shipped 2026-05-18** |
| **E+.3b** | Solo multi-chat parallelism | `maxParallelInferences`; job-scoped streams to main/detached; **Queued** + **Waiting for…** UI — **shipped 2026-05-18** |
| **E+.4** | Parity: two-phase, vision (mmproj), note-taker rollover | Vision on server when mmproj set; engine flags from output template (not Gemma filename); persona `contextLimitTokens` + `preferSessionRollover` → `id_slot` — **shipped 2026-05-18** |
| **E+.5** | Placement + mmap + remote nodes | Per-model GPU/CPU/node; GGUF mmap; federated `llama-server` on LAN (see workforce §12) |

**Rough effort (one engineer, Windows CUDA path already working):**

| Target | Calendar | Notes |
|--------|----------|--------|
| MVP (E+.1–E+.2, single model, text) | ~1.5–2 weeks | Enough for faster solo + group on one GGUF |
| Full (E+.3–E+.4, multi + vision + rollover) | ~3–5 weeks | VRAM accounting, crash recovery, settings migration |

**Risks:** server crash leaves queue stuck (watchdog + restart); port/socket lifecycle on Windows; VRAM estimate vs actual when N>1; vision path may need separate server flags or mmproj preload.

**Acceptance (E+.3):** with `residentMode: multi` and `maxResidentModels: N`, distinct companions in a group round do **not** reload weights between turns unless evicted; queue bar reflects **waiting for slot**, not **spawning binary**.

**Acceptance (E+.3b):** with four **different** companions (each on main or detached, never duplicated on main rail) and `maxParallelInferences: 3`, three can stream replies concurrently (subject to guards); fourth shows **Queued** on the rail (tooltip **Waiting for…**) and queue bar **Waiting for {mates ahead}** until a slot frees; group round-robin still runs **one speaker at a time**.

**Solo detach ownership (2026-05-16):** detaching removes the companion from the main rail; re-dock restores one tab — not parallel solo threads for the same mate. See [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) §7.1b.

### Phase F — Persona + automation (later)

- [ ] Port Android `AiPromptShaper` / persona packs into desktop path
- [ ] Roaming / scheduled companions (reuse queue + residency)
- [ ] Archivist retrieval over `journal/`
- [ ] **Desktop copilot** (screen see/act) — [`../DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../DESKTOP_COPILOT_AND_SCREEN_AGENT.md); **one copilot per machine**; actuation mutex independent of `maxParallelInferences`; ships **after E+** (J1–J4)

---

## 10. IPC & event contract (draft)

| Channel | Direction | Payload sketch |
|---------|-----------|----------------|
| `group:create` | R → M | `{ memberIds[], turnOrder }` |
| `group:send` | R → M | `{ groupId, text, attachment? }` |
| `group:turn-start` | M → R | `{ groupId, companionId, turnIndex }` |
| `group:chunk` | M → R | `{ groupId, companionId, chunk }` |
| `group:turn-end` | M → R | `{ groupId, companionId, text, thought?, meta }` |
| `group:cycle-end` | M → R | `{ groupId, actions[] }` |
| `group:plan-updated` | M → R | `{ groupId, planMarkdown }` |

---

## 11. Risks & mitigations

| Risk | Mitigation |
|------|------------|
| 3× latency every user message | One round per message by default; `@` for solo; optional “skip round” |
| VRAM exhaustion (multi 4B) | `maxResidentModels`, guards, queue, CPU fallback |
| Models ignore output contract | Post-process strip; UI split; fall back to single-phase |
| Plan drift | Plan file + note-taker; anchor refresh on lock |
| Same GGUF on two companions | Existing shared-queue warning; serialize infers |

---

## 12. Open decisions (record answers here)

| # | Question | Proposed default |
|---|----------|------------------|
| 1 | Turn order | Creation time |
| 2 | Multiple rounds per user message | **New user message starts a new round** — no extra “another round” control; each send is one cycle |
| 3 | Chair summary | Phase D optional |
| 4 | Group membership max | Soft cap 8 companions; warn above 4 |
| 5 | Alphabetical tie-break | Setting only |

---

## 13. Changelog (this plan)

| Date | Note |
|------|------|
| 2026-05-15 | Initial plan: group modes, roles, context policy, orchestration, phases A–F, hardware class, IPC sketch. |
| 2026-05-15 | Phases C–E marked done in desktop; Phase E+ (`llama-server`) added with slices and effort; spawn-per-call limitation documented. |
| 2026-05-16 | **E+.1** desktop: Settings → Runtime **Inference backend** = Server; `gguf:completion` text-only routes to `POST /completion` on resident `llama-server` (vision still spawn). |
| 2026-05-18 | **E+.2** desktop: `model-residency.js` owns server load/unload; idle LRU evict stops process; same-model turns skip reload; queue UI shows loading slot. |
| 2026-05-18 | §7 expanded: solo vs group concurrency, `maxParallelInferences` vs `maxResidentModels`, mmap/KV notes, E+.3b/E+.5 slices; no hardcoded “max 2” for high-RAM class. |
| 2026-05-18 | Phase F link: desktop copilot plan (screen agent after E+). |
| 2026-05-18 | **E+.3** desktop: multi-resident = N concurrent `llama-server` processes; per-model ports; LRU evict + idle unload sync. |
| 2026-05-18 | **E+.4** desktop: vision on server + template-driven `--jinja`/`-c`; persona context + session rollover slots; mtmd fallback. |
| 2026-05-18 | **E+.3b** desktop: parallel inference pool, job-scoped streams, thread **Queued** badges + **Waiting for…** queue copy. |
