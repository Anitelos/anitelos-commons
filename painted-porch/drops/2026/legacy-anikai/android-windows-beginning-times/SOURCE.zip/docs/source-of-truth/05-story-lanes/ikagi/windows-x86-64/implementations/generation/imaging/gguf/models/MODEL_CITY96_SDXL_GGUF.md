# Model sheet — city96 / stable-diffusion-xl-base-1.0-gguf

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [city96/stable-diffusion-xl-base-1.0-gguf](https://huggingface.co/city96/stable-diffusion-xl-base-1.0-gguf)  
- Base: [stabilityai/stable-diffusion-xl-base-1.0](https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0)  

## Pack family

`sdxl_single_m` — [`MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md`](./MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md)

## Product

- **Preset id (proposal):** `sdxl_base_gguf_city96`  
- **Profile (proposal):** `sdxl_gguf` — 1024²  

## Checklist

- [ ] `sdxl_single_m` router + optional VAE probe  
- [ ] E2E smoke  

## Links

- [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
