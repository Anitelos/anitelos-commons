# TODO — GGUF text generation on desktop (Windows x86-64, mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress (Phase 0 spawn bridge in `anikai-desktop`) |
| **Last reviewed** | 2026-05-10 |

---

## Source implementation docs

- `implementations/generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Ship **companion-visible** GGUF text generation (stream or complete) behind the first Windows native adapter.
- Keep **UI claims** aligned with engine probe + manifest (no filename-only inference).
- Bridge Electron **companion** UX (chat, panels, model import path) to the same capability contract as Android, without copying Android JNI details.

---

## Checklist (working)

- [x] Phase 0: companion **Chat & reasoning** slot ending in `.gguf` → main invokes **`llama-completion`** (`gguf:completion` IPC); model path constrained to `MODELS_DIR` (see `main-process/gguf-completion.js`).
- [ ] Wire slot to a **catalog row** (`model_id`, `adapter_id`) when `model.json` / registry exists (today: raw filename in `companions.json`).
- [ ] **Streaming** (or honest “complete-only” UX copy) with **cancel** on hide / companion switch.
- [ ] Persist per-companion chat transcripts to the agreed store (see desktop MODEL_DOWNLOAD doc until a dedicated persistence plan exists).
- [ ] Surface load failures (arch, OOM, missing ops) as user-readable states (surface stderr tail from bridge today; add dedicated codes later).
- [ ] Optional: multimodal **text answers about images** only after `vision_understand` + sidecar preflight matches engine plan.

---

## Next implementation order (desktop)

1. Token **streaming** IPC + renderer.  
2. **Cancellation** + ignore stale completions.  
3. **Warm process** or move to **`llama-server`** for keep-alive.  
4. **Probe** UI + mmproj warnings (models panel + chat status).

See also: [`../../implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) — **Desktop trajectory** table.

---

## Linked operations

- `todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md` (roles T1–T5 and scheduler policy on desktop)
- `implementations/companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md` (models dir + import UX)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-09 | Created Windows desktop GGUF text-generation todo; links generation/text GGUF plan and engine-inference GGUF plan. |
| 2026-05-10 | Phase 0 checklist item done; next implementation order; fixed engine-plan relative link. |
