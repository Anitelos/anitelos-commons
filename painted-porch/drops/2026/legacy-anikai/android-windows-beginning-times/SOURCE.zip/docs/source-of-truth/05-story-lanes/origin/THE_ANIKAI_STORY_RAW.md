# The ANIKAI story (raw capture)

**Captured from:** `the anikai story.txt` on the author desktop (workspace-external).  
**Purpose:** frozen snapshot of the organizing brainstorm so the structured folders can evolve without losing the original wording.

---

i have an idea but requires some thought and work but we need to discuss.  so i want to create a new structure in source of truth, but ignore the old ones for now. can we seperate all of this for now by implementation work ill try list everything:
source-of-truth
-the community (all device and cross device ideas and where to host, how to host) 
-anikai ip (ip and law)
-Ikagi (the place to belong)
--android (arm64v8)
---os quirks
----device mismatch/ oem quirks (app to device mismatches we log and idea patches/updates)
----ip (all things that need to be logged to one day solidify anikai and also not get my ass sued).
---complete (here we archive the work but i will think up something to have clear ideas of how it works and fits and why. so we have solid things to add to. go it we replicate the implementation layout as we complete things then when they are complete we move it from implement to complete. using the todo folder as the bridge of current works so implementation folder allows drifting the todo keeps track and complete shows what we have. sorry i just figured this helps)
---todo 
----low scope
----mid scope
----high scope
----shelved (items not touched on for a bit)
---implementations (solid and cemented untouchable ideas unless better scope for target, but no todos her just ideas)
----Generation
-----imaging (all imaging docs)
------(flux 1 and 2 gguf integrations, onnx imaging in the future anything ai imaging same with other subjects. even flux py if its even a thing)
-----video 
-----audio (all audio source. not the aware/sentient side so more output, but this section will later hold audio receiving capabilities for pipeline and audio creations anything that comes to mind but its easier to separate)
------voice
------music/sfx
------input maybe? or each would hold their own.
-----text
------(current text gen implementations, any category that may arise so not just new models but cool features late)
----sentience
-----roaming (anything that is sentient autonomy kinda) 
------guardian force defences
------24/7 alive
-----vision(the new sight findings go here)
-----hearing(any work on how they hear)
-----speech patterns (emotive, cadence,  phoneme emotion tie in,  anything with portraying who they are not voice generation engine stuff, if this makes sense))
-----interaction (how they move around)
-----awareness (emotion work any curiosity self interest/passion/knowledge gain and how to self improve and learn as they go)
-----product/user boundaries (here we note things we need to lock for it to actually maybe possible make some money. goal is no more than 20 pound per person. this buys the access to the community and puts a little security behind that member ship i dunno yet lol)
----engine inference (where we would plan inference work and combinations like mixing the toggle for flux 1 and 2, but more planned out. would also address how we piece user access together, minus curiosity its handled above).
-----model hub ( currently our swarm available models. here we work on what we did with other work than just generations like what we did with gguf)
------gguf
------litert
------onnx
------media pipe (google)
------ncnn
...
----the anikai handover(handover mechanics in how this fits in, could include roaming model hub stuff, the inner app cross functions basically).
-----reflex (its the app and ai reporter also the gap filler in-between guy, i think it fits here. any handover, doesn't just have to be our onboard but any idea for for ai reflex use even for the media pipe ideas)
----companion surface (how the user and soul bond and work together, anything to do with)
-----confidence
-----resona projects(workspace threads)
-----chat screen (life thread single continuity, no other threads, main app chat screen)
-----ui/ux direction (simple user is the target, but never hide advance mechanics for those that want it)
----resona (the multi workspace, i feel a cursor/antigrav type multi-peer work flow with multiple agents and swarms and emotions. with ai not just being assistants but playing part of a team as a singular soul with many models is next gen to me. so needs its own bit).
---(know im missing some more key things)
--windows x86-64 (all the same as above no bridge use maybe how it would connect from the ideas same as above but nothing to do with inner bridge mechs)
--linux
--(iphone, vr headset or any kind of device later)
-anima (the soul, i was holding this as this hit me a little bit. but anikai was anima and ikagi combine so cool). (this is the brigde all area its how anikai and the soul everything we spoke about cross device. all ideas for bridge functions including and more: todos, completes, the separate combos live here.)
--roaming
--awareness
....
