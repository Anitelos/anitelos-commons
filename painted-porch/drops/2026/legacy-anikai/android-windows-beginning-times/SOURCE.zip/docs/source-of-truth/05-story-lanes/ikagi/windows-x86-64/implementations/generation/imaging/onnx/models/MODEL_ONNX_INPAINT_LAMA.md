# Model sheet — LaMa inpaint (ONNX)

| Field | Value |
|-------|-------|
| **Family** | `onnx_inpaint` |
| **Reference** | [Carve/LaMa-ONNX](https://huggingface.co/Carve/LaMa-ONNX) |

Masked inpaint — requires **image + mask** PNG at run time (`maskPath` IPC). Use **lama_fp32.onnx** (not `lama.onnx` dynamo export).
