# Desktop copilot — screen see, voice, and act (Windows vision)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-18 |

**Purpose:** Plan a **Jarvis-style** desktop companion lane: **see** the screen (downscaled vision), **talk** with the user while moving (STT/TTS), and **act** via validated mouse/keyboard — **one copilot per machine**, orthogonal to group chat and solo multi-chat parallelism.

**Prerequisites (ship first):**

1. [`group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) — **Phase E+** (`llama-server`, multi-resident, vision parity E+.4)
2. [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) — B1–B3 segment + tool loop
3. [`LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) — semi-duplex voice (STT → stream LLM → TTS, barge-in)

**Related:** [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) (manager / `programmer` crafts), [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](WORKFORCE_AND_ORCHESTRATION_VISION.md), [`COMPANION_MEDIA_LIBRARY.md`](COMPANION_MEDIA_LIBRARY.md), [`../operations/RUNTIME_PACKS_AND_INSTALLER.md`](../operations/RUNTIME_PACKS_AND_INSTALLER.md).

**External references (direction only — not product commitments):** GUI/OCR multimodal models (e.g. Nemotron-class “browser agent” marketing); vision-to-action gaming foundations (e.g. NitroGen-class frame→control). Anikai v1 does **not** require either; we document adapter slots.

**Code today:** None for screen capture or input injection. Vision for **attachments** uses `llama-mtmd-cli` + mmproj (`gguf-completion.js`, media preflight in `chat.js`).

---

## 1. One sentence

One **system copilot** companion per machine runs a **perceive → plan → act** loop on downscaled screen frames (and optional UI trees), narrates over **voice**, and drives **mouse/keyboard only through a validated executor** — while other companions stay chat/media-only and respect the global inference queue.

---

## 2. Three layers (never merge in one module)

```mermaid
flowchart LR
  subgraph perceive [Perception]
    Cap[Screen capture]
    Scale[4K to 720p ROI]
    UIA[Optional UI Automation tree]
  end

  subgraph think [Cognition]
    VLM[Vision — mmproj or GUI VLM pack]
    LLM[Planner + narrator]
  end

  subgraph act [Actuation]
    Val[Action validator]
    Exec[desktop-agent-executor]
    IO[SendInput / UIA click]
  end

  Cap --> Scale --> VLM
  UIA --> LLM
  VLM --> LLM
  LLM -->|action JSON| Val --> Exec --> IO
  IO --> Cap
```

| Layer | Responsibility | Models do **not** |
|-------|----------------|-------------------|
| **Perception** | Capture monitor/window; resize; optional OCR crop; diff “frame changed?” | Call Win32 APIs |
| **Cognition** | Goal, state summary, next 1–3 actions, `ask_user` | Emit raw driver calls |
| **Actuation** | Parse schema, confirm destructive ops, run `SendInput` / UIA | Run unconstrained shell |

---

## 3. One copilot per system

| Rule | Rationale |
|------|-----------|
| Settings: `desktopCopilotCompanionId` (single UUID) | One persona “owns” the desktop session |
| **Actuation mutex** | Even if `maxParallelInferences` > 1, **screen control = 1** job |
| Other companions | Text, media library, group roles — **no** mouse/keyboard |
| Manager specialty | May **assign** tasks to copilot; does not bypass mutex — see [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) |

**Parallel inference:** Solo detached chats and group round-robin continue on the shared queue; copilot loop uses the same **residency** but holds the **input lock** while `copilotSessionActive`.

---

## 4. Vision path

### 4.1 Capture & resolution

| Setting | Default | Notes |
|---------|---------|--------|
| `screenCaptureMaxEdge` | `720` | Downscale from 4K (or native) before VLM |
| `screenCaptureFps` | `2` | Background observe; burst to `4` on user command |
| `screenCaptureRoi` | `full` \| `cursor` | Cursor ROI ± ~400px for latency |
| `screenCaptureSource` | `primary` \| `window` | v1: primary monitor |

Pipeline: ** DXGI Desktop Duplication** or equivalent in main process → JPEG/PNG buffer → optional letterbox → feed mtmd/mmproj or future GUI pack.

### 4.2 Model strategies (phased)

| Path | When | Input | Output |
|------|------|-------|--------|
| **J1 — mmproj (extend today)** | First slice | 720p frame(s) | State text + action JSON in prompt |
| **J4a — GUI VLM pack** | Dense UI / OCR-heavy | Frame + optional tree | Same action schema |
| **J4b — continuous control** | Games / smooth drag (opt-in) | High-FPS frames | Low-level deltas — **separate** safety tier |

Reuse [`COMPANION_MEDIA_LIBRARY.md`](COMPANION_MEDIA_LIBRARY.md) patterns: preflight-style “what changed?” captions, not full 4K essays every tick.

### 4.3 Relation to chat vision

| Today | Copilot |
|-------|---------|
| User **attaches** image → ingest → mtmd preflight | App **captures** desktop → ephemeral frame id (not media library) |
| Captions persisted in `index.json` | Ring buffer; journal may log **action log** only |
| Group: library text after preflight | Copilot: **solo system role** only |

E+.4 (vision on `llama-server`) should be designed so **screen frames** can use the same server/mmproj slot without duplicating spawn paths.

---

## 5. Actuation — “see and touch” we own

### 5.1 Action schema (v1)

Normalized coordinates **0–1** on the **capture buffer** (720p), not physical 4K.

```json
{
  "actions": [
    { "op": "click", "x": 0.42, "y": 0.31, "button": "left" },
    { "op": "type", "text": "hello" },
    { "op": "hotkey", "keys": ["ctrl", "l"] },
    { "op": "scroll", "dy": -3 },
    { "op": "wait", "ms": 500 },
    { "op": "ask_user", "say": "Should I click Install?" }
  ]
}
```

### 5.2 Executor (main process)

Planned module: `main-process/desktop-agent-executor.js`

| Step | Behavior |
|------|----------|
| Validate | Whitelist `op`; clamp coords; max actions per step |
| Confirm | Destructive patterns → `ask_user` or UI confirm |
| Execute | Win32 `SendInput` and/or **UI Automation** (control by name when tree exists) |
| Settle | `wait` + optional frame-diff before next observe |

**Hybrid default:** UIA when accessible; pixel click fallback for games/custom UI.

### 5.3 Models vs code

| Piece | Build vs adopt |
|-------|----------------|
| Capture, resize, timing | **Build** |
| Mouse/keyboard | **Build** (executor) |
| “What is on screen?” | **Start:** mmproj/mtmd; **Later:** optional GUI VLM runtime pack |
| Frame→continuous control | **Optional** third-party adapter (NitroGen-class), not v1 |

---

## 6. Supervisor loop

```mermaid
flowchart TD
  O[Observe frame + optional UIA diff]
  R[Orient — short VLM state]
  P[Plan — max 3 actions]
  A[Act — executor]
  N[Narrate — TTS or chat]
  O --> R --> P --> A
  A -->|settle| O
  P -->|ask_user| N
  A --> N
```

- Integrate with **segment/tool** pipeline: tools `screen_capture`, `screen_act`, `screen_ask_user` (IPC), thoughts in private panel.
- **Kill switch:** global hotkey (e.g. Ctrl+Shift+Pause) clears queue and releases input lock.
- **Panic:** user barge-in (voice) cancels in-flight actions — same as semi-duplex cancel.

---

## 7. Voice while navigating

After [`LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) semi-duplex:

| Channel | Copilot use |
|---------|-------------|
| **STT** | Short commands (“scroll down”, “open settings”, “stop”) |
| **LLM** | Resident `llama-server` session key `copilot:<companionId>` |
| **TTS** | High-level narration only (avoid speaking every micro-click) |
| **Barge-in** | Abort action queue + optional “what were you doing?” recovery |

Delivery order: **E+ → voice semi-duplex → J1/J2 copilot → J3 live loop**.

---

## 8. Safety & consent (v1 requirements)

| Control | Requirement |
|---------|-------------|
| Opt-in | Per-session: “Allow mouse and keyboard control” |
| Kill switch | Always available |
| Focus | v1: no silent control when Anikai is not focused (configurable later) |
| Blocklist | Banking, admin installers — app name / path deny list |
| Password fields | UIA `IsPassword` → never type |
| Destructive | `delete`, `send`, `purchase`, `format` → confirm |
| Audit | Journal: action log (op, target summary, timestamp) — not full screen recording by default |

---

## 9. IPC sketch (future)

| Channel | Direction | Payload sketch |
|---------|-----------|----------------|
| `copilot:start` | R → M | `{ companionId, goal?, captureProfile }` |
| `copilot:stop` | R → M | `{ sessionId }` |
| `copilot:frame` | M → R | `{ sessionId, thumb?, stateText? }` (debug UI) |
| `copilot:action-log` | M → R | `{ sessionId, actions[], result }` |
| `copilot:ask-user` | M → R | `{ say, choices? }` |

Inference still flows through existing `gguf:completion` / residency; copilot sets `exclusiveInputLock: true` on the job metadata.

---

## 10. Runtime packs (future)

| Pack id | Provides | Notes |
|---------|----------|--------|
| `gguf.core` | mtmd, `llama-server` | J1 vision on screen frames |
| `gguf.gui-vlm` *(planned)* | GUI-specialized VLM binary | Nemotron-class adapter slot |
| `agent.control-continuous` *(planned)* | Optional frame→action model | Opt-in; separate license |
| `gguf.asr` + `voice.*` | Hearing + speech | Live copilot J3 |

See [`../operations/RUNTIME_PACKS_AND_INSTALLER.md`](../operations/RUNTIME_PACKS_AND_INSTALLER.md) §10.

---

## 11. Implementation phasing

| Phase | Scope | Depends on |
|-------|--------|------------|
| **J0** | This doc + cross-links | — |
| **J1 — Screen see** | Capture, downscale, mmproj “describe screen” (no actuation) | E+.4 vision path helpful |
| **J2 — Screen touch** | Executor + action schema + `desktopCopilotCompanionId` + mutex | J1 |
| **J3 — Live copilot** | Voice + supervisor loop + ROI + UIA hybrid | Semi-duplex voice |
| **J4a** | GUI VLM pack adapter | J2 |
| **J4b** | Continuous control adapter (opt-in) | J2 + safety review |

**Explicitly after E+:** Do not block E+.3 / E+.3b / E+.4 on copilot work. Finish **true residency**, **multi-server**, **vision on server**, then **solo parallel** before J1.

Group plan **Phase F** (automation) and workforce **Manager** specialty remain the parent buckets; this doc is the **screen-agent** detail.

---

## 12. Open decisions

| # | Question | Proposed default |
|---|----------|------------------|
| 1 | Capture API | DXGI duplication primary; BitBlt fallback |
| 2 | Store frames on disk? | No by default; journal actions only |
| 3 | Copilot uses same mmproj as chat companion? | Yes, same companion runtime slots |
| 4 | Multi-monitor | Primary only in J1; picker in J3 |
| 5 | Electron overlay vs pure background | Background capture J1; optional highlight overlay J3 |

---

## 13. Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial plan: three layers, one copilot per system, 720p capture, action schema, executor, voice order, safety, J1–J4 phasing after E+. |
