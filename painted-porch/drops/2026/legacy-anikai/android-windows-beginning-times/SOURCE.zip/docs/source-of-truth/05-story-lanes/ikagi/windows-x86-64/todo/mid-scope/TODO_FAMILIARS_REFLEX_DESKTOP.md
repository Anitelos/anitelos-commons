# TODO — Familiars reflex system (desktop)

| Field | Value |
|-------|-------|
| **Lane** | ikagi / windows-x86-64 |
| **Scope** | mid |
| **Design** | [`../../implementations/anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md`](../../implementations/anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md) |
| **Index** | [`../../implementations/WINDOWS_DESKTOP_INDEX.md`](../../implementations/WINDOWS_DESKTOP_INDEX.md) |

---

## UI — Familiars

- [x] **F1** Companion panel: Familiar grid (3 per row); **+** → Companion \| Familiar
- [x] **F1** Single GGUF slot per familiar (drag model; rejects duplicate file)
- [x] **F1** Tabs: Persona, Assign, Inference, Journal, Metrics (shell)
- [x] **F2** Assign role chips (multi); companion checkbox blocklist (default allow all)
- [x] **F7** Split companion **Persona** vs **Inference**; add companion **Metrics** tab

## Reflex jobs

- [x] **F3** Journal + metrics persistence (`journal.jsonl`, `metrics.json`)
- [x] **F4** SmolLM2-Rethink classifier familiar + turn caps wire-up (chat pre-pass)
- [x] **F5** Prompt Guard 2 familiar (86M or 22M) — `familiar-guard.js` + optional Python sidecar; heuristic fallback
- [x] **F6** Script familiars: time, folder search, bounded quick edit (`familiar-scripts.js`)

## Persona packs

- [ ] Archetype stubs: droid, fairy, pixie, gizmo, borrower, sprite (no soul metrics)
