# TODO — Creations persona rig test pipeline (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-07 |

---

## Source implementation docs

- `implementations/pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`
- `implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `implementations/generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`
- `implementations/generation/imaging/PORTRAIT_PACK_SCHEMA.md`

---

## Intent

- Stand up a rig-first persona animation test surface in Creations.
- Validate speech/mood-driven face + body motion before full neural motion inference.
- Add neural enhancement (FOMM-class lane) only with explicit capability/failure signaling.
- Prepare multi-view persona references to reduce side-turn artifacts.

---

## Checklist (working)

- [ ] Add Creations entry surface for Persona Rig Test with lane label and diagnostics panel.
- [ ] Build primitive rig actor (head, mouth line, eye/brow lines, shoulders, forearms/hands).
- [ ] Implement phoneme bucket mapping (`rest`, `A`, `E`, `O`, `M/B/P`) and mood overlays (`calm`, `focus`, `warm`, `alert`).
- [ ] Add at least 3 gesture presets + 1 low-energy idle preset.
- [ ] Add shallow depth illusion controls (scale/parallax offsets) for pseudo-z staging.
- [ ] Integrate single-image persona bind (Stage B) and verify identity holds during talk cycles.
- [ ] Define and implement 8-view yaw bucket selection (`N, NE, E, SE, S, SW, W, NW`) for Stage C.
- [ ] Wire FOMM lane probe and enforce no silent fallback behavior when v1 neural lane is selected.
- [ ] Capture telemetry: active lane, average frame ms, p95 frame ms, failure reason code.
- [ ] Write export/debug bundle for run traces (rig params + selected view + lane transitions).

---

## Validation checkpoints

- [ ] 60-second speech run stable on rig lane (no major drift, no hard pose snaps).
- [ ] Mood changes reflect in brows/eyes/head posture in under one speaking turn.
- [ ] 8-view switching has no undefined angle gaps.
- [ ] Neural lane probe result is reproducible across repeated launches on same device state.
- [ ] Failure copy is user-facing and actionable (missing model, session fail, unsupported device).

---

## Linked operations

- `todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (parent dependency)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-07 | Created Persona Rig Test mid-scope todo with staged rig-first rollout and neural-lane diagnostics checkpoints. |
