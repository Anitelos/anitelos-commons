# FOMM (First-Order Motion Model) engine inference plan — Qualcomm ONNX (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define how ANIKAI **runs** the Qualcomm-exported FOMM ONNX bundle (detector + generator) on Android: storage, ORT session lifecycle, graph contracts, orchestration boundaries, and integration with Creations / Sprite motion lanes. This is **inference/engine** ownership, not the **generation** quality brief (see generation imaging docs) and not the full **product** Sprite pipeline UX (see `pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`).

---

## What this model family is

**First-Order Motion Model (FOMM)** is a class of **motion transfer** methods: a **source appearance** (e.g. a character image) is warped or driven to follow **motion** derived from a **driving signal** (classically a short video of a person). The Qualcomm package ships **ONNX** graphs (this plan focuses on a **detector** and **generator** pair) suitable for on-device experiments on Snapdragon-class hardware.

**Not in scope for “FOMM alone”:** end-to-end “audio in → talking avatar” (that layers other models on top of or beside motion transfer). This doc only covers **engine inference** for the bundled graphs.

**Canonical references (external):**

- [Qualcomm / Hugging Face — First-Order-Motion-Model](https://huggingface.co/qualcomm/First-Order-Motion-Model) (bundle card and notes).  
- [Aliaksandr Siarohin — first-order-model](https://github.com/AliaksandrSiarohin/first-order-model) (original research lineage).

---

## Relationship to other ANIKAI docs

| Concern | Owned by |
|--------|----------|
| Generic ONNX Mobile adapters (simple img2img SR graphs, registry, manifests) | [`../onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](../onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md) |
| Sprite Maker product flow, v1/v2 lanes, UI policy | [`../../../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../../../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md) |
| Visual quality gate for stills | [`../../../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](../../../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) |

FOMM graphs are **ONNX**, but they are **not** the same adapter profile as single-input NCHW super-resolution (`OnnxSwarmImageRuntime`). Treat FOMM as a **dedicated motion engine** with its own manifest, inputs, and orchestration.

---

## Artifact layout (ANIKAI Swarm storage)

| Artifact | Role |
|----------|------|
| Curated zip | `fomm-onnx-float.zip` (pinned download in app catalog; lands under `ANIKAI/Models/Swarm/`). |
| Extract folder | Predictable directory beside zip: `…/Swarm/fomm-onnx-float/` (basename of zip without `.zip`). |
| Detector ONNX | File whose name contains **`detector`** (case-insensitive). |
| Generator ONNX | File whose name contains **`generator`** (case-insensitive). |

Operational rule: **“downloaded” ≠ “usable”.** Readiness must verify **extract** + **both ONNX tokens present** + optional **ORT session creation** (see checklist).

---

## Current truth in codebase (staging)

Use Git as source of truth; this section is a **hint** for navigators.

- **Zip lifecycle:** download resume, extract with zip-slip guards, helpers to locate ONNX by name token (`ModelDownloadManager`).  
- **Probe-only inference:** `FommV2MotionProbe` loads detector and generator sessions briefly to validate ORT can parse the models (no full forward loop yet).  
- **Product surface:** Sprite Sheet Maker motion route **v2** runs prerequisites + probe; **no silent fallback** to v1 compose when v2 is selected (warnings only).

Full motion inference (forward passes, tensor plumbing, driving frames) is **not** operational until the checklist below is satisfied.

**Coordination:** the Creations **v1 motion sheet pipeline** builds an interim strip using **8 frames per facing row** (fixed, subtle offset loop) for smoother motion until FOMM outputs replace or augment that stage — see `pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md` (Lane B / v1 strip contract).

---

## Target runtime architecture

### Option A — Kotlin ORT (recommended first integration)

- Align with existing ONNX Mobile usage (`ai.onnxruntime`) elsewhere in the app (voice adapters, image adapter patterns).
- Implement a **`FommMotionOnnxRuntime`** (or similarly named) singleton or scoped pool with explicit thread policy for heavy inference.
- Pros: faster iteration, aligns with `FommV2MotionProbe`; easier structured errors to UI.

### Option B — JNI native bridge

- Justified if Qualcomm tooling or performance requires custom preprocessing or non-Java tensor paths later.
- Requires CMake/NDK checklist parity with other JNI lanes.

**Decision record:** ship **Option A** until profiling proves JNI is required.

---

## Graph contract (discovery checklist)

Qualcomm exports may differ by revision. Do **not** hard-code assumed shapes without verifying the **actual** graphs on disk.

- [ ] Enumerate **input/output tensor names** and ** dtypes** for detector and generator (Netron, ORT introspection, or small debug harness).  
- [ ] Document minimum **spatial sizes** and whether inputs expect **NCHW RGB**, **BGR**, normalized **[0,1]** vs **[-1,1]**, etc.  
- [ ] Identify **temporal** inputs if any (e.g. keypoints sequence): Sprite sheet pipeline may synthesize a minimal driving sequence from archetypes or reuse NESW facings as anchors — **product decision**, but tensors must match exports.  
- [ ] Capture **opset** version and ORT compatibility floor in the manifest.

---

## Orchestration model (inference stages)

High-level FOMM-style pipelines typically involve **multiple stages** (e.g. detection / representation → motion parameters → generation / warp). Exact wiring **must** match the Qualcomm ONNX pair:

1. **Prepare source image** (crop/resize to export contract; preserve alpha policy explicitly).  
2. **Run detector** (and any intermediate tensors required by the bundle docs).  
3. **Run generator** with conditioned inputs (and driving signal tensors when product supplies them).  
4. **Decode output** to bitmap / texture strip for sheet composer.

- [ ] Implement **stage boundaries** with structured errors (`detector_fail`, `generator_fail`, `shape_mismatch`, etc.).  
- [ ] Emit **per-stage timing** (`detector_ms`, `generator_ms`) for regression tracking.

---

## Android app integration checklist

### Capability / manifest

- [ ] Register a **capability id** for `qualcomm_fomm_onnx` (or aligned Swarm lane id) in the runtime registry narrative (`TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md` alignment).  
- [ ] Expose **readiness** API: device signal + zip + extract + ORT load (reuse probe, extend with full forward when ready).

### Threading and lifecycle

- [ ] Run heavy inference off main thread; single-flight or explicit queue policy for session usage.  
- [ ] Release tensors and sessions on failures; avoid leaking `OrtSession` across configuration changes.

### UI contract

- [ ] Motion lane labels remain explicit (`v2_motion_sheet_pipeline` vs `v1_motion_sheet_pipeline`) in metadata.  
- [ ] Failures surface **user-visible reasons**, consistent with “no silent fallback” policy for v2.

---

## Validation gates (before “operational” inference)

- [ ] Detector ORT forward succeeds on **golden** source crop from documented fixture bytes.  
- [ ] Generator ORT forward succeeds given **valid** intermediate tensors from detector (or documented bypass if export permits).  
- [ ] End-to-end produces **non-empty** raster output with stable dimensions across repeated runs (fixed seed / fixed inputs where applicable).  
- [ ] Thermal / memory budget sampled on at least one target Snapdragon device class.

---

## Linked todos

- [`../../../../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`](../../../../todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md) (motion / sheet product gate).  
- [`../../../../todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`](../../../../todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md) (broader imaging ONNX lane).

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Noted coordination with **v1 sheet strip** (8 frames per facing row interim) until full FOMM forward pass. |
| 2026-05-06 | Initial FOMM Qualcomm ONNX engine inference plan under model-hub (artifact layout, ORT-first strategy, orchestration + JNI/Android checklist). |
