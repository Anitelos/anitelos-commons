# Curated pipelines — index (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-22 |

Purpose: list the **named, reusable compositions** Anikai will ship alongside the Playground editor, with one doc per pipeline. Curated pipelines are *not* features of any single model — they are graphs that wire several model roles together to do a job. Mirrors the Android approach (`creations` screen + `pipelines/` docs).

This index does **not** replace:

- the Playground editor direction — [`./PLAYGROUND_NODE_EDITOR_DIRECTION.md`](./PLAYGROUND_NODE_EDITOR_DIRECTION.md) (Rete UI layer, phased graph),
- **why graphs are curated today vs Comfy-free wiring** — [`./COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md`](./COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md) (expert toggles, lane contracts, UE MI metaphor),
- per-model docs under [`../generation/`](../generation/),
- the engine inference plans under [`../engine-inference/`](../engine-inference/).

---

## Index

| Pipeline | Job | Roles used | Doc | Status |
|----------|-----|------------|-----|--------|
| **Suno-clone (instrumental + planned vocals)** | Text + style + lyrics → full song. Multi-stage: LLM plan → instrumental codec model → vocal model (planned) → mix. Media Magic: Compose + Voice Weaving + Assembly. | Reading + Audio Lane 4 + Audio Lane 5 (planned) + Voice Weaving + DSP | [`./CURATED_SUNO_CLONE_PIPELINE.md`](./CURATED_SUNO_CLONE_PIPELINE.md) · [`../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md`](../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md) | partial (Phase 0) |
| **Persona rig test** | Smoke-test a companion’s text + vision + voice + media slots end-to-end. | Reading + Sight + Voice + Imaging | _tbd_ | planned |
| **Whisper chain capability smoke** | Hold-to-talk → ASR → LLM → optional TTS reply. | Hearing + Reading + Voice | _tbd_ | planned |
| **Imaging quality stack** | Multi-stage image polish: normalize → primary pixels → consistency → upscale → palette unify → pack. | Imaging + ONNX upscale + pose extractors | _tbd_ | planned |
| **Media Magic pipeline record** | Record pre/main/post steps in Media Magic → save schema → replay in Pipelines. Image weaving compositor scaffolded; Video weaving shader scaffold shipped. | Imaging pre + main + post + image_mix + bake + video_weaving | [`./IMAGING_PIPELINE_RECORD_PLAYGROUND.md`](./IMAGING_PIPELINE_RECORD_PLAYGROUND.md) | Phase 1 shipped |
| **Sprite maker / sheet** | Character sprite + sheet builder from concept/ref → NESW → sheet. | Kontext Diffusers/GGUF + ONNX rembg + pack | [`./SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](./SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md) · [`../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) | **partial** (Steps 1–5 shipped) |
| **Voice + music workforce** | Compose music bed + render TTS narration + duck/mix. | Audio + Voice (TTS) + DSP | _tbd_ | planned |
| **Creations music generator** | One-button music: intent → composition plan → stems → arrangement → mix. | Audio (parametric + optional ONNX neural lane) | _tbd_ | planned |
| **Talking-head portrait** | Portrait + driving video or audio → animated clip via FOMM / LivePortrait. | Sentience motion-sense + Audio + Imaging | _tbd_ | planned |
| **AAA-style character production (research)** | Character/outfit stills → video loops (WAN LoRA) → mesh → MoCap retarget → theme audio; optional TriSplat environment. | Imaging + Video + 3D + Audio | [`../generation/threed/THREED_RESEARCH_CANDIDATES.md`](../generation/threed/THREED_RESEARCH_CANDIDATES.md) | research |
| **Desktop copilot loop** | Perceive (screen vision) → plan → validated action → narrate. | Sight + Reading + Control + Voice | _tbd_ | planned |

Each row earns its own doc as Anikai builds toward it. A row only graduates to **shipped** when:

1. Every model role it uses has a working engine plumb,
2. The pipeline runs end-to-end inside Playground,
3. Output artifacts and metadata match the contract in the pipeline doc.

---

## Authoring rule

Curated pipelines are **examples + presets**, not promises. The app validates **working models**. The user composes / runs / edits the pipeline. A curated graph that depends on a not-yet-shipped model role must mark that step as *planned* and never silently substitute another role.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-22 | Sprite maker row → Windows pipeline plan (partial Steps 1–3). Playground direction doc (Rete, graph layers, phases). |
| 2026-05-24 | Suno-clone row links Voice Weaving doc (engines vs presets). |
| 2026-05-19 | Initial index. Suno-clone first concrete doc; remaining rows are placeholders that earn docs as built. |
