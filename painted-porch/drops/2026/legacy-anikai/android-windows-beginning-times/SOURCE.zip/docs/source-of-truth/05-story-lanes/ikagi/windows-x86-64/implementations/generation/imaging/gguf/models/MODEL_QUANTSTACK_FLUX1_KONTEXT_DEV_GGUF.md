# Model sheet — QuantStack / FLUX.1-Kontext-dev-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Complete |
| **Operations** | Shipped (GGUF + Diffusers presets) |
| **Last reviewed** | 2026-05-20 |

## HF

- Repo: [QuantStack/FLUX.1-Kontext-dev-GGUF](https://huggingface.co/QuantStack/FLUX.1-Kontext-dev-GGUF)  
- Base (Diffusers): [black-forest-labs/FLUX.1-Kontext-dev](https://huggingface.co/black-forest-labs/FLUX.1-Kontext-dev) (gated)  
- **FP16 sidecars (Apache-2.0):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the GGUF  
- sd.cpp: [`kontext.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/kontext.md)  

## Pack family

`flux1_kontext` — same FLUX.1 encoders as Dev/FHDR; **requires reference image** (`-r` in sd.exe).

## Local folder (one directory, two tracks)

`models/kontext/` — shared pack folder name for GGUF and Diffusers.

### GGUF split-pack (Media Magic native)

```text
models/kontext/
  flux1-kontext-dev-Q8_0.gguf
  vae/ae.safetensors
  text_encoder/clip_l.safetensors
  text_encoder_2/t5xxl_fp16.safetensors
```

Register the `.gguf` in **Models** (Image tag). **Upload a reference image** in Media Magic before Generate.

### Diffusers tree (preset `flux1_kontext_dev`)

Copy the gated [FLUX.1-Kontext-dev](https://huggingface.co/black-forest-labs/FLUX.1-Kontext-dev) snapshot:

```text
models/kontext/
  model_index.json
  transformer/
  vae/
  text_encoder/
  text_encoder_2/
  tokenizer/
  tokenizer_2/
  scheduler/
```

Select **preset:flux1_kontext_dev** in Media Magic. Reference image required.

### Kontext inpaint (mask edit)

Preset **`flux1_kontext_dev_inpaint`** · `FluxKontextInpaintPipeline`. Upload **reference** (source) and **mask** (white = region to change) in Media Magic.

## Anikai

| Path | Preset / stack |
|------|----------------|
| GGUF | `kontext-quantstack` · router `flux1_kontext` · profile `flux_kontext_gguf` |
| Diffusers edit | `flux1_kontext_dev` · `FluxKontextPipeline` |
| Diffusers inpaint | `flux1_kontext_dev_inpaint` · `FluxKontextInpaintPipeline` |

## Checklist

- [x] GGUF router + `-r` reference image  
- [x] Diffusers preset + `FluxKontextPipeline`  
- [ ] Author GPU E2E smoke (optional)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet; phase2 edit. |
| 2026-05-20 | Shipped GGUF + Diffusers tracks (parallel to FHDR). |
