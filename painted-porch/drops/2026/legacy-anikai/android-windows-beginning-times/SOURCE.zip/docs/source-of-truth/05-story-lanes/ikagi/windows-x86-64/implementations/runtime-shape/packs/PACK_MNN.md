# MNN runtime pack

| Field | Value |
|-------|-------|
| **Pack id** | `pack.mnn` |
| **Tier** | promote-later |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Alibaba MNN lightweight EP.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

MNN prebuilt Windows.

## Staging path

`desktop-data/runtime-packs/engine.mnn/`

## Unlocks (no model weights)

mnn-inference

## Verification smoke

Per pipeline.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

**Promote rule:** Do not vendor until a row exists in `CURATED_PIPELINES_INDEX.md` or model-hub plan names this EP.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
