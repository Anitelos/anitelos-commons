# Skia / graphics pipeline “inference” implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: capture **non-neural** or **hybrid** paths where “inference-like” work belongs in the **graphics pipeline** (Skia, shaders, AGSL, Vulkan compute, LUTs) rather than tensor runtimes. Faster for filters, stylization, simple transforms, and some real-time preview effects.

---

## Scope

This file covers:

- Skia shader pipelines, color transforms, blur/sharpen stacks,
- AGSL / RuntimeShader usage where applicable,
- Vulkan compute for pixel kernels when justified,
- contracts for “effect graphs” that mirror Swarm stages but execute on GPU/CPU raster paths.

This file does **not** replace ONNX/MediaPipe for semantic understanding; it complements them for pixel-domain speed.

---

## Role model (single truth)

| Graphics pipeline lane | Ownership |
|------------------------|-----------|
| Creations preview / fast LUT | Strong fit. |
| Semantic segmentation | Usually neural; keep in NN lanes unless pure CV. |
| Sentience “touch” or UI mirroring | Possible for lightweight visual analysis via shaders only when defined. |

---

## Android implementation plan (stub checklist)

- [ ] Define when an effect must be graphics-pipeline vs NN (decision tree).
- [ ] Artifact format for LUT/preset bundles (`zip`, json graph, shader sources).
- [ ] Adapter id `skia_graphics` or `graphics_effect` separate from `onnx`.
- [ ] Thermal/GPU budget hooks consistent with runtime scheduler.

---

## Open decisions

- AGSL minimum API level vs Skia-only path,
- packaging trusted shaders vs user-supplied shader policy.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)
- Creations / imaging pipeline docs under `implementations/generation/imaging/`.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub for Skia/graphics-pipeline fast path vs tensor runtimes. |
