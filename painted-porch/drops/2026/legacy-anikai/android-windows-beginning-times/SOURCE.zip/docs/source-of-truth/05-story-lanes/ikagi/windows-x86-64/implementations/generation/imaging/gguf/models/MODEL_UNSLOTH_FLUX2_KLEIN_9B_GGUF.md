# Model sheet — unsloth / FLUX.2-klein-9B-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress (flux2 pack in `gguf-completion.js`) |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [unsloth/FLUX.2-klein-9B-GGUF](https://huggingface.co/unsloth/FLUX.2-klein-9B-GGUF)  
- Upstream base: [black-forest-labs/FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B)  
- Alternate GGUF (reference): [leejet/FLUX.2-klein-9B-GGUF](https://huggingface.co/leejet/FLUX.2-klein-9B-GGUF)  
- Related full-stack (Diffusers): [`MODEL_BFL_FLUX2_KLEIN_9B.md`](./MODEL_BFL_FLUX2_KLEIN_9B.md)  

## What it is

**GGUF-quantized** [FLUX.2 klein 9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B) diffusion weights (Unsloth Dynamic 2.0; tooling lineage from ComfyUI-GGUF / city96). The card ships **single-file** `.gguf` quant variants (Q2_K through BF16), not a full Diffusers folder.

**Capabilities (upstream):**

- Text-to-image, **~4 step** distilled sampling (klein family).  
- **Image-to-image / edit** via reference image (`-r` in `sd-cli`; multi-reference in Comfy graphs).  
- Built on **9B flow model + 8B Qwen3 text embedder** (per BFL / sd.cpp docs).  

**License:** [FLUX Non-Commercial License](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B) (same family as official 9B; confirm before commercial use).

## Intended inference family (Windows desktop)

| Path | Fit |
|------|-----|
| **Native `sd.exe` (flux2 klein graph)** | **Primary target** — see `vendor/stable-diffusion.cpp/docs/flux2.md` § “Flux.2 klein 9B”. Uses `--diffusion-model`, `--vae`, `--llm` (Qwen3), **not** FLUX.1 `--clip_l` / `--t5xxl` split-pack. |
| **Diffusers `Flux2KleinPipeline`** | Alternative; use [`MODEL_BFL_FLUX2_KLEIN_9B.md`](./MODEL_BFL_FLUX2_KLEIN_9B.md) + sidecar plan. |
| **ComfyUI-GGUF** | Supported by quant ecosystem; out of scope unless we embed a graph runtime. |

**Important:** Anikai’s **existing** FLUX.1 split-pack helper (`buildFluxSplitPackSdArgs` in `gguf-completion.js`) is **not** the right wiring for this model. Klein 9B needs a **flux2 pack** probe and CLI builder (below).

## Weight layout (proposal for `ANIKAI_HOME/models/…`)

Place files in **one folder** per preset (name is user-defined; example `flux2-klein-9b-unsloth/`):

| Role | Source (HF) | Example filename |
|------|-------------|------------------|
| **Diffusion (GGUF)** | [unsloth/FLUX.2-klein-9B-GGUF](https://huggingface.co/unsloth/FLUX.2-klein-9B-GGUF) | `FLUX.2-klein-9B-Q4_K_S.gguf` (or chosen quant) |
| **VAE** | [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae) → `diffusion_pytorch_model.safetensors` (save as `vae/flux2_ae.safetensors`; same weights as BFL [FLUX.2-dev](https://huggingface.co/black-forest-labs/FLUX.2-dev) VAE, ungated) | `vae/flux2_ae.safetensors` |
| **LLM (Qwen3 8B)** | [unsloth/Qwen3-8B-GGUF](https://huggingface.co/unsloth/Qwen3-8B-GGUF) (per sd.cpp) | `text_encoders/qwen_3_8b-Q4_K_M.gguf` (or safetensors from [Comfy-Org split](https://huggingface.co/Comfy-Org/flux2-klein-9B/tree/main/split_files/text_encoders)) |

**VRAM (guidance):** official 9B card cites **~29 GB** for full precision; GGUF Q4 diffusion + Q4 LLM is aimed at **16–24 GB class** GPUs with `--offload-to-cpu` / `--diffusion-fa` as in upstream examples. Smoke on target hardware before enabling by default.

### Reference `sd-cli` invocation (upstream)

From `vendor/stable-diffusion.cpp/docs/flux2.md`:

```text
sd-cli.exe --diffusion-model <klein-9b.gguf> --vae <flux2_ae.safetensors> --llm <qwen3-8b.gguf> ^
  -p "a lovely cat" --cfg-scale 1.0 --steps 4 --sampling-method euler ^
  -v --offload-to-cpu --diffusion-fa
```

**Img2img / edit:** add `-r <input.png>` and an edit prompt (same doc, klein 9B edit example).

## Product notes

- **Preset id (proposal):** `flux2_klein_9b_gguf_unsloth`  
- **Display name:** FLUX.2 Klein 9B (GGUF — Unsloth)  
- **Default profile (proposal):** 1024×1024, **4 steps**, `cfg-scale 1.0`, `euler`, `seed -1` (align with klein distilled + sd.cpp examples).  
- **Sequencing vs BFL full stack:** GGUF path can ship **in parallel** with Diffusers baseline; they share branding but **different** runtime folders and readiness checks.  
- **Phase 2 encoder swap:** optional uncensored Qwen3 encoder at `https://huggingface.co/ponpoke/flux2-klein-9b-uncensored-text-encoder` (gated) applies to **both** Diffusers and (if we use Qwen3 GGUF) native `--llm` path — see [`MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md`](./MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md). (Plain URL avoids auto-indexing this repo into the desktop imaging `hf[]` list; the About guide Encoders column + tooltip document the swap.)  

## Anikai integration (companion + Media Magic)

**Surfaces:**

| Surface | Today | Target |
|---------|-------|--------|
| **Media Magic** | GGUF via `media:generate-image` → `runImageGenerationMain` | Preset picker row + flux2 readiness banner |
| **Companion chat** | `generate_image` / `delegate_media` (W5a) when media slot is GGUF | Same IPC; profile id in handoff metadata |
| **Workforce** | Media actor picks companion with media-ready slot | No change to orchestration; needs **preset + path** on companion |

**Code touchpoints (implementation checklist):**

1. **`main-process/gguf-completion.js`**  
   - [x] `buildFlux2KleinSdArgs` → `--diffusion-model`, `--vae`, `--llm`, `--offload-to-cpu`, `--diffusion-fa`; img2img via `-r`.  
   - [x] `probeFlux2KleinPackLayout` for readiness UI.  
   - [x] Route in `runImageGenerationMain` when filename matches FLUX.2 klein 9B (before FLUX.1 split-pack).  

2. **`shared/sd-gguf-image-profiles.js`**  
   - [x] Profile `flux2_klein_9b_gguf` — 1024², 4 steps, cfg 1, euler.  

3. **`shared/image-style-presets.js`** (optional)  
   - [ ] Style tags tuned for klein (short prompts; avoid SD1.5-style long negative blocks unless tested).  

4. **Manifest / Models panel** (when manifest exists for image presets)  
   - [ ] Row linking HF ids: diffusion repo + VAE repo + Qwen3 8B repo; download hints.  

5. **UI honesty**  
   - [ ] Readiness: “FLUX.2 Klein pack incomplete — need VAE + Qwen3 LLM beside GGUF (see docs).”  
   - [ ] License note in preset description (non-commercial).  

6. **Companion path**  
   - [ ] Ensure `executeGenerateImageTool` passes `imagePreset` or model folder that resolves to flux2 pack.  
   - [ ] Img2img: map chat attachment to `initImagePath` / `-r` when user attaches reference still.  

7. **Lane index**  
   - [ ] Tick E2E in [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md) only after persisted PNG from Media Magic **and** one companion `generate_image` smoke.  

## Quant selection (starting point)

| Quant | Size (card) | Notes |
|-------|-------------|--------|
| **Q4_K_S** | ~5.83 GB | Balanced first smoke for desktop |
| Q4_K_M | ~5.91 GB | Slightly higher quality |
| Q8_0 | ~9.98 GB | Quality-first machines |
| BF16 / F16 | ~18.2 GB | Research / max quality |

Download **one** diffusion quant + matching Qwen3 LLM quant; VAE stays fp16/fp32 safetensors.

## Risks / open questions

- **Engine version:** Requires `sd.exe` build with **flux2** support (see repo `docs/flux2.md`). Verify staged `sd.exe` in `dist:full` before claiming support.  
- **Graph validation:** Unsloth GGUF ≠ leejet GGUF; smoke **this** repo’s file names on our binary.  
- **Prompt adherence:** klein is strong but still sensitive to prompt style; document in user-facing how-to when shipped.  
- **Commercial use:** blocked by license unless user obtains BFL commercial terms separately.  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- GGUF imaging rules: [`../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  
- Diffusers baseline: [`../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  
- Workforce media tools: [`../../../../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md`](../../../../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md) §17 (W5a)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet: unsloth GGUF quant, flux2 sd.cpp pack layout, Anikai integration checklist for Media Magic + companion. |
| 2026-05-18 | Desktop: `buildFlux2KleinSdArgs`, `probeFlux2KleinPackLayout`, profile `flux2_klein_9b_gguf`. |
| 2026-05-19 | Phase-2 ponpoke URL in prose as plain `https://…` (not markdown HF link) so `build-imaging-registry.mjs` does not add it to catalogue `hf[]`; swap documented on klein Encoders column + tooltip. |
