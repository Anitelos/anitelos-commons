# Thought → reply segment pipeline (Desktop)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-16 |

**Purpose:** Replace the `turn_mode: conversation|task` split with one **unified turn shape**, **structured tags** for orchestration, and a **segment loop** streamed in the UI. Per-companion **text inference** (temperature rails, token caps, thought budget) applies to whichever GGUF is in the Chat slot — not per model file.

**Related:** [`group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) · [`LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) (delivery order: this plan → E+ → voice) · [`execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md) (sandbox + agentic controller — **after** B1–B3 stable) · Android temperature UX: `Anikai App/.../AiTemperatureResolver.kt`, `UserAccessInferenceTab.kt`

**Code (today):** `anikai-desktop/shared/gguf-output-templates/`, `shared/thought-segment-tags.js` (incl. `<complexity/>`), `shared/vision-micro-caption.js`, `main-process/companion-skills.js`, `components/chat.js` (`runGgufThoughtTurn`), `shared/companion-text-inference.js`, `shared/group-role-policy.js`, `main-process/gguf-completion.js`, `main-process/gguf-metadata.js` (context probe for Persona caps + `-c`)

---

## 1. Product intent

- **One pipeline** for greetings, chat, questions, and operational asks (wallpaper, files, time).
- **Inner bubble:** all private planning (may ramble when needed).
- **Outer bubble:** only user-visible language (confide, clarifications, results).
- **No `turn_mode`** — the model does not classify “chat vs task” for the app; it plans and optionally emits **machine tags** in thought.
- **Anti-fabrication:** do not invent prior turns or group events not present in supplied transcript blocks. Real thread history is fine to use.
- **Model-led tool choice:** e.g. “what’s the time?” is short but may need a tool; “hi” may need no tool — no character-count or greeting regex in the app.
- **Uncertainty:** ambiguous paths (two Downloads folders) → list options, optional **one sentence per image** when vision/mmproj is available.

---

## 2. Layer A — Output shape (format vs behavior)

| Concern | Approach |
|---------|----------|
| **Behavior** | Single shared contract: thought channel → visible reply. Same for all companions. |
| **Format** | Template registry by model ref (e.g. `/gemma/i` → `<\|channel\|>thought` / `final`; else `<thought>` + `[End thinking]`). |
| **Tags** | Structured tags **inside thought only** (see §4). User never sees raw tags in the main bubble. |
| **Second infer pass** | **Recovery only** (no reply, leak, truncate) — not because of conversation mode. |

**Remove from prompts:** `turn_mode: conversation|task`, “STOP after [End thinking] for conversation”, “no automation yet” tied to mode.

---

## 3. Layer B — Segment orchestrator (stream segment-by-segment)

Per user message, run up to `maxSegments` (default 4–6):

```
Segment n:
  infer → parse thought + reply + tags
  stream thought panel + main bubble for this segment
  if <clarify> or user must answer → stop (wait next user message)
  if <tool …/> and skill available → run tool → append result → continue
  if <done/> or terminal reply → stop
```

**UI:** Stream **segment-by-segment** — user can see “let me check…” (reply segment 1) before tools run, then thought segment 2, then final reply. Thought panel may stack segments (accordion later).

**Wallpaper example:**

1. Thought: plan, `<tool name="list_dir" …/>` → Reply: “Checking your Downloads…”
2. Tool results: two folders, latest files
3. Thought: `<uncertain/>`, optional vision one-liners → Reply: “Found X and Y — which one?”
4. User picks (next turn) or auto policy → Thought: `<tool set_wallpaper/>` → Reply: “Applied …”

**Vision:** When mmproj is loaded and tool returns image paths, optional micro-caption pass (1–2 sentences per file, not essays).

---

## 4. Structured tags (thought channel only)

Draft vocabulary — tolerant parsing, unknown tags ignored.

| Tag | Role |
|-----|------|
| `<tool name="…" …/>` | Request skill execution |
| `<clarify>…</clarify>` | Block loop until user answers |
| `<uncertain reason="…"/>` | Log ambiguity; reply should disambiguate |
| `<done/>` | End segment loop for this user message |
| `<complexity temp_bias="…" thought_pct="…" reply_pct="…" task="…"/>` | Optional self-rating; merged with heuristics in `CompanionTextInference.resolveTurnDemand` (partial **C1**) |

**Skills registry:** Align with `buildCompanionCapabilityMap` / future IPC skills. If skill missing, inject `{ error: "skill_not_available" }` into next segment context so the model can say so honestly.

**Reply channel:** Plain language + optional confide line (template `UNCERTAINTY_CONFIDE`); no tags.

---

## 5. Layer C — Capability-aware execution (not pre-classification)

The app **does not** decide greeting vs task before inference.

| App responsibility | Model responsibility |
|--------------------|----------------------|
| Inject capability/skill map | Decide if a tool is needed |
| Execute parsed `<tool/>` when implemented | Emit tags + natural reply |
| Enforce max segments / timeouts | Plan, clarify, confess limits |
| Anti-fabrication in contract + leak strips | Use only provided transcript |

---

## 6. Layer D — Context hygiene

- **Allow** long planning in thought when useful.
- **Forbid** inventing events not in `Recent conversation`, cycle transcript, plan focus, or journal blocks.
- **Do not** strip real thread depth on turn 1 unless leak tests show a specific failure mode.
- Prompt line (shared): *Only treat provided transcript blocks as facts; do not invent earlier turns or shared memories.*

---

## 7. Per-companion text inference (not per model)

**Storage:** `companion.inferencePolicy` on disk (`configs/companions/<id>.json`), merged via `CompanionTextInference.mergeInferencePolicy` / `GroupRolePolicy.mergeCompanionGroupFields`.

**Applies to:** Chat & reasoning GGUF for that companion. Model runtime JSON (`model-runtime.v1`) keeps **GPU layers, CUDA, HF task types** — not persona temperature.

| Field | Meaning |
|-------|---------|
| `temperatureMode` | `auto` \| `manual` |
| `temperatureManual` | Fixed temp when manual (0.01–1.5) |
| `temperatureLow` / `temperatureHigh` | Rails when auto (Android parity) |
| `predictTokensPlan` | Cap for thought-heavy segments |
| `predictTokensReply` | Cap for user-visible segments |
| `thoughtBudgetPct` | % of plan cap allocated to thought in mixed segments (10–90) |
| `preferSessionRollover` | Session reuse (group / note-taker) |

**Role defaults** (overridable per companion): e.g. note-taker → colder rails; creative teammate → higher rails.

### 7.1 Auto temperature (v1 → v2)

**v1 (desktop now):** Midpoint of low/high rails; slight bias lower for thought segments, per `CompanionTextInference.resolveTemperature`.

**v2 (future):** Model- or reflex-driven pick **between** user low/high (Android `AiTemperatureResolver` + bond/reflex signals). Optional tag in thought, e.g. `<temp bias="creative"/>`, clamped to companion rails. Document only until reflex pipeline exists on desktop.

**Not in scope:** Per-message character rules or greeting detection.

---

## 8. Implementation phases

| Phase | Deliverable |
|-------|-------------|
| **A0** (done) | Design doc; `companion-text-inference.js`; Persona UI (context limit, adaptive temp/thought/reply, up to 131k); `--temp` on llama-cli; GGUF context probe + sync; chat uses `inferencePolicy` caps; footer meta |
| **A1** (done) | `behavior-contract.js`; unified one-pass prompts; `turn_mode` removed; recovery pass only when parse fails |
| **B1** (done) | Tag parser + segment loop in `runGgufThoughtTurn`; stream per segment (`thought-segment-tags.js`) |
| **B2** (done) | Skill executor + tool result injection (`companion-skills.js`, `companions:execute-skills`) |
| **B3** (done) | Vision micro-caption for disambiguation (`vision-micro-caption.js`, after tool batch when mmproj set) |
| **C1** (partial) | `<complexity/>` tag + heuristic merge shipped; full reflex/Android parity still open |

**After B1–B3 (required before live voice / E+ is not a substitute):** See [`LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) — **Phase E+ `llama-server`** next, then semi-duplex voice, then full-duplex later.

### B3 — Vision micro-captions (implemented)

When a segment’s tool results include **image file paths** (e.g. `list_dir` under Pictures/Downloads) and the companion has an **mmproj** slot:

1. Orchestrator runs up to **4** caption passes (`predictTokens` ~160 each, no stream).
2. Captions are injected into the **continuation** block as `Vision micro-captions:` bullet lines (filename + 1–2 sentences).
3. Next segment uses them to disambiguate (wallpaper pick, “which screenshot?”) without a user-visible caption essay.

If mmproj is missing, tool JSON still flows — no captions; model must not invent visuals.

---

## 9. Worked example — compound ask (B2 acceptance)

**User:** “What is the time, and do we have any plans coming up today?”

| Step | What happens |
|------|----------------|
| **Segment 1** | Model reads toolkit `skills` (`get_local_time`, `get_group_plan`). Thought may include `<tool name="get_local_time"/><tool name="get_group_plan" filter="today"/>`. Reply: short interim (“Checking the time and today’s plan…”). |
| **Orchestrator** | Runs **both** tools in one batch; injects JSON results into continuation prompt. |
| **Segment 2** | Model synthesizes: local time from `get_local_time.result.locale`; plan lines from `get_group_plan` (or states plan empty / no today lines). `<done/>` → stop. |
| **UI** | One user bubble; thought panel may show two planning blocks; main bubble updates from interim → final. |

**Solo chat (no group):** `get_group_plan` returns `group_required`; model answers time and says plan is only available in group threads (or uses plan focus if already in prompt — must not invent events).

**Aliases:** `time`, `list_plans_today`, etc. normalize to canonical skill ids in `companion-skills.js`.

---

## 10. Workforce & orchestration (design doc)

Full vision: **[`WORKFORCE_AND_ORCHESTRATION_VISION.md`](WORKFORCE_AND_ORCHESTRATION_VISION.md)** — link role tables via [`ROLES_INDEX.md`](ROLES_INDEX.md) / [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md); familiars via [`Familiars/FAMILIAR_ROLES.md`](Familiars/FAMILIAR_ROLES.md).

**Media orchestration (W5a):** **[§17 Media generation handoff](WORKFORCE_AND_ORCHESTRATION_VISION.md#17-media-generation-handoff-w5a)** — new thought tools `generate_image`, `delegate_media`, `media_review`; uses **`modelSlots.media`** (not chat slot); first-person delegation; group picks highest-reason media-capable speaker. Implementation slices **W5a.0–W5a.6**; star-button image mode is legacy shortcut until W5a.2.

Does not block **Phase E+** or voice roadmap; extends Layer C after `llama-server` residency.

---

## 11. Success checks

- “Hi” → short or warm reply; **no invented backstory** on empty thread.
- “What’s the time?” → model seeks time tool or states unavailable — **not** treated as greeting by app rules.
- Wallpaper with two Downloads → clarifies with real paths/names; optional vision one-liners.
- Creative companion at high rails vs scholar at low rails on **same** GGUF file when swapped between companions.
- Gemma and non-Gemma share behavior; only delimiters differ.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-16 | B1–B3 marked done; live voice ordering cross-link. |
| 2026-05-17 | A0 expanded (context probe, 131k caps, complexity tag); C1 partial; code paths updated. |
| 2026-05-18 | Cross-link workforce §17 (W5a media handoff tools + group routing). |
