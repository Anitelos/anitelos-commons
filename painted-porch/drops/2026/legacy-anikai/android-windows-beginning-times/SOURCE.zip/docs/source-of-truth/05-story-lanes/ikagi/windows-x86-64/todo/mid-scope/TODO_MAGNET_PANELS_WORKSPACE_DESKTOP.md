# TODO — Magnet panels workspace (mid scope, Windows desktop)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Tree M0 **shipped**; drag-magnet M0 **shipped** |
| **Last reviewed** | 2026-05-20 |

**Plan:** [`../../implementations/companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_IMPLEMENTATION_PLAN.md`](../../implementations/companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_IMPLEMENTATION_PLAN.md)

**Overview:** [`../../implementations/companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](../../implementations/companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md)

**Index:** [`../../implementations/WINDOWS_DESKTOP_INDEX.md`](../../implementations/WINDOWS_DESKTOP_INDEX.md)

---

## Outcome

Power users can **magnet** floating panels to chat (then to each other), **move the cluster** by dragging the highlighted anchor, and **detach** by dragging a satellite — without breaking chat clicks or re-introducing global panel snap on chat move.

---

## Project tree M0 (shipped — separate from magnetize-by-drag)

- [x] Chat left rail + workspace satellite HWND + dock inset
- [x] `projects/registry.json` + `+ Proj` picker
- [x] Tree list / expand / select + `+ File` / `+ Folder`
- [x] Per-thread `thread-workspace/*.json` (`activeProjectId`, `treeUi`, `panelUi.treeOpen`)
- [x] Thread switch restores project + tree open state

**Doc:** [`PROJECT_WORKSPACE_TREE.md`](../../implementations/companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md)

---

## M0 — Panel → chat (magnetize Settings/Models by drag)

- [x] `main-process/window-magnet-registry.js` — link table (`satelliteId` → anchor + offset)
- [x] `syncMagnetFollowers('main')` on chat move/resize (not on unrelated panel drag)
- [x] Magnetize on panel drag-end overlapping chat edge zone
- [x] Detach when user moves satellite window (&gt; move threshold)
- [x] Smoke: `anikai-desktop/scripts/smoke-magnet-panels.cjs` (registry); manual UI: Settings + Models magneted to chat

## M1 — Polish

- [ ] Shared placement math with `syncDockPosition` (`placeSatelliteBesideAnchor`)
- [ ] Anchor highlight border (IPC + `anikai-magnet-anchor` CSS)
- [ ] Header control or menu: Magnet to chat / Unmagnet
- [x] Preload: `magnet:get-links`, `magnet:link`, `magnet:unlink`

## M2 — Panel → panel

- [ ] Link panel anchor → satellite panel
- [ ] Transitive follow when root chat moves
- [ ] Cycle prevention on link create

## M3 — Power-user extensions

- [ ] _Spec TBD_ — fill from product when “power user bit” is written
- [ ] Optional: persist workspace preset to `desktop-data/magnet-layout.json`

## Regression guards

- [ ] Free-floating panels do **not** follow chat unless linked
- [ ] No `parent: mainWindow` on panel `BrowserWindow`
- [ ] Chat click/focus still raises chat above inactive satellites
- [ ] Tray hide/show still shows chat + dock + optional panels

---

## Done when

- [ ] M0 smoke test recorded in plan changelog or ops note
- [ ] README link under `companion-surface/desktop-overlay-and-panels/` in implementations index
