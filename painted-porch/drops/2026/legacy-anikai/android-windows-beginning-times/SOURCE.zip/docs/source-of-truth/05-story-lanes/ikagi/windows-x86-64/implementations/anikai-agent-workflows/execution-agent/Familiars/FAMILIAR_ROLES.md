# Familiar roles (Assign chips)

| Field | Value |
|-------|-------|
| **Scope** | Desktop workshop — Familiars panel → **Assign** tab |
| **Code** | `panels.js` (`FAMILIAR_ROLE_DEFS`), `familiar-classifier.js`, `familiar-guard.js` |
| **Parent** | [`FAMILIARS_REFLEX_SYSTEM.md`](FAMILIARS_REFLEX_SYSTEM.md) |

---

## What a role is

A **role** is a reflex job you enable on the **active** familiar (panel selection). Roles are **multi-select** chips. Each role defines *when* the familiar runs and *what stack* it uses — not a separate product or GGUF slot per role (except classifier/router/reporter jobs that use the familiar’s single GGUF).

**Gating (all reflex roles):**

1. Familiar is **selected** in the Team column.
2. Role chip is **on** in Assign.
3. Active companion (solo speaker or @mention target) is **not** on the familiar’s blocklist.

Reflex order on user send: **Guard (F5)** → **Scripts (F6)** → **Classifier (F4)** → companion GGUF turn.

---

## Role catalog

| Role id | UI label | Shipped | Model / stack | When it runs |
|---------|----------|---------|---------------|--------------|
| `guard` | Guard | **F5** | [Prompt Guard 2](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M) under `ANIKAI_HOME/models/prompt-guard-2-86m/` (Transformers via `scripts/prompt-guard-classify.py`), else **heuristic** in `familiar-guard.js` | Every user message (pre-pass). **Blocks** malicious prompts. |
| `classifier` | Classifier | **F4** | Familiar’s **one GGUF** (e.g. SmolLM2-Rethink-360M) via `llama-completion` | Every user message (pre-pass). Emits `<complexity/>` caps for the companion turn. |
| `router` | Router | Planned | Familiar GGUF | Turn routing / tag hints (same slot as classifier candidate). |
| `reporter` | Reporter | Planned | Familiar GGUF | Short status blurbs for UI or thought preamble. |
| `instructor` | Instructor | Planned | Familiar GGUF | One-step fix / how-to hints. |
| `time` | Time | **F6** | `get_local_time` skill | When user asks about time/date (heuristic). |
| `folder_scout` | Folder scout | **F6** | `list_dir` skill | When user asks to list/browse folders (heuristic). |
| `quick_edit` | Quick edit | **F6** | Bounded SEARCH/REPLACE | `<<<<<<< SEARCH` / `=======` / `>>>>>>> REPLACE` blocks or `file:` + `search:` + `replace:` lines. |

**Note:** `guard` does **not** use the familiar’s GGUF drop slot; it uses the shared Prompt Guard model directory (or heuristics).

---

## Metrics & journal

| Tool | Journal `toolName` | Metrics fields |
|------|-------------------|----------------|
| Guard | `guard` | `guardScans`, `guardHits` |
| Classifier | `classifier` | `byToolName.classifier`, complexity in `detail` |

Paths: `configs/familiars/<familiarId>/journal.jsonl`, `metrics.json`.

---

## Prompt Guard setup (guard role)

1. Accept license on Hugging Face for [Llama-Prompt-Guard-2-86M](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M).
2. Download model files into `ANIKAI_HOME/models/prompt-guard-2-86m/` (must include `config.json`).
3. Optional: `pip install transformers torch` for the Python sidecar.
4. Override path: env `ANIKAI_PROMPT_GUARD_MODEL` or `user-settings.json` → `familiars.promptGuardModelDir`.

Without the model, **heuristic** patterns still run (jailbreak / ignore-instructions phrases).

---

## Related

| Doc | Topic |
|-----|--------|
| [`../Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](../Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) | Companion **craft** vs group **session role** (includes **manager**) |
| [`../WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) | Full workforce vision |
