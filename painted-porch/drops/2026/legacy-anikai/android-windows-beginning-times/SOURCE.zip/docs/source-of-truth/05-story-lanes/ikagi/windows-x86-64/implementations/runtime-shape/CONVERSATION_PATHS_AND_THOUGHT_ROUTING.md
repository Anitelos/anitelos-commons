# Conversation paths & thought / reply routing (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Slice A shipped (desktop UI) |
| **Operations** | Slice B + C scoped |
| **Last reviewed** | 2026-05-20 |

**Purpose:** Define a single in-app **prompt pathing** surface that shows, teaches, and (eventually) lets advanced users tune **what happens between a user message and a companion reply** for any chat model **family**, with optional **per-model overrides** when a variant genuinely diverges (e.g. an uncensored Gemma 4 derivative whose channel-over-thought handling drifts from the family default).

**Primary home (locked):** **About → Sentience → Chat (reasoning / brain)** — same sub-tab rhythm as **Generating media → Imaging** (Quick start, How it works, Parts, Engine families, Model catalogue). Family-first in the families table; variety second in the catalogue. The pathing **window** (graph + scenario side-tabs + code pane) is one destination opened from those tables and from secondary entry points below — not a separate stack of pop-out windows.

This doc is the contract before any UI lands. The *code today* already half-builds it (see §10) — Conversation paths is the surface that exposes what is implicit in code.

---

## 1. Why this exists

Three converging needs:

1. **Teaching surface.** New / curious users want to see *how* a turn becomes a reply — what is "thought", what is a "tag", when does a tool fire, why does Gemma 4 need a different channel structure than other families. Today this lives in code (`shared/gguf-output-templates/`, `shared/thought-segment-tags.js`, `components/chat.js`'s `runGgufThoughtTurn`) and in implementation docs, both invisible to a normal user.
2. **Family-level tuning.** Different model families need different output shape (Gemma 4 channels, OpenAI-style `<thought>` + `[End thinking]`, future templates). A user who chooses an *uncensored* derivative of a known family sometimes needs to tweak one or two parameters rather than fork the engine.
3. **Honesty by visibility.** Anikai's identity is "show what the local AI is doing, do not hide composition". Conversation paths is the missing companion piece to Imaging's *Engine families* surface — same instinct, different lane (**Sentience**, not Generating media).

The runtime guarantee (today and after this work): **the user is never required to open prompt pathing** to use a companion. It is for the *"I finally get it"* users plus the small group who need an override.

---

## 2. Primary home — Sentience → Chat (Imaging-shaped)

The **Chat (reasoning / brain)** pane under **About → Sentience** gains the same horizontal sub-nav pattern as **Generating media → Imaging**:

| Sub-tab | Role |
|---------|------|
| **Quick start** | What you need, file placement, mmproj pairing, Check runtimes — *already drafted*; add a "Where to next" link into pathing. |
| **How it actually works** | Thought → tags → reply; channel model; why families differ. |
| **Parts & templates** | Channel tokens, behaviour contract, tag vocabulary (Imaging analogue: *Parts & encoders*). |
| **Engine families** | Master table of chat layout families (Gemma 4 channels, base template, …). **Conversation path** column → button opens the pathing window for that **family**. |
| **Model catalogue** | Concrete `.gguf` variants per family. Shows **inherits family** vs **custom prompt path** badge; click opens pathing window with **Model override** pre-selected when applicable. |

**Family-first, variety-second (locked):**

- One **family default** graph + config covers most quant / vendor builds via `modelRefMatchers`.
- A **per-model override** file exists only for genuine outliers (uncensored fork, channel drift) — not one JSON per download.
- The **families** table owns the path button for the family layer; the **catalogue** surfaces which variants have escalated to a model override.

This is where new users learn chat/brain; the global **About → Engines & families** tree remains a cross-lane index, not the home for chat pathing.

---

## 2.1 Entry points — one pathing window, many doors

All entries open **the same in-app pathing window** (§3). No extra windows spawned from inside it.

| Priority | Entry | Location | Behaviour |
|----------|-------|----------|-----------|
| **Primary** | **A — Chat → Engine families** | About → Sentience → Chat → **Engine families** → **Conversation path** column | Opens pathing window; **family** pre-selected; scenario defaults to *Turn routing*. |
| **Primary** | **B — Chat → Model catalogue** | About → Sentience → Chat → **Model catalogue** | Row with custom override → opens pathing with **Model override** pre-selected; inherits-only rows → family default. |
| **Primary** | **C — Chat Quick start** | Sentience → Chat → Quick start → *"Conversation paths"* (Where to next) | Deep-link to pathing window; family = built-in default (or first shipped family). |
| **Secondary** | **D — Global Engines & families** | About → **Engines & families** → **Conversation path** column (chat / GGUF text rows only) | Same window; for users who live in the master tree. |
| **Secondary** | **E — Optional top-level About tab** | About → **Conversation paths** *(optional; may ship as redirect to Sentience → Chat → Engine families in Slice A)* | Convenience bookmark only — **not** the canonical teaching home. |
| **Live** | **F — Companion chat ⋮** | Chat panel header → ⋮ → **View current prompt path** | **Family** of equipped chat model + **scenario** from live state (*Vision attachment* if image just attached; *Group round-robin* in group thread; else *Turn routing*). Shows **effective** config (built-in ⊕ family-custom ⊕ model-override). |

Entry **F** is the only one that pre-selects scenario from live chat state.

---

## 3. Window layout

```
┌──────────────────────────────────────────────────────────────────┐
│  Conversation paths  (read-only — Slice A)                      │
├──────────────────────────────────────────────────────────────────┤
│  Family ▾ [Gemma 4 channels]    Model override ▾ [None]          │
│  ┌────────┬──────────────────────────────────────────────────┐   │
│  │ Simple │  Turn routing                                    │   │
│  │ Turn → │  ┌────────────────────────────────────────────┐  │   │
│  │ Vision │  │       (graph rendered from structured       │  │   │
│  │ Group  │  │        description — nodes + edges)         │  │   │
│  │ Tool   │  └────────────────────────────────────────────┘  │   │
│  │ Voice* │                                                  │   │
│  │ Copil* │  Source preview (read-only in Slice A):          │   │
│  └────────┘  ┌────────────────────────────────────────────┐  │   │
│              │ // shared/gguf-output-templates/gemma4-… js │   │
│              │ ...                                          │   │
│              └────────────────────────────────────────────┘  │   │
│              [ Restore default ] [ Save copy ] [ Import ]    │   │
│              [ Export ] [ Delete custom ] [ Dry-run ]         │   │
└──────────────────────────────────────────────────────────────────┘
```

`* = reserved slot, ships when that lane ships.`

**Side-tab order** (locked for v1 so deep-links are stable):

1. Simple greeting
2. Turn routing
3. Vision attachment
4. Group round-robin
5. Tool-use loop
6. Voice (reserved)
7. Copilot perceive-plan-act (reserved)

**Graph rendering rule (locked for v1):** the graph is **derived** from a structured description object that the runtime also reads. The graph and the runtime cannot drift. No hand-authored mermaid that is allowed to lie about behaviour.

**Action buttons by slice:**

| Button | Slice A | Slice B | Slice C |
|--------|---------|---------|---------|
| Family selector | ✓ | ✓ | ✓ |
| Side-tab navigation | ✓ | ✓ | ✓ |
| Graph render | ✓ | ✓ | ✓ |
| Code preview | ✓ (read-only) | ✓ (read-only) | ✓ (read-only) |
| **Save copy** | — | ✓ (allow-listed fields) | ✓ |
| **Restore default** | — | ✓ | ✓ |
| **Model override toggle** | — | — | ✓ |
| **Import / Export** | — | — | ✓ |
| **Delete custom** | — | — | ✓ |
| **Dry-run** (build prompt without inference) | — | — | ✓ |

---

## 4. Scenarios (v1 side-tabs)

Each side-tab teaches one **named flow** with a **plain-language description**, the **graph**, and the **source pointer** in code.

### 4.1 Simple greeting

The "what does a chat turn look like at minimum" page — one segment in, one segment out, no tools, no attachment. Anchors a beginner before they look at the full router.

Source pointer: `shared/gguf-output-templates/base-template.js` + `behavior-contract.js`.

### 4.2 Turn routing

The **segment orchestrator** — thought channel → structured tags → optional tool call → next segment → final reply. This is the page the *"I finally get it"* moment usually lands on.

Mirrors [`../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) §3. Source pointer: `runGgufThoughtTurn` in `components/chat.js` + `shared/thought-segment-tags.js`.

### 4.3 Vision attachment

The flow already drawn in [`../companion-surface/COMPANION_MEDIA_LIBRARY.md`](../companion-surface/COMPANION_MEDIA_LIBRARY.md) §3:

```mermaid
flowchart TD
  Send[User sends message] --> Att{Attachment this turn?}
  Att -->|yes| InLib{In companion media index?}
  InLib -->|no or force rescan| Vision[mtmd: encode image + plan/reply]
  InLib -->|yes, fresh caption| Inject[Inject caption block into prompt]
  Att -->|no| Ref{Text references prior media?}
  Ref -->|yes| Inject
  Ref -->|no| Text[Text-only GGUF]
  Vision --> Save[Upsert index.json + copy file]
  Save --> Inject
  Inject --> Gen[Generate reply]
```

Source pointer: `shared/vision-micro-caption.js`, `main-process/gguf-completion.js` (mmproj path), companion media index code.

### 4.4 Group round-robin

Multi-companion routing — Manager pick, Lead-last, capability-aware turn assignment. Role definitions: [`../anikai-agent-workflows/execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](../anikai-agent-workflows/execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md).

Source pointer: `shared/group-role-policy.js`. Cross-link: [`../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md).

### 4.5 Tool-use loop

The B2 planner → executor expansion (parsed `<tool/>` tag → skill executor → JSON result injected as continuation). Cross-link: [`../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md`](../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md) §17 (media handoff is a special case).

Source pointer: `main-process/companion-skills.js`, segment orchestrator's tool branch.

### 4.6 Voice (reserved)

ASR → segment loop with barge-in → streaming TTS. Reserved slot — content lands when voice ships. Cross-link: [`../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md).

### 4.7 Copilot perceive-plan-act (reserved)

Desktop screen agent loop — vision + planner + validated executor. Reserved slot. Cross-link: [`../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md).

---

## 5. Schema — three-layer overlay

Anchors family-first with model overrides, identical to how Imaging sidecars overlay works.

| Layer | Path | Writable | Notes |
|-------|------|----------|-------|
| **Built-in family default** | `anikai-desktop/shared/gguf-output-templates/<family>.js` (today) → progressively extracted to JSON beside it | No (ships with app) | Source of truth at install. |
| **Family custom** | `ANIKAI_HOME/configs/prompt-paths/<family>.json` | Yes (Slice B onward) | Overlay over the built-in. |
| **Model-specific override** | `ANIKAI_HOME/configs/prompt-paths/models/<sanitisedModelRef>.json` | Yes (Slice C onward) | Last-wins. For the *"uncensored Gemma 4 needs a different channel"* case. |

### 5.1 Per-family config sketch

```json
{
  "schemaVersion": 1,
  "family": "gemma4",
  "label": "Gemma 4 channels",
  "applies": {
    "modelRefMatchers": ["/gemma[ -_]?4/i", "/e4b/i"]
  },
  "outputChannels": {
    "thoughtOpen":  "<|channel|>thought",
    "thoughtClose": "<|/channel|>",
    "finalOpen":    "<|channel|>final",
    "finalClose":   "<|/channel|>"
  },
  "behaviorContract": {
    "antiFabricationLine": "Only treat provided transcript blocks as facts; do not invent earlier turns or shared memories.",
    "uncertaintyConfide": "If unsure, name the ambiguity instead of guessing."
  },
  "segmentLoop": {
    "maxSegments": 6,
    "maxToolsPerTurn": 3,
    "stopOnDoneTag": true,
    "stopOnClarifyTag": true
  },
  "vision": {
    "microCaptionPasses": 4,
    "microCaptionPredictTokens": 160
  },
  "tags": {
    "allow": ["tool", "clarify", "uncertain", "done", "complexity"],
    "complexityHints": true
  },
  "graphs": {
    "simple-greeting":     [ /* nodes + edges */ ],
    "turn-routing":        [ /* nodes + edges */ ],
    "vision-attachment":   [ /* nodes + edges */ ],
    "group-round-robin":   [ /* nodes + edges */ ],
    "tool-use-loop":       [ /* nodes + edges */ ]
  }
}
```

**Slice-B tunable allow-list** (fields users can edit without restrictions): `outputChannels.*`, `behaviorContract.*`, `segmentLoop.maxSegments`, `segmentLoop.maxToolsPerTurn`, `vision.microCaptionPasses`, `tags.allow`.

**Outside the allow-list** (Slice C only, behind "Advanced" toggle + dry-run + Restore-default warning): `graphs.*` (full re-author of a scenario path).

### 5.2 Per-model override sketch

```json
{
  "schemaVersion": 1,
  "modelRef": "Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q4_K_M.gguf",
  "extends": "gemma4",
  "outputChannels": {
    "thoughtOpen": "<|channel|>thought",
    "finalOpen":   "<|channel|>final"
  },
  "behaviorContract": {
    "antiFabricationLine": "<override line if needed>"
  }
}
```

Only the fields that differ from the base family need to be present — everything else inherits.

### 5.3 Resolution order at runtime

1. Read **built-in family default** for the selected family.
2. If a **family-custom** JSON exists for that family → deep-merge overlay.
3. If a **model-specific override** exists for the *exact* `modelRef` → deep-merge overlay (last wins).
4. **Validate.** On schema violation: drop the offending override layer, log a UI banner *"custom config invalid — using defaults"*, and surface the validation errors inside the Conversation paths window so the user can fix and re-save.

Validation must run **before** the engine builds a prompt for that turn. A broken override never bricks chat.

---

## 6. Slice plan

### Slice A — Read-only teaching surface · **SHIPPED (desktop UI, 2026-05-20)**

**About guide — Sentience → Chat (primary):**

- Imaging-shaped sub-nav on **Sentience → Chat (reasoning / brain)**: Quick start · **How it actually works** · **Parts & templates** · **Engine families** · **Model catalogue**.
- **Engine families** table: rows from built-in template registry + **View path** → modal.
- **Model catalogue** table: example `.gguf` rows + **inherits family** badge + **View path** (Slice C will flip badge when `configs/prompt-paths/models/` exists).
- Quick start **Where to next** → first bullet points at Chat → Engine families / Conversation paths.

**Pathing modal (§3):**

- In-app modal: scenario side-tabs, step list (structured flow), read-only code excerpt, family selector. **No save / import** (Slice B/C).
- **Secondary:** **Engines & families** GGUF bullet — inline **Gemma 4 template** / **Base template** buttons.
- **Live:** Companion chat ⋮ → **View current prompt path** (family from `GgufOutputTemplates.resolveTemplateId`, scenario from group / attachment heuristics).

Acceptance: from **Sentience → Chat → Engine families**, user opens **View path** → *Turn routing* (or other tab) → sees flow + code pointer.

### Slice B — Curated edit · **PLANNED**

- Build the schema (§5) and the family-custom storage path under `ANIKAI_HOME/configs/prompt-paths/`.
- Allow-list of tunable fields per family (§5.1).
- **Save** button creates a copy at `configs/prompt-paths/<family>.json`.
- **Restore default** toggles between built-in and user copy (does not destroy the copy).
- Versioning: every config carries `schemaVersion`. When defaults bump major version, the window shows a *"your custom is from v1, here is what v2 changed"* banner with a one-click "merge defaults" assistant.
- Runtime: template registry merges built-in + user override at load time.
- Validation on save (warn if a required node is missing, refuse to save if the file would brick chat).

Acceptance: a user can change `segmentLoop.maxSegments`, save, restart a turn, and observe the new cap take effect.

### Slice C — Full power · **ENDGAME**

- Per-model override files under `configs/prompt-paths/models/<sanitisedModelRef>.json`.
- Import / Export JSON (single file per family or per model).
- Delete custom (revert to built-in or to parent family).
- **Dry-run**: simulate one turn with the current config, render the resulting prompt text in a modal, no inference fired. Lets users verify a change before letting the engine see it.
- "Advanced" gating on `graphs.*` edits with a clear *"you are now editing how your companion thinks"* banner.

Acceptance: a user can solve the *uncensored Gemma 4 channel-over-thought* case (or similar) without forking the app — import a known-good override, dry-run, save, ship.

---

## 7. Risks & mitigations

| Risk | Mitigation |
|------|------------|
| **Schema drift over Anikai versions** breaks user customs silently. | Every JSON carries `schemaVersion`; migration banner on mismatch; built-in defaults always restorable. |
| **Edit-anything is a footgun.** Bad config → companion cannot reply. | Slice B allow-list bounds the surface. Validation on save. Restore default always available. Slice C adds dry-run before save. |
| **Discoverability vs noise.** This is hardcore-user territory. | Primary discoverability: **Sentience → Chat** tables + ⋮ menu. Never required for normal chat. No nudge in the main chat input. Optional top-level About tab stays secondary. |
| **Graph drifts from code.** Hand-authored mermaid lies about behaviour. | Graphs are **derived from structured description objects that the runtime also reads** (§3 locked rule). No hand-authored mermaid. |
| **Per-model overrides explode** if every quant gets its own file. | Per-model is reserved for genuine outliers; the model-ref matcher in the family config handles 95 % of cases. Slice C UI nudges *"use the family override first"*. |

---

## 8. Naming decisions (locked)

| Surface | Name |
|---------|------|
| **Pathing window title** | Conversation paths |
| **Sentience → Chat sub-tabs** | Quick start · How it actually works · Parts & templates · Engine families · Model catalogue |
| **Chat → Engine families column** | Conversation path |
| **Chat → Model catalogue badge** | Custom prompt path *(when override exists)* · *inherits family* *(default)* |
| **Global Engines & families column** | Conversation path *(chat rows only)* |
| **Optional top-level About tab** | Conversation paths *(secondary; may redirect)* |
| **Chat ⋮ menu item** | View current prompt path |
| **Internal config folder** | `configs/prompt-paths/` |
| **Schema field for a scenario** | `graph` (one per scenario) |

Alternative names considered: *Brain paths*, *Prompt pathing*, *Reply paths*, *Thought routing*. **Conversation paths** is the user-facing name for the window and links; **prompt pathing** is fine in dev copy. Every scenario side-tab is a path *through a conversation* — greeting, routing, attachment, group, tool-use.

---

## 9. Connection to existing work

| Doc | Relationship |
|-----|--------------|
| [`../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../companion-surface/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) | The engine design we are surfacing. §2 (Output shape) ≈ Conversation paths schema §5.1 `outputChannels`. §3 (Segment orchestrator) ≈ scenario *Turn routing*. §4 (Structured tags) ≈ schema `tags.allow`. |
| [`../companion-surface/COMPANION_MEDIA_LIBRARY.md`](../companion-surface/COMPANION_MEDIA_LIBRARY.md) | §3 mermaid is the canonical *Vision attachment* graph; Slice A renders the same shape. |
| [`../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) | Source of the *Group round-robin* scenario. |
| [`../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md`](../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md) | §17 media handoff is a *Tool-use loop* sub-case; Conversation paths surface should link to W5a tools when they ship. |
| [`../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) | Fills the *Voice (reserved)* slot when the lane ships. |
| [`../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md) | Fills the *Copilot perceive-plan-act (reserved)* slot. |
| [`HF_TO_ANIKAI_DOWNLOAD_FLOW.md`](HF_TO_ANIKAI_DOWNLOAD_FLOW.md) | Sibling doc — same structural pattern (slice plan + schema + entry points). |
| [`RUNTIME_PACKS_AND_INSTALLER.md`](RUNTIME_PACKS_AND_INSTALLER.md) | The runtime contract that ships the binaries that ultimately read these configs. |

---

## 10. Code today (the half-built foundation)

| File | Role today | After Slice A |
|------|------------|---------------|
| `anikai-desktop/shared/gguf-output-templates/base-template.js` | Default output shape | Read-only display source for the *Simple greeting* + *Turn routing* code panes. |
| `anikai-desktop/shared/gguf-output-templates/gemma4-channels.js` | Gemma 4 channel structure | Read-only display source when family = Gemma 4. |
| `anikai-desktop/shared/gguf-output-templates/behavior-contract.js` | Behaviour-contract paragraphs | Code pane for *Simple greeting*. |
| `anikai-desktop/shared/gguf-output-templates/index.js` | Family selector backend | Same; Sentience → Chat families table + pathing window call the same registry. |
| `anikai-desktop/shared/conversation-paths-ui.js` | Slice A teaching modal (scenarios, step lists, code excerpts) | Same; extended in Slice B with save/load. |
| `anikai-desktop/components/about-guide.js` | About guide HTML + nav | Sentience → Chat sub-tabs + tables; `ConversationPathsUI.mountAboutGuide`; imaging panes scoped to `#aboutGenerateImaging`. |
| `anikai-desktop/shared/thought-segment-tags.js` | Tag vocabulary + parser | Source of truth for the *Turn routing* tag legend. |
| `anikai-desktop/components/chat.js` (`runGgufThoughtTurn`) | Segment orchestrator | Source of truth for the *Turn routing* graph (graph derived from this code path). |
| `anikai-desktop/main-process/companion-skills.js` | Skill executor + IPC | Source of truth for the *Tool-use loop* graph. |
| `anikai-desktop/shared/vision-micro-caption.js` | Vision caption pass | Source of truth for the *Vision attachment* graph. |
| `anikai-desktop/shared/group-role-policy.js` | Group routing policy | Source of truth for the *Group round-robin* graph. |

**Migration note:** Slice A treats these files as **read-only sources** displayed in the code pane. Slice B begins the gentle extraction of *tunable fields* (output channels, behaviour contract strings, segment caps) into JSON beside the JS, with the JS importing the JSON and continuing to export the same shape. Slice C may push further if we discover power users want to author graphs by hand, but the v1 rule (§3) — *graphs derived from structured descriptions the runtime reads* — never bends.

---

## 11. Gemma 4 channel-over-thought issue (deferred fix)

Not in scope for Slice A. Surfacing the channel structure in the *Simple greeting* and *Turn routing* code panes (Slice A) makes the bug visible to anyone opening the tab. Slice B is the right home for the actual fix: edit `outputChannels.thoughtOpen` / `finalOpen` (or the behaviour-contract paragraph that orchestrates them), save, restart a turn. Tracking that fix separately so this doc does not become a bug ticket.

---

## 12. Open questions

| # | Question | Default if not resolved |
|---|----------|--------------------------|
| Q1 | Do we need a **separate** "Simple greeting" scenario, or is it just *Turn routing* with the optional segments collapsed? | Keep separate — it is a teaching anchor; the graph is genuinely simpler. |
| Q2 | Should the ⋮ menu deep-link also pass the **current companion's** chosen output channels (so the window opens with the live config, not just the family default)? | Yes — show the **effective** config (built-in ⊕ family-custom ⊕ model-override) by default, with a toggle "show base family defaults" for comparison. |
| Q3 | Where do **Slice B / C imports** come from in the import dialog — local file picker only, or a curated registry the way `imaging-registry.json` works? | Local file picker for v1. Curated registry only if community sharing becomes a thing (Slice C+). |
| Q4 | Does a per-companion **inferencePolicy** override (Persona → Text inference) belong inside Conversation paths or stay where it is? | Stay where it is. inferencePolicy is **per-companion**; Conversation paths is **per-family/per-model**. They compose at runtime; do not merge their UI. |
| Q5 | Voice (reserved) — does TTS injection point belong here or in a separate Voice paths surface? | Same surface, same window. *Voice* side-tab is enough; do not split surfaces. |
| Q6 | Ship a **top-level About → Conversation paths** tab in Slice A, or only Sentience → Chat + ⋮? | **Sentience → Chat first.** Top-level tab optional redirect in Slice A; full duplicate shell only if user testing asks for it. |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-19 | Initial design doc. Locks in name (*Conversation paths*), side-tab order, four entry points (top-level About tab · Engines & families column · Chat Quick start link · companion chat ⋮ menu), three-layer overlay (built-in family → family-custom → model-override), graph-derived-from-structured-description rule, three-slice plan (A read-only · B curated edit · C full power), naming alternatives considered, schema sketch, Gemma 4 fix deferral note, open questions Q1–Q5. |
| 2026-05-20 | **Slice A shipped (anikai-desktop):** Sentience → Chat sub-tabs; Engine families + Model catalogue tables wired to read-only **Conversation paths** modal (`shared/conversation-paths-ui.js`); Engines GGUF inline buttons; chat ⋮ **View current prompt path**; imaging pane query scoped to `#aboutGenerateImaging` so chat sub-panes do not steal Imaging nav. |
