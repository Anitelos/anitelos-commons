# Model sheet — shuttleai / shuttle-3.1-aesthetic

| Field | Value |
|-------|-------|
| **Doc staging** | Complete |
| **Operations** | Shipped (GGUF E2E verified) |
| **Last reviewed** | 2026-05-20 |

## HF

- Repo: [shuttleai/shuttle-3.1-aesthetic](https://huggingface.co/shuttleai/shuttle-3.1-aesthetic)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the GGUF (matches Anikai `downloadPacks`).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- Encoders bundle (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  

## What it is

**Shuttle 3.1 Aesthetic** — Flux-family text-to-image. HF ships **safetensors** (bf16 / fp8) and **GGUF** quantizations (e.g. Q6_K). Card suggests **4–6 steps** for fast sampling.

## Intended inference family (Windows desktop) — **GGUF first**

| Path | Status |
|------|--------|
| **GGUF + stable-diffusion.cpp (`sd.exe`)** | **Primary** — Media Magic + companion image mode |
| **Diffusers sidecar** | Optional — preset `shuttle_31_aesthetic` when full HF snapshot is on disk |

GGUF requires a **split Flux pack** beside the diffusion `.gguf`:

```text
models/shuttle-31/
  shuttle-3.1-aesthetic-Q6_K.gguf
  vae/
  text_encoder/
  text_encoder_2/     # sharded T5 OK — merged per Generate, temp file deleted after
```

Without sidecars, `sd.exe` may run in weak **single `-m`** mode and **ignore the prompt**.

## Anikai Desktop defaults (GGUF)

Profile id: **`shuttle_31_flux`** in `anikai-desktop/shared/sd-gguf-image-profiles.js`

| Parameter | Default |
|-----------|---------|
| Size | 1024×1024 |
| Steps | 6 |
| CFG | 1.0 (Flux norm in sd.cpp) |
| Sampler | euler |
| Seed | -1 (random each run) |

**Style presets:** `shared/image-style-presets.js` — appends tags after user prompt; **None** = prompt only.

**Output names:** `generated-media/<model-slug>/<slug-from-prompt>-<YYYY-MM-DD_HHmmss>.png` via `main-process/generated-media-filename.js` (`model-slug` from the GGUF filename or Diffusers preset id).

**Build:** `npm run dist:full` bundles **media-python** (one-time venv) for sharded T5 merge + Diffusers presets.

## Anikai router

**shipped** — `flux1_clip_t5` split-pack; catalogue stack `shuttle-31`. About guide registry: **verified** (Media Magic sample, 2026-05-20).

## Diffusers (optional Track B)

- Preset id **`shuttle_31_aesthetic`** — `model_path`: `diffusers/shuttle-3.1-aesthetic` under Models root.  
- Runner: `media-python/run_diffusers_image.py`.  
- Guidance ~3.5 on HF card (Diffusers stack; not the same as sd.cpp CFG 1).

## Implementation checklist (Anikai Desktop)

- [x] GGUF path wired (flux split-pack, profiles, styles, prompt filenames).  
- [x] Verified end-to-end on author hardware (prompt follows text; Media Magic + catalogue).  
- [x] Lane index checkbox ticked when green.  
- [ ] Diffusers preset validated (optional).  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- GGUF imaging rules: [`../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  
- Diffusers family: [`../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-14 | Track B manifest + runner paths documented. |
| 2026-05-17 | GGUF-first; split-pack layout, sd profiles, style presets, dist:full media-python, filename slug. |
| 2026-05-19 | Document per-model `generated-media/` subfolders + prompt timestamp in filename. |
| 2026-05-20 | Marked **Complete** — GGUF E2E verified on author GPU (Shuttle 3.1 Aesthetic, flux1_clip_t5). |
