# Gemma 4 E4B — running in Anikai Desktop

| Field | Value |
|-------|-------|
| **Doc staging** | Living |
| **Operations** | Reference + fix backlog |
| **Last reviewed** | 2026-05-20 |

**Purpose:** Single place for **Gemma 4 E4B** (and close GGUF variants) behavior **inside Anikai** — not the Hugging Face model card. Track known issues, engine flags, parser expectations, and **planned custom changes** so chat stays stable.

**Phased UX / caps / timeline plan:** [`../CHAT_TURN_TIMELINE_PHASED_PLAN.md`](../CHAT_TURN_TIMELINE_PHASED_PLAN.md)

**Code templates:** `anikai-desktop/shared/gguf-output-templates/gemma4-channels.js`, `behavior-contract.js`, `anikai-desktop/shared/gguf-output-templates/utils.js`

**Engine:** `anikai-desktop/main-process/gguf-completion.js` (spawn `llama-completion` / `llama-mtmd-cli` for vision)

---

## What we call “Gemma 4 E4B” here

| Signal | Anikai treats as Gemma 4 channels |
|--------|----------------------------------|
| Path / filename | `/gemma/i` in `modelRef` (e.g. `gemma4_e4b/…`, `Gemma-4-E4B-Uncensored…`) |
| Template id | `gemma4-channels` (`GgufOutputTemplates` priority 100) |
| Multimodal | Same folder often has **`mmproj`** for Sight; chat + vision are separate slots |

Typical user layout:

```text
models/gemma4_e4b/
  Gemma-4-E4B-Uncensored-*.gguf    # Chat & reasoning slot
  mmproj-*.gguf                     # Sight slot (vision)
```

---

## How Anikai runs Gemma today (summary)

| Aspect | Current choice | Why |
|--------|----------------|-----|
| **Pass shape** | **One unified completion** per segment (`planningIncludesReply: true`) | Thought + reply in **one** `-n` budget via `<\|channel\|>thought` then `<\|channel\|>final` |
| **CLI mode** | **`-no-cnv`** one-shot prompt (`engineOneShotNoCnv: true`) | Full control of prompt text; avoids `llama-cli` REPL banners |
| **Jinja / `-cnv`** | **Off** for planning (`engineUseJinja: false`) | Raw prompt includes channel instructions; jinja path often **hides** thought in server stream |
| **Segment loop** | Up to 6 segments; tools → execute → continuation prompt | `<tool/>`, `<done/>`, `<clarify/>`, `<choices/>` in **thought only** |
| **Recovery pass** | Second completion if reply empty / leak / planning in answer | Conversation-style prompt; `preservePlanThoughtOnConvoStream` |
| **Parser** | `gemma4-channels.js` + `utils.js` leak filters | Split thought vs answer; strip contract echo when possible |

```mermaid
flowchart LR
  P[Planning prompt with contract]
  LC[llama-completion -no-cnv]
  PAR[parseAssistantOutput]
  SEG[Segment loop tools]
  UI[Single chat bubble stream]
  P --> LC --> PAR --> SEG --> UI
```

---

## Known issues (symptoms → cause → status)

| # | Symptom | Likely cause | Status | Mitigation / fix direction |
|---|---------|--------------|--------|---------------------------|
| G1 | **Full output contract echoed** at start of stream (debug + sometimes bubble) | Long `formatGemmaOutputContract()` embedded in `[System]`; model copies it under `-no-cnv` | **Open** | Phase 4: short hint in prompt; stronger prefix strip until first `<\|channel\|>thought` |
| G2 | **`[User]` block echoed** in generation | User line appended in raw prompt; model continues transcript | **Open** | Strip echoed `[User]` framing in parser; shorten prompt tail |
| G3 | Thought and reply feel **merged** | One pass + one bubble UI; parser lag on markers | **Open** (UX) | Timeline UI (Phase 3); channel parser hardening |
| G4 | **Partial `<complexity` / `<tool` lines** while streaming | Machine tags only stripped at **segment end** | **Open** | Stream-time `stripMachineTags` (Phase 2) |
| G5 | **Planning leaks into reply** (“None needed…”, contract lines, honesty boilerplate) | Model puts meta in `final`; sanitizer tug-of-war | **Mitigated** | `isPlanningProse`, `sanitizeVisibleReply`, `normalizeAiThoughtRow` — monitor regressions |
| G6 | **Thought doubles into reply** | Incomplete channel close; duplicate channel blocks | **Mitigated** | `mergeXmlThoughts`, channel re-parse on finalize |
| G7 | Footer **`thought cap 512`** vs Persona **plan max 32768** | Footer = **effective turn cap** = `max(512, planMax × thoughtPct)`; short greetings use **~14%** thought → hits **TOKEN_MIN** floor | **Clarify** | Phase 1 footer: show Max vs Turn (not a wrong slider) |
| G8 | **`<complexity/>` in output too late** for same-pass caps | Caps computed from **user text heuristic** before run; tag appears in model output after | **By design today** | Phase 5 optional classifier pre-pass |
| G9 | **Empty thought in UI** but answer OK | Server/jinja thought hidden; or thought-only in tags | **Mitigated** | `engineUseJinja: false` on desktop one-shot; thought stream toggle |
| G10 | **Recovery pass** adds second stream in debug | `needsGgufRecoveryPass` when answer leak / empty | **Expected** | Label passes in debug timeline |
| G11 | **Vision**: companion without mmproj | Solo chat stripped image path | **Mitigated** | Vision handoff to another companion with Sight; access issues in preflight |
| G12 | **Interactive choices** in reply | Model put `<choices>` in `final` | **Mitigated** | Choices only parsed from thought / segments |
| G13 | **Group plan tool** on solo “hi” | Model emits `get_group_plan` anyway | **Expected** | Tool no-op or journal empty; harmless but noisy in timeline |
| G14 | **Character encoding** `` in debug paste | Console/font CP1252 vs UTF-8 in contract | **Cosmetic** | Ensure UTF-8 in prompts and UI fonts |
| G15 | **131k context advertised** vs product default | Model card vs `contextLimitTokens` policy | **By design** | Persona context slider; engine `-c` from policy |

**Regression rule:** When fixing G5/G6/G9, re-check G1 — leak filters often trade off against thought visibility.

---

## Debug stream vs user-visible chat

| View | Content |
|------|---------|
| **Debug** (`meta.debugLiteral`) | **Literal** completion: markers, echo, partial tags, tools — **no** injection stripping |
| **Chat bubble** | Parsed thought phases + sanitized reply |

Example shape (from production debugging):

```text
<|channel|>thought
(private planning only …)
<|channel|>
<|channel|>final
(your reply …)
… [contract echo] …
[User]
hi! …
<|channel|>thought
<complexity …/>
<tool …/>
<done/>
<|channel|>final
Hey! …
```

User-visible layer should **start** at real thought content, not at “Format (one pass…”.

---

## Engine flags (Gemma template `turnPolicy`)

| Flag | Value (desktop) | Meaning |
|------|-----------------|--------|
| `planningIncludesReply` | `true` | Do not expect separate reply-only spawn for normal turns |
| `conversationUseChatTemplate` | `false` | Recovery pass avoids chat template pitfalls |
| `preservePlanThoughtOnConvoStream` | `true` | Recovery stream keeps prior thought |
| `engineUseJinja` | `false` | Planning uses raw channel prompt |
| `engineOneShotNoCnv` | `true` | `llama-completion` one-shot |
| `engineFlashAttnVision` | `true` | Vision path preference when mmproj used |

**Do not flip `engineUseJinja` to `true` on desktop one-shot** without validating thought visibility in stream and server slot behavior (see group chat E+ notes).

---

## Token caps (companion policy × Gemma one-pass)

| Concept | Formula / note |
|---------|----------------|
| Persona **plan max** | `predictTokensPlan` (e.g. 32768) |
| Persona **reply max** | `predictTokensReply` (e.g. 8192) |
| **This-turn thought cap** | `planMax × thoughtPct` (heuristic or future classifier), **≥ 512** |
| **This-turn reply cap** | `replyMax × replyPct` (heuristic) |
| **Engine `-n`** | `min(context, thoughtCap + replyCap)` unified |

Greeting-like user text lowers `thoughtPct` / `replyPct` (`classifyTurnDemand`) → small effective thought cap → **512 floor** common.

---

## Custom changes planned for Anikai (backlog)

Track implementation in [`../CHAT_TURN_TIMELINE_PHASED_PLAN.md`](../CHAT_TURN_TIMELINE_PHASED_PLAN.md).

| ID | Change | Issue refs |
|----|--------|------------|
| **C1** | **Short Gemma completion preamble** (channel lines only, not full tool catalog) | G1, G2 |
| **C2** | **Prefix gate:** hide streamed text until `<\|channel\|>thought` or validated start | G1, G2 |
| **C3** | **Stream-time tag stripping** in thought pane | G4 |
| **C4** | **Turn timeline events** (thought segment, tool, reply) | G3 |
| **C5** | Footer **Max / Turn** split | G7 |
| **C6** | Optional **classifier slot** (0.5B–1B) for `<complexity/>` before main run | G8 |
| **C7** | **E+:** Gemma on `llama-server` with tested jinja + thought stream policy | G9, long-term |
| **C8** | **GBNF / grammar** on classifier output only | G8 optional |
| **C9** | Re-test **two-pass** (plan `-no-cnv`, reply server) as advanced companion toggle | power users only |

---

## Prompt contract (what we ask Gemma to emit)

**Thought channel only:**

- `<complexity temp_bias="…" thought_pct="…" reply_pct="…" task="…"/>`
- `<tool name="…" …/>`
- `<clarify>…</clarify>`
- `<choices question="…">a \| b \| c</choices>`
- `<uncertain reason="…"/>`
- `<done/>`

**Final channel only:**

- Plain-language reply (honesty beat when tone unclear — **not** the long static honesty paragraph from contract)

Full text: `behavior-contract.js` → `formatGemmaOutputContract()`.

---

## Multimodal (Gemma + mmproj)

| Case | Behavior |
|------|----------|
| Companion has **mmproj** | Image path in turn; preflight scans; `llama-mtmd-cli` or server vision path |
| **No mmproj** | Image stripped or **vision handoff** to another companion (solo); user sees Sight notice |
| Screen capture attach | Same as image attachment; cleanup choices after turn |

---

## Testing checklist (manual)

1. Fresh companion, Persona plan max **32768**, reply **8192**, all “companion decides” on.
2. Send: `hi! ready to jump in…` (no attachment).
3. **Debug:** note whether stream starts with contract echo (G1).
4. **Bubble:** thought readable, no contract; reply one paragraph (G3, G5).
5. **Footer:** record Turn vs Max lines (G7).
6. Attach image without mmproj: handoff or clear “no Sight” message (G11).
7. Toggle **Thought stream** menu: thought stays visible when reply arrives (G9).

---

## Related docs

| Topic | Path |
|-------|------|
| Group two-phase / E+ | [`../../../anikai-agent-workflows/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../../../anikai-agent-workflows/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) |
| Live conversation / `-cnv` | [`../../../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../../../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) |
| Workshop index | [`../../../companion-surface/DESKTOP_WORKSHOP_STATE.md`](../../../companion-surface/DESKTOP_WORKSHOP_STATE.md) |
| Execution / channels | [`../../../anikai-agent-workflows/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](../../../anikai-agent-workflows/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md) |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial Gemma 4 E4B Anikai doc: issues G1–G15, engine flags, planned C1–C9, debug vs UI |
