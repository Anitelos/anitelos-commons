# TODO — ONNX engine inference on desktop (Windows x86-64, mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-10 |

---

## Source implementation docs

- `implementations/engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` (boundary: GGUF vs ONNX lanes)

---

## Intent

- Ship **ONNX Runtime** on Windows with explicit **execution provider** policy (CPU / DirectML / optional CUDA) and **no silent EP fallback** that hides failures.
- Register imaging graphs with **tensor contracts** and visible error strings on shape/opset mismatch.
- Align **post-pass** ONNX chains with the GGUF imaging plan when GGUF is primary.

---

## Checklist (working)

- [ ] EP probe + manifest `allowed_eps` enforced at session create.
- [ ] One reference **primary** ORT imaging graph passes on a clean Windows machine.
- [ ] Optional **post** graph validated and chained in pipeline metadata.
- [ ] Companion / panels can pick ONNX-backed actions only when manifest row passes.

---

## Linked operations

- `implementations/generation/imaging/IMAGING_GENERATION_INDEX.md`
- `implementations/generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`
- `../../../android-arm64/implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`
- `../../../android-arm64/todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-10 | Created Windows ONNX engine inference todo linked to new ONNX plan and Android ONNX / imaging pipeline todos. |
