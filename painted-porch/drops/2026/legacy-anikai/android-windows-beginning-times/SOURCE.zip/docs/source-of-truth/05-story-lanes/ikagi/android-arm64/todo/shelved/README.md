# Shelved (intentional pause)

**Scope:** ideas that deserve retention but not calendar time. Prefer a one-line “resume trigger” in each note (for example: “when GGUF diffusion PNG decode is canonical…”).
