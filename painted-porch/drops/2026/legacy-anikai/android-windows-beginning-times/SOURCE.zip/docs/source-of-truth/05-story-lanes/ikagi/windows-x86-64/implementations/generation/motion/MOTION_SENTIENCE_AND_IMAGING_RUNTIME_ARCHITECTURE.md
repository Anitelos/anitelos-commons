# Motion-sense, imaging ONNX, and runtime architecture (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-20 |

**Purpose:** Single write-up for everything discussed in the motion-sense / imaging ONNX thread: what each runtime does, how **body pose rigs** (OpenPose-style) differ from **phoneme face rigs**, how a **small AI** directs movement, and how that maps to **registries** and **Settings → Device → Software** runtime packs.

**Registries (desktop UI):**

| Registry | Path |
|----------|------|
| Runtime packs (Software tab + About) | `anikai-desktop/assets/about-guide/runtime-packs-registry.json` |
| Motion-sense families / stacks | `anikai-desktop/assets/about-guide/motion-sentience-registry.json` |
| Imaging ONNX stacks | `anikai-desktop/assets/about-guide/imaging-registry.json` (built from `scripts/build-imaging-registry.mjs`) |
| ONNX runner catalogue | `anikai-desktop/shared/onnx-imaging-stacks.js` |

**Related plans:**

- [`../imaging/onnx/ONNX_IMAGING_STACK_LIBRARY.md`](../imaging/onnx/ONNX_IMAGING_STACK_LIBRARY.md)
- [`../imaging/onnx/ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../imaging/onnx/ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)
- [`../../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)
- [`../../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](../../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md)
- [`RIG_AND_POSE_INTENT_SCHEMA.md`](./RIG_AND_POSE_INTENT_SCHEMA.md)
- Android strategy: [`../../../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md`](../../../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md)

---

## 1. Design principle: raw tensors, small runtimes

| Layer | Technology | Role |
|-------|------------|------|
| **Heavy decode** | GGUF + `sd.exe`, Python Diffusers | New pixels (txt2img, portrait still) |
| **Fast perception / post** | ONNX Runtime (`onnxruntime-node` on desktop) | Depth, matting, upscale, pose extract, Wav2Lip-class lip sync |
| **Temporal portrait** | Python sidecar (PersonaLive, SadTalker, LivePortrait) | Motion over time — not one `.onnx` file |
| **Speech face** | Anikai **deterministic rig** + optional phoneme driver synth | Mouth/eyes from TTS timing — no NN required for v0 |
| **Body / scene pose** | DWPose / OpenPose maps + **PoseIntent** JSON | Control img2img / sprite sheets (OpenPose grid demos) |
| **Director** | Small GGUF **Familiar** | Fills strict JSON (`PoseIntent`, rig channels) — does not paint frames |

Libraries stay small when each stage only moves **narrow tensors**; Python is reserved where diffusion-over-time is unavoidable.

---

## 2. Two different “rigs”

### 2.1 Body rig (your OpenPose reference image)

- **Signal:** Colored stick figure / keypoints / OpenPose PNG.
- **Source:** Extract from photo (DWPose) **or** synthesize from `PoseIntent` (pose library + procedural renderer).
- **Consumer:** ControlNet-style img2img, sprite NESW (“same pose, four styles”), future video conditioning.
- **Not driven by phonemes** — driven by scene, dialogue stage direction, and Familiar `PoseIntent`.

### 2.2 Face rig (phonemes + mood)

- **Signal:** `mouthShape`, `brow`, `gaze`, `blink`, head nod — curves over time.
- **Source:** Kokoro/TTS phoneme timing + companion mood bus (deterministic policy).
- **Consumer:** UI canvas (Android today), **phoneme driver synth** → low-res driver MP4 → **PersonaLive** (does not ingest phonemes directly).
- **Later:** word-level triggers (`gestureOnWord`) from chat, not full-body pose.

```mermaid
flowchart LR
  subgraph in
    Scene[Scene + chat]
    Words[Director lines]
    Phonemes[TTS phonemes]
  end
  subgraph small
    Familiar[Familiar GGUF]
    RigPolicy[Rig policy]
  end
  subgraph rigs
    Body[Body: PoseIntent / OpenPose map]
    Face[Face: rig channels]
  end
  subgraph runtimes
    ORT[ONNX imaging]
    PL[PersonaLive Python]
    SD[sd.exe GGUF]
  end
  Scene --> Familiar
  Words --> Familiar
  Familiar --> Body
  Phonemes --> RigPolicy
  RigPolicy --> Face
  Body --> ORT
  Body --> SD
  Face --> PL
  ORT --> SD
```

---

## 3. ONNX imaging — cool uses (catalogue)

| Stack id | Use | Motion / sentience tie-in |
|----------|-----|---------------------------|
| `onnx_upscale` | 4× after FLUX stills | Sprite NESW polish |
| `onnx_bg_remove` | Alpha cutout | Stickers, UI, compositing |
| `onnx_portrait_depth` | Depth overlay | Stage B parallax beside hero |
| `onnx_inpaint` | LaMa-class mask fill | Fix hands/props; local edit |
| `onnx_pose_dwpose` | Body keypoints + overlay | ControlNet feed; pose library target |
| `onnx_gfpgan` (imaging registry) | Face cleanup | Before portrait motion |
| `onnx_wav2lip` (motion registry) | Lip sync on crop | Audio-driven fallback |

**Planned ONNX (registry rows, runner later):** face landmarks (InsightFace-class), segmentation (SAM / U²-Net variants), CLIP-vision tiny classifiers for Familiar scene read, Whisper-tiny for aligner.

**Desktop runner:** `main-process/onnx-imaging-runtime.js` · IPC `imaging:onnx-*` · Media Magic post-process row.

**Weights:** `%ANIKAI_HOME%/models/onnx/...` via About **Get pack** (not inside runtime ZIP).

---

## 4. Python motion lanes

| Family | Runtime pack | Primary input | Phonemes? |
|--------|--------------|---------------|-----------|
| `personalive_portrait` | `pack.personalive` | Still + driving frames | Via driver synth |
| `sadtalker` | `pack.motion.python` (future) | Still + wav | Audio |
| `liveportrait` | `pack.motion.python` (future) | Still + driver video | Indirect |
| `anikai_rig_deterministic` | `pack.rig.anikai` (app) | Phoneme + mood | **Yes** |
| `anikai_phoneme_driver` | `pack.rig.anikai` | Rig bus | **Yes** |

PersonaLive is **P0**; rig + phoneme driver **P0/P1**; SadTalker / LivePortrait **P3** alternates.

---

## 5. Small AI as director (Familiar)

Familiar outputs **structured JSON** only — see [`RIG_AND_POSE_INTENT_SCHEMA.md`](./RIG_AND_POSE_INTENT_SCHEMA.md).

Downstream is deterministic:

- `body` → pose library / DWPose target map → img2img or ControlNet stage.
- `face` + phoneme clock → rig curves → driver synth → PersonaLive.
- Timeline fields (`holdPoseMs`, `gestureOnWord`) → `PortraitAnimationWorker` scheduling.

---

## 6. Runtime packs ↔ Software tab

**Canonical list:** `runtime-packs-registry.json`.

**Check runtimes:** `main-process/runtime-pack-probes.js` rolls per-slot probes into pack cards (Settings → Device → Software).

| Pack id | Format | Severity | Probes |
|---------|--------|----------|--------|
| `pack.gguf` | GGUF | required | llama-completion, sd.exe |
| `pack.media.anikai` | Media | optional | FluidSynth, Diffusers venv |
| `pack.onnx` | ONNX | optional | ORT DLLs (voice.onnx staging) |
| `pack.onnx.imaging` | ONNX | optional | onnxruntime-node + imaging stacks on disk |
| `pack.voice` | Voice | optional | eSpeak + ORT + Piper |
| `pack.hearing` | Hearing | optional | whisper.cpp |
| `pack.cuda` | CUDA | optional | toolkit bin |
| `pack.personalive` | PersonaLive | optional | bundled personalive-runtime |
| `pack.motion.python` | Python | optional | SadTalker/LivePortrait (planned) |
| `pack.rig.anikai` | ANIKAI | optional | built-in rig (always partial) |
| `pack.mediapipe` … | various | optional | MODEL_HUB promote-later |

**About guide:** Engines & families → **Runtime packs** table (loaded from same JSON).

---

## 7. Implementation waves

| Wave | Deliverable |
|------|----------------|
| **A (done / partial)** | ONNX post in Media Magic; DWPose two-graph; inpaint dual-feed; Get packs for UltraSharp/depth/rembg/DWPose; registries + runtime catalogue |
| **B** | PoseIntent schema + pose library PNG renderer; Familiar tool `set_pose_intent` |
| **C** | Phoneme driver synth MP4; PersonaLive IPC with synth stream |
| **D** | ControlNet / img2img stage consuming OpenPose map in pipeline editor |
| **E** | Wav2Lip ONNX, GFPGAN runner, face landmark ONNX |

---

## 8. Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial architecture doc; links runtime-packs-registry and rig schema. |
