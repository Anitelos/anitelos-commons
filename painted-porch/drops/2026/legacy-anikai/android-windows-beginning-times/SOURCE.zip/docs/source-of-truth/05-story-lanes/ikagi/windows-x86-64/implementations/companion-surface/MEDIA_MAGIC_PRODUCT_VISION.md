# Media Magic — product vision (Windows)

| Field | Value |
|-------|-------|
| **Status** | Active build center — inference + UX, not terminal/log tooling |
| **UI home** | `anikai-desktop` → Panels → **Media Magic** (`#mediaMagicMount`) |
| **Story anchor** | [`../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md) |
| **Imaging lanes** | [`../generation/imaging/IMAGING_GENERATION_INDEX.md`](../generation/imaging/IMAGING_GENERATION_INDEX.md) |
| **Generation IA + designers** | [`MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`](MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md) |
| **Top-level IA** | [`MEDIA_MAGIC_TOP_LEVEL_IA.md`](MEDIA_MAGIC_TOP_LEVEL_IA.md) |
| **Video IA + engine map** | [`../generation/video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`](../generation/video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md) |
| **Phased creative flow plan** | [`MEDIA_MAGIC_PHASED_CREATIVE_FLOW_PLAN.md`](MEDIA_MAGIC_PHASED_CREATIVE_FLOW_PLAN.md) |
| **Runtime packs** | [`../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) |

---

## Why Media Magic exists

Most people do **not** want three months of “what is local AI.” They want what chat-hosted image/music sites give them — **fast, visual, forgiving** — without £20/month rent, folder archaeology, or “install Python and clone five repos.”

**Media Magic** is the **head-turner surface**: sovereign, on-PC, one app. It is where Anikai proves that **every inference family** the workshop supports can be **used**, not just **listed** in About.

---

## The simple loop (non-engineer)

```mermaid
flowchart LR
  Get[Quick Get from HF]
  Gen[Generate]
  See[See result matches prompt]
  Post[Post-process / preprocess]
  Save[Save or send to chat]

  Get --> Gen --> See --> Post --> Save
```

| Step | What the user experiences | What we hide |
|------|---------------------------|--------------|
| **Quick Get** | Tap **Get** on a curated or searched model — file lands in the right place; no “open Downloads and guess” | Registry paths, pack shards, ONNX vs GGUF routing |
| **Generate** | Pick preset / tab (image, music, …), prompt, **Generate** | Engine binary, VRAM queue, staging |
| **See it work** | Preview in-panel; try another prompt; trust the tool | Smoke logs, cluster debug (creator tooling — not user-facing) |
| **Post / pre** | Sliders and ops: upscale, depth, pose, **mask** (e.g. Kontext inpaint), DWPose, etc. | Multi-graph ONNX, pipeline ids |
| **Later: talk** | Mic or companion: “make it warmer,” “inpaint the sky,” “30s loop” | Segment orchestrator, PersonaLive, Kokoro voice stack |

**Pattern already proven for images:** Flux-class GGUF + split-pack **Get** + Media Magic tabs + post-process row — **extend the same story** to music, video, and ONNX families without requiring one giant “main” model.

---

## Engine rule (same as product lane)

- **Every family** that Anikai claims must **run** end-to-end in Media Magic or chat tools (at least one honest preset per family).
- **Not every weight / variant** — life is finite; pick **representative** checkpoints per family (like Flux Klein / Kontext today).
- Missing engine → **Runtime** panel: **one-time install** pack (`stage-*` / Check runtimes), not “go read a GitHub README.”

Families include (non-exhaustive): GGUF image, ONNX imaging stacks, MIDI + SoundFont, neural music/video lanes, PersonaLive / motion-sentience, voice (Kokoro-class), text GGUF for companion — each wired through **runtime packages** and registry rows.

---

## Sentience on the same stage (not Media Magic only)

Media Magic is **hands-on creation**. **Sentience** is **relationship**:

- **Kokoro 8** voice, emotion, mood, confidence, bonds (Android Soul Meridian ideas — port when ready).
- **PersonaLive** facetime-style chat ([`../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)).
- User can **ask or talk** for image / music / video / edits without typing — companion routes to the same engines Media Magic uses.

Playground / pipeline graph editors are for **creators** who compose nodes; Media Magic is for **everyone else** first.

---

## What we are not optimizing right now

| Deferred | Why |
|----------|-----|
| In-app Workshop Terminal / logcat UI | Helps **pipeline/playground creators** debug; not the mass-market hook |
| Every Suno / Pixel Lab / hosted clone | Goal is **local plug-and-play**, not feature parity on day one |
| Cloud inference | Sovereign PC lane — local only for this phase |

---

## Community groundwork

The app is laid out so **others can keep adding** engines, presets, and packs without re-architecting:

- **Anikai Registry** + About tables — honest “what exists.”
- **Runtime packs** — staged binaries, one installer story.
- **Imaging / audio indexes** — where to add a new family smoke + Media Magic tab.
- **Sideloads** — power users welcome; defaults stay guided.

Vision: anything we imagine, we **throw at the workshop** — shard pairing, multi-pack downloads, and graph composition become **boring plumbing**, not a science project.

---

## Dashboard layout v2 (image — shipped direction)

Anchored on the **dashboard mock** (hero center, post right, stacked left cards, console under hero+post only). Anikai keeps the **Anikai dock** (no mock left icon rail) and adds **header dropdowns** + **Recent generations** full-width below.

### Region map

```
┌─ Header ─────────────────────────────────────────────────────────────┐
│ Media Magic · [Media ▾] [Mode ▾] [Model ▾]              📁 🔄 ⚙    │
└────────────────────────────────────────────────────────────────────┘

┌─ Main workspace ─────────────────────────────────────────────────────┐
│                                                                      │
│  LEFT COLUMN (collapsible cards)   │  CENTER + RIGHT                 │
│  ┌ Prompt editor ───────────────┐ │  ┌────────────────┬──────────┐ │
│  │ Shaper ▾ (header, above field)│ │  │                │ Post-    │ │
│  │ Prompt textarea              │ │  │  HERO RESULT   │ process  │ │
│  └──────────────────────────────┘ │  │  (generated)   │ Upscale  │ │
│  ┌ Model parameters ────────────┐ │  │                │ Remove BG│ │
│  │ steps, CFG, seed, engine…    │ │  │  [Generate]    │ Depth    │ │
│  └──────────────────────────────┘ │  └────────────────┴──────────┘ │
│  ┌ Reference uploads ───────────┐ │                                  │
│  │ reference image (required    │ │  ┌─ Workshop console ─────────┐ │
│  │  for img2img / Kontext)      │ │  │ prompt echo · runtime ·    │ │
│  └──────────────────────────────┘ │  │ errors · step progress     │ │
│  ┌ Pre-process (inpaint) ──────┐ │  │ (spans center+right only)  │ │
│  │ mask — tied to reference     │ │  └────────────────────────────┘ │
│  │ above; pre **generation**    │ │                                  │
│  └──────────────────────────────┘ │                                  │
│  (full height; not under console) │                                  │
└──────────────────────────────────┴──────────────────────────────────┘

┌─ Recent generations (full panel width, scroll if tight) ─────────────┐
│ thumb strip + detail (unchanged data model)                          │
└──────────────────────────────────────────────────────────────────────┘
```

### Left column cards (order matters)

| Card | Contents | Collapse |
|------|----------|----------|
| **Prompt editor** | Textarea; **Shaper ▾** in card header (above field); style/genre row | `<details>` / chevron |
| **Model parameters** | Former “Image settings” + sd.exe / Diffusers grids | collapsible |
| **Reference uploads** | Init / reference image for img2img & Kontext | collapsible |
| **Pre-process (inpaint)** | **Mask** upload only — **below** reference card; uses same reference as generation input; shown when preset needs mask (e.g. Kontext inpaint) | collapsible; hidden when N/A |

**Pre vs post:** Mask is **pre-process** (feeds the generator with reference + mask). ONNX Upscale → DWPose are **post-process** (run on the **result** image). UX separates them; pipeline may chain pre → gen → post.

### Center + right

| Zone | Role |
|------|------|
| **Hero** | Large `#mediaWorkflowResult` preview |
| **Post-process card** | Vertical list of ONNX ops; disabled when weights not onboard; **`!`** → future Get-pack / missing ONNX panel |
| **Generate** | Primary action under or beside hero (slim row, not full-panel purple slab) |

### Anikai media console

- Sits **under center + right only** — does **not** extend under the left column (matches mock terminal width).
- **Single readout** for readiness, errors, success, generation progress, T5 merge, sd.exe stderr, Diffusers Python lines — same class of logs as `npm run dev` terminal during Generate (no separate terminal needed for imaging runs).
- Distinct from **Workshop Terminal** (M1 logcat); this is **Media Magic–local** until M0 bus exists.

### Header vs old tabs

| Old | New |
|-----|-----|
| Image / Music / Video pills | **Media ▾** |
| Standard / Sprite / … pills | **Mode ▾** (options depend on Media ▾) |
| Model row below tabs | **Model ▾** in header |

Audio / Video panes keep their own bodies until ported to the same dashboard grid.

---

## Audio tab (shipped direction)

| Sub-tab | Role |
|---------|------|
| **Synth / MIDI** | Lanes 1–2 — keyboard, FluidSynth, GGUF arranger hints |
| **Compose** | Suno-style desk: **song plan** + **Lyrics → Voice → Instrumental** — consumes voice presets; see [`../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md`](../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md) |
| **Voice Weaving** | Author voice clones and presets (LongCat, XTTS, CosyVoice, Kokoro, …) — planned tab; clone UI migrates out of Compose |
| **Assembly** | Stem paths, ffmpeg analysis, export mix — own tab (not inside Compose scroll) |
| **SFX** | Lane 3 one-shots — separate so video/game SFX are not buried inside Compose |
| **Games** | Sprite sheet (from Image tab) |

**Compose order chip** (beside subtabs when Compose is active): toggles **Lyrics & voice first** vs **Instrumental first** — reorders stage order for voice vs instrumental only.

**Suno pipeline doc:** [`../pipelines/CURATED_SUNO_CLONE_PIPELINE.md`](../pipelines/CURATED_SUNO_CLONE_PIPELINE.md).

**Code:** `media-pane-templates.js` (`composePane`, `audioSubtabsRow`), `media.js` (`syncAudioSubtabs`, `syncComposeStageOrder`).

---

## Weaving modes (image + video)

| Mode | Path | Runtime pack? |
|------|------|----------------|
| **Image weaving** | **Image → Image weaving** — layer stack, opacity, recent gens → layers | No extra pack (still compositor) |
| **Video weaving** | **Video → Video weaving** — track tree, ShaderToy preview, shader generate | **No** — WebGL2 is in Electron; procedural GLSL gen is in-app |

**Video weaving (shipped scaffold):** channel groups (`iChannel0` top … `iChannel3` bottom), **Weave shader** prompt strip under preview, shader tools when a shader track is selected, `generate_shader` from chat, saves under `generated-media/shaders/`. GLSL errors → **media console**, not under preview.

**Direction doc:** [`../pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md`](../pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md).

---

### Code map

| Piece | File |
|-------|------|
| Markup | `anikai-desktop/components/media.js` (`render`, image `standard` subpane) |
| Layout CSS | `anikai-desktop/styles/media.css` (`.media-dashboard-*`) |
| Default panel size | `anikai-desktop/components/panels.js` (`media` width/height) |

**Do not** reintroduce the horizontal `Ref | or | Prompt | = | Result` grid — mask as an extra column broke layout (2026-05).

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05-28 | Added phased implementation doc for Character -> Video/Fashion -> 3D/Sprite flow and showcase gates (`MEDIA_MAGIC_PHASED_CREATIVE_FLOW_PLAN.md`) |
| 2026-05-28 | Added linked video IA map: specialist engine tabs, curated experiments, and video weaving split (`VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`) |
| 2026-05-28 | Added linked IA spec: `Generation` + `Others` split and designer lane contracts (`MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`) |
| 2026-05-22 | Initial vision doc — Media Magic as product center; simple loop; family-not-weight rule |
| 2026-05-22 | Dashboard layout v2 map — left cards, pre-process below refs, console span, header dropdowns |
| 2026-05-22 | Dashboard v2 implemented in `media.js` / `media.css` — header dropdowns, collapsible left cards, hero+post, workshop log |
| 2026-05-22 | UX polish: scrollable left column, Image parameters + in-panel model, source/style refs, readiness strip (not settings box), fixed resize layout |
| 2026-05-24 | Voice Weaving architecture linked; Audio tabs: Compose, Voice Weaving (planned), Assembly separate |
| 2026-05-23 | Audio tab: Compose workflow (BPM plan, stage collapsibles, instrumental-first chip); SFX separate |
| 2026-05-22 | Image weaving + Video weaving naming; weaving modes section + shader runtime note |
