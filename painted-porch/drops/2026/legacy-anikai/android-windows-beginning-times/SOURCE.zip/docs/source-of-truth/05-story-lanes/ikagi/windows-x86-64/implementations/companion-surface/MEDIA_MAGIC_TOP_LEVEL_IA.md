# Media Magic top-level IA (Windows)

| Field | Value |
|-------|-------|
| **Status** | Active — scaffolding in desktop UI |
| **Scope** | Top-level kinds, per-kind mode groups, and cross-kind creative flow |
| **Related** | [`MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`](MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md), [`../generation/video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`](../generation/video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md), [`MEDIA_MAGIC_PHASED_CREATIVE_FLOW_PLAN.md`](MEDIA_MAGIC_PHASED_CREATIVE_FLOW_PLAN.md) |

---

## Top-level kinds

Header tabs (target):

| Kind | Role |
|------|------|
| **Image** | Designer intent — references and concepts for downstream lanes |
| **Audio** | Music, voice, SFX, assembly |
| **Video** | Engine execution — motion and controllable video |
| **3D** | Specialist 3D stacks + scene weaving |
| **Others** | Games (2D/3D), and future creators: web, app, magazine, manga, anime, … |

**Games** is no longer a top-level tab; it lives under **Others** with sub-lanes.

Long-term, Media Magic should support designing and creating anything, with agentic companions, saved pipelines, and terminal-backed magnet workflows — this doc is the IA spine for that.

---

## Shared mode pattern (Image, Video, 3D)

Each creative kind uses the same three mode groups where applicable:

1. **Generation** — specialist engines (or Standard multi-model lane)
2. **Weaving** — compose, mix, timeline, scene assembly
3. **Others** — curated experiments, rig tests, post tools (UV, rigging, …)

Image sets the reference implementation:

- Generation → Standard + designer lanes
- Image weaving
- Others → Still motions, persona experiments

### Image → Generation → Standard workflows (header)

When **Media = Image**, **Mode = Generation**, and the workspace is **Standard**, a fourth header control **Workflow** appears beside Media and Mode:

| Workflow | Slots | Model filter (v1) |
|----------|-------|-------------------|
| **Text → image** | Prompt only | t2i-capable GGUF / Diffusers |
| **Prompt + source** | Source + prompt | img2i / edit models |
| **Source + style** | Source + style + prompt | Kontext dual-ref, Flux+IP-Adapter class |
| **Mask / edit** | Source + mask + prompt | Kontext inpaint, Qwen Image Edit, … |
| **Alpha / mask prep** | Source + Pre-process | Mask builders (rembg, Qwen mask) — then switch to Mask / edit |

Pipeline class is not shown in the UI — it is derived from the model preset and workflow (e.g. `FluxKontextInpaintPipeline` when **Mask / edit** + Kontext). Inpaint controls live on the mask / pre-process slots, not in Image parameters. Post-process ONNX stays in the side flyout; ready tools light even before a hero still exists (click explains if no image yet).

**Standard desk layout (v1):** **Model** card first (main model + workflow hint + readiness line), then **Prompt editor** (Shaper flyout), then **Image parameters** (resolution/steps only), then reference slots. Generate shows a workflow-specific tooltip when blocked (missing source, mask, weights, or prompt).

Video and 3D follow the same header **Mode** dropdown pattern in the dashboard.

---

## Video IA

### Mode: Generation

| Engine tab | Purpose |
|------------|---------|
| **Standard** | General T2V / I2V / V2V — Lance and other motion models when not needing a specialist panel |
| **Lance** | ByteDance unified multimodal — **Original (HF)** or **GGUF (Abiray)** weight chooser; dedicated controls |
| **Fashion** | Human–garment customization (coming soon) |
| **CogOmni** | Controllable video watch tab until local release |

### Mode: Video weaving

Post-generation composition: layers, shaders, timeline, audio bridge, look-unification (including V2V pass to match clips from different engines).

### Mode: Others

- PersonaLive rig test (curated)
- Future internal experiments

---

## Video reference contract (character + scene)

For I2V and similar engines (planned on **Standard** and shared across engines where supported):

| Slot | Source examples | Required? |
|------|-----------------|-----------|
| **Character / cast** | Character designer output, portrait, walk-cycle frame | No |
| **Scene source** | Building, environment, concept-scene still; later CogOmni full scene | No |

**Rules:**

- Any combination of filled/empty slots is valid.
- Character-only, scene-only, or both together.
- An empty slot does not block the other.
- Handoffs from Image designers pre-fill the matching slot when the user lands on a video engine tab.

This keeps specialist engine tabs separate from **Standard** editing while allowing scene planning from Image → Video.

### Model picker tagging (Video vs Image)

| Model class | Image tab | Video tab | Notes |
|-------------|-----------|-----------|-------|
| Image-only GGUF (e.g. SD 3.5 Turbo) | Yes | **Never** | Filtered by HF task tags on scanned weights |
| Video-only weights | No* | Yes | `text-to-video`, `image-to-video`, etc. |
| **Lance** (multimodal stack) | Yes | Yes | `MEDIA_STACK_CATALOG` — same stack id, tab-gated lists |
| Specialist tabs (Fashion, CogOmni) | N/A | Own panes | Not merged into Standard dropdown |

\*Unless a future Image “others” pipeline explicitly exposes a video-capable path.

**Standard Video** workspace includes prompt, shaper, preview, and the video-only model select. **Lance** tab remains the pro multi-step surface; it does not replace Standard’s shared desk.

### Lance inference host (Windows vs WSL)

Lance upstream expects **CUDA + flash-attn**. There is **no silent fallback** between hosts.

| Setting | When to use |
|---------|-------------|
| **Windows** | After `npm run stage-lance` with flash-attn successfully installed in `resources/lance-runtime/venv` |
| **WSL** | Recommended on Windows when native flash-attn build fails — one-time **WSL setup (Lance)** in Video/Image settings |

Post-check: `npm run verify-lance` (CUDA + flash-attn on both paths). User picks host under **Media Magic → Settings (gear) → Lance inference**.

---

## 3D IA

### Mode: Generation

One dropdown/engine tab per stack: LiTo, SHARP, TRELLIS, TripoSR, Hunyuan3D-2, …

Each stack keeps its own pack row, runner, and viewport preview in the generation pane.

### Mode: 3D weaving

Scene composer: import splats/meshes from generation stacks, arrange in a viewport, export to Video weaving or Games. Not game-runtime yet — “mini DCC” for AI-generated assets.

### Mode: Others

- UV editing (later)
- Auto rigger (later)
- Animation tools (later)

---

## Others IA (top-level)

Current:

| Lane | Status |
|------|--------|
| Games · Sprite sheet | Active |
| Games · 3D | Later |
| Web / App / Magazine / Manga / Anime creators | Later stubs |

Games 2D and 3D remain sub-lanes under Others, not mixed into Video/3D weaving semantics.

---

## Weaving vs generation (why separate)

| Layer | Video | 3D |
|-------|-------|-----|
| **Generation** | Run a model once; get clips/frames | Run a stack once; get mesh/splat |
| **Weaving** | Combine clips, timing, look match | Combine imports in a scene |
| **Standard** | Multi-model / edit lane | N/A at 3D top level (use per-engine generation) |

Specialist tabs stay focused; weaving is where cross-engine story assembly happens.

---

## Handoffs (cross-kind)

Image designer footers link to Video engines, 3D, Games, and concept timeline.

Video/3D engines link back to Image designers when references need improvement.

Destination tabs open with slot guidance in the media console until deep linking ships.

---

## Specialist runtime gates (Lance, LiTo, Fashion)

Lanes outside the shared **media-python / GGUF** core use **split packs**:

| Lane | Runtime pack id(s) | Model pack | UI gate |
|------|-------------------|------------|---------|
| **Video → Lance** | `lance.runtime.win` or `lance.runtime.wsl` — **Original (HF)** needs flash-attn; **GGUF** needs CUDA python only (hidden host UI) | `lance-3b-unified` (HF) or `lance-3b-gguf` ([samuelchristlie/Lance-GGUF](https://huggingface.co/samuelchristlie/Lance-GGUF)) | Weight-format chooser; GGUF pack includes **image + video** quants under `Lance-GGUF/` |
| **3D → LiTo** | `lito.runtime.wsl` | `apple-lito-image3d` | Same gate on LiTo stack section |
| **Video → Fashion** | `pack.fashion` (planned) | TBD | Watch gate until FashionChameleon runtime ships |

User flow: **Download / Import runtime pack** (prebuilt Windows + WSL venvs from CI — includes **flash-attn** inference core) → **Get model pack** → workspace unlocks. No in-app WSL setup or PyPI-on-first-use.

**Settings → Device → Runtime** is grouped: Core · Media (basic + Lance/LiTo) · Live motion · Sentience.

**Lance GGUF** ([samuelchristlie/Lance-GGUF](https://huggingface.co/samuelchristlie/Lance-GGUF)) ships separate **image** (`Lance_3B-*.gguf`) and **video** (`Lance_3B_Video-*.gguf`) files. It is **not** Wan/`sd.exe` GGUF. Anikai includes an **experimental** runner (`anikai_lance_gguf_infer.py`); production T2I/T2V should use **Original (HF)** until a full Lance GGUF loader lands in diffusers/ComfyUI-GGUF.

**Runtime layout target** (dedup disk, keep separate pip envs): [`../runtime-shape/MEDIA_RUNTIME_LAYOUT.md`](../runtime-shape/MEDIA_RUNTIME_LAYOUT.md).

---

## Open implementation items

- Wire character/scene upload slots on Video → Standard
- Persist handoff payloads into slot state
- Video weaving ingest from concept-scene timeline
- 3D weaving scene graph + import from generation outputs
- Others lanes beyond Games sprite
- CDN-delivered runtime packs (gate UI already structured for install + model only)
- Lance GGUF inference runner (weights + catalogue wired; generation stub)
