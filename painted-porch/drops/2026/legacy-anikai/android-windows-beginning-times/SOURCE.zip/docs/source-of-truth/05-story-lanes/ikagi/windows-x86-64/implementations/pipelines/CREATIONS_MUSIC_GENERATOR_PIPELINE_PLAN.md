# Creations music generator pipeline plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define the in-app Creations music generator pipeline (parallel to Sprite Maker style planning) so generation stages, model roles, and output artifacts are explicit before deep implementation.

---

## Scope

This file covers:

- one-button music generation flow in Creations screen,
- stage responsibilities and runtime-family role boundaries,
- artifact outputs and handoff contracts,
- user-facing progress/fail-state behavior.

This file does **not** replace:

- music generation capability recommendations (generation doc),
- voice+music mixed workforce doc (cross-domain pipeline),
- engine-specific inference docs.

---

## Pipeline DAG (Creations music generator)

| Stage | Job | Typical owner |
|-------|-----|----------------|
| **M0 - Input normalize** | prompt/mood/tempo/length/style tags normalized into run spec | app layer |
| **M1 - Composition plan** | chord/progression/form scaffold | parametric engine or lightweight model lane |
| **M2 - Source material generate** | motif loops/melody/rhythm stems produced | deterministic lane and/or neural short-loop lane |
| **M3 - Arrangement and layering** | stems arranged into timeline sections | app orchestration + runtime helpers |
| **M4 - FX and polish** | EQ/compression/reverb/cleanup pass | DSP chain + optional neural restoration |
| **M5 - Mix/master render** | final WAV/PCM render + loudness normalization | audio render engine |
| **M6 - Pack/export** | save stems/master + metadata and preview artifacts | Creations export/storage contract |

---

## Runtime role map

| Runtime form | Pipeline role |
|--------------|----------------|
| **Parametric/deterministic** | M1-M3 baseline guaranteed lane |
| **Sample + FX chain** | M3-M5 core production lane |
| **MIDI + soundfont/SFZ** | M2-M5 optional lightweight instrument lane |
| **ONNX neural loop model** | M2 additive creative lane |
| **ONNX stem utility model** | M4 helper cleanup/separation lane |

Rule: runtime selection must be explicit in metadata and user-visible status.

---

## Creations UX contract (music generator screen)

1. User selects intent/preset (`FAST`, `BALANCED`, `QUALITY`) and optional advanced controls.
2. One generate action starts full M0-M6 pipeline.
3. Progress surface shows current stage and runtime source.
4. Cancel/thermal events produce explicit partial/fail state.
5. Completed run lands in Creations with:
   - master track,
   - optional stems,
   - metadata trail (runtime ids, preset, durations, stage timings).

---

## Failure and degraded-state policy

- no silent cloud fallback for local-labeled runs,
- if a stage cannot execute, mark run `degraded` or `failed` with reason,
- partial outputs may be kept only when labeled and non-misleading.

---

## Phased implementation

### Phase 0 - scaffold

- define run spec schema and stage event logging.

### Phase 1 - baseline pipeline

- operationalize M0-M6 using deterministic/sample lanes only,
- ensure reliable master export and metadata trail.

### Phase 2 - neural augment

- add ONNX loop/stem helper stages behind device/preset gates.

### Phase 3 - advanced creative controls

- variation/regenerate-from-stage and multi-version branching support.

---

## Validation gates (before "operational" claim)

- one full M0-M6 run succeeds and exports valid artifacts in app,
- progress and stage labels match actual execution path,
- failed stages are surfaced honestly with no silent route-switching,
- repeated runs are stable under cancellation and thermal pressure.

---

## Linked docs

- `implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`
- `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`

---

## Linked todo

- `todo/mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial Creations music generator pipeline plan created from local media split requirements. |
