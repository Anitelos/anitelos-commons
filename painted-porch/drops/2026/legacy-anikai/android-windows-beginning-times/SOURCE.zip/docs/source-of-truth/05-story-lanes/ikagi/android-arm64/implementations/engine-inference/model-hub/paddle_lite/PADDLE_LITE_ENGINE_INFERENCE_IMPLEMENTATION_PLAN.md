# Paddle Lite engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: reserve an ANIKAI lane for **Paddle Lite** (PaddlePaddle mobile inference), useful where models originate from the Paddle ecosystem (often OCR, detection, and Asian-market vision stacks).

---

## Scope

This file covers Paddle Lite for:

- JNI/native inference sessions with `.nb` or documented Paddle Lite model bundles,
- ARM CPU / GPU / NPU delegate hooks supported by Paddle Lite on Android,
- Swarm/Sentience helper tasks when manifest declares `paddle_lite`.

This file does **not** replace ONNX or LiteRT as default cross-ecosystem formats.

---

## Role model (single truth)

| Paddle Lite lane | Ownership |
|------------------|-----------|
| OCR / detection helpers | Strong candidate use case. |
| Primary companion reasoning | Not assumed. |

---

## Android implementation plan (stub checklist)

- [ ] Paddle Lite Android library ABI matrix and size budget.
- [ ] C++/JNI bridge pattern aligned with other native engines.
- [ ] Adapter id `paddle_lite` + manifest schema for Paddle inputs/outputs.
- [ ] Conversion/export notes from Paddle training repos.

---

## Open decisions

- first reference model (e.g. OCR) vs broader CV,
- coexistence with NCNN/MNN for similar workloads.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)
- [`../mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for Paddle Lite mobile inference lane. |
