# 3D generation (Windows desktop)

Authority for **image→3D**, **text→3D**, and the Media Magic **3D weaving** desk.

## Registry

- `anikai-desktop/assets/about-guide/threed-registry.json` (`testedStacks` + `researchCandidates` watchlist)
- About → **Generating media with ANIKAI → 3D**
- Research integrations (TriSplat, PhysX-Omni, CubePart, MoCapAnything V2): [`THREED_RESEARCH_CANDIDATES.md`](./THREED_RESEARCH_CANDIDATES.md)

## Flows

| Flow | Input | Output | Desktop today |
|------|--------|--------|----------------|
| Image → splat | PNG still | `.ply` (Gaussian splat) | **SHARP ONNX** (`onnx-sharp-3d`) |
| Image → mesh | PNG still | Mesh + UV | TripoSR / TRELLIS — planned |
| Text → 3D | Prompt | Mesh / GLB | Hunyuan3D-2 Diffusers — planned |
| Text + image → 3D | Prompt + still | Refined asset | Hunyuan3D-2 — planned |

## Media Magic

- Header **Media: 3D** → **3D weaving**
- **Viewport** (orbit splat/mesh) and **UV texture** viewer — UI placeholders; WebGL wiring follows mesh runners.
- Image-lane IA and designer contracts that improve 3D handoff are tracked in [`../../companion-surface/MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`](../../companion-surface/MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md).
- Video-side IA (specialist engines vs curated vs weaving) is tracked in [`../video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`](../video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md); 3D engine tabs should support reciprocal links back to relevant Image designers.

## Not 3D

- Imaging **depth overlay** (2D parallax) stays on Image post-process / Still motions.
- **ByteDance Lance** (unified still + video) is under **Media → Video → Lance** / About **Video** catalogue — not 3D.
- **Apple LiTo** (`apple/ml-lito`) — image→3D Gaussians with view-dependent appearance; catalogue stack `apple-lito-image3d`.

### LiTo staging

```bash
cd anikai-desktop
npm run stage-lito
# optional ~3 GB checkpoint:
# set ANIKAI_STAGE_LITO_DOWNLOAD_CKPT=1
```

Repo + venv land under `resources/lito-runtime/`. **Get pack** on `apple-lito-image3d` downloads `lito_dit_rgba.ckpt` (~3 GB).

**In-app generate (Windows):** Media Magic → **3D → LiTo → Generate (WSL)** runs inference inside WSL without leaving Anikai; the `.ply` path shows in the viewport + Media console.

**One-time WSL setup** (after `npm run stage-lito` + Get pack):

```bash
wsl -d Ubuntu -e bash /mnt/c/path/to/anikai-desktop/scripts/wsl-setup-lito.sh
```

Optional env: `ANIKAI_WSL_DISTRO=Ubuntu`
