# TODO — GGUF imaging generation on desktop (Windows x86-64, mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-14 |

---

## Source implementation docs

- `implementations/generation/imaging/IMAGING_GENERATION_INDEX.md` (entry + per-model checkboxes)
- `implementations/generation/imaging/models/` (per-repo / stack detail)
- `implementations/generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/generation/imaging/diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md` (non-native stacks)
- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `implementations/engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` (post-pass / alternate primary)

---

## Intent

- Prove **GGUF diffusion decode** end-to-end: bytes on disk + visible UI + honest failure when adapter cannot decode.
- Wire **capability** flags so imaging UI never appears without engine + manifest agreement.
- Integrate optional **ONNX post** chain without masking GGUF primary failures.

---

## Checklist (working)

- [ ] Canonical output format (e.g. PNG) written and re-opened successfully after generation.
- [ ] `diffusion_decode` false → imaging entry points hidden or labeled unavailable.
- [ ] Documented preset / resolution caps tied to VRAM probe where applicable.
- [ ] If ONNX post is enabled, chain fails with explicit reason when ORT session fails.

---

## Linked operations

- `todo/mid-scope/TODO_ONNX_ENGINE_INFERENCE_DESKTOP.md`
- `../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-10 | Created GGUF imaging desktop todo linked to imaging generation plan and engine plans. |
| 2026-05-14 | Linked lane index + per-model `models/` + Diffusers stub. |
