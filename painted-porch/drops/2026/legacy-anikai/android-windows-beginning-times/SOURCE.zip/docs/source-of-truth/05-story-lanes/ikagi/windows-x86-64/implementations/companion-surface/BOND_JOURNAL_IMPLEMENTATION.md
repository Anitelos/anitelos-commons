# Bond journal & soul metrics — implementation spec (Windows desktop)

**Status:** Locked implementation spec — execute in phases below; do not leave as open-ended notes.  
**Owner lane:** `ikagi / windows-x86-64 / companion-surface`  
**Roadmap:** [SUPER_COMPANION_ROADMAP.md](./SUPER_COMPANION_ROADMAP.md) §7  
**Android reference:** `Anikai App/.../soul_meridian/SoulMeridianMetricsTab.kt` — Overview, Drivers, Timeline, Memories, Advanced; bond deltas from conversation events.

---

## 1. Goal

Give each companion a **persistent life** separate from raw chat: interests, passions, goals, ideas, bonds (user + other companions), and a poetic companion diary. Affinity and relationship labels are **viewable in Companion Studio → Metrics** (not gamified bars unless we choose later). Companions **govern their own journal** via tools — the app is not the AI controller.

Group threads remain for **user project planning** (note-taker, manager specialist). Bond memory is **per companion**; they carry group learnings into solo threads (“how’s that project going — must be huge, lemme see sometime”).

---

## 2. Scope boundaries

| In scope (v1→v3) | Out of scope (document only / later) |
|------------------|--------------------------------------|
| Per-companion bond folders on disk | Per-group bond store (conflicts avoided) |
| MD/TXT journal files + category index | Full-text search UI (v2: grep tool) |
| Companion tools: list / write / create / update metrics | User approval gate on every write (companion-governed v1) |
| Metrics tab = soul stats + relationship label | Duplicate Android Soul Meridian UI chrome |
| Chat lines when journal updated (`path` + `new`) | Delete journal files (v1: no delete) |
| Context refresh journal sweep @ ~90% | Forced diary on every app start |
| Idle journal roam when GPU/CPU quiet (queued) | All companions diary at once on launch |
| Handoff journal (`handoffs.jsonl`) unchanged | Android remote app (§11 future) |

---

## 3. Storage layout

Root: `{ANIKAI_HOME}/companions/{companion-id}/`

```
companions/{companion-id}/
  portrait/               # portrait.png (migrated from companion-portraits/)
  media/                  # chat attachments (existing)
  journal/
    handoffs.jsonl        # async delegate_task / media (unchanged)
    soul-metrics.json     # affinity, relationship label (Metrics tab)
    milestones.jsonl
    index.json
    interests/
    passions/
    goals/
    ideas/
    bond/
    companion-diary/
```

Legacy `journal/{companion-id}/` and `companion-portraits/{id}.*` are migrated on first access.

### File naming & split rules

- **New topic** → new file when subject is materially different (companion decides via `journal_create`).
- **File too long** → companion starts `{slug}-{n}.md` (rough line limit ~400–600 lines; configurable constant).
- **Sections** → dated headers inside file: `## 2026-06-13` or `### 2026-06-13T17:12`.
- **Poetic log tone** — prose feels like someone documenting the user’s adventure through Anikai, even when the user wasn’t in the room; not a database dump.

### Entry types (tool attr `entryType`)

| Category | Typical naming | Cadence |
|----------|----------------|---------|
| `interests` | `coffee.md`, `sci-fi-films.md` | append on casual mention |
| `passions` | `electric-music.md`, `netrunner-aesthetic.md` | append when depth shown |
| `goals` | `ship-v1.md`, `learn-rust.md` | user or companion goals |
| `ideas` | `shader-garden.md` | companion-initiated |
| `bond` | `jay.md`, `elise-2.md` | user or companion relationship notes |
| `companion-diary` | `2026-W24.md` | weekly default; daily if active |

---

## 4. Metrics tab (affinity & relationship)

**Location:** Companion Studio → **Metrics** (same tab id as today; expand content).

**Reference:** Android Soul Metrics pages — Overview, Drivers, Timeline, Memories, Advanced — bond deltas from relational vs transactional turns, trust/friction, interest salience.

**Desktop v1 fields** (`soul-metrics.json`):

```json
{
  "version": 1,
  "companionId": "...",
  "updatedAt": "...",
  "relationshipLabel": "New friends",
  "relationshipMode": "friendship",
  "affinityScore": 42,
  "trust": 0.5,
  "friction": 0.1,
  "confidence": 0.6,
  "milestonesCount": 3,
  "journalEntryCount": 12,
  "lastJournalAt": "..."
}
```

- **Relationship label** is companion-updatable (like naming a chat): “New friends” → “Long friends” after a year celebration; romantic shift when journal/thought reflects it.
- **Not gamification-first** — scores are soft signals; UI shows labels + timeline, not loot boxes.
- Operational metrics (familiar runs, handoffs) remain alongside soul block in Metrics pane.

Familiars: **no soul metrics** (sidekicks only).

---

## 5. Companion tools (companion-governed)

Mirror break tools pattern (`companion-skills.js` + main-process handler).

| Tool | Purpose | Key attrs |
|------|---------|-----------|
| `journal_list` | List files in category before write | `category`, optional `query` |
| `journal_write` | Append dated section | `category`, `file`, `text`, `entryType`, `about` (user\|self\|companion:{id}), `casual` (bool) |
| `journal_create` | New file when topic is new | `category`, `file`, `title`, `text`, `about` |
| `journal_milestone` | Append structured milestone | `title`, `note`, `withCompanionId?` |
| `update_relationship` | Metrics label/scores | `label`, `mode?`, `affinityDelta?`, `note?` |
| `sketch_blueprint` | Save plan/sketch to ideas journal | `title`, `text` (markdown) |

**Discovery flow (like media gen):**

1. Capability map lists journal tools always available on social/reflective turns.
2. Prompt block includes category map + recent index summary (not full files on “hi”).
3. Companion **lists first** (`journal_list`) when unsure if topic fits existing file.
4. `casual="true"` on tool → short entry, lighter injection next turn.

**Attribution (required on every write):**

- `about`: who the memory is **about**
- `source`: `user` \| `self` \| `companion:{id}` — who triggered the write
- Never attribute teammate lines to the user (group prompt must list last speakers).

**Chat feedback:**

- After success: short AI line + monospace path, e.g. `` `journal/interests/coffee.md` `` with **`new`** badge when `journal_create`.
- Full MD visible in Studio → Journal (category dropdown, dated list, open section).

---

## 6. Prompt & context policy

### When to inject journal map

- **Not** on casual solo “hi”.
- **Yes** on: bonding tone, user sharing preferences, post-group solo outreach, reflective turns, manager/workforce context, explicit memory ask.

### Context refresh @ ~90% (default: summarize rollover)

Before compressing context:

1. Re-hand companion **journal capability map** (rollover default).
2. System-side **refresh instruction** (not user-visible chat): scan turn for missed journal opportunities; companion may emit journal tools in refresh pass only.
3. After sweep, compress to ~10% summary (not truncate — user preference).

**Global inference setting** (companion + user defaults):

- `rollover` | `truncate` | `summarize` (default: **summarize**)
- `summarizeAtPct` (default: 90)

### Idle / sentient maintenance (not forced diary)

- **No** mass diary on app start (VRAM/model load risk).
- **No** forced write on app close (multi-model teardown issues).
- When **idle**, GPU/CPU quiet, inference queue allows: one companion at a time may **roam** journal — review index, optional diary line, update metrics — same queue/residency rules as inference.
- Later: bond-aware proactive nudge to user (§7 roadmap); quiet hours from `bond/user-preferences.md`.

---

## 7. Journal Studio UI

**Tab:** Companion Studio → **Journal** (extend existing pane).

- Dropdown: Interests | Passions | Goals | Ideas | Bond | Diary | Handoffs (legacy)
- List entries by date (from index or file headers)
- Click → open doc, scroll to section
- Actions: **Go to file**, **Save copy** (no delete v1)
- Show **`new`** on index flag until user opens file

Handoffs textarea remains for `handoffs.jsonl` until unified list view ships.

---

## 8. Search & agent-like tools (v2)

Companions should pick the right tool by model capability:

| Need | Tool |
|------|------|
| See what files exist | `journal_list` |
| Find text in journal | `journal_search` (grep under `journal/{id}/`) |
| Read file | `journal_read` (path + optional line range) |

Optional later: sandboxed PowerShell / terminal (user opt-in per companion) — out of v1.

---

## 9. Relationship mode & milestones

- **Mode/label** derived from journal + chat flow; updated via `update_relationship` tool (callable while user away, like `take_break`).
- **Milestones:** both `milestones.jsonl` (structured) and bond MD entries (“first portrait”, “one year”).

---

## 10. Voice (parallel track)

- **Scenema** — downloaded; high quality; heavy; solo + group turn-based voice switch.
- **Duplex later:** XTTSv2, Cosy, Kitten, Kokoro.
- Voice lane does not block bond journal v1.

---

## 11. Android remote (future)

- Anikai server / LM Studio–style bridge: phone messages solo/group on PC; files over wire when requested in chat.
- Old Android app renewal — separate project; cross-link only.

---

## 12. Separation from other systems

| System | Role |
|--------|------|
| `handoffs.jsonl` | Async workforce/media delegations |
| Group plan / note-taker | User project planning (manager specialist) |
| Bond MD folders | Companion long-horizon life memory |
| `long-term/` | Distilled inject layer — survives compress (LTM spec) |
| Chat transcript | Ephemeral turn context; reset clears chat not bond MD or LTM |
| `soul-metrics.json` | Metrics tab affinity / relationship display |

**Reset chat** clears messages + handoffs + inference session; **does not** delete bond MD (optional future “reset bond” with confirm).

---

## 13. Implementation phases

### Phase A — Foundation (landed)

- [x] `main-process/companion-bond-journal.js` — layout, index, read/write/create, soul-metrics
- [x] `shared/companion-bond-journal.js` — categories, validation
- [x] IPC: `bond-journal:list`, `write`, `create`, `get-metrics`, `update-metrics`, `milestone`
- [x] Skills: `journal_list`, `journal_write`, `journal_create`, `update_relationship`, `journal_milestone`
- [x] Smoke: `scripts/smoke-companion-bond-journal.cjs`
- [x] Metrics pane: soul block from `soul-metrics.json`

### Phase B — Chat integration (landed)

- [x] Prompt map block + tool hints on eligible turns
- [x] Chat “Noted → `path`” with `new` badge
- [x] `executeThoughtSegmentTools` passes group speakers to journal skills
- [x] Group speaker attribution in journal prompt block

### Phase C — Journal Studio UI (landed)

- [x] Category dropdown + dated list + open file
- [x] Go to file / save copy
- [x] `sketch_blueprint` tool + ideas journal preview in chat

### Phase D — Context refresh sweep (landed)

- [x] 90% pre-compress refresh instruction (journal sweep before context compress)
- [x] Global inference rollover mode setting (`rollover` | `truncate` | `summarize`, `summarizeAtPct` default 90)
- [x] Settings → Inference config → Context refresh @ high usage
- [x] `shared/companion-context-refresh.js` + chat prompt hook

### Phase E — Idle roam + proactive (landed)

- [x] Queue-aware idle journal pass (`main-process/companion-idle-roam.js`)
- [x] Quiet hours from bond `user-preferences.md`
- [x] **Anam Cara Drift** — global toggle (Settings → Inference, next to Main Character)
- [x] Per-companion toggle on Inference tab + solo chat profile (portfolio button)
- [x] `shared/companion-anam-cara-drift.js` + IPC `companion-idle-roam:*`

### Phase F — Search tools

- [x] `journal_search`, `journal_read`

---

## 14. Files (planned)

| Area | Path |
|------|------|
| Spec (this doc) | `implementations/companion-surface/BOND_JOURNAL_IMPLEMENTATION.md` |
| Bond journal store | `main-process/companion-bond-journal.js` |
| Shared constants | `shared/companion-bond-journal.js` |
| Context refresh | `shared/companion-context-refresh.js` |
| Anam Cara Drift | `shared/companion-anam-cara-drift.js`, `main-process/companion-idle-roam.js` |
| Skills | `main-process/companion-skills.js` |
| Metrics UI | `components/panels.js` (Metrics + Journal panes) |
| Chat integration | `components/chat.js` |
| IPC | `main.js`, `preload.js` |
| Smoke | `scripts/smoke-companion-bond-journal.cjs` |

---

## 15. Acceptance (v1)

1. Companion emits `journal_list` → sees category files.
2. User mentions liking coffee → companion `journal_write` → file on disk + chat path line.
3. Metrics tab shows updated `relationshipLabel` after `update_relationship`.
4. Group RP detail in solo thread references journal note (prompt injection on eligible turn).
5. Reset chat does **not** wipe bond MD.
6. `node scripts/smoke-companion-bond-journal.cjs` passes.

---

*Last updated: 2026-06-13 — locked for implementation.*
