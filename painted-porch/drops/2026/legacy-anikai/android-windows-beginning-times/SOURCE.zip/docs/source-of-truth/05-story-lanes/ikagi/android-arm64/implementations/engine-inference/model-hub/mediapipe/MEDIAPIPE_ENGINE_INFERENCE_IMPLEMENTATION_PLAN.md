# MediaPipe engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define how MediaPipe becomes a real ANIKAI runtime lane (not just a mention in backlog text), including Android build/JNI wiring, capability manifests, app integration points, and execution gates across vision/recognition workflows.

---

## Scope

This file covers MediaPipe as an inference engine for:

- vision helper tasks (segmentation, landmarks, gesture, pose, object signals),
- companion-adjacent understanding support (structured signals, not generative pixels),
- pipeline pre/post assists for imaging and roaming/reflex surfaces,
- capability-pack style model ownership in ANIKAI model hub.

This file does **not** replace:

- image generation quality contracts in `generation/imaging/`,
- multi-model stage choreography contracts in `pipelines/`,
- anti-drift global log in `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`.

---

## What MediaPipe is (and why useful here)

MediaPipe is a runtime + task graph stack for fast, on-device perception (mostly image/video/audio feature extraction). In ANIKAI terms it is a **specialist inference engine**, not the companion chat brain and not the diffusion pixel generator.

ANIKAI value:

- low-latency helper inference for camera/gallery assets,
- structured outputs (masks, landmarks, bounding boxes, gestures) that other lanes can consume,
- good fit for "capability packs" where users see engine type + host + role badges.

---

## ANIKAI role model (single truth)

| Role | MediaPipe ownership |
|------|----------------------|
| **Primary pixel generation** | Not owned by MediaPipe (belongs to diffusion/ONNX/native image adapters). |
| **Perception / recognition helpers** | Core MediaPipe ownership where task pack exists and is validated on-device. |
| **Pipeline assist stage** | Allowed as pre/post helper for segmentation/masking/keypoints before or after generation stages. |
| **Companion context feeder** | Allowed via structured summaries (JSON/tensors/metadata), not direct replacement for VLM or LLM lanes. |

Rule: MediaPipe lane is "operational" only after adapter + capability manifest + runtime task session + artifact output are all passing.

---

## Engine implementation plan (Android build + runtime)

### 1) Packaging and dependency strategy

Pick one startup path and lock it in docs before coding:

1. **MediaPipe Tasks AAR path (recommended first ship)**  
   - add MediaPipe Tasks dependency in Android module,
   - stage `.task`/model assets under ANIKAI model storage contract,
   - bind runtime by explicit adapter id + task type.
2. **Custom native graph/JNI path (later, optional)**  
   - add native target in `Anikai App/src/main/cpp/CMakeLists.txt`,
   - expose JNI bridge with strict input/output contracts,
   - use only when Tasks API cannot satisfy needed capability/latency.

### 2) JNI/native checklist (if custom path is used)

- [ ] CMake target added with ABI strategy aligned to app build matrix.
- [ ] JNI bridge class in Kotlin (`com.anikai.media.vision` or equivalent) with IO-thread execution only.
- [ ] Native input contract documented (bitmap format, tensor shape, orientation).
- [ ] Native output contract documented (mask PNG, landmarks JSON, confidence bundle).
- [ ] Error taxonomy mapped to user-visible failure states (no silent "worked" fallback).
- [ ] Memory/thermal release path verified (`close`, cancellation, lifecycle cleanup).

### 3) Task manifest contract (required even for AAR path)

Each MediaPipe pack/task row must declare:

- adapter id (example: `mediapipe_face_mesh_v1`),
- task type (`segmentation`, `face_landmark`, `hand_landmark`, `pose`, `gesture`, etc.),
- accepted inputs (still image, frame stream, audio chunk),
- output artifact schema (mask PNG path, JSON schema, confidence fields),
- preset fit (`FAST`/`BALANCED`; `QUALITY` only when justified),
- device gate hints (RAM, thermal policy, optional GPU delegate),
- lane eligibility (Swarm callable / pipeline callable / reflex callable).

---

## App integration map (where it lands in ANIKAI)

### A) Engine registry / model hub

- add `MediaPipe` engine family rows under engine-inference model hub,
- ensure model hub cards show host + engine + capability badges (matching local media log direction),
- bind packs to capability flags, not vendor names.

### B) Swarm / specialist routing

- map MediaPipe capabilities to relevant `TaskSpecialistRegistry` lane ids (segmentation/mask/depth/keypoints equivalents),
- enforce explicit adapter resolution before execution,
- fail visibly when task pack missing or unsupported.

### C) Imaging pipeline assists (not generation replacement)

- pre-generation: optional segmentation/mask extraction from user refs,
- post-generation: landmark/mask checks for consistency tooling,
- feed outputs to pipeline stages without claiming MediaPipe generated final pixels.

### D) Reflex / roaming support

- route lightweight perception checks into reflex packets where useful,
- write structured evidence only (confidence + tagged findings),
- keep wake/alert thresholds in reflex docs, not hidden in task wrappers.

### E) Companion surfaces

- expose feature outputs as helper artifacts (JSON/mask overlays) for companion reasoning and UX explanation,
- maintain source labeling (`MediaPipe local`) in logs/status for honesty.

---

## Phased delivery plan (slow, buildable order)

### Phase 0 - skeleton (Not started)

- create MediaPipe adapter interface + no-op implementation,
- add manifest row schema and validation hooks,
- wire diagnostics path in operations logging.

### Phase 1 - first operational helper (Started target)

- ship one capability pack end-to-end (recommend segmentation),
- input: image URI -> output: mask artifact + metadata JSON,
- bind one Swarm lane to this adapter with visible status/errors.

### Phase 2 - multi-task pack (In progress target)

- add second/third tasks (face mesh or hand/pose landmarks),
- define shared artifact schema and storage paths,
- add preset and device-class gating behavior.

### Phase 3 - pipeline/reflex integrations (Operational target)

- imaging pipeline consumes MediaPipe helper outputs where contract says so,
- reflex consumes selected findings through packet schema integration,
- update coverage/todo reports and operations index to keep tracking honest.

---

## Verification gates (before "operational" claim)

- one MediaPipe task runs on-device from app-selected asset and writes artifact,
- artifact opens and schema validates in app flow,
- Swarm lane invokes adapter directly (no provider masquerade),
- failure states are explicit and user-visible,
- thermal/cancel lifecycle is stable under repeated runs.

---

## Open decisions

- first ship task: segmentation vs landmark first,
- AAR-only first milestone vs immediate custom JNI lane,
- minimum device class for enabling continuous-frame tasks.

---

## Linked todos

- `todo/mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial MediaPipe engine inference implementation plan split from local media mega-log, including Android build/JNI checklist and app integration map. |
