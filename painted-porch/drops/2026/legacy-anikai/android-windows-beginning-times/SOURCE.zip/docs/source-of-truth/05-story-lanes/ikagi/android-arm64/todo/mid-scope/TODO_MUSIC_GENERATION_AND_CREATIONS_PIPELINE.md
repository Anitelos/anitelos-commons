# TODO — music generation and Creations pipeline (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation docs

- `implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/pipelines/CREATIONS_MUSIC_GENERATOR_PIPELINE_PLAN.md`

---

## Intent

- Track music generation capability planning and Creations pipeline implementation together in one execution lane.
- Ensure local-first "real PCM on disk" contract is implemented honestly.
- Keep model/runtime recommendations separate from pipeline stage wiring, but delivered as one workstream.

---

## Checklist (working)

- [ ] Lock baseline local music generation form (parametric/sample/MIDI) and output schema.
- [ ] Implement M0-M6 Creations pipeline baseline with reliable master export.
- [ ] Add stage progress + runtime metadata trail in UI/output.
- [ ] Define and validate FAST/BALANCED/QUALITY behavior for music generation.
- [ ] Integrate first neural additive lane (ONNX loop or stem utility) behind explicit gating.
- [ ] Enforce explicit degraded/fail behavior without silent cloud fallback.

---

## Linked operations

- `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created single todo bridge for music generation implementation + Creations music pipeline plan. |
