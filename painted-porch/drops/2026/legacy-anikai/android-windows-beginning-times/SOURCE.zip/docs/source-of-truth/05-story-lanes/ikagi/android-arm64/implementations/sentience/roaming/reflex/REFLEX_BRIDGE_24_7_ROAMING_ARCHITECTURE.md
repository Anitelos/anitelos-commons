# Reflex Bridge 24/7 Roaming Architecture

Status: Draft source-of-truth  
Scope: Runtime architecture and role boundaries for Reflex vs Main AI

## 1) Purpose

Reflex is the always-on bridge between app signals and the main AI.  
It allows continuous roaming and sensing without keeping the main model awake at all times.

Primary goal:
- Keep power/resource usage low while preserving high-quality main-model reasoning.

## 2) Core Principle: Mind Sovereignty

Main AI keeps full ownership of:
- reasoning
- policy
- interpretation
- user-facing decisions
- final action planning

Reflex must not:
- route cognition policy
- force intent outcomes
- replace or "babysit" the main model's logic
- act as authority on truth

Reflex is a scout/reporter, not a director.

## 3) Runtime Roles

### Reflex (always-on, low-cost lane)
- Runs 24/7 in low-power mode.
- Collects lightweight app/system signals.
- Produces compact factual reports with confidence and known gaps.
- Raises wake events when main reasoning is needed.

### Main AI (wake-on-demand lane)
- Sleeps when not required.
- Wakes only on relevant reflex events or direct user interaction.
- Re-validates reflex findings against broader context (chat, journal, memory, folders).
- Decides next steps independently.

## 4) What Reflex Can Monitor

Allowed signal families:
- power and thermal state
- time windows/schedules
- roaming pre-check conditions
- notification summaries
- folder/file drift snapshots
- app-level health/status deltas

These are observations only. They are not final conclusions.

## 5) Reflex -> Main Report Contract

Reflex handoff must be structured and non-directive.

Required fields:
- `eventType`: `roam_precheck | file_candidate | notif_digest | thermal | power | schedule`
- `summary`: one-line factual summary
- `evidence`: concrete observations (timestamps, counters, paths)
- `candidateLocations`: optional list of likely paths/targets
- `confidence`: float `0.0..1.0`
- `knownGaps`: list of uncertainty/missing coverage
- `requiresMainReasoning`: always `true`
- `issuedAt`: epoch timestamp

Forbidden fields:
- direct action commands
- policy overrides
- "must/always do X" instructions

## 6) 24/7 Roaming Wake Flow

1. Reflex idles in low-power sensing loop.  
2. Trigger arrives (state change, schedule tick, notification delta, roam check).  
3. Reflex emits a report packet.  
4. Main AI wakes and reads packet as a hint, not authority.  
5. Main AI validates and expands search/context as needed.  
6. Main AI either:
   - proceeds with a user-approved action,
   - asks for clarification,
   - or defers/requeues.

## 7) Reliability Rules

- No silent directive behavior from reflex.
- Main AI must verify reflex candidate paths before acting.
- Main AI should check sibling/parent context if reflex points to incomplete locations.
- Low-confidence packets should be down-ranked, not blindly followed.
- If reflex misses something, main AI remains free to broaden investigation.

## 8) Power and Resource Intent

Expected behavior:
- Reflex keeps "small senses" awake continuously.
- Main AI stays asleep unless reasoning is needed.
- Device avoids permanent heavy-model residency.

This is the mechanism for practical 24/7 roaming without battery drain from always-on large-model inference.

## 9) Voice Studio Alignment

Current preview strategy is compatible:
- Reflex-first dynamic preview line generation.
- Preview-only scope for reflex text shaping.
- Main AI reasoning remains untouched.

## 10) Non-Goals (for now)

- Reflex controlling main prompt policy
- Reflex deciding tool/image/code intent on behalf of main AI
- Reflex replacing main-model reasoning in user conversations

## 11) Future Implementation Modules (planned)

- `ReflexReporterService`: always-on signal collector + report emitter
- `ReflexEventQueue`: bounded queue for wake packets
- `MainWakeCoordinator`: validates packet and wakes main AI when justified
- `ReflexDiagnosticsPanel`: visibility into packet counts, confidence, misses, wake reasons

This architecture keeps Reflex useful, efficient, and safely separated from the model's cognitive core.
