﻿# Android arm64 - doc progress and checkbox snapshot

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Operational (generated digest) |
| **Last reviewed** | 2026-05-06 |

**Generated:** 2026-05-06 19:19:48 UTC  
**Regenerate (repo root):** `powershell -NoProfile -ExecutionPolicy Bypass -File docs/source-of-truth/05-story-lanes/ikagi/android-arm64/scripts/Generate-DocProgressReport.ps1`
**Optional (counts + roll-ups only):** append ``-NoDrilldown`` to skip the verbatim open-checkbox lists.

**Scope:** all `*.md` under `implementations/` (except `DOC_STATUS_HEADER.md`) and all `*.md` under `todo/`. Parses the `| Field | Value |` table for **Doc staging** and **Operations**. Task checkboxes are `- [ ]` / `- [x]` lines outside fenced code blocks. **Drill-down** lists each open item's line text by file (omit with `-NoDrilldown`).

---

## Summary

| Metric | Value |
|--------|-------|
| Implementation markdown files | 34 |
| Todo markdown files | 24 |
| Files missing **Doc staging** cell | 10 |
| Files missing **Operations** cell | 10 |
| Open checkboxes (total) | 248 |
| Done checkboxes (total) | 24 |

---

## Roll-up: Doc staging

| Doc staging | Files |
|-------------|-------|
| — | 10 |
| Started | 48 |

---

## Roll-up: Operations

| Operations | Files |
|------------|-------|
| — | 10 |
| In progress | 14 |
| Needs revisit | 1 |
| Needs work | 9 |
| Not started | 22 |
| Operational (check procedure) | 1 |
| Operational (generated digest) | 1 |

---

## Per file (implementations)

| Path | Doc staging | Operations | Open | Done | Total |
|------|-------------|------------|------|------|-------|
| `anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md` | Started | Not started | 0 | 0 | 0 |
| `companion-surface/BOND_STORE_ISSUES_AND_FIXES_PLAN.md` | — | — | 45 | 24 | 69 |
| `DOC_PROGRESS_SNAPSHOT.md` | Started | Operational (generated digest) | 0 | 0 | 0 |
| `engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | Not started | 5 | 0 | 5 |
| `engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | In progress | 5 | 0 | 5 |
| `engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | Not started | 5 | 0 | 5 |
| `engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | Not started | 6 | 0 | 6 |
| `engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | Not started | 5 | 0 | 5 |
| `engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | Not started | 5 | 0 | 5 |
| `engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md` | Started | In progress | 0 | 0 | 0 |
| `engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md` | Started | Not started | 5 | 0 | 5 |
| `generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md` | Started | Not started | 0 | 0 | 0 |
| `generation/audio/voice/CLOUD_VOICE_PROVIDER_PLAN.md` | Started | In progress | 4 | 0 | 4 |
| `generation/audio/voice/COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md` | Started | In progress | 5 | 0 | 5 |
| `generation/audio/voice/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md` | Started | Needs work | 5 | 0 | 5 |
| `generation/audio/voice/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md` | Started | In progress | 5 | 0 | 5 |
| `generation/audio/voice/VITS_RUNTIME_IMPLEMENTATION_PLAN.md` | Started | Needs work | 5 | 0 | 5 |
| `generation/audio/voice/VOICE_RUNTIME_IMPLEMENTATION_PLAN.md` | Started | In progress | 0 | 0 | 0 |
| `generation/audio/voice/XTTS_RUNTIME_IMPLEMENTATION_PLAN.md` | Started | Needs work | 5 | 0 | 5 |
| `generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md` | Started | Not started | 0 | 0 | 0 |
| `generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md` | Started | Not started | 0 | 0 | 0 |
| `generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md` | Started | Needs work | 0 | 0 | 0 |
| `generation/imaging/PORTRAIT_PACK_SCHEMA.md` | Started | Needs work | 0 | 0 | 0 |
| `generation/imaging/sprite-quality-floor/README.md` | — | — | 0 | 0 | 0 |
| `generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md` | Started | Needs work | 9 | 0 | 9 |
| `generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md` | Started | Not started | 0 | 0 | 0 |
| `OPERATIONS_INDEX.md` | Started | Needs work | 0 | 0 | 0 |
| `pipelines/CREATIONS_MUSIC_GENERATOR_PIPELINE_PLAN.md` | Started | Not started | 0 | 0 | 0 |
| `pipelines/IMAGING_PIPELINE_QUALITY_STACK.md` | Started | Needs work | 0 | 0 | 0 |
| `pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md` | Started | In progress | 0 | 0 | 0 |
| `resona/RESONA_UNIFICATION_PLAN.md` | — | — | 1 | 0 | 1 |
| `sentience/roaming/reflex/REFLEX_BRIDGE_24_7_ROAMING_ARCHITECTURE.md` | — | — | 0 | 0 | 0 |
| `sentience/roaming/reflex/REFLEX_BRIDGE_PACKET_SCHEMA_AND_WAKE_THRESHOLDS.md` | — | — | 0 | 0 | 0 |
| `TODO_COVERAGE_REPORT.md` | Started | Operational (check procedure) | 0 | 0 | 0 |

---

## Per file (todo)

| Path | Doc staging | Operations | Open | Done | Total |
|------|-------------|------------|------|------|-------|
| `high-scope/README.md` | — | — | 0 | 0 | 0 |
| `high-scope/TODO_GAME_MAKER_SHOWPIECE.md` | Started | In progress | 9 | 0 | 9 |
| `low-scope/README.md` | — | — | 0 | 0 | 0 |
| `mid-scope/README.md` | — | — | 0 | 0 | 0 |
| `mid-scope/TODO_BOND_MEMORY_THREAD_FIXES.md` | Started | In progress | 4 | 0 | 4 |
| `mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md` | Started | Not started | 15 | 0 | 15 |
| `mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md` | Started | In progress | 6 | 0 | 6 |
| `mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md` | Started | Needs work | 8 | 0 | 8 |
| `mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md` | Started | Not started | 7 | 0 | 7 |
| `mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md` | Started | Not started | 6 | 0 | 6 |
| `mid-scope/TODO_REFLEX_ROAMING_BRIDGE.md` | Started | In progress | 4 | 0 | 4 |
| `mid-scope/TODO_RESONA_UNIFICATION_ROADMAP.md` | Started | In progress | 4 | 0 | 4 |
| `mid-scope/TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md` | Started | In progress | 13 | 0 | 13 |
| `README.md` | — | — | 0 | 0 | 0 |
| `shelved/README.md` | — | — | 0 | 0 | 0 |
| `shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md` | Started | Needs revisit | 4 | 0 | 4 |
| `shelved/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md` | Started | In progress | 6 | 0 | 6 |

---

## Files missing status cells (needs paste from DOC_STATUS_HEADER)

| Kind | Path | Missing |
|------|------|---------|
| implementations | `companion-surface/BOND_STORE_ISSUES_AND_FIXES_PLAN.md` | Doc staging, Operations |
| implementations | `generation/imaging/sprite-quality-floor/README.md` | Doc staging, Operations |
| implementations | `resona/RESONA_UNIFICATION_PLAN.md` | Doc staging, Operations |
| implementations | `sentience/roaming/reflex/REFLEX_BRIDGE_24_7_ROAMING_ARCHITECTURE.md` | Doc staging, Operations |
| implementations | `sentience/roaming/reflex/REFLEX_BRIDGE_PACKET_SCHEMA_AND_WAKE_THRESHOLDS.md` | Doc staging, Operations |
| todo | `high-scope/README.md` | Doc staging, Operations |
| todo | `low-scope/README.md` | Doc staging, Operations |
| todo | `mid-scope/README.md` | Doc staging, Operations |
| todo | `README.md` | Doc staging, Operations |
| todo | `shelved/README.md` | Doc staging, Operations |

---

## Open checkbox drill-down (implementations)

Each bullet is the text after an open `- [ ]` task item (same scope as counts: outside fenced code blocks).

### `companion-surface/BOND_STORE_ISSUES_AND_FIXES_PLAN.md`
- Snapshot current behavior (manual smoke notes + baseline screenshots).
- Validate lobby room thread isolation behavior.
- Define failure handling (retry/backoff/user-visible status) if snapshot generation fails.
- Add tests for deterministic summary artifact generation.
- Mark one canonical thread/message source of truth.
- Demote secondary stores to derived/cache/export roles.
- Remove or quarantine duplicate overlap paths.
- Document ownership boundaries:
- Build/normalize unified thread index API.
- Implement reliable thread search (LIFE/PROJECT/LOBBY).
- Implement jump behavior (recent/history/favorites).
- Validate performance under realistic thread counts.
- Enforce raw archive retention target (7 days).
- Delete raw entries early once condensation succeeds.
- Define fallback retention for condensation failure.
- Enforce short-term storage cap policy (target 1 GB).
- Add telemetry for archive size growth and cleanup success rate.
- Confirm schedules/ritual definitions remain in Bond Store domain.
- Confirm companion diary/journal remains in Bond Store domain.
- Confirm schedule/ritual execution events can still emit log events to Audit.
- Run full smoke across: life continuity, project switch, lobby isolation, search/jump, snapshot carryover.
- Run thermal/perf spot check for memory-related screens.
- Remove temporary diagnostics and close TODO tags.
- Lock audit scope to operational/compliance events only.
- Confirm exclusions: conversational thread bodies, bond diary content, ritual definitions.
- Confirm inclusions: automation actions, guardian force actions, access/authority history, schedule/ritual execution logs.
- Define/confirm typed audit event schema (type, actor, source, timestamp, payload).
- Add normalized event categories and severity levels.
- Ensure append-only event policy for primary audit ledger.
- Add migration/adapter for legacy event rows if needed.
- Build one unified audit feed.
- Add filter chips by category/type.
- Add filter chip or controls for time windows.
- Add detail view for event payload/provenance.
- Ensure empty/loading/error states are clear and lightweight.
- Define safe read contract for companion access to audit summaries.
- Expose summarized/permission-safe operational history for companion assistance.
- Ensure privacy/authority gates are respected for sensitive logs.
- Add tests for event write/read/filter correctness.
- Add tests for audit feed ordering and pagination stability.
- Add telemetry for dropped events, parse failures, and filter latency.
- Validate that audit queries do not regress app responsiveness.
- Verify no Bond Store conversational memory flows depend on Audit tables.
- Verify audit feed is understandable for user troubleshooting.
- Update docs and close remaining audit TODOs.

### `engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- ExecuTorch adapter family added to model hub runtime registry.
- Session init verifies tensor signatures and expected output schema.
- Backend/provider selection is deterministic and logged.
- Lifecycle/cancellation behavior is stable under repeated execution.
- Fail/degraded states are explicit in UX and logs.

### `engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- Native target(s) declared and ABI-gated in CMake.
- JNI bridge classes mapped to specific GGUF lane functions (chat, multimodal encode/decode, diffusion where enabled).
- Input/output contracts documented per bridge (tokens, embeddings, image bytes, structured JSON).
- Cancellation/teardown lifecycle stable (foreground stop, app backgrounding, thermal abort).
- Runtime errors mapped to visible app states (no "fake success" fallbacks).

### `engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- LiteRT adapter interface row(s) declared in engine registry.
- Session init path validates tensor IO specs before execution.
- Delegate init errors map to explicit fallback paths.
- Cancellation and resource cleanup verified under repeated runs.
- Error taxonomy visible in app surfaces (not silent downgrade).

### `engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- CMake target added with ABI strategy aligned to app build matrix.
- JNI bridge class in Kotlin (`com.anikai.media.vision` or equivalent) with IO-thread execution only.
- Native input contract documented (bitmap format, tensor shape, orientation).
- Native output contract documented (mask PNG, landmarks JSON, confidence bundle).
- Error taxonomy mapped to user-visible failure states (no silent "worked" fallback).
- Memory/thermal release path verified (`close`, cancellation, lifecycle cleanup).

### `engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- MNN adapter family registered in engine model hub.
- Session init validates tensor contracts and output schemas.
- Tuning/benchmark path has timeout and fallback policy.
- Lifecycle and cancellation are stable under repeated runs.
- Degraded states are explicit and user-visible.

### `engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- Native target declared in CMake and included in Android build.
- JNI bridge API documented per task (input contract/output schema).
- Model/param asset validation path exists before run.
- Runtime lifecycle (init, reuse, close, cancel) is stable.
- Errors propagate to user-visible degraded states.

### `engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- QNN/SNPE adapter family registered in engine model hub.
- Device compatibility probe and backend init checks implemented.
- Input/output tensor contracts validated before run.
- Explicit fallback path to alternative local runtimes when unsupported.
- Thermal/lifecycle/cancellation stability verified for always-on scenarios.

### `generation/audio/voice/CLOUD_VOICE_PROVIDER_PLAN.md`
- Routing matrix validated for all supported mode/provider combinations.
- Provider credential validation and error taxonomy documented.
- UI/source labels verified (`local` vs `cloud`) for session transparency.
- Fallback guardrails confirmed against local-first policy.

### `generation/audio/voice/COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Warmup lock behavior validated (retry windows and state reset correctness).
- Pack inspection coverage complete (missing assets, bad graph mixes, wrong profile).
- Reference/reprocess controls verified end-to-end.
- Streaming chunk synthesis and finalization path tested.
- Runtime error taxonomy documented (adapter init, synth fail, profile mismatch).

### `generation/audio/voice/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md`
- Pack contract validation (model/tokens/assets).
- Runtime readiness and fallback messaging.
- Synth quality and stability sweep.
- Voice session and streaming behavior validation (if supported).
- Final lane status decision: `Operational` or `Needs revisit`.

### `generation/audio/voice/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md`
- Readiness contract test matrix (missing model, missing tokenizer/voices, invalid pack).
- Synthesis quality sweep (short/long utterances, punctuation, non-ASCII edge cases).
- Emotion recipe validation against runtime output (not just parameter updates).
- Voice session state correctness (`Queued -> Synthesizing -> Ready/Playing -> Completed`).
- Failure UX messages aligned with actionable remediation.

### `generation/audio/voice/VITS_RUNTIME_IMPLEMENTATION_PLAN.md`
- Finalize front-end strategy (grapheme vs phoneme pipeline).
- Validate VITS pack asset contract and profile detection.
- End-to-end synth verification in orchestrator session flow.
- Performance profiling and thermal behavior check.
- Final lane status decision: `Operational` or `Needs revisit`.

### `generation/audio/voice/XTTS_RUNTIME_IMPLEMENTATION_PLAN.md`
- Confirm runtime binary install/staging path for active ABIs.
- Implement native adapter bridge in XTTS runtime pack.
- Add deterministic pack validation before runtime init.
- Wire synth + streaming state transitions.
- Document explicit fallback behavior when XTTS is selected but unavailable.

### `generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`
- **Lock deterministic request contract** (`seed`, `steps`, `cfg`, sampler, width/height profile, preset) and pass as one canonical native struct.
- **Validate img2img source bytes up front** (decode success, supported format, channel layout) and fail early with explicit reason when invalid.
- **Use one canonical render path** (`conditioning -> sampler -> VAE decode -> PNG encode`) with no alternate empty-byte success path.
- **Validate output before return** (non-empty buffer, valid dimensions/channels, PNG signature bytes present).
- **Enforce memory/session lifecycle discipline** (no leaked tensor/session buffers; predictable cleanup on all failure branches).
- **Guard runtime concurrency** (single-writer model session or explicit pool policy; no shared mutable sampler state races).
- **Return structured JNI status codes** (`decode_fail`, `infer_fail`, `vae_fail`, `encode_fail`, `oom`, `invalid_output`) instead of generic null/empty failure.
- **Emit stage timing telemetry** (`decode_ms`, `infer_ms`, `vae_ms`, `png_ms`) for regression detection and per-device tuning.
- **Add golden repeatability run** (fixed prompt + seed + style ref) and verify: valid PNG, decodeable bitmap, expected dimensions, stable multi-run success rate.

### `resona/RESONA_UNIFICATION_PLAN.md`
- **Post-Resona:** Soul Meridian / memory IA, User Access consolidation, `!` + About deep links, trace metadata normalization, Gemma4 UNK, vocal layering (see historical bullets in git if you remove detail from here).

---

## Open checkbox drill-down (todo)

Each bullet is the text after an open `- [ ]` task item (same scope as counts: outside fenced code blocks).

### `high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- **Local media execution backbone is operational**
- **Sprite/character visual bar is operational**
- **Imaging pipeline stages are operational (S1 diffusion -> S3 ONNX post -> one-button path)**
- **Portrait creator flow is operational (4-shot -> animation handoff)**
- **Pack/output schema is operational for runtime ingestion**
- **Kokoro lane is operational at current quality bar**
- **Kitten lane is operational at current quality bar**
- **Voice+music workforce pipeline is operational (lyric -> generation -> mix -> optional voice layer)**
- **Operations board stays synced while subjects change**

### `mid-scope/TODO_BOND_MEMORY_THREAD_FIXES.md`
- Extract current open implementation items from the Bond fixes plan into active subtasks.
- Reconcile storage/runtime links now that docs live under story lanes.
- Keep progress log entries mirrored with dated todo updates.
- Set each item status (`In progress` / `Operational` / `Needs revisit`).

### `mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md`
- Finalize ExecuTorch artifact intake/conversion policy for ANIKAI packs.
- Implement adapter + manifest schema and runtime session initialization checks.
- Ship one operational helper/specialist pack end-to-end.
- Add deterministic backend fallback policy + diagnostics.
- Bind at least one Swarm lane to ExecuTorch adapter resolution.
- Ensure explicit degraded/failure states without silent cloud substitution.

### `mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md`
- Lock Flux 1 baseline profile and preset mapping for first operational target.
- Define minimum output size/quality gate tied to sprite floor contract.
- Validate one end-to-end txt2img flow and persist metadata trail.
- Add/refine img2img ref-tether path for consistency stage.
- Wire ONNX post-pass chain for QUALITY and validate deterministic outputs.
- Define Flux 2 lane as gated experimental profile with explicit device policy.
- Lock deterministic native request contract (`seed`, `steps`, `cfg`, sampler, size profile, preset).
- Validate img2img source decode + channel layout before inference (explicit fail reason on invalid input).
- Keep one canonical native render path (`conditioning -> sampler -> VAE decode -> PNG encode`) with no empty-byte success branch.
- Validate output buffer before return (non-empty, expected dimensions/channels, PNG signature).
- Enforce memory/session lifecycle cleanup on all native success/failure branches.
- Guard concurrency around model session/sampler state (single writer or explicit safe pool policy).
- Return structured JNI statuses (`decode_fail`, `infer_fail`, `vae_fail`, `encode_fail`, `oom`, `invalid_output`).
- Emit stage timing telemetry (`decode_ms`, `infer_ms`, `vae_ms`, `png_ms`) for regression tracking.
- Add golden repeatability run (fixed prompt/seed/ref) and require stable success across repeated runs.

### `mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`
- Lock GGUF manifest capability schema (`text_generation`, multimodal flags, sidecar requirements, diffusion flag policy).
- Verify runtime load config mapping parity between settings and native/runtime session parameters.
- Validate one stable multimodal understanding flow with explicit sidecar preflight checks.
- Complete canonical diffusion decode/output contract and document pass criteria.
- Wire Swarm GGUF specialist calls to same adapter registry and fail states.
- Confirm visible degraded states when GGUF lane is unavailable or unsupported.

### `mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md`
- Define LiteRT adapter ids and manifest schema fields for ANIKAI model hub.
- Deliver one operational LiteRT helper lane with validated output schema.
- Implement delegate selection policy and explicit fallback diagnostics.
- Wire at least one Swarm specialist lane to LiteRT adapter resolution.
- Validate cancellation/lifecycle reliability under repeated runs.
- Ensure no silent non-local fallback when LiteRT lane fails.

### `mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- Split oversized sections out of `LOCAL_MEDIA…` into focused docs; leave the log as index + anti-drift only.
- ONNX split phase 1: keep only summary in `LOCAL_MEDIA…`; maintain detailed ONNX plan in `ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`.
- Align native diffusion handoff (GGUF JNI) with **S1** in `IMAGING_PIPELINE_QUALITY_STACK.md` once PNG path is canonical.
- Register at least one **S3** ONNX post graph for QUALITY preset (opset/shape validated).
- ONNX generation split phase 1: complete ONNX primary/post generation checklist in `TODO_ONNX_GENERATION_IMAGING_PLAN.md`.
- Portrait path: ensure **S5/S6** handoff matches `PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md` (still → pack → frame animation).
- MediaPipe split phase 1: define first operational helper task and complete adapter + manifest + lane wiring checklist in `TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`.
- FLUX split phase 1: complete Flux 1 baseline + Flux 2 experimental lane planning checklist in `TODO_FLUX_GENERATION_IMAGING_PLAN.md`.

### `mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`
- Decide first ship path: MediaPipe Tasks AAR first or custom JNI graph first.
- Implement adapter registration + manifest schema for MediaPipe capability packs.
- Deliver one operational task end-to-end (recommended: segmentation).
- Bind at least one Swarm/task lane to MediaPipe adapter with explicit fail states.
- Add artifact schema validation (mask/landmark JSON) and storage contract notes.
- Add device/thermal gating policy for continuous or heavy tasks.
- Verify lifecycle and cancellation stability for repeated task runs.

### `mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md`
- Finalize MNN adapter IDs and manifest schema for model hub.
- Implement runtime tuning policy + timeout/fallback behavior.
- Deliver one operational helper pack end-to-end.
- Wire one specialist lane to MNN adapter resolution.
- Validate lifecycle, cancellation, and repeat-run stability.
- Ensure local failure states remain explicit and honest.

### `mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md`
- Finalize handover packet schema (task, source model, evidence, confidence, cost).
- Define role-class scheduler policy (latency/quality/memory/thermal/user policy).
- Implement baseline chain: reflex trigger -> specialist -> text summarizer -> companion.
- Implement T1 fast lane + T2 summarizer lane with explicit role metadata.
- Add on-demand deep lane switching and return-to-fast behavior.
- Validate degraded labeling and no hidden cloud substitution in local-only mode.

### `mid-scope/TODO_MUSIC_GENERATION_AND_CREATIONS_PIPELINE.md`
- Lock baseline local music generation form (parametric/sample/MIDI) and output schema.
- Implement M0-M6 Creations pipeline baseline with reliable master export.
- Add stage progress + runtime metadata trail in UI/output.
- Define and validate FAST/BALANCED/QUALITY behavior for music generation.
- Integrate first neural additive lane (ONNX loop or stem utility) behind explicit gating.
- Enforce explicit degraded/fail behavior without silent cloud fallback.

### `mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md`
- Finalize NCNN packaging strategy (native libs + model assets + ABI matrix).
- Implement NCNN JNI bridge and adapter registration.
- Deliver first operational NCNN helper lane with artifact output validation.
- Define Vulkan preferred path and CPU fallback policy by device class.
- Bind one specialist lane to NCNN adapter with explicit fail/degraded states.
- Validate lifecycle cleanup and repeated-run stability.

### `mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md`
- Lock ONNX generation profile matrix (`FAST` / `BALANCED` / `QUALITY`).
- Select and validate first ONNX generation-capable graph path (or confirm post-first path).
- Deliver deterministic ONNX output persistence and metadata trail.
- Wire and validate at least one QUALITY S3 post graph chain.
- Define S4 helper pass policy (ONNX vs CPU) with explicit labeling.
- Promote operational status only after floor-resolution checks pass.

### `mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md`
- Implement chipset/runtime compatibility probe path.
- Register QNN/SNPE adapter family and manifest schema requirements.
- Deliver one operational always-on helper lane on supported hardware.
- Define fallback precedence for unsupported devices (local runtime only).
- Wire capability-gated UI reveal behavior to actual runtime availability.
- Validate lifecycle/thermal stability for long-running helper scenarios.

### `mid-scope/TODO_REFLEX_ROAMING_BRIDGE.md`
- Define active milestones from architecture doc (capture, classify, route, handoff).
- Version packet schema transitions and validation plan.
- Confirm wake threshold defaults for low-power and charging states.
- Add test/telemetry checks for false wake and missed wake behavior.

### `mid-scope/TODO_RESONA_UNIFICATION_ROADMAP.md`
- Pull currently active items from `RESONA_UNIFICATION_PLAN.md` into scoped execution steps.
- Validate which deferred items should be promoted back to active for current Android cycle.
- Keep migration/diagnostics links current after doc moves.
- Mark operation status per item (`In progress` / `Operational` / `Needs revisit`).

### `mid-scope/TODO_RUNTIME_REGISTRY_GUARDRAILS_AND_PLACEMENT.md`
- Adapter-first rule enforced: assignment -> capability manifest -> engine session -> bytes/artifacts.
- No silent cloud substitution when local-only policy is active.
- Quality presets remain explicit and user-visible (`FAST`, `BALANCED`, `QUALITY`).
- Runtime claims require artifact output + honest failure labeling.
- Swarm specialist execution resolves registered adapters or fails visibly.
- Per-lane placement policy remains explicit (`PHONE`, `PC`, `CLOUD`, `SERVER`, `HYBRID`).
- Capability packs define pack id, runtime type, capabilities, host source, and eligible lanes.
- Model hub shows host badge, engine badge, capability badges, and role count (`xN`).
- Bridge sync behavior keeps phone+PC model visibility and lane-level placement controls coherent.
- Keep imaging generation tracks (FLUX + ONNX) aligned to quality-floor contracts.
- Keep music generation + Creations pipeline aligned to local PCM contract.
- Keep handover/text role orchestration aligned to runtime family capability docs.
- Keep operations board links synchronized when docs/todos move.

### `shelved/TODO_EXPANDED_VOICE_RUNTIME_LANES.md`
- Re-validate runtime viability per engine (quality, latency, memory, install size).
- Define per-engine promote/shelve criteria and acceptance thresholds.
- Link resumed items to active mid/high-scope todos before implementation starts.
- Update operations status per lane after each review cycle.

### `shelved/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md`
- Confirm current behavior from code and lock baseline (what is config-only vs executed).
- Define lane outputs for `music_generator`, `lyric_weaver`, `audio_stem_mixer` (artifact contracts).
- Route music requests through workforce pipeline when lane assignments are present.
- Add optional voice-over stage with `VoiceOrchestrator` and emotion/prosody controls.
- Persist metadata + provenance tags for each stage so replay/debug is deterministic.
- Add visible fallback policy (provider/fallback tone vs workforce path) with honest status labels.

---

## Changelog (this snapshot)

| Date | Note |
|------|------|
| 2026-05-06 | Roll-ups, per-file counts, and open-checkbox drill-down (verbatim line text per file). |
