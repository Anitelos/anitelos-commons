# Portrait Autogen 4-Shot Contract (v1)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

Purpose: define a low-friction profile creator pipeline where the user provides identity/style notes, ANIKAI auto-plans 4 persona-specific shots, and the user can redo any single shot before animation.

**Related:** [`SPRITE_QUALITY_FLOOR.md`](./SPRITE_QUALITY_FLOOR.md) (visual floor), [`../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`](../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md) (stage/engine roles for stills → pack), [`../../pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`](../../pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md) (rig-first avatar motion test path), [`../../OPERATIONS_INDEX.md`](../../OPERATIONS_INDEX.md).

## Product flow

1. User enters base profile details (identity + optional style hints).
2. User taps `Generate companion set`.
3. Planner produces exactly 4 shot plans.
4. Image generator renders 4 stills.
5. User can `Keep`, `Redo this shot`, or `Save`.
6. User taps `Animate companion/persona`.
7. Animation pipeline runs for all kept shots.
8. User reviews and approves/regenerates animation outputs.

No manual camera angle picker in this flow.

## Fixed shot slots (required)

Every persona must output these slots in order:

1. `hero_close` - identity anchor shot
2. `focus_work` - in-action role shot
3. `ambient_presence` - relaxed context shot
4. `edge_mode` - archetype/dramatic signature shot

Slots are fixed; scene content varies by persona.

## Hybrid planner architecture

- System constraints define hard camera/pose/animation safety limits.
- Main brain (Gemma E2B/E4B class) fills persona-specific scene language.
- Validator enforces schema + constraints before image generation.

This keeps creativity while preserving animation reliability.

## Input contract (planner)

```json
{
  "personaId": "guardian_v1",
  "personaLabel": "Guardian",
  "archetype": "guardian",
  "identityBrief": "protective, tactical, calm authority",
  "styleHints": ["cyber-noir", "urban night", "subtle armor"],
  "userNotes": "optional free text",
  "generationMode": "profile_creator",
  "safetyProfile": "app_default",
  "constraintsVersion": 1
}
```

## Output contract (planner)

```json
{
  "version": 1,
  "personaId": "guardian_v1",
  "shots": [
    {
      "slot": "hero_close",
      "camera": "close_3q",
      "pose": "steady_forward",
      "scene": "command_console",
      "mood": "calm_confident",
      "promptPositive": "....",
      "promptNegative": "....",
      "animationSafe": true,
      "idleMotionHints": {
        "mode": "off",
        "regions": [],
        "intensity": 0.0,
        "rationale": "Identity anchor: no body micro-motion; face-only policy if needed."
      }
    },
    {
      "slot": "focus_work",
      "camera": "mid_profile",
      "pose": "hands_active",
      "scene": "monitor_wall",
      "mood": "focused",
      "promptPositive": "....",
      "promptNegative": "....",
      "animationSafe": true,
      "idleMotionHints": {
        "mode": "subtle_2d",
        "regions": ["forearm_left", "hand_rest"],
        "intensity": 0.35,
        "rationale": "Desk work: tiny wrist / finger idle; keep head box stable."
      }
    },
    {
      "slot": "ambient_presence",
      "camera": "mid_front",
      "pose": "relaxed_stand",
      "scene": "quiet_patrol_point",
      "mood": "warm_watchful",
      "promptPositive": "....",
      "promptNegative": "....",
      "animationSafe": true,
      "idleMotionHints": {
        "mode": "subtle_2d",
        "regions": ["ankle_cross", "torso_sway"],
        "intensity": 0.3,
        "rationale": "Relaxed stand: weight shift and subtle lower-leg motion only."
      }
    },
    {
      "slot": "edge_mode",
      "camera": "close_cctv",
      "pose": "perch_observe",
      "scene": "rooftop_night",
      "mood": "high_alert",
      "promptPositive": "....",
      "promptNegative": "....",
      "animationSafe": true,
      "idleMotionHints": {
        "mode": "subtle_2d",
        "regions": ["torso_sway"],
        "intensity": 0.25,
        "rationale": "High alert: minimal sway only; no large limb arcs that break the locked frame."
      }
    }
  ]
}
```

## Optional per-shot: `idleMotionHints` (v2)

Ties **subtle idle / body micro-motion** to the **same shot plan** that drives prompts and later pack build. Pack runtime maps shot → scene and copies hints into manifest `idleMotion` (see `PORTRAIT_PACK_SCHEMA.md` optional v2); use `drivingShotSlot` there to match the source slot.

Omit `idleMotionHints` entirely in v1-only flows; validators treat absence as “no hint.”

| Field | Required | Notes |
| --- | --- | --- |
| `idleMotionHints.mode` | if object present | `off`, `subtle_2d`, `masked_cycle` |
| `idleMotionHints.regions` | if object present | When `mode` is `off`, may be `[]`. Otherwise non-empty subset of allowed region ids (below). |
| `idleMotionHints.intensity` | if object present | `0.0`–`1.0` |
| `idleMotionHints.rationale` | optional | Short string for logs / UI “why this motion” |

**Allowed `regions` ids (v2 starter set):** `forearm_left`, `forearm_right`, `hand_rest`, `wrist_subtle`, `ankle_cross`, `calf_shift`, `torso_sway`, `weight_shift`

**Guidance:** `hero_close` should usually use `mode: off` or very low intensity so identity stays stable; `ambient_presence` / seated or bench scenes can carry leg or forearm hints; `focus_work` favors hands; `edge_mode` stays minimal.

## Allowed vocabulary (v1)

The planner must choose from controlled enums:

- `camera`: `close_front`, `close_3q`, `mid_front`, `mid_profile`, `wide_environment`, `close_cctv`
- `pose`: `steady_forward`, `relaxed_stand`, `seated_focus`, `hands_active`, `perch_observe`
- `mood`: `calm_confident`, `focused`, `warm_watchful`, `high_alert`

Engine can map these enums to prompt fragments internally.

## Persona adaptation rules

- Persona may provide `allowedScenes`, `blockedScenes`, `wardrobeRules`, `propRules`.
- Planner must never use blocked scenes.
- If planner suggests blocked scene, validator rewrites scene from allowed fallback table.
- Example: ninja/guardian can reject "park bench casual"; fallback to "tree_sentinel" or "rooftop_night".

## Validation rules

Reject and regenerate plan if any condition fails:

- not exactly 4 shots
- missing required slots or wrong order
- duplicate slot
- non-enum camera/pose/mood values
- blocked scene used
- any shot has `animationSafe = false`
- if `idleMotionHints` is present on a shot:
  - `mode` must be one of `off`, `subtle_2d`, `masked_cycle`
  - `intensity` must be between `0.0` and `1.0`
  - if `mode` is not `off`, `regions` must be non-empty and every entry must be in the allowed region id set (v2 starter set above)
  - if `mode` is `off`, `regions` must be `[]` and `intensity` must be `0.0`

## Single-shot redo contract

Redo one shot without replacing the whole set:

```json
{
  "version": 1,
  "personaId": "guardian_v1",
  "redoSlot": "edge_mode",
  "currentAcceptedShots": [
    "hero_close",
    "focus_work",
    "ambient_presence"
  ],
  "variationIntent": "more tactical less fantasy",
  "keepIdentityLocked": true
}
```

Rules:

- Only `redoSlot` is regenerated.
- Other accepted shots stay unchanged.
- Identity anchors (face shape, hair, palette) stay locked.
- If the planner emits `idleMotionHints`, redo may refresh **only** that slot’s hints together with the new prompts.

## Animation handoff contract (v1)

For each approved still, animation step receives:

- shot slot
- source image path
- animation preset id
- optional lip/eye layer policy
- optional `idleMotionHints` for that slot (propagate into pack `manifest.json` → per-scene `idleMotion`, with `drivingShotSlot` set to the shot slot for traceability)

Target output count remains 4 animations (1 per slot) for the profile creator path.

## Runtime notes

- Gemma E2B/E4B class models are suitable as planner brains when output is schema-constrained.
- Keep deterministic validation in app code; do not trust free-form LLM output.
- Advanced custom freedom remains available via chat-driven generation path outside this guided creator.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-07 | Added cross-link to Persona Rig test pipeline plan for rig-first avatar motion staging. |
| 2026-05-06 | Added staging header + links to sprite floor, imaging pipeline stack, operations index. |
