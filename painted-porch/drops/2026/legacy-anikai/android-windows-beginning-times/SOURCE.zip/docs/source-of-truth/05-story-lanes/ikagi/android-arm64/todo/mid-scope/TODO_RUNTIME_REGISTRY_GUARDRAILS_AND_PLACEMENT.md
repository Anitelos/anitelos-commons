# TODO — runtime registry guardrails and placement policy (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Intent

- Preserve cross-track anti-drift guardrails after retiring `LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`.
- Keep one current-truth snapshot for key media/runtime lanes.
- Track runtime placement and capability-pack policy until fully implemented in product and docs.

---

## Current truth snapshot (carry-forward)

| Area | Today (honest) | Target |
|------|----------------|--------|
| Main companion **text** | GGUF / LiteRT / `.task` per matrix | Keep as primary local brain |
| **Image** previews (Sprite Maker etc.) | Local adapter scaffold exists; mixed placeholder/native paths | Native/ONNX primary + ONNX post with quality-floor compliance |
| **Music** | Provider + fallback tone in companion path | LocalMusicAdapter tiers with real PCM outputs |
| **Video** | Provider-oriented | LocalVideoAdapter sequence pipeline first, neural later |
| **Vision helpers** | Registry exists; execution depth varies | ONNX/MediaPipe/LiteRT per lane with manifest-gated execution |
| **Companion VLM** | Depends on bound runtime build + sidecars | Capability-manifested multimodal understanding lane |

---

## Guardrails checklist (must stay true)

- [ ] Adapter-first rule enforced: assignment -> capability manifest -> engine session -> bytes/artifacts.
- [ ] No silent cloud substitution when local-only policy is active.
- [ ] Quality presets remain explicit and user-visible (`FAST`, `BALANCED`, `QUALITY`).
- [ ] Runtime claims require artifact output + honest failure labeling.
- [ ] Swarm specialist execution resolves registered adapters or fails visibly.

---

## Runtime placement and capability-pack policy

- [ ] Per-lane placement policy remains explicit (`PHONE`, `PC`, `CLOUD`, `SERVER`, `HYBRID`).
- [ ] Capability packs define pack id, runtime type, capabilities, host source, and eligible lanes.
- [ ] Model hub shows host badge, engine badge, capability badges, and role count (`xN`).
- [ ] Bridge sync behavior keeps phone+PC model visibility and lane-level placement controls coherent.

---

## Cross-track sequencing (active)

- [ ] Keep imaging generation tracks (FLUX + ONNX) aligned to quality-floor contracts.
- [ ] Keep music generation + Creations pipeline aligned to local PCM contract.
- [ ] Keep handover/text role orchestration aligned to runtime family capability docs.
- [ ] Keep operations board links synchronized when docs/todos move.

---

## Linked docs

- `implementations/OPERATIONS_INDEX.md`
- `implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`
- `implementations/engine-inference/*`
- `implementations/generation/*`
- `implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created as carry-forward replacement for remaining anti-drift, guardrails, and placement concepts from retired local media mega-log. |
