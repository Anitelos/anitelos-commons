# Imaging pipeline — quality stack (stage roles & engines)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-22 |
| **Platform** | Windows x86-64 (`anikai-desktop`) |

**Scope:** **product pipeline schema** — what each **stage** must accomplish, which **inference families** are appropriate, and how quality upgrades over time. This is **not** the Kotlin/C++ schema for tensors (that stays in code + manifest specs).

**Not in scope here:** **video** as a muxed timeline product (see `generation/video/` when added). **Frame animation** for sprites / portrait packs (strip sequencing, cell timing) **is** in scope as **packaging** stages that consume **still** outputs from this stack.

---

## Authority split (read first)

| Question | Document |
|----------|----------|
| **What counts as “success” visually?** | [`../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) (Floors A–D, showcase vs playable). |
| **Portrait creator slots, redo, animation handoff** | [`../generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](../generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md). |
| **On-disk pack layout** | [`../generation/imaging/PORTRAIT_PACK_SCHEMA.md`](../generation/imaging/PORTRAIT_PACK_SCHEMA.md) + storage contract. |
| **Adapter honesty, downloads, JNI state** | [`../../../../../02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`](../../../../../02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md). |

This file answers: **given those contracts, what pipeline **steps** run, and which **engine lane** owns each step for best quality today (upgradable later)?**

---

## Pipeline DAG (logical stages)

Aligned with the multi-pass table in `SPRITE_QUALITY_FLOOR.md`, but named here for **engine assignment**. Stages are **ordered**; some may be skipped only when a preset says so (never silently).

| Stage | Job (must hold) | Primary engine family (best quality **today**, upgrade path) | Notes |
|-------|-----------------|---------------------------------------------------------------|--------|
| **S0 — Normalize input** | Square-ish crop, refs, safety/version tags | **App code** + file drops (no ML) | Media Magic sprite zones; optional pixel downscale tool. |
| **S1 — Primary pixels** | txt2img / img2img; identity + first raster | **Diffusers** (`media-diffusers-image.py`) **or** **`sd.exe` GGUF** | Kontext preferred on Windows; upgrade via new presets / pixel-space models (see emerging backlog). |
| **S2 — Consistency** | Same character across facings / shots | Same family as S1 with **locked seeds**, **ref tether**, or second pass | May merge with S1 in FAST presets; QUALITY keeps explicit. |
| **S3 — Sharpen / upscale** | Edge clarity at authored resolution | **ONNX desktop runtime** post graphs (e.g. 4× UltraSharp-class) | Runs **after** bytes exist; validates opset/shape. Upgrade: swap graph id in manifest. |
| **S4 — Palette / outline unify** | Game-ingest readability at small scale | Small **ONNX** or **CPU** pass | Must not fake quality if S1 was mush. |
| **S5 — Pack / manifest** | `manifest.json`, thumbs, N·E·S·W or portrait slots | **App bundling** + schema validators | Animation **hints** attach here per portrait contract. |
| **S6 — Frame animation (not video codec)** | Sprite sheet / blink layers / strip from approved stills | **Parametric + optional specialist ONNX** (motion separate from generative diffusion) | Keeps “imaging pipeline” distinct from full **video** adapter later. |

**Quality preset mapping:** FAST may collapse S2 into S1 or skip S4; QUALITY keeps S2–S4 explicit. All presets stay **on-device** for paths that claim ANIKAI-local showcase (per floor doc).

---

## Engine inference matrix (summary)

| Family | Typical stage | When it is “best” |
|--------|----------------|-------------------|
| **GGUF (`sd.exe`)** | S1–S2 | Kontext and SD-family stills; split-pack + probe in Models UI. |
| **Diffusers (Python CUDA)** | S1–S2 | `FluxKontextPipeline`, dual ref, sprite facings. |
| **ONNX primary txt2img** | S1–S2 | When a validated ORT graph ships for fixed shapes. |
| **ONNX post** | S3–S4 | Industry-standard sharpen/upscale; swap graphs without rewriting companion. |
| **LiteRT / MediaPipe / NCNN** | Mostly **vision understanding**, not generative pixels—unless a future specialist graph is generative | Capability packs / recognition—parallel row in hub, not a substitute for S1. |

Upgrade policy: **improve manifests + adapter ids** and keep the **stage jobs** stable so UX and Storage contracts do not churn.

---

## Related

- [`README.md`](./README.md) — what belongs in `pipelines/` vs imaging contracts.  
- [`OPERATIONS_INDEX.md`](../OPERATIONS_INDEX.md) — checklist ↔ todos.  

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-22 | Windows desktop engines (Diffusers, sd.exe, ONNX desktop) in stage matrix. |
| 2026-05-06 | Initial pipeline stack: stages S0–S6, engine matrix, split from imaging contracts and local media log. |
