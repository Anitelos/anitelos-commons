# TODO — FLUX generation imaging plan (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md`

---

## Intent

- Turn FLUX references from backlog notes into an implementation-grade generation track.
- Track Flux 1 baseline, Flux 2 experimental lane, and ONNX post-chain alignment.
- Keep generation responsibilities separate from engine-inference internals.

---

## Checklist (working)

- [ ] Lock Flux 1 baseline profile and preset mapping for first operational target.
- [ ] Define minimum output size/quality gate tied to sprite floor contract.
- [ ] Validate one end-to-end txt2img flow and persist metadata trail.
- [ ] Add/refine img2img ref-tether path for consistency stage.
- [ ] Wire ONNX post-pass chain for QUALITY and validate deterministic outputs.
- [ ] Define Flux 2 lane as gated experimental profile with explicit device policy.

---

## JNI consistency gate (Sprite Maker primary diffusion)

- [ ] Lock deterministic native request contract (`seed`, `steps`, `cfg`, sampler, size profile, preset).
- [ ] Validate img2img source decode + channel layout before inference (explicit fail reason on invalid input).
- [ ] Keep one canonical native render path (`conditioning -> sampler -> VAE decode -> PNG encode`) with no empty-byte success branch.
- [ ] Validate output buffer before return (non-empty, expected dimensions/channels, PNG signature).
- [ ] Enforce memory/session lifecycle cleanup on all native success/failure branches.
- [ ] Guard concurrency around model session/sampler state (single writer or explicit safe pool policy).
- [ ] Return structured JNI statuses (`decode_fail`, `infer_fail`, `vae_fail`, `encode_fail`, `oom`, `invalid_output`).
- [ ] Emit stage timing telemetry (`decode_ms`, `infer_ms`, `vae_ms`, `png_ms`) for regression tracking.
- [ ] Add golden repeatability run (fixed prompt/seed/ref) and require stable success across repeated runs.

---

## Linked operations

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through imaging maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Added Sprite Maker JNI consistency gate checklist so progress snapshots track diffusion reliability work. |
| 2026-05-06 | Created dedicated FLUX generation todo bridge during local media split pass. |
