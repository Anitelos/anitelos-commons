# Model sheet — FHDR Uncensored (Diffusers)

| Field | Value |
|-------|-------|
| **Format** | Diffusers |
| **HF** | [kpsss34/FHDR_Uncensored](https://huggingface.co/kpsss34/FHDR_Uncensored) |
| **Desktop preset** | `flux_fhdr_uncensored_kpsss34` |

Full `model_index.json` tree under `models/fhdr/` (or user override in `media-models.json`). GGUF variant documented in [`../../gguf/models/MODEL_KPSSS34_FHDR_UNCENSORED.md`](../../gguf/models/MODEL_KPSSS34_FHDR_UNCENSORED.md).
