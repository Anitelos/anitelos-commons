# Imaging generation lane (Windows x86-64) — index

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

This file is the **entry point** for Windows **imaging generation**: which **HF stacks / presets** we intend to support, which **inference families** (native GGUF tool, Diffusers runner, future graphs) own them, and **what is actually working** in the desktop app today. Per-target GGUF notes live under [`gguf/models/`](./gguf/models/). Diffusers / ONNX / Python sidecar sheets will live under sibling folders as those lanes grow. Cross-cutting GGUF **product** rules (capabilities, ONNX post role) stay in [`gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md).

---

## Story (three layers)

1. **Engine-inference** answers: *which binary or runtime implements decode, what does probe report, and which tasks are honest?*  
   - GGUF engine: [`../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
   - ONNX (post / alternate primary): [`../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
2. **Generation / imaging** answers: *what does the user get per model choice (resolution, failure strings, routing)?*  
   - This index + [`gguf/models/`](./gguf/models/) sheets + family plans under [`gguf/`](./gguf/), [`diffusers/`](./diffusers/), [`onnx/`](./onnx/), [`python/`](./python/).  
3. **Todo / mid-scope** answers: *what shipped vs unchecked?*  
   - [`../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md)  

---

## Inference families

| Family | Imaging product plan | Engine / runtime notes |
|--------|----------------------|-------------------------|
| **GGUF native image** (CLI) | [`gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) | [`../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| **Diffusers / PyTorch** (sidecar) | [`diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) | *Subprocess / venv contract in that plan; not the GGUF engine table.* |
| **ONNX** (post or alternate primary) | [`onnx/ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./onnx/ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) | [`../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) (EP policy, sessions) |
| **Python sidecar** (portrait motion, specialty) | [`python/PYTHON_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./python/PYTHON_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) | PersonaLive and other non–txt2img Python rigs that touch imaging/motion UX |

Add a row when a new **family** gets a real plan file (e.g. embedded Comfy graph).

**Shipped in app (tick when end-to-end in Anikai Desktop):** orthogonal to any single HF repo.

- [x] **Native GGUF image (infrastructure)** — `sd.exe` in `dist:full`, flux **split-pack** (`vae/` + encoders beside `.gguf`), sharded T5 merge per Generate, model **profiles**, **style presets**, prompt-based output names, readiness UI. *Per-model E2E still ticked below.*  
- [x] **Diffusers / PyTorch sidecar (infrastructure)** — `media-python` venv staged with `dist:full`; FHDR preset path.  
- [ ] **External graph runtime** (e.g. ComfyUI) — *doc TBD when we lock an embedding story.*  

### Desktop code touchpoints (2026-05-17)

| Area | Code |
|------|------|
| Image IPC | `main.js` `media:generate-image` |
| sd.exe runner | `main-process/gguf-completion.js` (`runImageGenerationMain`, split-pack + flux2 klein); step preview [`SD_CPP_PROJ_STEP_PREVIEW.md`](../runtime-shape/SD_CPP_PROJ_STEP_PREVIEW.md) via `sd-proj-preview.js` |
| GGUF pack families | [`gguf/GGUF_MODEL_PACK_FAMILIES.md`](./gguf/GGUF_MODEL_PACK_FAMILIES.md) (auto-route spec) |
| Model defaults | `shared/sd-gguf-image-profiles.js` |
| Style presets | `shared/image-style-presets.js` |
| Output paths | `main-process/generated-media-filename.js` — `generated-media/<model-slug>/<prompt-slug>-<date_time>.png` |
| Media Magic UI | `components/media.js` |
| Companion image turns | `components/chat.js` + same IPC |
| Build | `npm run dist:full` → `stage-runtimes` (llama + sd.exe + media-python) |

## Plug-and-play goal (GGUF)

Users drop weights into `ANIKAI_HOME/models/` → app **detects `pack_family_id`** → applies **profile defaults** → Media Magic / companion need **prompt + style only**. Pack layouts and router waves: [`gguf/GGUF_MODEL_PACK_FAMILIES.md`](./gguf/GGUF_MODEL_PACK_FAMILIES.md).

**Later lanes (out of scope for this registry’s E2E ticks):** img2img / edit (`-r`, Kontext, Qwen-Image-Edit), vision models, **music**, **video** (see [`models/MODEL_WAN_GGUF.md`](./gguf/models/MODEL_WAN_GGUF.md) stub).

---

## Model registry — GGUF native (`sd.exe`)

Tick **[x]** only when **txt2img** works in the shipping desktop flow (persisted PNG + honest errors). **Router:** shipped | partial | planned (per sheet).

### `sd_single_m` — single-file SD 1.x

| Status | Target | Sheet |
|--------|--------|-------|
| planned | Family umbrella | [`models/MODEL_GGUF_FAMILY_SD15_SINGLE_FILE.md`](./gguf/models/MODEL_GGUF_FAMILY_SD15_SINGLE_FILE.md) |
| planned | city96 / SD 1.5 GGUF | [`models/MODEL_CITY96_SD15_V15_GGUF.md`](./gguf/models/MODEL_CITY96_SD15_V15_GGUF.md) |

### `sdxl_single_m` — single-file SDXL

| Status | Target | Sheet |
|--------|--------|-------|
| planned | Family umbrella | [`models/MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md`](./gguf/models/MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md) |
| planned | city96 / SDXL base GGUF | [`models/MODEL_CITY96_SDXL_GGUF.md`](./gguf/models/MODEL_CITY96_SDXL_GGUF.md) |
| planned | Segmind / SSD-1B | [`models/MODEL_SEGMIND_SSD1B_GGUF.md`](./gguf/models/MODEL_SEGMIND_SSD1B_GGUF.md) |

### `flux1_clip_t5` — FLUX.1 split-pack

| Status | Target | Sheet |
|--------|--------|-------|
| partial | city96 / FLUX.1-schnell | [`models/MODEL_CITY96_FLUX1_SCHNELL_GGUF.md`](./gguf/models/MODEL_CITY96_FLUX1_SCHNELL_GGUF.md) |
| partial | city96 / FLUX.1-dev | [`models/MODEL_CITY96_FLUX1_DEV_GGUF.md`](./gguf/models/MODEL_CITY96_FLUX1_DEV_GGUF.md) |
| partial | leejet / FLUX.1-dev | [`models/MODEL_LEEJET_FLUX1_DEV_GGUF.md`](./gguf/models/MODEL_LEEJET_FLUX1_DEV_GGUF.md) |
| partial | leejet / FLUX.1-schnell | [`models/MODEL_LEEJET_FLUX1_SCHNELL_GGUF.md`](./gguf/models/MODEL_LEEJET_FLUX1_SCHNELL_GGUF.md) |
| shipped | shuttleai / shuttle-3.1-aesthetic | [`models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC.md`](./gguf/models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC.md) |

### `flux1_chroma`

| Status | Target | Sheet |
|--------|--------|-------|
| planned | silveroxides / Chroma | [`models/MODEL_SILVEROXIDES_CHROMA_GGUF.md`](./gguf/models/MODEL_SILVEROXIDES_CHROMA_GGUF.md) |

### `flux2_llm_vae` — FLUX.2 / ERNIE triple-pack

| Status | Target | Sheet |
|--------|--------|-------|
| partial | unsloth / FLUX.2-klein-9B-GGUF | [`models/MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](./gguf/models/MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md) |
| shipped | leejet / FLUX.2-klein-9B-GGUF | [`models/MODEL_LEEJET_FLUX2_KLEIN_9B_GGUF.md`](./gguf/models/MODEL_LEEJET_FLUX2_KLEIN_9B_GGUF.md) |
| planned | leejet / FLUX.2-klein-4B-GGUF | [`models/MODEL_LEEJET_FLUX2_KLEIN_4B_GGUF.md`](./gguf/models/MODEL_LEEJET_FLUX2_KLEIN_4B_GGUF.md) |
| planned | city96 / FLUX.2-dev-GGUF | [`models/MODEL_CITY96_FLUX2_DEV_GGUF.md`](./gguf/models/MODEL_CITY96_FLUX2_DEV_GGUF.md) |
| planned | unsloth / ERNIE-Image-GGUF | [`models/MODEL_UNSLOTH_ERNIE_IMAGE_GGUF.md`](./gguf/models/MODEL_UNSLOTH_ERNIE_IMAGE_GGUF.md) |
| planned | unsloth / ERNIE-Image-Turbo-GGUF | [`models/MODEL_UNSLOTH_ERNIE_IMAGE_TURBO_GGUF.md`](./gguf/models/MODEL_UNSLOTH_ERNIE_IMAGE_TURBO_GGUF.md) |

### `qwen_image_llm_vae`

| Status | Target | Sheet |
|--------|--------|-------|
| planned | QuantStack / Qwen-Image-GGUF | [`models/MODEL_QUANTSTACK_QWEN_IMAGE_GGUF.md`](./gguf/models/MODEL_QUANTSTACK_QWEN_IMAGE_GGUF.md) |

### `z_image_llm_vae`

| Status | Target | Sheet |
|--------|--------|-------|
| planned | unsloth / Z-Image-GGUF | [`models/MODEL_UNSLOTH_Z_IMAGE_GGUF.md`](./gguf/models/MODEL_UNSLOTH_Z_IMAGE_GGUF.md) |
| planned | leejet / Z-Image-Turbo-GGUF | [`models/MODEL_LEEJET_Z_IMAGE_TURBO_GGUF.md`](./gguf/models/MODEL_LEEJET_Z_IMAGE_TURBO_GGUF.md) |

### `sd3_clip_stack`

| Status | Target | Sheet |
|--------|--------|-------|
| shipped | SD 3.5 Large (calcuis GGUF) | [`models/MODEL_CALCUIS_SD35_LARGE_GGUF.md`](./gguf/models/MODEL_CALCUIS_SD35_LARGE_GGUF.md) |
| shipped | SD 3.5 Lite 2B (calcuis) | [`models/MODEL_CALCUIS_SD35_LITE_GGUF.md`](./gguf/models/MODEL_CALCUIS_SD35_LITE_GGUF.md) |
| shipped | SD 3.5 Large Turbo (stduhpf) | [`models/MODEL_STDUHPF_SD35_TURBO_GGUF.md`](./gguf/models/MODEL_STDUHPF_SD35_TURBO_GGUF.md) |

### `ovis_llm_vae`

| Status | Target | Sheet |
|--------|--------|-------|
| planned | leejet / Ovis-Image-7B | [`models/MODEL_LEEJET_OVIS_IMAGE_GGUF.md`](./gguf/models/MODEL_LEEJET_OVIS_IMAGE_GGUF.md) |

### Phase 2 — edit / vision (documented, not txt2img E2E)

| Target | Sheet |
|--------|-------|
| QuantStack / FLUX.1-Kontext-dev-GGUF | [`models/MODEL_QUANTSTACK_FLUX1_KONTEXT_DEV_GGUF.md`](./gguf/models/MODEL_QUANTSTACK_FLUX1_KONTEXT_DEV_GGUF.md) |
| ponpoke / flux2-klein uncensored **encoder only** (doc; not a desktop catalogue row) | [`models/MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md`](./gguf/models/MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md) |
| Wan (video) | [`models/MODEL_WAN_GGUF.md`](./gguf/models/MODEL_WAN_GGUF.md) |

---

## Model registry — Diffusers

Stack library: [`diffusers/DIFFUSERS_IMAGING_STACK_LIBRARY.md`](./diffusers/DIFFUSERS_IMAGING_STACK_LIBRARY.md). Sheets: [`diffusers/models/`](./diffusers/models/).

| Status | Target | Sheet |
|--------|--------|-------|
| [x] | FHDR Uncensored (preset) | [`diffusers/models/MODEL_KPSSS34_FHDR_UNCENSORED.md`](./diffusers/models/MODEL_KPSSS34_FHDR_UNCENSORED.md) |
| [ ] | Shuttle 3.1 Aesthetic (tree) | [`diffusers/models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC_DIFFUSERS.md`](./diffusers/models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC_DIFFUSERS.md) |
| [ ] | FLUX.2 Klein 9B (BFL) | [`diffusers/models/MODEL_BFL_FLUX2_KLEIN_9B_DIFFUSERS.md`](./diffusers/models/MODEL_BFL_FLUX2_KLEIN_9B_DIFFUSERS.md) |
| [ ] | FLUX.1 Dev (BFL) | [`diffusers/models/MODEL_BFL_FLUX1_DEV_DIFFUSERS.md`](./diffusers/models/MODEL_BFL_FLUX1_DEV_DIFFUSERS.md) |
| [ ] | ERNIE-Image (Baidu) | [`diffusers/models/MODEL_BAIDU_ERNIE_IMAGE_DIFFUSERS.md`](./diffusers/models/MODEL_BAIDU_ERNIE_IMAGE_DIFFUSERS.md) |

## Model registry — ONNX (post / aux)

Stack library: [`onnx/ONNX_IMAGING_STACK_LIBRARY.md`](./onnx/ONNX_IMAGING_STACK_LIBRARY.md). Sheets: [`onnx/models/`](./onnx/models/).

| Status | Target | Sheet |
|--------|--------|-------|
| [ ] | 4× UltraSharp post | [`onnx/models/MODEL_ONNX_ULTRASHARP_X4.md`](./onnx/models/MODEL_ONNX_ULTRASHARP_X4.md) |
| [ ] | Portrait depth | [`onnx/models/MODEL_ONNX_PORTRAIT_DEPTH.md`](./onnx/models/MODEL_ONNX_PORTRAIT_DEPTH.md) |
| [ ] | rembg / U²-Net | [`onnx/models/MODEL_ONNX_REMBG_U2NET.md`](./onnx/models/MODEL_ONNX_REMBG_U2NET.md) |
| [ ] | GFPGAN face restore | [`onnx/models/MODEL_ONNX_GFPGAN.md`](./onnx/models/MODEL_ONNX_GFPGAN.md) |
| [ ] | DWPose aux | [`onnx/models/MODEL_ONNX_DWPOSE.md`](./onnx/models/MODEL_ONNX_DWPOSE.md) |

## Model registry — Diffusers / other (legacy section)

| Status | Target | Sheet |
|--------|--------|-------|
| [x] | kpsss34 / FHDR_Uncensored **GGUF** | [`models/MODEL_KPSSS34_FHDR_UNCENSORED.md`](./gguf/models/MODEL_KPSSS34_FHDR_UNCENSORED.md) — `FHDR_ComfyUI-*.gguf` + split-pack in Media Magic (E2E verified 2026-05-20) |
| [x] | kpsss34 / FHDR_Uncensored **Diffusers** (optional) | same sheet — preset `flux_fhdr_uncensored_kpsss34` |
| [ ] | BFL / FLUX.2-klein-9B full stack | [`models/MODEL_BFL_FLUX2_KLEIN_9B.md`](./gguf/models/MODEL_BFL_FLUX2_KLEIN_9B.md) |

Add a row + `models/MODEL_*.md` when adopting a new HF repo; assign a **`pack_family_id`** in the sheet.

**FLUX.2 Klein 9B** has **two** desktop tracks:

1. **Diffusers** — official [FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B) bundle → [`MODEL_BFL_FLUX2_KLEIN_9B.md`](./gguf/models/MODEL_BFL_FLUX2_KLEIN_9B.md).  
2. **GGUF native** — [unsloth/FLUX.2-klein-9B-GGUF](https://huggingface.co/unsloth/FLUX.2-klein-9B-GGUF) + companion VAE/LLM files per `vendor/stable-diffusion.cpp/docs/flux2.md` → [`MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](./gguf/models/MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md). **Not** the FLUX.1 `vae/` + `text_encoder/` + `text_encoder_2/` split-pack.

Swapping in the [ponpoke uncensored text encoder](https://huggingface.co/ponpoke/flux2-klein-9b-uncensored-text-encoder) is **phase 2** after a baseline runs; the encoder-only repo is not a standalone image preset.

---

## GGUF imaging lane (product rules, not per-repo)

- [`gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](./gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) — capabilities, ONNX post, UX  
- [`gguf/GGUF_MODEL_PACK_FAMILIES.md`](./gguf/GGUF_MODEL_PACK_FAMILIES.md) — **pack layouts + auto-router** (plug-and-play)

---

## Model paths / import UX

- [`../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)

---

## Android reference (same product lane, different runtime)

Folder taxonomy aligns with [`../../../../android-arm64/implementations/generation/imaging/`](../../../../android-arm64/implementations/generation/imaging/) for FLUX / ONNX plans; Windows rows above are authoritative for **desktop** status.

---

## Linked todos (lane-wide)

| Todo | Intent |
|------|--------|
| [`../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md`](../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md) | First desktop imaging stack, probes, and UI honesty. |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-14 | Added imaging lane index: inference-family checkboxes, per-model registry with detail docs under `models/`, links to GGUF lane + Diffusers stub. |
| 2026-05-14 | Clarified FLUX.2 full-model vs ponpoke encoder phase 2; added BFL FLUX.2-klein sheet link. |
| 2026-05-17 | Aligned with desktop: GGUF infra + dist:full media-python; Shuttle GGUF-first sheet; FHDR Diffusers ticked at infra level. |
| 2026-05-18 | Added unsloth FLUX.2-klein-9B-GGUF sheet; clarified Diffusers vs flux2 native pack for klein 9B. |
| 2026-05-20 | Model sheets under `gguf/models/`; added `onnx/` and `python/` imaging lane plans (ONNX post, PersonaLive sidecar). |
| 2026-05-18 | Expanded GGUF registry (~25 model sheets); added `GGUF_MODEL_PACK_FAMILIES.md` and plug-and-play routing waves. |
| 2026-05-20 | Marked **shipped** / E2E verified: Shuttle 3.1 Aesthetic, leejet FLUX.2 Klein 9B GGUF, FHDR Uncensored GGUF (author GPU). |
