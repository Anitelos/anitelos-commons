# Compose pipeline — sources, compare manifests, and graph routing

| Field | Value |
|-------|-------|
| **Parent** | [`CURATED_SUNO_CLONE_PIPELINE.md`](./CURATED_SUNO_CLONE_PIPELINE.md) |
| **Code** | `compose-instrumental-pipeline.js`, `compose-pipeline-artifacts.js` |

Purpose: document how **secondary sources** (image, audio, prior outputs) flow through Compose today and how saved pipelines will let users **wire outputs to inputs** in the Playground graph. Editor direction: [`./PLAYGROUND_NODE_EDITOR_DIRECTION.md`](./PLAYGROUND_NODE_EDITOR_DIRECTION.md).

---

## Today (desktop)

### Single backend

1. **Prepare** — merge user bed prompt + **From image** / **From audio**:
   - **Image → audio (I2A):** pick a **vision model** (image-to-text GGUF + mmproj) → caption merged into bed prompt → Lane 4 defaults to **AudioLDM 2** (BLIP augments again at generation). Compare-all prefers the `audioldm2` candidate. Other backends still get the vision caption in the shared prompt; BLIP adds a second caption when an image path is passed.
   - **Audio → text:** native GGUF `--audio` via mtmd when model + mmproj exist; else Whisper ASR.
   - **Audio → audio (A2A):** optional semantic brief (GGUF or Whisper) for the text prompt; default backend **MusicGen Melody** (neural conditioning on `referenceAudioPath`). Legacy ffmpeg `amix` blend is opt-in (`legacyA2aBlend`) and is not labeled neural A2A in the UI.
2. **Lane 4** — one backend (`stable_audio_open`, `musicgen`, `musicgen_melody`, `audioldm2`) with `imagePath` / `referenceAudioPath` when applicable.

### Compare all (four backends)

1. **Prepare once** — same source pipeline as single-backend (sources are not re-run per backend).
2. **Four Lane 4 passes** — shared `bedPrompt`; reference audio is passed only to `musicgen_melody` during A2A.
3. **Record** — `generated-media/audio/compose-instrumental-compare/<runId>/compare.json` plus one WAV per backend.

`compare.json` shape:

```json
{
  "version": 1,
  "kind": "compose-instrumental-compare",
  "bedPrompt": "…",
  "sources": { "fromImageMode": "vision_bed", "imageSourcePath": "…" },
  "candidates": [
    { "backend": "stable_audio_open", "ok": true, "wavPath": "…/instrumental-stable_audio_open.wav" },
    { "backend": "musicgen", "ok": true, "wavPath": "…" },
    { "backend": "audioldm2", "ok": false, "error": "…" }
  ],
  "selectedBackend": "stable_audio_open",
  "selectedWavPath": "…"
}
```

Compose UI **Compare pick** switches preview / handoff to another candidate without re-running sources.

---

## Planned — graph source routing

When the Playground canvas mirrors the Suno DAG:

| Concept | Behavior |
|---------|----------|
| **Output port** | A stage exposes `instrumental.wav`, `voice.wav`, `lyrics.txt`, etc. |
| **Source input** | **From audio** / **From image** can bind to **a file path** *or* **an upstream output ref** (`stageId` + artifact id). |
| **Edge** | User draws a line from output → source; runner resolves path at execute time. |
| **Reuse** | Re-running a saved pipeline reuses prior artifacts unless the user clears the edge or replaces the source. |

Secondary sources remain editable per node — e.g. swap reference audio from disk to “use bed from S2 compare pick `audioldm2`”.

This matches Android Kokoro-style preset reuse: **engines** stay stable; **edges** choose which artifact feeds the next step.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-24 | Compare-all via compose pipeline + `compare.json` manifest; graph routing plan. |
| 2026-05-22 | Native GGUF audio (mtmd `--audio`), vision-guided I2A, MusicGen Melody neural A2A. |
