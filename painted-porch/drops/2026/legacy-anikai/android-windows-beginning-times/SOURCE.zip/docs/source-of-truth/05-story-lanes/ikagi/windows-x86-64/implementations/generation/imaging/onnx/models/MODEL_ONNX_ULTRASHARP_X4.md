# Model sheet — 4× UltraSharp (ONNX post)

| Field | Value |
|-------|-------|
| **Family** | `onnx_image_post` |
| **Reference** | [Kim2091/UltraSharp](https://huggingface.co/Kim2091/UltraSharp) |

Post-pass upscale after FLUX still generation. See [`../ONNX_IMAGING_STACK_LIBRARY.md`](../ONNX_IMAGING_STACK_LIBRARY.md) and Android [`SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../../../../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md).
