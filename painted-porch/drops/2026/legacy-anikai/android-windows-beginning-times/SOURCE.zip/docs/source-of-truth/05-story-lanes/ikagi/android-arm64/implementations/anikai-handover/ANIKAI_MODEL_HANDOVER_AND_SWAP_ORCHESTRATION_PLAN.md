# ANIKAI model handover and swap orchestration plan

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define the "ultimate swap-out mechanic" so ANIKAI can hand tasks across installed model families and device/runtime lanes without keeping everything resident in memory.

---

## Scope

This file covers:

- cross-model handover orchestration for live app behavior,
- role-based model switching for reflex/reporting/research/creative flows,
- memory-aware activation/deactivation policy,
- runtime placement decisions (`PHONE`, `PC`, `CLOUD`, `SERVER`, `HYBRID`) per task.

This file does **not** define model internals for each runtime family (those stay in engine-inference docs).

---

## Why this exists

ANIKAI is not a single-model app. It is a local-first sentient platform where:

- companion continuity is maintained,
- specialist models are loaded only when needed,
- task outcomes return to companion memory/context,
- UI controls can reflect real installed capability rather than hardcoded assumptions.

---

## Core handover concept (Multi-Modal Fusion)

1. **Sensory Fusion:** Input specialists (Audio/Vision/Screen) feed "Modality Packets" (Emotion/Phonemes/Visuals) to the Orchestrator.
2. **Companion Context Injection:** The "Soul" receives the fused packet, bypassing "flat text" limitations.
3. **Turn-Taking Guardrails:** Flow monitors (e.g., Namo/PersonaPlex) trigger interruptions or "Listening" states in real-time.
4. **Companion decides intent + lane class** based on this enriched situational awareness (chat, reflex, surveillance review, creative generation, etc.).

---

## Service planes and ownership

To avoid control confusion, ANIKAI should separate service planes in UX while keeping one shared model capability pool underneath.

- **Sentience Systems (formerly Reflex-heavy surface):** always-on or event-driven perception/interaction services (eyes/ears/touch/turn/emotion/screen awareness).
- **Swarm Pipelines:** workflow and automation flows that chain tasks, tools, and specialist models.
- **Soul/Companion:** intent policy, memory continuity, reasoning depth, and final conversational decisions.
- **Meridian voice layer:** companion voice/persona shaping and expressive render controls.

Rule: Sentience and Swarm stay separate in user-facing controls, but both pull from the same runtime adapter registry and model capability manifests.

### Sentience assignment model

Users can assign models to sentience roles from any supported runtime family when readiness gates pass.

- `sentience.eyes.primary` (vision/facial/emotion/screen)
- `sentience.ears.asr` (speech front-end)
- `sentience.turn.monitor` (interrupt and turn boundaries)
- `sentience.touch.context` (interaction-state sensing)
- `sentience.emotion.classifier` (tone/affect sensing)

Each role can define primary + fallback models and a disabled state. If a role is unavailable, the handover path must show an explicit degraded label instead of silently pretending full sentience support.

---

## Live speech latency model

Live speech should not assume a single blocking path of:

`user audio -> ASR text -> main text model -> full text answer -> Kokoro/TTS render -> playback`

That path is valid for thoughtful replies, saved chat, journals, and reports, but it stacks latency from every model in the chain. For instant conversation, ANIKAI should split live speech into parallel lanes:

1. **Speech front-end lane:** fast ASR, partial transcript, turn state, optional phoneme/tone/emotion features.
2. **Turn monitor lane:** detects start/end/interruption and can cut current TTS immediately.
3. **Fast response lane:** emits short acknowledgements, listening signals, and lightweight replies.
4. **Companion reasoning lane:** the main text model decides meaning, memory updates, intent, and richer response content.
5. **Voice render lane:** Kokoro/XTTS/other TTS renders selected text into sound, ideally chunked or warmed.

The text model remains the truth layer for memory, journal, task records, and durable chat. It does not need to handle every live-speech micro-action before the user hears anything.

### Canary-Qwen style reference

Models such as NVIDIA Canary-Qwen-2.5B are useful as a reference architecture even when they are too large or runtime-specific for the phone app. Canary-Qwen combines a speech encoder with a Qwen text model and supports ASR mode plus text-only LLM mode. This shows the desired role split:

- **ASR mode:** speech becomes high-quality transcript quickly, without pretending the model is the whole companion.
- **LLM/text mode:** transcript can later be summarized, cleaned, answered, or documented.
- **ANIKAI implication:** a speech specialist can serve the companion rather than replacing it.

For mobile ANIKAI, a smaller ASR/turn/emotion stack should handle live hearing. A larger model such as Gemma 4B/e4B-class text reasoning should be reserved for deeper replies, memory synthesis, reports, or moments where quality matters more than instant speech.

### Fast path vs deep path

| Path | Target latency | Model roles | User-facing purpose |
|------|----------------|-------------|---------------------|
| **Fast live path** | sub-second to a few seconds | ASR/turn detector + small reflex/text lane + warmed short TTS | "I'm listening", interruption, short reply, conversational presence |
| **Deep companion path** | slower, quality-first | main text model + memory/context + Kokoro expressive render | meaningful response, journal-safe transcript, durable memory |
| **Documentation path** | async/background | transcript cleanup + summarizer/report model | readable chat history, memory summaries, workspace records |

Rule: adding more models only improves live speech if they run in parallel, stay warm when needed, and return compact packets. Sequentially chaining more models makes live speech slower.

---

## Role classes for handover

| Role class | Typical behavior | Candidate model/runtime families |
|------------|------------------|----------------------------------|
| **Sensory Perception (Eyes/Ears)** | Extracts emotion, phonemes, and visual context | Qwen3-ASR / Face-Emotion / MediaPipe |
| **Flow/Turn Monitor** | Detects interruptions and conversational turns | Turn-Detector-v1 / PersonaPlex |
| **Digital/Screen Analyst** | "Screen surfing" for in-app context awareness | Specialized VLM / OCR-Lanes / Accessibility Node Scraping |
| **Always-alive reflex monitor** | low-cost environment checks and event triggers | LiteRT / MediaPipe / QNN-class lanes |
| **Rapid-response text** | immediate conversational reply with good enough reasoning | compact GGUF / LiteRT text lane |
| **Deep reasoning/reporting** | slower but richer synthesis and evidence framing | larger GGUF or other high-quality local lane |
| **Vision surveillance review** | frame/event analysis and structured findings | MediaPipe / NCNN / ONNX / QNN lanes |
| **Creative generation orchestrator** | delegates to image/music/video pipelines | FLUX/ONNX generation + pipeline lanes |
| **Post-process specialist** | enhancement/cleanup/consistency passes | ONNX / NCNN / DSP helpers |

---

## Handover packet contract (Protobuf V1)

To ensure maximum speed across JNI boundaries (Kotlin <-> C++ runtimes), ANIKAI uses **Protobuf** for the handover packet. This avoids JSON parsing overhead and ensures memory safety during "warm" swaps.

Every specialist handoff should return a packet with:

- `taskId` (string)
- `sourceModelId` (string) and `runtimeFamily` (string)
- `inputSummary` (string): Compressed context of what the model received.
- `outputSummary` (string): The primary result/thought.
- `evidenceRefs` (repeated string): Artifact paths/ids.
- `confidence` (float)
- `latencyMs` (int32)
- `resourceCost` (enum): `TIER_LOW`, `TIER_MED`, `TIER_HIGH` (mapped to thermal impact).
- `nextSuggestedAction` (string)

Companion stores the binary packet summary and may persist full artifact refs in workspace/drop flows.

---

## Swap policy (memory and thermal aware)

### A) Residency tiers

- **Tier A (Resident):** The "Soul" core. Minimal reflex/companion lanes. Locked in memory; only evicted by OS-level `onTrimMemory(FATAL)`.
- **Tier B (Warm Pool):** A registry of recently used specialist runtimes (e.g., Kokoro, NCNN filters). 
    - **Logic:** Keeps runtimes initialized but idle.
    - **Eviction:** Uses LRU (Least Recently Used) weighted by *Role Importance*. 
    - **Heartbeat:** Orchestrator pings the JNI handle before delegation to ensure the OS hasn't reclaimed the memory.
- **Tier C (Cold Swap):** Heavy-duty models (FLUX, 8B+ GGUFs). Loaded strictly on-demand. Released immediately after task completion unless in a "Deep Session."

### B) Trigger rules (The Orchestrator Logic)

1. **Thermal Pressure (Throttling):**
    - `Level: Moderate` -> Disable Tier B Warm Pool (force Cold Swaps to allow cooling).
    - `Level: High` -> Force "Lizard Brain" mode (run only Tier A LiteRT/QNN models).
2. **Memory Pressure (RAM):**
    - On `onTrimMemory(MODERATE)`, evict the oldest Tier B specialist.
    - On `onTrimMemory(CRITICAL)`, wipe Tier B and clear KV Caches in Tier A.
3. **Task Urgency:**
    - `Urgent` -> Bypass reasoning chain, route to the fastest "Warm" specialist regardless of quality.
    - `Background` -> Queue for NPU-only execution (QNN/SNPE) to save battery.

### C) Honesty rules

- no hidden route switch to cloud when local policy says local-only,
- degraded mode must be labeled when downgraded model used.

---

## Example orchestration scenarios

### 1) Smart surveillance review (user phone + camera app events)

1. Reflex trigger receives event metadata.
2. Scheduler chooses vision specialist (MediaPipe/NCNN/QNN based on device).
3. Specialist returns structured observations + key frames.
4. Companion summarizer model produces report for user.
5. If follow-up needed, deeper text model swaps in for expanded explanation.

### 2) Live chat with background awareness

1. Fast text lane handles interactive replies.
2. Reflex lane runs lightweight awareness checks in parallel windows.
3. On notable event, specialist lane analyzes and sends packet.
4. Companion injects relevant result into chat naturally.

### 3) Creative + research mixed session

1. Companion planning lane breaks request into sub-tasks.
2. Image/music pipelines run on specialist generation lanes.
3. Reporting lane summarizes outputs and options.
4. Idle heavy models are swapped out to free memory.

---

## UI/UX implications (future user access section)

- show which model/runtime handled each major task,
- show handover chain in advanced logs (compact by default),
- allow user policy presets:
  - `speed-first`,
  - `quality-first`,
  - `battery-first`,
  - `local-only strict`.

---

## Phased implementation

### Phase 0 - contract and metadata

- Define `HandoverPacket.proto` schema for cross-language JNI efficiency.
- Map role classes to existing model families (NCNN, GGUF, LiteRT, etc.).
- Establish the "Warm Pool" registry for recently used specialist runtimes.

### Phase 1 - basic orchestrator

- implement one-way delegation with return packet to companion,
- support at least reflex -> specialist -> companion loop.

### Phase 2 - dynamic swap policy

- add memory/thermal-aware selection and unloading rules,
- implement policy presets and explicit degraded labeling.

### Phase 3 - full placement matrix

- integrate phone/pc/cloud/server/hybrid routing policy under same handover contract.

---

## Open decisions

- first role class pair to operationalize (recommended: sentience ears/turn + fast text companion),
- minimal packet schema for v1 vs v2 diagnostics depth,
- whether warm pool should be fixed-size or adaptive,
- whether Reflex should remain a compatibility sub-service label under Sentience Systems in user-facing surfaces.

---

## Linked docs

- `implementations/engine-inference/model-hub/*` (runtime family docs)
- `implementations/anikai-handover/SENTIENCE_SYSTEMS_UI_CONTRACT.md`
- `implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`
- `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`

---

## Linked todo

- `todo/mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial ANIKAI handover orchestration plan added for dynamic model-role swap architecture. |
| 2026-05-08 | Added service plane split (Sentience Systems vs Swarm), shared model-pool rule, and sentience role assignment model. |
| 2026-05-08 | Linked dedicated Sentience Systems UI contract for user-facing role-card and readiness behavior. |
