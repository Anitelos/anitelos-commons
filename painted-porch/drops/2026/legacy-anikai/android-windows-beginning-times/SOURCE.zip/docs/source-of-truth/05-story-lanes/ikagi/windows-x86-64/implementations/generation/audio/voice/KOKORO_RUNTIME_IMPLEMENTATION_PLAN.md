# Kokoro runtime implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Current state (code)

- Engine catalog present under `ExpressiveEngineKind.KOKORO`.
- Runtime lane implemented via `HfKokoroRuntimePack`.
- ONNX adapter path exists in `HfKokoroOnnxAdapter`.
- Kokoro emotion/tuning UI and helper assets exist in Soul Meridian voice surfaces.

Primary references:

- `.../voice/catalog/ExpressiveVoiceCatalog.kt`
- `.../voice/provider_runtimes/VoiceProviderRuntime.kt` (`HfKokoroRuntimePack`)
- `.../voice/provider_runtimes/local_runtime/HfKokoroOnnxAdapter.kt`
- `.../voice_tab/engines/kokoro/*`

---

## Operational goals

1. deterministic pack readiness and clear diagnostics,
2. predictable synthesis behavior under local runtime budget constraints,
3. verified emotion/prosody integration path (not only UI controls),
4. stable streaming + non-streaming parity where expected.

---

## Checklist

- [ ] Readiness contract test matrix (missing model, missing tokenizer/voices, invalid pack).
- [ ] Synthesis quality sweep (short/long utterances, punctuation, non-ASCII edge cases).
- [ ] Emotion recipe validation against runtime output (not just parameter updates).
- [ ] Voice session state correctness (`Queued -> Synthesizing -> Ready/Playing -> Completed`).
- [ ] Failure UX messages aligned with actionable remediation.

---

## Dependencies

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Umbrella: `../VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Mixed pipeline relation: `../../../pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial dedicated Kokoro runtime plan split from umbrella voice doc. |
