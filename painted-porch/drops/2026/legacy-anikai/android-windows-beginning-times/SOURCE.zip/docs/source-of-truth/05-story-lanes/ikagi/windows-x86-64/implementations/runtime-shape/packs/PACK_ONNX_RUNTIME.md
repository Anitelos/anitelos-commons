# ONNX Runtime pack (ORT DLLs)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.onnx` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Shared ORT providers for neural TTS (Kokoro / Cosy / VITS-class). Imaging still uses onnxruntime-node until unified.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

voice.onnx ZIP: ORT + CUDA/DirectML provider DLLs tested matrix.

## Staging path

`desktop-data/runtime-packs/voice.onnx/`

## Unlocks (no model weights)

neural-tts, shared-ort-dlls

## Verification smoke

Load Kokoro-class graph on CPU EP.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
