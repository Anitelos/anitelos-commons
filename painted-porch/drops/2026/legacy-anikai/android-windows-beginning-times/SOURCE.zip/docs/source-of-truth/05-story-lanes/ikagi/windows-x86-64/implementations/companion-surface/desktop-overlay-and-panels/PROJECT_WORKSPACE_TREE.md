# Project workspace tree (Windows desktop)

| Field | Value |
|-------|-------|
| **Scope** | M0 tree slice — separate HWND + chat left rail |
| **Operations** | **Shipped** (2026-05-20) |
| **Magnet generalization** | [`MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](./MAGNET_PANELS_WORKSPACE_OVERVIEW.md) (panel→panel magnets still planned) |

---

## Layout

```text
[ Dock ] | [ Tree strip ] | Chat body | [ Thread rail ]
              ↓ toggle
         [ Project panel HWND ]  ← magnet-linked left of main chat
```

- **Left rail** (`#chatProjectRailToggle`) — on the chat shell, not the thread rail.
- **Tree panel** — `?panel=workspace` satellite; `magnetRegistry.setLink('workspace', 'main', -width, 0)`.
- **Dock** — shifts left by `workspaceLayout.width` when the tree is open (`syncDockPosition`).

Detached companion chat uses its own HWND; workspace tree stays on **main** chat anchor today (tree does not auto-follow detached windows).

---

## Data model

| Store | Path | Content |
|-------|------|---------|
| Global catalogue | `ANIKAI_HOME/projects/registry.json` | `[{ id, name, rootPath, createdAt }]` |
| Project meta | `ANIKAI_HOME/projects/<projectId>/project.json` | Copy of entry metadata |
| Per-thread UI | `ANIKAI_HOME/desktop-data/thread-workspace/<threadKey>.json` | `activeProjectId`, `treeUi`, `panelUi` |

**threadKey:** `companion:<id>` solo · `group:<groupId>` for groups (shared project choice per group thread).

```json
{
  "version": 1,
  "activeProjectId": "proj_…",
  "treeUi": {
    "expandedPaths": ["src"],
    "scrollTop": 420,
    "selectedPath": "src/main.js"
  },
  "panelUi": {
    "treeOpen": true,
    "treeWidth": 260
  }
}
```

---

## IPC (`workspace:*`)

| Channel | Role |
|---------|------|
| `workspace:projects-list` / `projects-add` | Global registry |
| `workspace:thread-load` / `thread-save` | Per-thread state |
| `workspace:tree-list` | Read tree (`workspace-tree-fs.js`) |
| `workspace:tree-mkdir` / `tree-touch-file` | Create under project root |
| `workspace:toggle-panel` | Open/close tree HWND; `open: true/false` to force |
| `workspace:set-thread-context` | Push thread key to panel |
| `workspace:panel-state` | Chat rail sync |

---

## Code map

| Piece | File |
|-------|------|
| Tree UI | `anikai-desktop/components/workspace-tree.js` |
| Panel host | `anikai-desktop/components/panels.js` (`mountWorkspacePanel`) |
| Chat rail + thread restore | `anikai-desktop/components/chat.js` |
| Registry | `anikai-desktop/main-process/projects-registry.js` |
| Thread state | `anikai-desktop/main-process/thread-workspace-state.js` |
| FS helpers | `anikai-desktop/main-process/workspace-tree-fs.js` |
| Placement + magnet | `anikai-desktop/main.js` (`syncWorkspacePanelPosition`, `workspace:toggle-panel`) |

---

## Build order status

| Step | Status |
|------|--------|
| M0 magnet + placement (tree satellite) | **Done** |
| Project registry + picker (+ Proj) | **Done** |
| Read-only tree + expand/select | **Done** |
| + File / + Folder | **Done** |
| Per-thread `panelUi.treeOpen` restore on thread switch | **Done** (2026-05-20) |
| Multi-root “+ project to tree” | Planned |
| Group blackboard / manager embed | [`execution-agent/TEAM_BLACKBOARD_ORCHESTRATION.md`](../../anikai-agent-workflows/execution-agent/TEAM_BLACKBOARD_ORCHESTRATION.md) |

---

## See also

- [`../../WINDOWS_DESKTOP_INDEX.md`](../../WINDOWS_DESKTOP_INDEX.md) — doc tighten hub
- [`../../anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md`](../../anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md) — workshop status
- [`../../anikai-agent-workflows/execution-agent/ROLES_INDEX.md`](../../anikai-agent-workflows/execution-agent/ROLES_INDEX.md) — manager vs familiars vs session roles
- [`../../anikai-agent-workflows/execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md`](../../anikai-agent-workflows/execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md) — future writes under project root
- [`MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](./MAGNET_PANELS_WORKSPACE_OVERVIEW.md) — drag-magnet panels (planned)
- [`../../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md`](../../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md)
