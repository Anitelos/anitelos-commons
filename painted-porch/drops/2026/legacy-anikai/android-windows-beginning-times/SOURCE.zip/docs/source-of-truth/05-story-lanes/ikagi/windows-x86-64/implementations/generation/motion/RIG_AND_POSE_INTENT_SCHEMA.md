# Rig bus and PoseIntent schema (draft)

| Field | Value |
|-------|-------|
| **Parent** | [`MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md`](./MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md) |

Anikai separates **face rig channels** (phoneme-driven) from **body PoseIntent** (scene-driven). Both are JSON-friendly so a **Familiar** can fill them without generating pixels.

---

## Face rig frame (deterministic)

```json
{
  "t": 1.24,
  "mouthShape": "M",
  "brow": 0.2,
  "gaze": "camera",
  "blink": "normal",
  "headYaw": -0.05,
  "headPitch": 0.02,
  "mood": "warm"
}
```

| Field | Type | Notes |
|-------|------|-------|
| `t` | number | Seconds from phrase start |
| `mouthShape` | string | Phoneme bucket id (Kokoro-aligned set) |
| `brow` | number | −1..1 |
| `gaze` | string | `camera` \| `away_left` \| `away_right` \| `down` |
| `blink` | string | `normal` \| `slow` \| `wide` |
| `headYaw` / `headPitch` | number | Radians, small range |
| `mood` | string | From companion mood bus |

**Consumer:** canvas rig (Android), future `PhonemeDriverFrameSynth` → RGB driver video → PersonaLive.

---

## PoseIntent (body / scene)

```json
{
  "version": 1,
  "body": {
    "preset": "standing_hands_clasped",
    "facing": "three_quarter_left",
    "weight": "center",
    "energy": 0.7
  },
  "scene": {
    "holdPoseMs": 1200,
    "gestureOnWord": { "jar": "lift_hands" }
  },
  "face": {
    "mouthShape": "M",
    "brow": 0.2,
    "gaze": "camera"
  }
}
```

| Field | Type | Notes |
|-------|------|-------|
| `body.preset` | string | Id into app pose library (maps to OpenPose skeleton PNG) |
| `body.facing` | string | `front` \| `profile_left` \| `three_quarter_left` \| … |
| `body.weight` | string | `left` \| `center` \| `right` |
| `body.energy` | number | 0..1 — affects line thickness / optional motion blur hint |
| `scene.holdPoseMs` | number | Minimum hold before next Familiar update |
| `scene.gestureOnWord` | object | Token → preset id fired at TTS alignment time |
| `face` | object | Optional mirror of face rig for same beat |

**Consumers:**

1. **Procedural** — render OpenPose-colored skeleton PNG from preset.
2. **Extract** — DWPose on reference photo; diff against preset for retarget hints.
3. **Generate** — img2img with skeleton as conditioning (OpenPose grid workflow).

---

## Familiar tool contract (planned)

```json
{
  "tool": "set_motion_directive",
  "poseIntent": { },
  "rigFrame": { },
  "reason": "User asked character to sit at desk"
}
```

Validator rejects unknown presets and out-of-range floats before timeline enqueue.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Draft schema for phoneme + OpenPose-style control. |
