# Anikai media runtime pack

| Field | Value |
|-------|-------|
| **Pack id** | `pack.media.anikai` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** MIDI (FluidSynth + soundfont) + Diffusers Python venv for FHDR / diffusers presets.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

resources/audio-midi-bin + resources/media-python-runtime.

## Staging path

`resources/audio-midi-bin + resources/media-python-runtime`

## Unlocks (no model weights)

midi-render, diffusers-image, music-dsp-preview

## Verification smoke

FluidSynth render; venv import torch + diffusers.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
