# Model sheet — Background removal (U²-Net ONNX)

| Field | Value |
|-------|-------|
| **Family** | `onnx_matting` |
| **Upstream** | [rembg](https://github.com/danielgatis/rembg) |

Alpha cutout for sprites, stickers, and UI assets.
