# Model sheet — DWPose (ONNX aux)

| Field | Value |
|-------|-------|
| **Family** | `onnx_pose` |
| **Reference** | [yzd-v/DWPose](https://huggingface.co/yzd-v/DWPose) |

Pose maps for control / rig reference — img2img and future video lanes.
