# Diffusers imaging generation (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Started |
| **Last reviewed** | 2026-05-14 |

## Purpose

Track the **Python / Diffusers (and related)** path for still-image generation when a Hugging Face target is **not** satisfiable through the native **GGUF image CLI** alone. Examples live in [`../gguf/models/`](../gguf/models/) (GGUF sheets) and future [`../diffusers/models/`](../diffusers/models/) when we split Diffusers-only targets: ERNIE-Image, FHDR_Uncensored, Shuttle 3.1, and **multi-weight** stacks such as FLUX.2-klein + ponpoke text encoder.

**Engine load/probe for GGUF LM tasks** remains in the GGUF **engine** plan, not here.

## Anikai Desktop wiring (Track B)

Repo-relative paths (Electron **main** reads these at runtime):

| Artifact | Path |
|----------|------|
| Preset manifest | `anikai-desktop/config/media-models.json` |
| Python entry | `anikai-desktop/media-python/run_diffusers_image.py` |
| Node bridge | `anikai-desktop/main-process/media-diffusers-image.js` |

Environment:

| Variable | Role |
|----------|------|
| `ANIKAI_MEDIA_PYTHON` | Overrides bundled / PATH. Absolute path to `python.exe` (venv or portable) with deps installed. |
| `HF_TOKEN` | Only when a preset uses **`hf_model_id`** (hub) instead of **`model_path`** (local folder), e.g. gated repos. Local snapshots do not need it. |
| `ANIKAI_MEDIA_DIFFUSERS_TIMEOUT_MS` | Subprocess kill timeout (default 3_600_000 ms). |

**Local weights (default):** each preset should set **`model_path`** to either (1) a path **relative to the app Models root** (`ANIKAI_HOME/models/`, no `..`), e.g. `diffusers/shuttle-3.1-aesthetic`, or (2) an **absolute** directory that already contains a Diffusers snapshot (`config.json` + weights). The app creates empty relative folders on startup so users see where to copy files. **`from_pretrained` is then fully offline** for those presets.

**User overrides:** if `<ANIKAI_HOME>/media-models.json` exists, it is **merged** with the bundled manifest **by preset `id`** (user fields override bundled fields). End users can point `model_path` at their own layout without editing the app install.

**Bundled Python (optional, “no venv” for users):** ship a **portable** interpreter + preinstalled wheels under `anikai-desktop/resources/media-python-runtime/` (e.g. Windows embeddable Python + `pip install -r media-python/requirements.txt` into that tree). Packaged builds copy this folder via `extraResources` → `process.resourcesPath/media-python-runtime/`. The app picks up `python.exe` there **before** falling back to `ANIKAI_MEDIA_PYTHON` or system `PATH`. That artifact is **large** (CUDA torch is GB-scale); many teams ship it as a **separate “Media runtime” download** (same idea as your staged `llama-bin`) so the main installer stays small.

**What users still download:** only **model weights** into their Models directory. The **runtime** (Python+torch+diffusers) is either bundled once, staged like llama-bin, or power-user `venv` until you automate it.

IPC: `media:list-image-presets` returns `{ presets, modelsDir, userManifestPath }`. `media:generate-image` with `{ imagePreset, prompt, modelRef? }`.

## Scope

- Venv layout, pinned deps, subprocess contract (stdin JSON, stdout result line, output path).  
- GPU policy (CUDA vs CPU offload) and honest “env missing” UX in Electron.  
- Mapping **preset_id** → pipeline class + `from_pretrained` ids / local dirs (manifest-driven).

## Out of scope (for now)

- Shipping a full conda stack inside the installer (document manual setup until we automate).  
- ComfyUI-in-process embedding (see lane index “external graph runtime” row when promoted).

## Linked docs

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- **Stack library:** [`DIFFUSERS_IMAGING_STACK_LIBRARY.md`](./DIFFUSERS_IMAGING_STACK_LIBRARY.md)  
- Per-target sheets: [`models/`](./models/)  
- GGUF native lane (parallel, not duplicate): [`../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-14 | Stub plan added when imaging lane split per-model docs. |
| 2026-05-14 | Documented Anikai Desktop Track B paths (`config/media-models.json`, `media-python/run_diffusers_image.py`, env vars). |
| 2026-05-14 | Bundled `resources/media-python-runtime` discovery + extraResources; user model-only downloads stay under Models/. |
