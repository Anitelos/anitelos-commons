# Media WASAPI capture pack

| Field | Value |
|-------|-------|
| **Pack id** | `pack.media.wasapi` |
| **Tier** | A |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Loopback / mic capture for live transcribe, music react, copilot audio context.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

Native helper exe or node native addon; document consent UX.

## Staging path

`desktop-data/runtime-packs/media.wasapi/`

## Unlocks (no model weights)

loopback-capture, live-asr-input

## Verification smoke

5s loopback capture to WAV.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
