# TODO — Resona unification roadmap (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/resona/RESONA_UNIFICATION_PLAN.md`

---

## Intent

- Track active execution work from the Resona unification plan.
- Keep deferred items explicit without losing completion history.
- Preserve alignment with room/thread model and rollout diagnostics behavior.

---

## Checklist (working)

- [ ] Pull currently active items from `RESONA_UNIFICATION_PLAN.md` into scoped execution steps.
- [ ] Validate which deferred items should be promoted back to active for current Android cycle.
- [ ] Keep migration/diagnostics links current after doc moves.
- [ ] Mark operation status per item (`In progress` / `Operational` / `Needs revisit`).

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created todo bridge for Resona unification implementation doc. |
