# Model sheet — city96 / FLUX.1-schnell GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-14 |

## HF

- Repo: [city96/FLUX.1-schnell-gguf](https://huggingface.co/city96/FLUX.1-schnell-gguf)  
- Upstream base: [black-forest-labs/FLUX.1-schnell](https://huggingface.co/black-forest-labs/FLUX.1-schnell)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the diffusion `.gguf` (same layout `gguf-completion` probes).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- Encoders bundle (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  

## What it is

Direct **GGUF** conversion of **FLUX.1-schnell**, intended for **ComfyUI-GGUF** (`unet` placement per repo README). Same file may or may not load under **stable-diffusion.cpp** (`sd.exe`); that is an **engine compatibility** question, not implied by the HF card.

## Intended inference family (Windows desktop)

- **Primary candidate:** native **GGUF image** CLI (`sd.exe` / leejet fork) *if* graph and flags match our build.  
- **Fallback:** Diffusers or Comfy graph if native rejects the tensorization.

## Product notes

- **Preset id (future):** `flux1_schnell_gguf_city96` (proposal; align with manifest when implemented).  
- **User expectation:** fast few-step generation; document width/height and step defaults when we lock CLI.

## Implementation checklist (Anikai Desktop)

- [ ] Smoke: chosen `.gguf` loads without “version from file failed” class errors.  
- [ ] Documented CLI (flags, seeds, output path) in app or companion doc.  
- [ ] UI: preset or path picker + clear failure when unsupported.  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- GGUF imaging lane: [`../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-14 | Initial model sheet split from consolidated GGUF imaging doc. |
| 2026-05-19 | Document second-state FP16 sidecar repo (ae + clip_l + t5xxl_fp16) as primary ungated source; keep Letian/BFL as alternates. |
