# PersonaLive engine inference plan (portrait motion)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Upstream:** [GVCLab/PersonaLive](https://github.com/GVCLab/PersonaLive) (CVPR 2026) — expressive **portrait image animation**, real-time / streamable, infinite-length.

**Not the same as:**

| Family | Difference |
|--------|------------|
| **FOMM** (Qualcomm ONNX) | Classical first-order **motion transfer**; detector + generator `.onnx`; driving video → warp source appearance. |
| **Generic ONNX** (`PortraitDepthOnnxRuntime`) | Single-graph NCHW in/out; no diffusion stack. |
| **Deterministic rig** | App-drawn phoneme/mood signals; no neural re-render of the face texture. |

**Pipeline consumer:** [`../../../pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md`](../../../pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md)

**Cross-platform matrix:** [`../../../../windows-x86-64/implementations/engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](../../../../windows-x86-64/implementations/engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md)

**About / registry (goal inventory):** `anikai-desktop/assets/about-guide/motion-sentience-registry.json` — family `personalive_portrait`, format `personalive`.

**Todo:** [`../../../../windows-x86-64/todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md`](../../../../windows-x86-64/todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md)

---

## What PersonaLive gives Anikai

From the reference demo: **one portrait still** + **driving stream** (video of a face in motion) → **animated portrait** that matches expression/pose of the driver while keeping identity.

That replaces the old Android approach of **slicing mouth/eye layers per shot** and hand-wiring 2D parts — the **persona still stays one image**; motion is inferred.

**Honest limit:** PersonaLive does **not** ingest phonemes or TTS audio directly. It ingests **driving frames** (webcam, video file, or a **synthetic driver** Anikai builds from rig signals).

---

## Engine classification (registry / hub)

| Field | Value |
|-------|-------|
| `engineFamily` | `personalive` (new hub row — **not** `onnx` alone) |
| `runtimePack` | `python.personalive` (sidecar venv, like `media-python`) |
| `primaryArtifacts` | `pretrained_weights/personalive/*.pth` + SD/VAE deps (see upstream README) |
| `optionalAccelerators` | ONNX `unet_opt` + TensorRT engine (optional; quality/latency tradeoff) |
| `capabilities` | `portrait_motion_offline`, `portrait_motion_stream` |
| `license` | Apache-2.0 (academic disclaimer in upstream — surface in About) |

**About / registry table:** add a **Portrait motion** family row when weights path + VRAM floor are known — do **not** stuff PersonaLive into the generic ONNX imaging table.

---

## Weight layout (reference)

```text
pretrained_weights/
├── personalive/
│   ├── denoising_unet.pth
│   ├── motion_encoder.pth
│   ├── motion_extractor.pth
│   ├── pose_guider.pth
│   ├── reference_unet.pth
│   └── temporal_module.pth
├── sd-vae-ft-mse/
├── sd-image-variations-diffusers/
├── onnx/unet_opt/          # optional ORT/TRT path
└── tensorrt/               # optional, device-specific rebuild
```

**Staging policy (desktop, 2026-05-20):**

| Source | Role |
|--------|------|
| [huaichang/PersonaLive](https://huggingface.co/huaichang/PersonaLive) on Hugging Face | Canonical **`personalive/*.pth`** mirror (same files as upstream README) |
| `stabilityai/sd-vae-ft-mse` + `lambdalabs/sd-image-variations-diffusers` | SD sidecars (not all files live in the HF model repo tree) |
| `GVCLab/PersonaLive` git checkout | Engine code + venv; **not** a second weight copy — desktop **junction-links** `ANIKAI_HOME/models/personalive/pretrained_weights` → `personalive-engine/pretrained_weights` |

**Desktop UX:** **Download PersonaLive** (weights only, HF) → `models/personalive/pretrained_weights/`; engine + Python **bundled** in `personalive-runtime/` (installer); app **links** weights after download; **Run rig** → `inference_offline.py`.

Label **~12GB VRAM** class for streaming (upstream offline streaming note). Optional ONNX/TRT paths remain manual / later tier.

---

## Runtime integration shape (Anikai)

```mermaid
flowchart LR
  subgraph inputs [Anikai inputs]
    Portrait[Persona still PNG]
    Driver[Synthetic or live driving frames]
  end

  subgraph bridge [Adapter layer]
    Rig[Phoneme + mood rig signals]
    Synth[Driver frame synthesizer]
  end

  subgraph engine [python.personalive sidecar]
    PL[PersonaLive inference_online or offline]
  end

  subgraph out [Output]
    Stream[RGBA frame stream to UI]
  end

  Rig --> Synth --> Driver
  Portrait --> PL
  Driver --> PL
  PL --> Stream
```

| Component | Owner |
|-----------|--------|
| **Phoneme / TTS timing** | Existing rig + Kokoro phoneme path (`PersonaRigTestScreen`) |
| **Driver synthesizer** | New — renders low-res **face driver** video from rig channels (stick figure, LivePortrait-class landmarks, or looped template modulated by `mouthShape`) |
| **PersonaLive session** | Sidecar process; IPC: `reference_image`, `driving_frame[]`, `fps` |
| **UI** | Creations / home portrait — same slot as `PortraitAnimationWorker` output |

**v0 product path:** driving = **prebuilt driver clip** or **webcam** (prove engine). **v1 path:** driving = **synth from phonemes + emotion** (your goal).

---

## Verification gates (tick engine)

| Gate | Pass criteria |
|------|----------------|
| **INSTALLED** | Weights + base SD bundles on disk |
| **SUPPORTED** | CUDA/DML GPU class meets VRAM floor; Python venv imports |
| **LOADABLE** | `inference_offline.py` runs 32 frames reference+driving smoke |
| **VERIFIED** | Stream mode holds ≥ N fps at declared resolution on reference device |
| **DEGRADED** | Offline-only, no stream, or CPU fallback labeled |

Windows and Android can share **manifest + contract**; sidecar may ship desktop-first (VRAM room).

---

## FOMM vs PersonaLive (product choice)

| | FOMM (current Android plan) | PersonaLive |
|--|----------------------------|-------------|
| **Stack** | ONNX detector + generator | PyTorch diffusion + temporal module |
| **Feel** | Motion transfer / warp | Expressive re-synthesis, streaming |
| **Device story** | Snapdragon ONNX / ORT | GPU + Python; 12GB+ class |
| **Live** | Probe stage | Built for live streaming |
| **Anikai policy** | Keep on Android Swarm path | **Primary candidate** for “talking persona from one still” on PC + flagship phones |

Run **both** as capability-gated lanes; UI labels active engine. Do not block rig-only v0 on PersonaLive bring-up.

---

## Open decisions

1. **Driver synthesizer format** — raw RGB video vs landmark tensor API if PersonaLive exposes hooks (today: video path in configs).
2. **Windows vs Android first smoke** — desktop likely first; Android sidecar packaging later.
3. **Commercial use** — upstream academic disclaimer; product legal review before consumer ship.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial plan from PersonaLive discovery; separated from FOMM and generic ONNX. |
