# Roaming (anima)

Cross-device continuity when the soul’s presence shifts hosts—story-first notes before they become bridge schemas.
