# Model sheet — SD 3.5 Large Turbo (stduhpf GGUF)

| Field | Value |
|-------|-------|
| **Pack family** | `sd3_clip_stack` |
| **DiT** | [stduhpf/SD3.5-Large-Turbo-GGUF-mixed-sdcpp](https://huggingface.co/stduhpf/SD3.5-Large-Turbo-GGUF-mixed-sdcpp) |
| **Encoders** | `clip_l.safetensors`, `clip_g.safetensors`, `t5xxl_fp8_e4m3fn.safetensors` (from [calcuis/sd3.5-large-gguf](https://huggingface.co/calcuis/sd3.5-large-gguf) URLs — not in the stduhpf repo) |

**Get pack (4 files):** one `sd3.5_large_turbo-*.gguf` + three encoder safetensors in `models/sd35-turbo-stduhpf/`. Preflight can reuse encoders already in `sd35-large-calcuis/` or `_shared/` when present.

Turbo DiT has no `--vae` in sd.cpp (same as large). Encoder weights are gated via the calcuis large repo (Stability AI community license).
