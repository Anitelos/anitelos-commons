# Model sheet — QuantStack / Qwen-Image-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [QuantStack/Qwen-Image-GGUF](https://huggingface.co/QuantStack/Qwen-Image-GGUF)  
- Comfy splits: [Comfy-Org/Qwen-Image_ComfyUI](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI)  
- sd.cpp: [`qwen_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/qwen_image.md)  

## Pack family

`qwen_image_llm_vae` — **distinct** from flux2 (different VAE + Qwen2.5-VL-7B + `--flow-shift 3`).

## Weight layout

```text
models/qwen-image/
  qwen-image-Q8_0.gguf
  vae/qwen_image_vae.safetensors
  text_encoders/Qwen2.5-VL-7B-Instruct-….gguf
```

## Product

- **Preset id:** `qwen_image_gguf_quantstack`  
- **Profile (proposal):** `qwen_image_gguf` — 1024², cfg 2.5, euler, flow-shift 3  

## Anikai router

`planned` — new `buildQwenImageSdArgs` + `probeQwenImagePackLayout`.

## Phase 2

[`qwen_image_edit.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/qwen_image_edit.md) — editing / inpaint (vision slice).

## Checklist

- [ ] Router + probe  
- [ ] E2E with Chinese + English prompt smoke  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
