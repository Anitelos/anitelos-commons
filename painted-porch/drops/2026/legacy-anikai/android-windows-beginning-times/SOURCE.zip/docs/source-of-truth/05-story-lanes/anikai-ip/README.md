# ANIKAI IP & legal posture

**Scope:** naming, marks, asset provenance, license choices, and “how we stay out of trouble while still shipping fast.”

**When to open:** you are deciding what to log now so later filings or partner conversations are not guesswork.

**Pair with:** `01-catalogs/ANIKAI_OEM_QUIRK_REGISTER.md` for device reality; this folder is the **strategic** side, not per-OEM bugs.
