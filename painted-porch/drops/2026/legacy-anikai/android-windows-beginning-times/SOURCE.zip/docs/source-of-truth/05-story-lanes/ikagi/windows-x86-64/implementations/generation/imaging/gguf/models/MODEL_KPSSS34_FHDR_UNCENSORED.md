# Model sheet — kpsss34 / FHDR_Uncensored

| Field | Value |
|-------|-------|
| **Doc staging** | Complete |
| **Operations** | Shipped (GGUF E2E verified) |
| **Last reviewed** | 2026-05-20 |

## HF

- Repo: [kpsss34/FHDR_Uncensored](https://huggingface.co/kpsss34/FHDR_Uncensored)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the GGUF (matches Anikai `downloadPacks`).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- Encoders bundle (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  

## What it is

**FLUX**-family model. The Hugging Face repo ships both a **Diffusers** tree and **Comfy/GGUF** files (`FHDR_ComfyUI-*.gguf`). **Anikai supports both paths:**

| Path | How |
|------|-----|
| **GGUF native (primary for many users)** | Register `FHDR_ComfyUI-Q8_0.gguf` (or other quant) in Models, tag **Image**, select in **Media Magic**. Folder = **FLUX.1 split-pack**: `vae/`, `text_encoder/`, `text_encoder_2/` beside the `.gguf`. Router: `flux1_clip_t5`; profile: `flux_dev_gguf`. **Gated** on HF — accept repo terms, then Get pack or manual copy. |
| **Diffusers sidecar** | Preset `flux_fhdr_uncensored_kpsss34` → `models/fhdr/` with full Diffusers snapshot (`model_index.json`, `transformer/`, etc.). |

## Local folder for Anikai (one “model” = one directory)

The preset uses **`model_path`: `fhdr`** → on-disk layout is **`{Models root}/fhdr/`** (same place as other models).

### GGUF split-pack (Media Magic — verified 2026-05-20)

```text
models/fhdr/
  FHDR_ComfyUI-Q4_K_M.gguf    # example quant
  vae/ae.safetensors          # from second-state FLUX.1-schnell-GGUF pack
  text_encoder/clip_l.safetensors
  text_encoder_2/t5xxl_fp16.safetensors   # sharded T5 merged per Generate
```

### Diffusers tree (optional Track B)

Copy the **Diffusers** layout — the same tree you would pass to `FluxPipeline.from_pretrained` from disk:

| Copy into `models/fhdr/` | Purpose |
|---------------------------|---------|
| `model_index.json` | Maps subfolders to pipeline components. |
| `scheduler/` | Schedule config. |
| `transformer/` | Main FLUX weights (often large sharded `.safetensors`). |
| `vae/` | VAE. |
| `text_encoder/` | First text encoder. |
| `text_encoder_2/` | Second text encoder. |
| `tokenizer/` | Tokenizer for encoder 1. |
| `tokenizer_2/` | Tokenizer for encoder 2. |

**GGUF beside Diffusers files?** Yes — one `models/fhdr/` folder can hold **both** tracks; each path uses only what it needs.

## Anikai router

**shipped** — `flux1_clip_t5` for `FHDR_ComfyUI-*.gguf`; catalogue stack **`fhdr-gguf`**. Media Magic txt2img E2E verified on author GPU (2026-05-20).

## Anikai Desktop (Track B — optional)

- Preset id **`flux_fhdr_uncensored_kpsss34`** — bundled `model_path`: **`fhdr`** → **`models/fhdr/`** (Diffusers tree; no `HF_TOKEN` once files are local).  
- Runner: `media-python/run_diffusers_image.py` + Python (see Diffusers plan: bundled runtime or `ANIKAI_MEDIA_PYTHON`).

## Implementation checklist (Anikai Desktop)

- [x] GGUF split-pack + Media Magic generate (author GPU smoke, 2026-05-20).  
- [x] Lane index GGUF row ticked.  
- [ ] Diffusers tree smoke on target GPU profile (optional).  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- Diffusers family stub: [`../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-14 | Model dir convention: `models/fhdr/`; GGUF may coexist; clarified HF copy list. |
| 2026-05-18 | Document GGUF native path (split-pack) as shipped; Diffusers preset optional second track. |
| 2026-05-20 | Marked **Complete** — GGUF E2E verified on author GPU (FHDR Uncensored, gated repo). |
