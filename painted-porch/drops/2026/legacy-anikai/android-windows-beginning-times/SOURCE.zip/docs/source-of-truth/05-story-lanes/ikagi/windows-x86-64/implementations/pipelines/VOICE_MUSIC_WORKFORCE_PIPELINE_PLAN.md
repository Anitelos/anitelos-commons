# Voice+music workforce pipeline plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Purpose: document the mixed voice+music pipeline as its own implementation subject, separate from per-engine voice runtime bring-up.

---

## Current implementation reality (code discovery)

### What exists now

1. **Music workforce lanes are defined and deployable in settings/UI**
   - `music_generator`
   - `lyric_weaver`
   - `audio_stem_mixer`
   - Source: `AudioPipelineWorkforce.kt`, `AudioWorkforceSwarmCoordinator.kt`, `SwarmWorkforcePackActions.kt`, `UserAccessSwarmPipelinesSection.kt`.

2. **Intent routing maps audio-gen requests to music specialist lane**
   - `AUDIO_GEN -> music_generator`
   - Source: `IntentRouter.kt`.

3. **Chat/companion music generation currently runs direct generation helper path**
   - `CompanionController` calls `generateMusicToDropBox(...)`.
   - `generateMusicToDropBox` uses provider audio where available, else local fallback tone WAV.
   - personalization + novelty fingerprints are already tracked.
   - Source: `CompanionController.kt`, `CompanionImageGeneration.kt`, `AnikaiRepository.kt`.

### Critical gap (why this needs a dedicated plan)

The workforce lane trio is mostly **assignment/deploy surface** today, but not yet an enforced end-to-end execution graph for music output.  
Meaning: lane presence does not yet guarantee `lyric_weaver -> music_generator -> audio_stem_mixer` execution before output.

---

## Target pipeline (first operational contract)

`request -> lyric pass -> music pass -> stem/mix pass -> optional voice-over -> packaged output`

### Stage contract

| Stage | Owner | Output |
|-------|-------|--------|
| **A1 lyric shaping** | `lyric_weaver` | lyrics/hook artifact + constraints metadata |
| **A2 music generation** | `music_generator` | base audio render (or structured stem plan) |
| **A3 stem/mix finish** | `audio_stem_mixer` | final mix artifact |
| **A4 optional voice overlay** | voice runtime lane (`VoiceOrchestrator`) | spoken layer / callouts / NPC line mix |
| **A5 publish** | app packer | DropBox artifact + provenance markers |

---

## Integration with voice engines (sideways dependency)

This doc does not replace engine docs.  
Engine readiness stays in:

- `generation/audio/VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`

Pipeline rule:

- if A4 (voice overlay) is requested, use currently selected operational voice runtime;
- if selected voice engine is not operational, skip A4 with explicit status note (no silent pretend mix).

---

## Implementation steps

1. **Execution switch**
   - when workforce lanes are assigned and enabled, route music requests through pipeline stages A1-A3.
2. **Artifact schema**
   - store per-stage result metadata (stage id, lane id, model path, fallback reason).
3. **Voice bridge**
   - add A4 option for overlay/announce/NPC variant voice segment.
4. **Fallback clarity**
   - label provider/fallback tone path as non-workforce fallback when A1-A3 cannot run.
5. **Validation**
   - require stage provenance markers before claiming workforce pipeline success.

---

## Links

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Todo: `todo/mid-scope/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md`
- Related: `generation/audio/VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Registry context: `02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial dedicated mixed voice+music pipeline plan from code discovery pass. |
