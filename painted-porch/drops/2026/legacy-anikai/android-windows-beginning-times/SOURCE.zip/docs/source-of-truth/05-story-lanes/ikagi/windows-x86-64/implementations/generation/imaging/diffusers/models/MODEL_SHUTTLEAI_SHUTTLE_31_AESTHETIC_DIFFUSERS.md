# Model sheet — Shuttle 3.1 Aesthetic (Diffusers)

| Field | Value |
|-------|-------|
| **HF** | [shuttleai/shuttle-3.1-aesthetic](https://huggingface.co/shuttleai/shuttle-3.1-aesthetic) |
| **GGUF alternate** | [`../../gguf/models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC.md`](../../gguf/models/MODEL_SHUTTLEAI_SHUTTLE_31_AESTHETIC.md) |

Diffusers folder for users who want the native HF tree. Sprite Maker **Flux.1 default** lane can bind either GGUF or this tree.
