# QNN/SNPE engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define Qualcomm-targeted inference lane (QNN/SNPE class) for ANIKAI where direct NPU/DSP paths are available, enabling low-thermal always-on and high-efficiency specialist workloads.

---

## Scope

This file covers QNN/SNPE for:

- Snapdragon-specific acceleration lane planning,
- low-power always-on sensory workloads (listen/awareness helper lanes),
- NPU-first backend policy and fallback behavior,
- capability-pack integration in model hub and runtime placement matrix.

This file does **not** replace generation/pipeline contracts.

---

## Why this runtime matters for ANIKAI

QNN/SNPE class runtimes are the "hardware maxing" lane on compatible Snapdragon devices.

ANIKAI value:

- lower CPU impact and lower thermal footprint on supported hardware,
- stronger ambient/curiosity use-cases with local-first always-on behavior,
- concrete realization of "device soul" differences in malleable UI.

Rule: QNN/SNPE claims are valid only on supported device classes with explicit adapter + manifest + backend pass + fallback labeling.

---

## Role model (single truth)

| QNN/SNPE lane | Ownership |
|---------------|-----------|
| **Always-on sensory helpers** | Core target role on compatible Snapdragon devices. |
| **Specialist Swarm tasks** | Allowed where model/backend compatibility is proven. |
| **Companion primary text** | Optional and likely device-limited; not default assumption. |
| **Generative primary media** | Only when explicitly validated and documented; not implied by NPU access. |

---

## Android implementation plan (vendor-targeted lane)

### 1) Support matrix policy

- define supported Snapdragon classes and OS/runtime prerequisites,
- enforce capability probe before exposing controls,
- gate features in UI via installed+supported runtime checks.

### 2) Adapter/session checklist

- [ ] QNN/SNPE adapter family registered in engine model hub.
- [ ] Device compatibility probe and backend init checks implemented.
- [ ] Input/output tensor contracts validated before run.
- [ ] Explicit fallback path to alternative local runtimes when unsupported.
- [ ] Thermal/lifecycle/cancellation stability verified for always-on scenarios.

### 3) Manifest contract

Each QNN/SNPE pack row includes:

- adapter id + task family,
- required chipset/runtime prerequisites,
- expected tensor IO and output artifact schema,
- fallback runtime policy (for non-supported devices),
- lane eligibility (Curiosity/Swarm/background helper).

---

## App integration map

### A) Model hub and sensory gating

- show `QNN` (or `SNPE`) engine badge only when compatibility probe passes,
- reveal "super-power" controls dynamically per installed/supported packs,
- keep host/runtime placement labels explicit.

### B) Curiosity tab integration

- prioritize QNN/SNPE for compatible always-on see/hear/touch helper lanes,
- keep source labeling and privacy/permission boundaries explicit.

### C) Swarm/runtime placement

- allow per-lane placement policy (`PHONE`, `PC`, `CLOUD`, `SERVER`, `HYBRID`) while preserving local option where feasible,
- route to QNN/SNPE only when pack + hardware constraints pass.

---

## Phased delivery

### Phase 0 - compatibility scaffolding

- create chipset/runtime probe, manifest schema, and adapter skeleton.

### Phase 1 - first always-on helper lane

- operationalize one low-power helper lane on supported Snapdragon hardware.

### Phase 2 - fallback + policy hardening

- validate graceful fallback on unsupported devices without UX confusion.

### Phase 3 - capability-pack expansion

- add more sensory/specialist packs with strict support labeling.

---

## Verification gates (before "operational" claim)

- one QNN/SNPE lane runs reliably on supported hardware with expected low thermal impact,
- unsupported devices fail gracefully into declared fallback lanes,
- capability-gated UI behavior matches actual runtime availability,
- no hidden cloud substitution for failed local claims.

---

## Open decisions

- first operational QNN/SNPE helper lane target,
- fallback precedence (LiteRT/ONNX/NCNN) by task family,
- minimum telemetry needed for thermal and battery claims.

---

## Linked todos

- `todo/mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through sentience/runtime placement maturity)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial QNN/SNPE engine inference implementation plan added for Snapdragon-targeted acceleration lane. |
