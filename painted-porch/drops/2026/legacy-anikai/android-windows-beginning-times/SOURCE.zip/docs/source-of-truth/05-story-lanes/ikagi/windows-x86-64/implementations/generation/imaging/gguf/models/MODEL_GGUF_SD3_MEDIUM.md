# Model sheet — Stable Diffusion 3 Medium (GGUF / safetensors)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Shipped (router) |
| **Last reviewed** | 2026-05-18 |

## HF

- Base: [stabilityai/stable-diffusion-3-medium](https://huggingface.co/stabilityai/stable-diffusion-3-medium)  
- Encoders: [Comfy-Org/stable-diffusion-3.5-fp8](https://huggingface.co/Comfy-Org/stable-diffusion-3.5-fp8) (clip_l, clip_g, t5xxl splits)  
- sd.cpp: [`sd3.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/sd3.md), [`sd.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/sd.md)  

## Pack family

`sd3_clip_stack` — `-m` + `--clip_l` + `--clip_g` + `--t5xxl`.

## Weight layout

```text
models/sd3-medium/
  sd3_medium_incl_clips_t5xxlfp16.safetensors   # or converted .gguf
  clip_l.safetensors
  clip_g.safetensors
  t5xxl_fp16.safetensors
```

## Product

- **Preset id:** `sd3_medium_gguf`  
- **Profile (proposal):** `sd3_medium` — 1024², cfg 4.5, euler, `--clip-on-cpu`  

## Anikai router

`shipped` — `buildSd3ClipStackSdArgs` + `probeSd3ClipStackLayout` in `gguf-completion.js`.

## Checklist

- [x] Router + probe  
- [ ] E2E smoke (your GPU)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
