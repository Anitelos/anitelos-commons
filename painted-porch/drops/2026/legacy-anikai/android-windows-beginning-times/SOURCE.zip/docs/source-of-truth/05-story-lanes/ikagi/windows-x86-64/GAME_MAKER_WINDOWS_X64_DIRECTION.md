# Game Maker Windows x86-64 direction (quick draft)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Purpose: quick Windows-native Game Maker direction for higher quality lanes.  
No bridge mechanics documented here yet (intentionally out of scope for now).

---

## Why Windows lane exists

Android Game Maker should stay lean and fast; Windows lane can carry heavier quality stacks and wider tooling depth.

---

## Voice direction (quality-first on desktop)

Primary candidates for higher-quality desktop NPC voice lanes:

- XTTS-class runtime lane,
- CosyVoice-class lane,
- optional VITS high-quality variants.

Mobile/desktop split rule:

- Android showcase: prioritize fast/cheap (`Kokoro`, `Kitten`) for gameplay iteration.
- Windows showcase: prioritize quality and richer cloning/prosody where resources allow.

---

## 3D pipeline direction (future)

Prompt + concept + conversion pipeline for ANIKAI 3D game workflows:

1. concept generation (text/image references),
2. asset planning (character/prop/environment breakdown),
3. 3D model generation/conversion lane experiments,
4. animation/rig/motion helper lanes,
5. packaging for playable prototype iterations.

This mirrors the current 2D philosophy (modular pipeline specialists), but for 3D-ready workflows.

---

## Efficiency + orchestration

- Keep stage contracts explicit (input/output/provenance per lane).
- Use model slots per role so heavy models are swappable without rewriting orchestration.
- Maintain deterministic fallbacks and honest source labels.

---

## Cross-device / next-gen game idea lane (concept only)

- Potential links between Windows game workflows and ANIKAI device apps:
  - synchronized model role slots,
  - crossplay/session assistance,
  - optional distributed swarm task slots across devices.

This remains concept-level in this doc; implementation design can be opened later under dedicated cross-device docs.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial Windows x64 Game Maker direction doc (quality voice + future 3D + cross-device concept lane). |
