# Model sheet — PersonaLive (portrait motion)

| Field | Value |
|-------|-------|
| **Format** | Python sidecar (`python` in About / registry — not a separate `personalive` format id) |
| **Engine** | `python.personalive` |
| **Upstream code** | [GVCLab/PersonaLive](https://github.com/GVCLab/PersonaLive) |
| **Upstream weights (HF)** | [huaichang/PersonaLive](https://huggingface.co/huaichang/PersonaLive) — same `pretrained_weights/` tree as the README |
| **Registry family** | `personalive_portrait` |

## Role

**Portrait still + driving frame stream → animated RGB portrait.** The hero still usually comes from **Imaging** (GGUF or Diffusers). PersonaLive animates that still; it does not replace txt2img.

## Pack layout (Anikai staging)

All weights live under **`%ANIKAI_HOME%/models/personalive/pretrained_weights/`** — matching upstream PersonaLive:

```text
models/personalive/pretrained_weights/
├── personalive/
│   ├── denoising_unet.pth
│   ├── motion_encoder.pth
│   ├── motion_extractor.pth
│   ├── pose_guider.pth
│   ├── reference_unet.pth
│   └── temporal_module.pth
├── sd-vae-ft-mse/
│   ├── config.json
│   └── diffusion_pytorch_model.bin
├── sd-image-variations-diffusers/
│   ├── model_index.json
│   ├── image_encoder/ …
│   └── unet/ …
├── onnx/unet_opt/          (optional — not in desktop Download model tier)
└── tensorrt/               (optional — device-specific)
```

**Download model** (Media Magic → PersonaLive rig test) pulls:

- Six **`personalive/*.pth`** files from [huaichang/PersonaLive](https://huggingface.co/huaichang/PersonaLive) on Hugging Face (~10.5 GB).
- **SD sidecars** (VAE + image-variations) from the same dependency URLs upstream uses (~4 GB).

Registry: `anikai-desktop/config/personalive-pack-registry.json`.

## Desktop user flow (honest)

| Piece | Where | Who sets it up |
|-------|--------|----------------|
| **Weights** | `%ANIKAI_HOME%/models/personalive/pretrained_weights/` | User: **Download PersonaLive** in Media Magic (~15 GB HF) |
| **Engine + Python** | `personalive-runtime/` next to the app (like `media-python-runtime`) | **Installer / `npm run stage-personalive`** on the build machine |

| Step | User action | What Anikai does |
|------|-------------|------------------|
| 1 | **Download PersonaLive** | HF weights + sidecars into `models/personalive/pretrained_weights/`; then **auto-link** into bundled engine |
| 2 | **Run rig** | `inference_offline.py` when weights + bundled runtime ready; else **ffmpeg PIP preview** |

**End user does not** install Git, clone repos, or run `pip` — only downloads weights once, then runs in-app.

**Dev / unpackaged builds:** run `npm run stage-personalive` (needs Git + Python on the build box). Fallback may clone into `ANIKAI_HOME/personalive-engine` if the bundle is missing.

**GPU:** **~12 GB VRAM** class for full neural output (upstream). Optional ONNX/TRT and streaming remain later.

## Pipelines

| Pipeline | Doc |
|----------|-----|
| Portrait rig & motion (strategy) | [`../../../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md`](../../../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md) |
| 4-shot still contract | [`../../PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](../../PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md) |
| Engine inference | [`../../../../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |

## Not FOMM

FOMM is removed from the product plan. Use this pack or deterministic rig baseline for new portrait motion work.
