# Model sheet — silveroxides / Chroma-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [silveroxides/Chroma-GGUF](https://huggingface.co/silveroxides/Chroma-GGUF)  
- Base: [lodestones/Chroma](https://huggingface.co/lodestones/Chroma)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the GGUF (matches Anikai `downloadPacks`).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- FLUX.1 encoders bundle (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  
- sd.cpp: [`chroma.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/chroma.md)  

## Pack family

`flux1_chroma` — diffusion GGUF + FLUX.1 `ae.safetensors` + `t5xxl` (no clip_l in upstream example).

## Weight layout

```text
models/chroma/
  chroma-unlocked-v40-q8_0.gguf
  vae/ae.safetensors
  text_encoder_2/t5xxl_fp16.safetensors
```

## CLI note

Upstream adds `--chroma-disable-dit-mask` and cfg ~4.0.

## Product

- **Preset id:** `chroma_gguf_silveroxides`  
- **Profile (proposal):** `chroma_gguf` — 1024², cfg 4, euler  

## Anikai router

`planned` — extend flux1 builder with chroma flag when basename matches `chroma`.

## Checklist

- [ ] `flux1_chroma` probe + args  
- [ ] E2E smoke  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
