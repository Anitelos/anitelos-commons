# Sprite & character pixel art — quality floor (Windows success contract)


| Field             | Value                                                                          |
| ----------------- | ------------------------------------------------------------------------------ |
| **Doc staging**   | Started                                                                        |
| **Operations**    | Partial (Media Magic Games sprite Steps 1–3)                                   |
| **Last reviewed** | 2026-05-22                                                                     |
| **Platform**      | **Windows x86-64** — `anikai-desktop`, local GPU/CPU only for showcase claims. |


**Status:** ACTIVE product contract for **Media Magic → Games → Sprite sheet** and related imaging lanes.  
**Pairs with:** `[../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md](../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md)` (stage owners). **Pipeline plan:** `[../../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md](../../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md)`. **Android reference (different runtime):** `[../../../../android-arm64/implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md](../../../../android-arm64/implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md)`.

---

## What this document fixes

- **No “success by downsizing.”** For **showcase** and **ship-tier character output**, reducing resolution or accepting mushy thumbnails **does not** count as meeting the bar. If the machine cannot run the pipeline at the **contracted** preview/export size, the run is **degraded or fails visibly** with reason—**not** silently passed as “good enough,” and **not** deferred to another host for showcase-tier claims.
- **One model is not required.** A **quality bar** may map to **multiple local tasks** (Diffusers Kontext, `sd.exe` GGUF, ONNX rembg/post). Each stage has a **job**; together they hit the floor. Cloud HTTP is **not** a substitute for on-device showcase success.

---

## Canonical visual floor (lowest acceptable “success”)

The following references define the **minimum** look fidelity the product means when it claims a **successful** sprite or character still for **demo / game-ingest** purposes (not internal greybox).


| Ref role                                       | Description (intent)                                                                                                                                                                                     | Use in pipeline                                                                                                                                                                                |
| ---------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Floor A — tactical / hero sprite**           | HD pixel art: dark silhouette outline, ramped shading, selective highlight, readable materials (metal, cloth, magic read); ~512-class square composition; **FFT / tactical RPG** density—not chibi mush. | **Gameplay-facing N·E·S·W** and **strip exports** must read at this silhouette + material clarity when judged at **full intended cell size** (e.g. 256–512 px per facing for showcase builds). |
| **Floor B — fighting-game / portrait density** | High-count pixel, strong outline, body/costume read at three-quarter; **KOF / SFIII-class** illustration density for **cutscene or closeup** stills.                                                     | **Portrait / cutscene** lane may target this bar **at authored resolution**; downscale to in-game HUD only as a **separate explicit export**, never as the only “success” artifact.            |
| **Floor C — front hero / VN read**             | Waist-up or bust, strong focal props (weapon, magic, fur), **forward** readability for dialogue scenes.                                                                                                  | **Front-facing** pack and **dialogue still** exports (Step 3 **South** + optional portrait lane).                                                                                              |
| **Floor D — concept lineup**                   | Full cast sheet on painted background; **per-character crop** is the **style + identity** input—not the whole poster.                                                                                    | Step 1 **concept + style ref** (`multiple_images` on Diffusers Kontext).                                                                                                                       |


**Authoring note:** commit canonical PNGs under version control when policy allows — see `reference-art/sprite-quality-floor/README.md` in roadmap tree for suggested filenames.

---

## Success vs fail (showcase tier)


| Tier                             | Definition                                       | Pass condition                                                                                                                         |
| -------------------------------- | ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| **Showcase / “app making” demo** | What you ship in recordings and partner reviews. | Output matches **Floor A–D** intent at **declared export resolution** (per facing). **No** “we shipped 128 because smaller is easier.” |
| **Playable / perf**              | In-engine downscale for FPS.                     | Optional **second artifact** from the same high-res master; never the only deliverable for showcase success.                           |
| **Internal / blocked**           | OOM, missing weights, or runner failure.         | **Visible fail** + reason; **no** silent acceptance as success.                                                                        |


---

## Multi-pass pipeline (recommended jobs)

Do **not** rely on a single forward pass to hit the floor. Split work so each engine has one clear responsibility.


| Stage                           | Job                                                                | Windows owner (today / near)                                                                                                   |
| ------------------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------ |
| **0 — Input**                   | Square-ish crop, concept + style refs, fringe cleanup before NESW. | Media Magic drops; optional `[tools/pixel-sprite-downscale](../../../../../../../../tools/pixel-sprite-downscale/index.html)`. |
| **1 — Primary pixels**          | txt2img / img2img; locks identity + palette.                       | **Diffusers** `FluxKontextPipeline` (`media-diffusers-image.py`) or `**sd.exe` GGUF** Kontext.                                 |
| **2 — Consistency**             | Same character across facings; south → N/E/W img2img.              | Step 3 `generateSpriteFacing()`; locked pixel W/H; facing prompts.                                                             |
| **3 — Matte**                   | Remove background halos before south is canonical.                 | ONNX **rembg** + edge flood **Remove color** + **Tight crop** (Step 2).                                                        |
| **4 — Upscale / sharpen**       | Neural upscale at authored resolution.                             | ONNX post (4× UltraSharp-class) via Media Magic post row — **planned** as default QUALITY preset on master stills.             |
| **5 — Palette / outline unify** | Game-scale readability.                                            | CPU/ONNX pass — optional; must not fake S1 mush.                                                                               |
| **6 — Pack**                    | N·E·S·W + manifest / metadata.                                     | Creations recents today; full `NeswArtifactSet` export **planned**.                                                            |


**Run metadata:** persist `pipelineStage`, `qualityTier` (`showcase`  `playable`), `targetSidePx`, `modelRef`, and engine (`diffusers`  `sd_gguf`  `onnx_post`) per job.

---

## Model direction (Windows, realistic stacking)

### Primary generative (identity + first pixels)

- **FLUX Kontext (Diffusers)** — preferred for Step 1 **concept + reference** and Step 3 **facings** (same `#mediaSpriteModelSelect`). Requires preset weights on disk (About → imaging packs).
- **FLUX Kontext (GGUF / `sd.exe`)** — fallback; Step 1 concept-only; Step 3 img2img from **south** at user pixel W/H.
- **Future — pixel-space diffusion (e.g. L2P-class)** — see `[../../WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md](../../WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md)`; evaluate against Floor A–D before catalogue row.

### Post (edge “make it look expensive” on device)

- **4× UltraSharp V2 FP32** or **PurePhoto RealPLSKR** (ONNX via desktop ONNX runtime) — after moderate-res base; see `[../onnx/models/](../../onnx/models/)` pack docs.

### When the GPU cannot finish the contracted pass

- **Fail visible** or offer a labeled lower preset (steps / resolution / quant). Do **not** silently shrink and claim showcase pass.

---

## Generate = automatic pipeline (sprite workspace)

**Generate** on Step 1 and **Generate N/E/W** on Step 3 should present **one progress surface** per run: ordered stages, cancel, elapsed time, and compute device label (GPU vs CPU) — same discipline as other Media Magic image jobs.

**Step 3 model rule:** no duplicate picker; status hint shows which Step 1 Kontext model will run.

---

## Desktop diffusion / Diffusers gate (before “showcase-pass”)

Use before claiming Kontext sprite output is stable:

- **Lock request contract** — seed, steps, CFG, W/H, preset, `modelRef` in IPC payload and Python runner.
- **Validate init image paths** — south / concept / ref decode and exist before queue.
- **Single success path** — conditioning → sample → VAE/decode → PNG write; no empty-file success.
- **Validate output** — non-zero PNG, expected dimensions, readable in UI preview.
- **Structured errors** — decode / infer / OOM / cancel surfaced to `#mediaSpriteNeswStatus` and recents.
- **Stage timings** — `decode_ms`, `infer_ms`, etc. in logs for regression.
- **Golden repeatability** — fixed concept + ref + seed → stable PNG across three runs on reference GPU.

GGUF path: same checklist on `sd.exe` stderr/exit codes and output path probes.

---

## FAQ: does “weak GPU” mean we’re stuck at 128×128?

**No.** **128×128** is an example of an **unacceptable substitute** for showcase quality—not a hardware cap.

**What actually limits size on Windows**

- **Graph / runner contract** — Diffusers preset and `sd.exe` flags must match supported W/H (pixel fields in sprite UI, typically 16–512).
- **VRAM / time** — larger squares and more steps cost more; use FAST vs QUALITY presets or **moderate gen → ONNX upscale** instead of one oversized forward pass.
- **Honest degradation** — if the GPU cannot finish the **contracted** resolution, say so; do not silently ship a thumbnail as the only “success” artifact.

---

## Relation to code today

- **Games → Sprite sheet** Steps **1–3** in `anikai-desktop/components/media.js` are the live enforcement surface for still + NESW work.
- **Procedural / placeholder** output is dev fallback only—not showcase fulfillment.
- UI must not label showcase-pass unless the pipeline attests **Floor A–D** at **contracted** resolution with **local** inference (not procedural-only).

---

## Related documents

- `[../../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md](../../pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md)`
- `[../../WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md](../../WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md)`
- `[../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md](../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md)`
- `[../../../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md](../../../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md)`

---

## Change log


| Date       | Note                                                                                                                                                                                                       |
| ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 2026-05-22 | **Windows lane:** retargeted from Android/on-device JNI; Media Magic sprite Steps 1–3, Kontext Diffusers vs GGUF, rembg+cleanup, Step 3 model hint; desktop gate checklist; linked emerging-model backlog. |
| 2026-05-06 | JNI diffusion consistency checklist (Android-era; superseded on Windows by desktop gate above).                                                                                                            |
| 2026-05-06 | Doc staging table; multi-pass, no downsizing-as-success, Floors A–D.                                                                                                                                       |
| 2026-05-05 | Native-only stance (Android).                                                                                                                                                                              |


