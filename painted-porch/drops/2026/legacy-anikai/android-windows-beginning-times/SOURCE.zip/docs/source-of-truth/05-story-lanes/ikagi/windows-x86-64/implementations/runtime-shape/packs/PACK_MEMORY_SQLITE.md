# Workshop memory (SQLite + FTS)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.memory.sqlite` |
| **Tier** | B |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Thread memory, asset catalog, local RAG index over ANIKAI_HOME — optional sqlite-vec later.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

sqlite3.dll or better-sqlite3 native; schema migrations in app.

## Staging path

`ANIKAI_HOME/desktop-data/workshop.db`

## Unlocks (no model weights)

local-rag, asset-search, provenance-log

## Verification smoke

FTS query over 100 test rows.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
