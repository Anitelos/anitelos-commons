# Companion execution & agent architecture — overview (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Origin:** Promoted from Antigravity brain export `companion_sandbox_security_architecture.md` plus follow-on design threads (agentic loop, team blackboard). **This page is the map** — the scope is intentionally large; implementation is sliced.

**Workshop context:** [`../DESKTOP_WORKSHOP_STATE.md`](../DESKTOP_WORKSHOP_STATE.md)

---

## One sentence

Move Anikai Desktop from a **single-pass chat loop** toward a **consent-gated execution agent** with **safe file/shell access**, **durable working memory**, and (later) **multi-model team planning** — without collapsing trust, local-first policy, or the segment pipeline already shipping.

---

## Why this feels “a lot”

Four largely independent tracks share one user-facing promise (“the companion can work on my PC like a coding agent”) but need **different engineering**:

| Track | Question it answers | Doc |
|-------|---------------------|-----|
| **A — Sandbox & edits** | How do we avoid destroying the OS or corrupting files mid-generation? | [`COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md`](./COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md) |
| **B — Agentic control loop** | How does the companion keep going, roll context, and hide thought spillage? | [`AGENTIC_CONTROL_LOOP_AND_PERSISTENT_MEMORY.md`](./AGENTIC_CONTROL_LOOP_AND_PERSISTENT_MEMORY.md) |
| **C — Team blackboard** | How do several small models plan in parallel before the user presses Go? | [`TEAM_BLACKBOARD_ORCHESTRATION.md`](./TEAM_BLACKBOARD_ORCHESTRATION.md) |
| **D — Screen copilot** | How does one machine copilot see the display and act on input? | [`../DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../DESKTOP_COPILOT_AND_SCREEN_AGENT.md) |

**Rule:** Ship **A + B0** before **C**. **D** stays after E+ and semi-duplex voice per copilot plan.

---

## What already ships (do not re-plan)

| Capability | Status | Anchor |
|------------|--------|--------|
| Thought / final channel split (Gemma 4) | Shipping | `shared/gguf-output-templates/gemma4-channels.js` |
| Segment orchestrator (`<tool/>`, `<done/>`, clarify) | Shipping (B1–B3) | [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) |
| Per-companion text inference rails | Partial (C1) | `shared/companion-text-inference.js` |
| Companion skills / capability map | Shipping | `main-process/companion-skills.js` |
| Workforce handoffs (first-person, media W5a) | In progress | [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md) |
| Journal concept (per-companion notes) | Documented §8 workforce | `journal/<companionId>/` — not full agentic journal yet |
| File/shell execution sandbox | **Not started** | This track |

---

## Dependency graph

```mermaid
flowchart TB
  subgraph today [Shipping today]
    Seg[Segment orchestrator]
    Chan[Channel templates]
    Skills[Companion skills]
  end

  subgraph trackA [Track A - Sandbox]
    HITL[HITL command approve]
    Root[Workspace root lock]
    Stage[Shadow staging + bake]
    Patch[SEARCH/REPLACE applier]
  end

  subgraph trackB [Track B - Agentic loop]
    Ctrl[Controller not raw chat stop]
    Scratch[Active scratchpad + TODO]
    Roll[Sliding horizon compression]
    UI[Strict thought UI isolation]
  end

  subgraph trackC [Track C - Team]
    BB[Blackboard state]
    Debate[Parallel draft + cross-review]
    Freeze[Freeze and approve UI]
    DAG[Task DAG execution]
  end

  Seg --> HITL
  Seg --> Ctrl
  Chan --> UI
  Skills --> Root
  Stage --> Patch
  Ctrl --> Scratch
  Scratch --> Roll
  BB --> Debate --> Freeze --> DAG
  HITL --> DAG
  Eplus[E+ multi-resident] --> BB
  Seg --> Eplus
```

---

## Phased delivery (honest)

| Phase | User-visible | Tracks | Prerequisite |
|-------|--------------|--------|--------------|
| **P0** | Read-only workspace tools (`list_dir`, read file) with root lock + HITL on anything mutating | A0 | Segment loop |
| **P1** | Shadow stage → diff UI → bake; SEARCH/REPLACE tool output | A1 | P0 |
| **P2** | Controller extends segment loop: scratchpad + mutable TODO in system state; thought never in user bubble | B0 | P0, channel parser |
| **P3** | Context roll at ~80% window → micro-summaries; scratchpad/TODO pinned | B1 | P2, `gguf-metadata` context probe |
| **P4** | Companion journal writes (markdown), cross-thread inject | B2 | P3, workforce journal folder |
| **P5** | Blackboard planning: parallel drafts + debate UI + Freeze & Approve | C0 | P2, E+ or 2+ concurrent servers |
| **P6** | DAG execution with per-agent scratchpads | C1 | P5, P1 |
| **P7** | Screen copilot executor shares validator with shell/file | D | [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../DESKTOP_COPILOT_AND_SCREEN_AGENT.md) |

**Not in v1:** cloud VMs, unconstrained background shell, auto-apply without diff, silent exfil paths.

---

## Answers the Antigravity thread asked

| Question | Answer (Windows desktop today) |
|----------|--------------------------------|
| **Orchestrator runtime** | Electron **main process** + renderer `chat.js` (`runGgufThoughtTurn`); inference via `main-process/gguf-completion.js` → local `llama-server`. |
| **Typical context window** | Per-model via **Persona** + `gguf-metadata` probe; server started with `-c` from companion caps (8k–128k depending on GGUF). Rolling compression (P3) must respect this probe, not a fixed constant. |
| **Multi-model at once** | Today: mostly **one chat server** per active turn; **E+** plan adds multi-resident / extra ports — required before Team blackboard (P5). |
| **UI personalities vs roles** | Companion **specialty** + group **session role** + familiar **Assign roles** — index [`ROLES_INDEX.md`](ROLES_INDEX.md). Team blackboard uses **agent labels** (Gemma/Qwen/Phi) as slots, not separate products. |

---

## Local-first constraints

- No silent upload of workspace files.
- Execution and staging under user-chosen **workspace root** (or `%ANIKAI_HOME%/workspaces/<id>`).
- Git as optional safety net — not a substitute for shadow staging on non-git folders.

---

## See also

- [`../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md)
- [`../../operations/OPERATIONS_INDEX.md`](../../operations/OPERATIONS_INDEX.md)
- Android handover (emotion/slots only): [`../../../../android-arm64/implementations/anikai-handover/SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md`](../../../../android-arm64/implementations/anikai-handover/SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md)

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial scope map; promoted sandbox doc; split agentic + team tracks from Antigravity export. |
