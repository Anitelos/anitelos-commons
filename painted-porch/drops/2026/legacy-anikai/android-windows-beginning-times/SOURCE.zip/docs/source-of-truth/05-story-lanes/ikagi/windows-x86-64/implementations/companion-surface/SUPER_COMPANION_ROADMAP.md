# Super Companion & Maintenance Assist — Master Roadmap

Living document for Anikai Desktop: companion surface, maintenance automation, media intelligence, planning canvas, bond memory, and review pipelines. Updated as design conversations land.

---

## 0. Pre-roadmap polish (landed)

### Familiar portrait generation

- **15 archetypes** (droid, fairy, pixie, wisp, sentinel, cherub, nimbus, beetle, cogling, lantern, drone, imp, borrower, sprite, gizmo) with `portraitPromptHint` per type — guardians, summons, tiny helpers (Tinker Bell / R2-D2 energy, not mogwai).
- **`shared/familiar-avatar-generator.js`** — archetype-driven prompts; style/genre/aspect menus mirror companion portrait sizing.
- **Storage:** `{ANIKAI_HOME}/familiar-portraits/`; IPC `familiars:install-portrait` / `familiars:remove-portrait`.
- **UI:** Familiar persona tab — Add / Remove / Generate portrait (same flow as companion portraits).

### Companion portraits in chat (solo + group)

- AI bubbles show **companion portrait or emoji avatar** in a left column.
- **Dedup rule:** avatar on the **last** message in a consecutive run from the same author; when another companion speaks, their segment gets a fresh avatar. Streaming updates one bubble — one avatar.
- Messages persist optional `companionId` for group round-robin attribution.

---

## 1. Current pain points (active bugs)

### Companion chat engine — status (Jun 2026)

**Goal:** All three chat models (Ava / Elise / Rose) produce reliable visible replies in **solo** and **group**, including multi-turn and autonomous bursts.

**Current read (manual QA):** **Ava and Elise are working** for normal solo + group user rounds. **Rose (Qwen2.5-VL) is the primary blocker** — `(no visible reply)` despite inference. **Further-down issues** (autonomous burst turn 3+, empty-speaker re-pick, Ava contract echo) are P1 — watch but do not regress the Ava/Elise baseline while fixing Rose.

#### Landed (parse + finalize unification — Jun 2026 session 2)

| Change | Path | Purpose |
| ------ | ---- | ------- |
| **Family finalize delegation** | `companion-turn-finalize.js` | Batch finalize calls `QwenGroupStreamUi` / `ChannelGroupStreamUi` / `ThoughtGroupStreamUi` |
| **Elise partial-final salvage** | `utils.js` `extractChannelThoughtTailReply`, `channel-group-stream-ui.js` | Roleplay / dialogue lines salvaged when `<\|channel\|>final` missing |
| **Group recovered body wins** | `chat.js` `_runGroupCycleSpeakerTurn` | Salvaged visible body shown even when `turn.ok === false` |
| **Group recovery pass** | `chat.js` `runGgufThoughtTurn` | Recovery eligible for all group turns when primary fails |
| **Skip empty autonomous picks** | `companion-social-chat.js` `pickAutonomousSpeaker` | Don't re-pick companions after empty turn in burst |
| **Rose group recovery first** | `chat.js` `recoverGroupTurnVisibleBody` | Family finalize before generic salvage |

#### Landed (parse + finalize unification — session 1)

| Change | Path | Purpose |
| ------ | ---- | ------- |
| **Unified turn finalize** | `shared/companion-turn-finalize.js` | Single `finalizeCompanionTurn` / `streamPatchCompanionTurn` for solo + group — no more six divergent stream paths |
| **Ava hybrid parser** | `splitGemmaE4bHybridOutput` in `utils.js`, `gemma-e4b-thought.js` | Hauhau E4B `*** (Self-Correction Check:…)` + bare `<channel>` without `[End thinking]` |
| **Elise partial-final salvage** | `assessPrimaryPassCompletion`, channel split slice | Thought without `<\|channel\|>final` in same pass → tail/partial salvage before error |
| **Stream bubble anchors** | `registerStreamBubbleAnchor`, `pruneDuplicateStreamBubbles` in `chat.js` | One AI bubble per turn (`messageTs`); duplicate-bubble safety net |
| **Group recovery pass** | `_runGroupCycleSpeakerTurn` | Unified finalize + `runCasualRecoveryPass` before `(no visible reply)` |
| **Smoke parse tests** | `scripts/smoke-companion-stream-parse.cjs` | Ava hybrid, Elise thought-tail, unified Qwen group stream patch |

#### Model status (manual QA — Jun 2026)


| Companion | Model family | Solo | Group user round | Group autonomous burst |
| --------- | ------------ | ---- | -------------- | ---------------------- |
| **Ava** | Gemma E4B thought | ✅ Works | ✅ Works | ⚠️ Turn 1–2 OK; turn 3+ may hit `Model produced no reply` or scaffold leak (`Plan`/`Execution`) |
| **Elise** | Gemma 12B channel | ✅ Works | ✅ Works | ✅ Works (occasional partial-final salvage path) |
| **Rose** | Qwen2.5-VL thought | ⚠️ Turn 1 sometimes OK; turn 2+ unreliable | ❌ Often `(no visible reply)` | ❌ Forced into burst despite empty output; high tok/s, no visible body |

**Rose failure pattern (P0):** Inference runs (~350–1800 tok in metadata) but finalize yields empty body → UI shows `(no visible reply)` → autonomous burst **still picks Rose** → cycle poison + wasted GPU. Ava/Elise continue talking *about* Rose being quiet (see “Naughty Angels” group thread, Jun 2026).

**Further-down issues (P1 — do not block Rose fix, but track):**

- **Ava autonomous turn 3+** — intermittent `Model produced no reply` after early burst turns succeed  
- **Ava casual solo** — contract echo (`Reply in plain language…`) or hallucinated `[User]` block in debug raw  
- **Autonomous empty-speaker re-pick** — burst should skip companions whose last turn was empty/placeholder (ties to §18 availability)  
- **Rose solo turn 2+** — `Model produced no reply`, wrong bubble attribution (user line under Rose avatar)

#### Active gaps


| Priority | Gap | Symptom | Next fix direction |
| -------- | --- | ------- | ------------------ |
| **P0** | **Rose group finalize** | `(no visible reply)` every autonomous/user turn | Trace `QwenGroupStreamUi.finalizeTurn` + unified finalize with real group raw; relax over-aggressive `rejectRoseBody` when debug has greeting |
| **P0** | **Rose solo turn 2+** | Hang / no reply / wrong attribution | Session rollover / KV poison after turn 1; verify user row stays `type: 'user'` |
| **P1** | **Skip empty speakers in burst** | Rose forced when body empty | Don't pick companion for autonomous turn if last turn was empty/placeholder |
| **P1** | **Ava contract echo** | Instruction text in visible bubble | Hybrid parser + `rejectThoughtBody` on stream; prompt suffix audit for hallucinated user block |
| **P1** | **Ava autonomous turn 3+** | `Model produced no reply` after burst warms up | Trace group cycle context poisoning vs parse-only empty body |
| **P2** | **Integration tests** | Smoke passes but UI still breaks | Manual checklist below + future headless 2-turn test per model |

#### Regression watch (after every chat change)

Re-run **solo + group** on **all three** companions before merging chat engine work. Ava/Elise must stay green on items 1–2 below even while Rose is in flux.

#### Verification checklist (run on **fresh threads** after each chat change)

**Solo (each companion):**

1. `hi <name>` → visible greeting, no scaffold/contract in body  
2. Follow-up casual line → visible reply (not `Model produced no reply`)  
3. Thought panel (if any) collapses; user message stays under **user** styling, not companion avatar  

**Group (all three equipped):**

1. User: `hi girls` → **Ava + Elise** always visible; **Rose** must show text (currently failing — track until P0 closed)  
2. User: follow-up → same  
3. Main Character **OFF** → one autonomous burst → Ava/Elise keep talking; **Rose must not spam empty turns**  
4. `@Rose hi` while others on break → Rose wakes for one reply (**§18 landed — verify in UI**)  

**Regression bar:** Items 1–2 must pass for **Ava and Elise** on every chat change. Rose items are the active fix target.

**Commands:**

```bash
cd anikai-desktop
node scripts/smoke-companion-stream-parse.cjs
node scripts/smoke-companion-availability.cjs
```

Parse smoke **does not** catch Electron bubble routing, session KV, or GPU hangs — always run manual checklist above before calling chat “fixed”.

---

### Qwen 2.5 / Rose thought stair loop

- **Symptom:** Planning streams the same `Thought:` lines forever; no user reply; UI “Thinking” block grows in a stair pattern.
- **Root cause:** Model emits bare `Thought:` lines (not `<thought>` / `[End thinking]`); parser treated non-empty buffer as “final”, or open thought never closed; repeat lines not collapsed; recovery used generic prompt instead of reply-after-thought.
- **Fixes (scoped to Qwen only — must not regress Gemma / base chat):**
  - `normalizeBareThoughtFormat` only in `qwen25-vl-thought.js` (removed from `base-template.js` — was mis-parsing other models)
  - `detectThoughtStreamStall` + force-close only when bare `Thought:` format detected (Qwen)
  - `usesQwenThoughtTemplate` gates segment-loop stall handling and recovery stall checks
  - `buildReplyAfterThoughtPrompt` recovery pass for open/stalled Qwen thought
  - Stuck **Thinking** badge: cleared when stream ends with closed thought but no reply (non-streaming)
  - **Jun 2026:** Unified finalize routes Qwen solo + group through same `QwenGroupStreamUi` path — **group empty-reply issue persists** (see §1 companion chat status)

### Companion panel ↔ chat desync

- **Symptom:** TEAM list empty (“No companions yet”) while chat rail stacks many “New companion” tabs; creating a companion flashes then vanishes from panel.
- **Root causes identified:**
  - Race: panel mount vs `onPanelShown` refresh applying **empty** IPC payloads and wiping in-memory list.
  - Save path could persist **partial** in-memory list over full `companions.json` on disk.
  - Chat rail loaded all disk companions; panel did not.
- **Fixes in flight:**
  - Never apply empty companion payloads unless explicit first-mount.
  - `persistCompanionsNow` merges disk + memory (`memoryWins`) before save.
  - `createNewCompanion` loads disk first, then appends one row, then saves.
  - Chat thread list dedupes by `persona-`* id.
  - Mount retry `refreshCompanionsFromDisk` when list still empty.
- **User cleanup after fix:** Rename recovered companions; re-assign Chat & reasoning `.gguf` per slot; prune duplicate “New companion” rows.

### Vulkan / multi-GPU

- Settings → Device → Hardware shows **Vulkan SDK** + **Vulkan offload** under CUDA.
- SDK auto-discovers `VULKAN_SDK`, `C:\VulkanSDK\`*, Program Files LunarG paths.
- `ggml-vulkan.dll` staging via `stage-llama-runtime` when built with `-DGGML_VULKAN=ON`.
- Companion chat uses CPU offload when live media tasks hold GPU (mixed NVIDIA + AMD).

---

## 2. Maintenance assist — LTX smoke vision reports

**Goal:** After each LTX smoke (t2v / i2v), terminal report includes **prompt-adherence score** similar to existing image frame scoring.

### Pipeline

1. Run smoke → output video path (+ source image for i2v).
2. Extract keyframes (start / 25% / 50% / 75% / end).
3. Run **vision GGUF** (mmproj / multimodal chat model) with rubric prompt:
  - Prompt adherence 1–10
  - Subject / motion / style / audio-cue notes (from prompt text)
  - For i2v: first-frame fidelity vs reference image
4. Terminal summary:
  - `PASS 7.5/10 — motion matches; missing audio cue “leaves rustling”`
  - `FAIL 4/10 — wrong subject; suggest: lower steps, raise guide strength, check LoRA`
5. On failure: structured **follow-up suggestions** (config knobs, not generic errors).

### Files / hooks

- Extend `scripts/smoke-ltx-*.cjs` post-step.
- Shared helper: `scripts/lib/video-prompt-assess.cjs` (frames + vision IPC or subprocess).
- Reuse existing vision slot / mmproj resolution from companion models.

---

## 3. Control / view model — app testing (terminal-first)

**Goal:** Agent can see UI, act (mouse/keyboard or direct IPC), and log structured results — foundation for companion “sight + touch” later.

### Phase A — Headless smoke runner (now)

- Electron CDP or main-process screenshot capture.
- Script steps: open panel → assert DOM text → screenshot → JSON log line.
- Terminal consumer reads pass/fail.

### Phase B — Input automation

- Windows: `@nut-tree/nut-js` or `robotjs` for pointer/keyboard.
- Prefer **IPC shortcuts** for Media Magic toggles (faster than pixel hunting).

### Phase C — Planner loop

- Small GGUF in terminal: plan → act → observe → report.
- Same JSON schema companions will use in chat thread.

### Phase D — Companion-operated

- Companion thread receives review report; user converses to adjust (see §5 Shaper).

---

## 4. Media Magic intelligence via chat

**Goal:** Companion has **full situational awareness** of Media Magic when user asks specifics (chroma weights, Civitai LoRA wiring, Sculpt4D, LTX timeline, etc.).

### Capability layers


| Layer                   | What                                                                  | Example question                                             |
| ----------------------- | --------------------------------------------------------------------- | ------------------------------------------------------------ |
| **Local wiring audit**  | Read registries, `media-models.json`, staged packs, logs              | “What do we need for chroma to work like the other weights?” |
| **Web research**        | Fetch docs / HF / Civitai → structured report → user approves changes | “Find NSFW LoRA requirements for Illustrious”                |
| **Safe mutations**      | Whitelisted chat intents only                                         | `setLoraStrength`, `switchPreset`, `openPackFolder`          |
| **Error investigation** | Parse stderr + source, not just UI warning string                     | “Why did LTX batch job 3 fail?”                              |


### LTX 2.3 simple timeline (LTX Director–inspired)

- Horizontal timeline: blocks for image/video refs.
- Click to append; drag edges for duration; per-block prompt + optional audio cue.
- Character/scene intro markers; stretch-to-fit for cuts.
- Chat can **author timeline JSON**; Media Magic **renders** it (no mode switch — conversational planning).
- Reference: LTX Director multi-block prompt UI (duration_frames, guide strength, AV cues).

---

## 5. Planning canvas window (new surface)

**Goal:** Dedicated window (like Pipelines node view) — **blank canvas** for AI planning, mood board, timelines, script notes, quick Z-Image Turbo previews.

### UX principles

- **No mode switch** — natural back-and-forth in companion chat; companion may *suggest* “start a plan” when idea is large enough.
- Canvas is a **project artifact surface**, not a separate app mode.

### Canvas contents

- Sticky notes, arrows, refs to images/videos from library.
- Timeline strips (§4).
- Optional **think-panel** lines / mood-board layout.
- Quick render tiles (Z-Image Turbo) for concept frames.
- Export: detailed `.md` plan doc + canvas snapshot.

### Context management

- When context nears limit:
  1. Write **intention notes** (goals, constraints, open questions) to plan doc **before** summarizing.
  2. Summarize session chunk; keep intention doc as anchor.
  3. Edits during work append to “changelog” section in plan doc.
- Goals survive summary boundaries.

### Interlinks

- Chat ↔ Canvas ↔ Media Magic ↔ Pipelines node view.
- **Shaper** (generation review persona) appears in chat for conversational adjustment (see §6).

---

## 6. Review gens (Media Magic)

**Goal:** Button next to **Batch** — **Review gens** — runs post-completion quality review.

### Behaviour


| Mode       | When review runs                                                        |
| ---------- | ----------------------------------------------------------------------- |
| Single gen | After completion                                                        |
| Batch      | After **whole batch** finishes (not between jobs)                       |
| Errors     | Investigate code/logs + optional web research, not only UI warning text |


### Outputs

- Structured report in **companion thread** that performed review (like Shaper).
- Vision + prompt adherence for video; frame score for images.
- User discusses findings in chat; Shaper can propose parameter tweaks.

### Settings

- Toggle: batch review on/off (default off for speed).
- Per-companion reviewer assignment (specialty = media QA).

---

## 7. Bond & long-term memory (per companion)

**Bond journal (landed):** **[BOND_JOURNAL_IMPLEMENTATION.md](./BOND_JOURNAL_IMPLEMENTATION.md)** — MD categories, tools, context refresh, idle roam (Phases A–F).

**Long-term memory (next):** **[LONG_TERM_MEMORY_IMPLEMENTATION.md](./LONG_TERM_MEMORY_IMPLEMENTATION.md)** — distilled inject layer (`long-term/`), Phase A locked. Survives compress; distinct from bond MD prose.

**Goal:** Persistent relationship layer — romance / professionalism / friendship / favourites / milestones — separate from raw chat log. **Per companion only** (group learnings absorbed into each companion’s journal; group note-taker stays for user project planning).

**Metrics tab:** Affinity, relationship label, trust/friction-style soul stats — viewable in Companion Studio → **Metrics** (mirror Android Soul Meridian metrics pages; operational familiar/handoff counts remain alongside).

### Journal folder structure (per `persona-id`)

```
journal/{persona-id}/
  handoffs.jsonl      # existing async handoffs (unchanged)
  soul-metrics.json   # Metrics tab — relationship label, affinity
  index.json
  interests/ passions/ goals/ ideas/ bond/ companion-diary/
```

Full rules, tools, context refresh @ 90%, idle roam, and phases: **BOND_JOURNAL_IMPLEMENTATION.md**.  
LTM distill/inject/phases: **LONG_TERM_MEMORY_IMPLEMENTATION.md**.

### Bond store fields (draft → soul-metrics.json)

- `relationshipLabel`: companion-updatable (e.g. “New friends” → “Long friends”)
- `relationshipMode`: romantic | professional | friendship | custom
- `affinityScore`: 0–100 (soft signal; Metrics tab, not gamification UI)
- Milestones: `milestones.jsonl` + bond MD

### Proactive messages (later)

- Idle / queue-aware journal roam and bond-aware nudges — not forced on app start.
- Quiet hours via bond journal (user says in chat → companion writes preference).
- Toggle per companion in chat menu.

> **Not the same as §16 Main Character off.** Bond idle proactive = per-companion when app quiet. §16 = group/solo social layer among companions.

### Separation from existing journal

- `handoffs.jsonl` = workforce / media delegations only.
- Bond MD folders = long-horizon poetic life memory; companion-governed via tools.

---

## 8. Shaper in chat

- Shaper (generation critic persona) surfaces in **chat thread**, not only terminal.
- Same report schema as §6; user refines via conversation.
- Links to Media Magic params and Planning canvas refs.

---

## 9. Chat flow fixes (completed baseline)

- Reply area empty until `<|channel|>final`; strip contract echo / `, then` spam.
- Defer capability map / journal / workforce until user intent warrants.
- Segment loop continues after tools until user-facing reply exists.
- Companion CPU offload when live media uses GPU.

---

## 10. Post-portrait contextual UX (queued)

After companion self-portrait gen:

persona-1781037740672

- Context-aware `<choices>` chips: wallpaper 16:9, save/retry, tone-aware wording (persona + affinity).
- Uses existing `chat-interactive-choices.js`.
- Wallpaper via Windows IPC (not built).

---

## 11. Implementation priority (suggested)


| Priority | Item                                          | Effort                      |
| -------- | --------------------------------------------- | --------------------------- |
| P0       | Companion panel sync (§1)                     | Done — verify after restart |
| P0       | **Rose/Qwen group + solo visible reply (§1)** | **In progress** — Ava/Elise baseline ✅ |
| P1       | **Autonomous burst hygiene (§1, §16)**        | Empty-speaker skip; Ava turn 3+ |
| P0       | Prune duplicate companions + rename recovered | User + small tool           |
| P1       | LTX smoke vision reports (§2)                 | Medium                      |
| P1       | Review gens button + batch toggle (§6)        | Medium                      |
| P1       | In-chat res + LoRA wiring (§14)               | In flight                   |
| P2       | Local media wiring audit tool (§4 layer 1)    | Medium                      |
| P2       | Planning canvas window MVP (§5)               | Large                       |
| P3       | CDP smoke runner (§3 phase A)                 | Medium                      |
| P3       | Bond journal folders schema + UI (§7)         | **In progress** — [BOND_JOURNAL_IMPLEMENTATION.md](./BOND_JOURNAL_IMPLEMENTATION.md) Phase A |
| P4       | Idle proactive messages (§7)                  | After Phase E (idle roam) |
| P4       | **Companion social chat / Main Character (§16)** | **Landed (baseline)**    |
| P4       | **Companion availability / break tools (§18)** | **Landed (needs live QA)** |
| P4       | LTX simple timeline UI (§4)                   | Large                       |
| P5       | Full mouse/keyboard agent (§3 phase B–D)      | Large                       |


---

## 12. Architecture sketch

```mermaid
flowchart TB
  subgraph surfaces [Surfaces]
    Chat[Companion Chat]
    Panel[Companion Panel]
    MM[Media Magic]
    Canvas[Planning Canvas]
    Pipe[Pipelines Node View]
  end

  subgraph brain [Companion Brain]
    LocalAudit[Local Wiring Audit]
    WebResearch[Web Research]
    Vision[Vision / mmproj]
    Bond[Bond Memory Store]
    Social[Social Chat / Main Character]
    Avail[Companion Availability / Breaks]
    PlanDoc[Plan .md + Intention Notes]
  end

  subgraph maint [Maintenance]
    LTXSmoke[LTX Smokes]
    ReviewGens[Review Gens]
    CDPRunner[CDP Smoke Runner]
    Shaper[Shaper Reports]
  end

  Chat --> Panel
  Chat --> Canvas
  Chat --> MM
  Canvas --> PlanDoc
  MM --> ReviewGens
  LTXSmoke --> Vision
  ReviewGens --> Vision
  ReviewGens --> Shaper
  Shaper --> Chat
  LocalAudit --> MM
  WebResearch --> Chat
  Bond --> Chat
  Social --> Chat
  Avail --> Chat
  CDPRunner --> Chat
```



---

## 13. Open questions

- Canvas window: separate `BrowserWindow` vs tab inside workspace panel?
- Bond affinity: visible to user or background-only?
- Review gens: always same companion or rotate by specialty?
- Timeline: store in `generated-media/` project folder or companion-scoped?
- Proactive messages: max frequency cap?
- Main Character solo idle: same burst budget as group or separate curve?
- Break tool: auto-clear on @mention or require explicit `clear_break`?

---

## 14. In-chat companion media (W5a+ — active)

**Goal:** Companion `generate_image` / video / music handoffs use **real** generation settings (pixels, quality tier, LoRA stack) — not prompt-only hints. Mirror Media Magic wiring from chat tools.

### Landed / in flight


| Capability | Behaviour |
| ---------- | --------- |
| **Resolution & aspect** | `aspect="16:9"`, `width`/`height`, or user turn (“hi-res wallpaper 16:9”) → `resolveImageDimensionsFromToolAttrs` sets actual `sdCliArgs` / `diffusersDefaults` (preview ~1024 long edge; full up to 1536–1920). |
| **Quality tier** | `quality="preview|full"` + user phrasing (“hi-res”, “4k”) → `resolveQualityFromRequest`; full gated behind clarify unless user asked or preview already ran this turn. |
| **LoRA wiring** | Tool attrs `loras="id-or-name:0.8,other"` → scan stack via `listImagingLoras` → `matchLorasFromCatalog` → `imageLoras` on `generateImage` (apply order = tool list order). |
| **Context LoRAs** | Thread text scanned for on-disk LoRA names/ids (`resolveContextLorasFromThread`); merged with explicit tool attrs. Toggle per companion: **Auto-apply LoRAs mentioned in the thread** (default on). |
| **Proactive generation** | `detectProactiveMediaIntent` + companion opt-in → preview `generate_image` after turn when user discusses logos/concepts without explicit draw command. ~2 min cooldown per thread+companion. Toggle: **Proactive preview on logo / concept discussion**. |
| **Khala (Lane 4)** | `khala` backend → `khala_api_infer.py` (local FastAPI). Weights: `khala-musicgeneration-v1`. Stage: `npm run stage-khala`; start `backend/run_backend.sh`; smoke: `ANIKAI_LANE4_SUPER_BACKEND=khala`. |
| **Handoff prompt** | Planning block documents aspect + LoRA attrs + proactive/context hints so Rose emits real `<tool/>` tags. |
| **Terminal smokes from chat** | `<tool name="run_smoke" smoke="lane4-probe|lane4-catalog|lane4-audio|lane4-super"/>` — whitelisted `scripts/smoke-*.cjs` via `companion-maintenance.js`. |
| **HF / Civitai fetch** | `<tool name="fetch_hf" repo="owner/name"/>` → `models/loras/…`; `<tool name="fetch_civitai" versionId="…"/>` → Civitai API download. |

### Queued (next)


| Item | Notes |
| ---- | ----- |
| **Group working blocks** | In group chat, show per-companion “working…” blocks while media tools run (parallel to solo stream bubble). |
| **Khala subprocess inference** | HTTP API disabled by default (`ANIKAI_KHALA_ALLOW_API=1` only when user started backend). Goal: in-process subprocess like Tango2. |

### Files

- `shared/companion-media-resolution.js` — dims, quality, LoRA parse/match
- `components/chat.js` — `executeMediaHandoffTool` → `generateImage`
- `main-process/media-lora-scan.js` — on-disk LoRA catalogue per stack

---

## 16. Companion social chat — Main Character mode

**Goal:** Group (and eventually solo) companions feel like a living hangout — not a turn-based queue that stops when the user goes quiet. **Main Character** is the master switch: when **on** (default), behaviour matches classic Anikai (user drives each round). When **off**, companions keep social momentum among themselves.

### What “Main Character” means


| Main Character | User experience |
| -------------- | --------------- |
| **ON** (default) | You send a message → full group round-robin runs → round ends. Companions wait for your next prompt. Footer tip reminds you that social mode exists. |
| **OFF** | Same user round, **then** an **autonomous burst** (companions talk peer-to-peer). **Idle bursts** fire after quiet periods. User messages **queue** during an active round instead of hard-blocking. Solo tab may get a **proactive outreach** after group RP. |


**Design intent:** Not a fixed timer sim — event-driven (post-round follow-up, variable idle delay 6–20s, peer tags, interrupt merge). Uses existing **model residency** / parallel inference cap where safe; group **round lock** still serializes one orchestrated round per thread at a time.

### Settings (where to configure)


| Setting | Location | Default | Notes |
| ------- | -------- | ------- | ----- |
| **Main Character** | Settings → Inference → *Companion social chat* | ON | Autosaves on toggle (no separate Save click required). |
| **Solo autonomous turns max** | Same panel | 10 | Reserved for solo-thread idle bursts (§16 queued). |
| **Group autonomous turns max** | Same panel | 10 | Max companion turns per autonomous burst. |
| **Main Character (group override)** | Group → Members editor | Inherits global | Only stored when different from global (`null` = inherit). |
| **Autonomous burst turns (group)** | Group → Members editor | Inherits global | Per-group cap override. |
| **Parallel inferences** | Settings → Inference → Residency | 1 | Raise with multi-residency so peer/autonomous work can overlap when GPU allows. |


**Storage:**

- Global: `configs/user-settings.json` → `ui.chat.social`
- Per group: `{group}/thread.json` → `settings.social` (nullable overrides)

### Behaviour when Main Character is OFF

1. **User round** — unchanged round-robin (all equipped companions reply to your message).
2. **Follow-up burst** — after round completes, `runGroupSocialBurst` runs up to **N** autonomous turns (`groupAutonomousTurnsMax`, default 10).
3. **Idle burst** — if thread stays quiet (6–20s jitter), another burst may run while you remain on the group tab (skipped if input focused or stream active).
4. **Peer tags** — enabled on casual group rounds; companions may `@` each other; autonomous picker prefers tagged speaker.
5. **User queue** — sending while a round/burst runs **queues** your message; drained into the cycle instead of “round already in progress”.
6. **Interrupt merge** — if you send during a companion’s thought phase, next inference merges your line with partial thought context.
7. **Solo outreach** — ~45% chance after a burst: one companion queues a solo-thread DM about the group RP; **badge** on their tab; flushes when you open that solo tab.

### Prompt / inference guardrails (group casual)

- **Social-only turns** (casual + autonomous): no media toolkit, no proactive media intent, **maxSegments = 1**, no tool continuation unless user explicitly asked for media.
- **Slim group prompts** for Qwen (Rose) and base/Gemma (Ava) — avoids system-prompt regurgitation.
- **Recovery pass** — if primary pass is empty or prompt-echo, a second slim completion runs (`recoveryPassUsed` in turn metadata).
- **Cycle hygiene** — `(no visible reply)`, contract echoes, and meta fallbacks are **not** fed back into teammate context.

### Architecture (control flow)

```mermaid
flowchart TD
  UserSend[User sends message] --> Round[runGroupRoundRobin]
  Round --> QueueDrain[Drain queued user lines]
  Round --> Speakers[Sequential speaker turns]
  Speakers --> MC{Main Character?}
  MC -->|ON| Hint[Round complete hint]
  MC -->|OFF| Burst[runGroupSocialBurst]
  Burst --> Idle[scheduleGroupSocialIdleCheck]
  Idle -->|6-20s quiet| Burst
  Burst --> Outreach{Random solo outreach?}
  Outreach -->|yes| QueueSolo[Queue pending solo DM + tab badge]
  QueueSolo --> Flush[flushPendingSoloOutreach on tab switch]
```

### Files


| Area | Path |
| ---- | ---- |
| Settings schema + burst logic | `shared/companion-social-chat.js` |
| Group thread social overrides | `main-process/group-threads.js` |
| Chat engine (burst, queue, interrupt, outreach) | `components/chat.js` |
| Global UI | `components/panels.js` (#socialMainCharacterEl, autosave) |
| Group UI | `components/chat.js` (Members editor) |
| Stream finalize (Rose / Ava / Elise isolated) | `shared/qwen-group-stream-ui.js`, `thought-group-stream-ui.js`, `channel-group-stream-ui.js` |
| **Unified turn finalize (solo + group)** | `shared/companion-turn-finalize.js` |
| Slim Qwen group prompt | `shared/gguf-output-templates/qwen25-vl-thought.js` (`buildQwenGroupCasualPrompt`) |
| Parse smoke (not UI integration) | `scripts/smoke-companion-stream-parse.cjs` |


### Landed (baseline — Jun 2026)


| Capability | Status |
| ---------- | ------ |
| Main Character global toggle + autosave | ✅ |
| Per-group inherit/override | ✅ |
| Autonomous burst after user round | ✅ |
| Event-driven idle scheduler | ✅ |
| User message queue + interrupt merge | ✅ |
| Peer tags on casual social rounds | ✅ |
| Solo outreach queue + tab badge | ✅ |
| Social-only prompt slimming + recovery pass | ✅ |
| Multi-residency hint in Inference settings copy | ✅ |
| Unified turn finalize + Ava hybrid + group recovery | ✅ (Jun 2026) |
| Ava + Elise solo/group user rounds | ✅ (Jun 2026 QA — regression watch) |
| Ava/Elise autonomous burst baseline | ✅ Elise; ⚠️ Ava turn 3+ intermittent |
| Rose/Qwen visible reply group + autonomous | ❌ P0 |


### Known gaps (Jun 2026 — keep watching)


| Priority | Issue | Notes |
| -------- | ----- | ----- |
| **P0** | Rose `(no visible reply)` in group/autonomous | Tokens generate; finalize empty — primary blocker |
| **P0** | Rose solo turn 2 / message attribution | User line under Rose avatar reported |
| **P1** | Ava autonomous turn 3+ | Intermittent `Model produced no reply` after early burst OK |
| **P1** | Ava contract echo on casual solo | Instruction text in bubble; hallucinated `[User]` in debug |
| **P1** | Autonomous burst picks failed speakers | Should skip empty + respect future §18 breaks |


### Queued (next evolutions)


| Item | Notes |
| ---- | ----- |
| **Companion availability tools** | §18 — `take_break`, @mention wake, user away |
| **Skip empty autonomous picks** | Don't re-pick companion after `(no visible reply)` |
| **Solo autonomous idle** | Use `soloAutonomousTurnsMax` on solo threads when Main Character off (not only group burst). |
| **Parallel autonomous speakers** | When `maxParallelInferences > 1`, safe parallel peer turns within burst budget. |
| **Richer idle triggers** | Bond/memory-aware nudges, not only post-round timer. |
| **Cross-thread bond memory** | Group RP context feeding solo outreach copy (ties to §7 bond store). |
| **Group working blocks** | Per-companion “generating…” during parallel media (§14 queued). |


### Verification checklist

**Settings / social mode:**

1. Settings → Inference → uncheck **Main Character** (should persist immediately).
2. Group chat → send `hi` → all companions reply → **burst continues** without you.
3. Send again mid-burst → message appears after queue drain, not blocked.
4. Switch to a companion solo tab after group RP → optional proactive outreach message.
5. Turn Main Character back **ON** → only user-driven rounds; footer shows tip again.

**All models (§1 checklist — required after chat engine changes):**

6. Fresh solo thread per companion: 2-turn hi + follow-up — **Ava + Elise must pass every time**.  
7. Fresh group thread: user round + one autonomous burst — **Ava + Elise visible**; Rose tracked until P0 closed.  
8. `node scripts/smoke-companion-stream-parse.cjs` passes.

---

## 18. Companion availability & break tools (landed — live QA pending)

**Goal:** Companions control their own participation — not dragged through every autonomous turn. Same philosophy as media tools: **they decide context and timing**, not forced timers in settings.

### Landed (Jun 2026)

| Area | Path | Notes |
| ---- | ---- | ----- |
| Shared logic | `shared/companion-availability.js` | `take_break`, `clear_break`, `set_user_away`, `schedule_checkin`, prompt block, speaker filters |
| Persistence | `main-process/companion-availability.js` | Group → `group-threads/{gid}/thread.json`; solo → `{ANIKAI_HOME}/companion-availability/` |
| Skills + IPC | `companion-skills.js`, `main.js`, `preload.js` | Execute skills, get/set state, mark check-in fired, broadcast updates |
| Chat engine | `components/chat.js` | Prompt block, round-robin + autonomous skip, @mention wake, user `brb` parse, check-in timer |
| Presence UI | `companion-presence-status.js`, `styles/chat.css` | `presence-dot--break` + label |
| Prompt templates | `gguf-output-templates/` | `availabilityBlock` in behavior contract |
| Smoke | `scripts/smoke-companion-availability.cjs` | Break/skip/filter/check-in unit tests |

### Problem today

When Main Character is OFF, `pickAutonomousSpeaker` and round-robin **always pick every equipped companion**. A companion who says “I’m taking a 30-minute break” (Ava/Elise RP) has **no engine support** — Rose still gets forced turns → `(no visible reply)` spam and wasted inference.

### Desired behaviour


| Actor | Action | Engine |
| ----- | ------ | ------ |
| **Companion** | `<tool name="take_break" minutes="30" reason="…"/>` | Skip in autonomous/round-robin until timer expires |
| **Companion** | `<tool name="clear_break"/>` | Return to active immediately |
| **User** | `@Ava` while Ava on break | **Wake** — one reply allowed (mention override) |
| **User** | “brb 1 hour” | Set `userAwayUntilMs`; companions may social burst without user |
| **Timer expiry** | Break ends | Optional `schedule_checkin` — companion sends one proactive line to group or solo thread |
| **Teammates** | RP | Prompt block lists who’s away and ~time left (“Ava back in ~12 min”) |

### Tools (draft — mirror `companion-skills.js` pattern)


| Tool | Attributes | Effect |
| ---- | ---------- | ------ |
| `take_break` | `minutes`, optional `reason`, `until` | Persist away state per thread; inject availability into group prompt + light cycle line |
| `clear_break` | — | Clear away state |
| `set_user_away` | `minutes`, `reason` | Thread-level user away (optional; may also parse user text) |
| `schedule_checkin` | `minutes`, `message` | After break, one autonomous message from that companion |

### State (per thread)

```
group:{gid} / solo companion thread:
  companions[companionId] → { status, untilMs, reason, visibleLabel }
  userAway → { untilMs, note }
```

Persist in group thread settings / chat storage. Extend `companion-presence-status.js` with **social** dot (Break · 24m) separate from GPU warm/cold.

### Integration points

1. **`pickAutonomousSpeaker`** — filter out `status === 'break' && now < untilMs`
2. **`_runGroupCycleSpeakerTurn`** — skip unless @mention / peer-tag override
3. **Prompt shaper** — `Availability:` block for group turns (like media handoff)
4. **`executeThoughtSegmentTools`** / `companion-skills.js` — handlers + capability map entries
5. **Main timer** — on expiry → optional check-in burst for returning companion only

### Rules

- **No global disable** of group social mode — companions opt out individually
- Empty/failed turns must **not** feed cycle (existing hygiene) + **must not** re-pick same empty speaker next autonomous slot
- Casual turns: availability tools only on social/autonomous turns or when discussing breaks (not every “hi”)

### Priority

**P4 — landed.** Live QA: companion emits `<tool name="take_break" minutes="30"/>`, autonomous burst skips them, `@Name` wakes one reply, `clear_break` restores, `brb 1 hour` marks user away.

### Files (planned)


| Area | Path |
| ---- | ---- |
| Skills + capability map | `main-process/companion-skills.js`, `companion-capability-map.js` |
| State store + IPC | `main-process/companion-availability.js` (new), `preload.js`, `main.js` |
| Speaker skip + prompt block | `shared/companion-social-chat.js`, `components/chat.js`, `components/gguf-prompt-shaper.js` |
| Presence UI | `shared/companion-presence-status.js`, `components/chat.js` |

---

## 17. Related docs

- `implementations/pipelines/PLAYGROUND_NODE_EDITOR_DIRECTION.md`
- `implementations/pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md`
- `implementations/generation/video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`
- `implementations/generation/video/DITTO_ONE_TO_ALL_LOCAL_INFERENCE.md`
- `WHAT_IS_ANIKAI_ON_WINDOWS.md`

---

*This file is the single tracking doc for Super Companion work discussed in Cursor sessions. Append sections rather than spawning scattered notes.*