# TODO — GGUF engine inference runtime (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Track GGUF as an engine family implementation (not only text lane notes).
- Keep multimodal capability checks and diffusion-lane completion criteria explicit.
- Prevent drift between runtime settings UI, native lane reality, and Swarm routing claims.

---

## Checklist (working)

- [ ] Lock GGUF manifest capability schema (`text_generation`, multimodal flags, sidecar requirements, diffusion flag policy).
- [ ] Verify runtime load config mapping parity between settings and native/runtime session parameters.
- [ ] Validate one stable multimodal understanding flow with explicit sidecar preflight checks.
- [ ] Complete canonical diffusion decode/output contract and document pass criteria.
- [ ] Wire Swarm GGUF specialist calls to same adapter registry and fail states.
- [ ] Confirm visible degraded states when GGUF lane is unavailable or unsupported.

---

## Linked operations

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through imaging runtime maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created dedicated GGUF engine inference todo bridge during local media split phase. |
