# OpenCV DNN engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: document **OpenCV `dnn` module** as a pragmatic lane for classic CNNs (Caffe/ONNX/TF frozen graphs where supported), fast prototyping, and lightweight detection/segmentation without pulling a full separate framework.

---

## Scope

This file covers OpenCV DNN for:

- Android OpenCV SDK integration (native),
- small CV helpers (edges, face detectors, simple classifiers) where graph fits `readNet`,
- explicit CPU fallback and optional backend hints (OpenCL/CPU).

This file does **not** target large generative models or LLMs.

---

## Role model (single truth)

| OpenCV DNN lane | Ownership |
|-------------------|-----------|
| Legacy/classic CV helpers | Strong fit. |
| Primary diffusion or LLM | Out of scope. |

---

## Android implementation plan (stub checklist)

- [ ] OpenCV Android dependency footprint vs benefit tradeoff.
- [ ] JNI bridge for `Mat` <-> GPU texture / Bitmap pipelines.
- [ ] Adapter id `opencv_dnn` + manifest for `.onnx`/`caffe` inputs where applicable.
- [ ] Compare overlap with MediaPipe tasks before duplicating detectors.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)
- [`../mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for OpenCV DNN helper inference lane. |
