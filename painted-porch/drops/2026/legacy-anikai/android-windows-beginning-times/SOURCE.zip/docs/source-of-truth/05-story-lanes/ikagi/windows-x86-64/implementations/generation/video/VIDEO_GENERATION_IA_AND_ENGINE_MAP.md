# Video generation IA and engine map (Windows desktop)

| Field | Value |
|-------|-------|
| **Status** | Active IA — UI scaffolding in Media Magic |
| **Scope** | Video tab grouping, engine specialization, and links to Image designers |
| **Anchor** | [`../../companion-surface/MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`](../../companion-surface/MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md), [`../../companion-surface/MEDIA_MAGIC_TOP_LEVEL_IA.md`](../../companion-surface/MEDIA_MAGIC_TOP_LEVEL_IA.md) |

---

## Why this doc exists

Image lanes focus on **design intent and references**.  
Video lanes focus on **engine execution and shot output**.

This document formalizes that split and aligns with the same **Generation | Weaving | Others** mode pattern as Image.

---

## Video mode groups (header)

| Mode | Purpose |
|------|---------|
| **Generation** | Run specialist engines (and Standard multi-model lane) |
| **Video weaving** | Mix, layer, timeline, look-unify clips from any engine |
| **Others** | Curated experiments (PersonaLive rig test, …) |

---

## Generation engines

Each engine gets its own sub-lane under **Generation** (dropdown in UI):

| Engine | Role | Status |
|--------|------|--------|
| **Standard** | T2V / I2V / V2V — Lance + other motion models when a specialist panel is not needed | Scaffolding + ref slots |
| **Lance** | ByteDance unified multimodal generation/edit | Staged UI |
| **Fashion** | Human–garment customization | Coming soon (watch) |
| **CogOmni** | Reasoning-driven controllable video | Watch until local release |

Fashion and CogOmni are **not** folded into Standard — they have dedicated tabs even though some capabilities overlap.

---

## Standard lane — character + scene refs

Planned shared contract for I2V-class models on Standard (and engines that opt in):

- **Character / cast** — optional; from Character designer or recents
- **Scene source** — optional; building, environment, concept-scene still, or future CogOmni scene

**Dynamic slots:** character-only, scene-only, or both; empty slots never block each other.

Handoffs from Image designers should pre-target the correct slot (console guidance today; persisted refs later).

---

## Video weaving

Purpose:

- Combine clips from specialist engines and Standard
- Timing / layer blending / shader ops
- Optional V2V pass to unify look across heterogeneous gens
- Bridge to audio assembly
- Ingest concept-scene timeline beats (planned)

Video weaving is **post-generation composition**, not a core engine.

---

## Others

- **PersonaLive rig test** — curated internal lane
- Future Anikai experiments (separate from specialist engine tabs)

---

## Cross-links with Image designer lanes

Designer tabs link into engines they naturally feed:

- Character / Outfit → Fashion or Lance (or Standard)
- Concept scene → CogOmni-ready refs; timeline → Video weaving
- Building / Environment → scene source on Standard; archviz branches

Reciprocal links from video engines back to Image designers are required.

---

## Fashion tab requirements (coming soon contract)

Until local runtime is ready, Fashion tab remains visible with `Coming soon` and this checklist.

### Inputs

- source character reference (image and/or video clip)
- standalone outfit references (cropped garments preferred)
- optional preserve-identity control

### Controls

- garment apply mode, fit/style strength, temporal consistency, occlusion preference

### Outputs

- preview clip, look variants, send-to-weaving, frame export for 3D/sprite downstream

### Readiness states

| State | UI |
|-------|-----|
| Watch | Tab visible, requirements listed, no Generate |
| Pack ready | Get pack enabled |
| Runnable | Generate + console stages |

---

## CogOmni watch tab

- Paper, repo, expected inputs/outputs
- Graduates to runnable engine mode when local inference lands
- Own Generation tab (not buried in Standard)

---

## Ditto / Editto (staged)

**Role:** Instruction **video-to-video** editor on **Wan2.1-VACE-14B** with **QingyanBai/Ditto_models** adapters.

| Pack | HF | Folder under `models/` |
|------|-----|-------------------------|
| Ditto adapters | [QingyanBai/Ditto_models](https://huggingface.co/QingyanBai/Ditto_models) | `ditto/Ditto_models/` |
| VACE base | [Wan-AI/Wan2.1-VACE-14B](https://huggingface.co/Wan-AI/Wan2.1-VACE-14B) | `ditto/Wan2.1-VACE-14B/` |

**Catalogue:** `componentHf.diffusion` / `encoders` point at Hugging Face weights; `componentHf.project` is the [GitHub repo](https://github.com/EzioBy/Ditto) (project page column later).

**Product fit:** With **LTX** (gen/edit multimodal) and **Wan** (GGUF / Diffusers motion), Ditto is the dedicated **instruction V2V** lane for editors who want text-driven clip surgery.

**UI:** Media → Models → **Ditto V2V** — two Get pack buttons (adapters + base).

---

## One-to-All Animation (staged)

**Role:** **Reference still** + **driving motion video** → animated output that follows the motion (pose-guided; skeleton overlay in demos).

| Stack | HF | Folder |
|-------|-----|--------|
| 14B (default in UI) | [MochunniaN1/One-to-All-14b](https://huggingface.co/MochunniaN1/One-to-All-14b) | `one-to-all/One-to-All-14b/` |
| 1.3B | [MochunniaN1/One-to-All-1.3b_2](https://huggingface.co/MochunniaN1/One-to-All-1.3b_2) | `one-to-all/One-to-All-1.3b_2/` |

**Future:** MoCap / pose export from the motion reference (same mental model as the skeleton side-by-side in the paper UI).

**UI:** Media → Models → **One-to-All** — 14B primary Get pack, 1.3B secondary; stack picker in Generate workspace.

**Local inference:** See [`DITTO_ONE_TO_ALL_LOCAL_INFERENCE.md`](DITTO_ONE_TO_ALL_LOCAL_INFERENCE.md) — upstream Git clone + `ANIKAI_DITTO_PYTHON` / `ANIKAI_ONE_TO_ALL_PYTHON`.

---

## Resolved / updated

- Video uses **Generation | Video weaving | Others** (matches Image pattern)
- Lance, Fashion, CogOmni are Generation sub-lanes, not top-level mode dropdown entries
- Standard is first Generation engine in the dropdown
