# Live conversation, engine modes, and delivery order (Desktop + Voice)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-16 |

**Purpose:** Capture how **llama.cpp conversation mode (`-cnv`)** relates to Anikai’s **thought/reply UI**, **semi-duplex voice**, and **full-duplex** ambitions — and define **what ships before** Codacus-style live voice (streaming STT → LLM → TTS, barge-in, tools without resetting the session).

**Prerequisites (must ship first):**

1. [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) — phases **B1–B3** (segment loop, skills, vision disambiguation)
2. [`group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) — **Phase E+** (`llama-server` / warm session)

**Later (this doc §6):** Semi-duplex voice on desktop; full-duplex after quality + duplex work on Android voice roadmap.

**Reference (external):** Local offline voice assistant pattern (Whisper + local LLM + streaming TTS + interrupt + tools) — e.g. [Codacus build walkthrough](https://www.youtube.com/watch?v=Xuh6PzhqrgQ); internal notes in `live voice local agent.txt` on the author machine.

**Code touchpoints today:** `anikai-desktop/main-process/gguf-completion.js` (`-no-cnv`, `llama-mtmd-cli`), `Anikai App/.../soul/voice/`, `VoiceOrchestrator.kt`, `AnikaiCustomVoiceEngineRoadmap.kt` (Phase 3 duplex).

---

## 1. Delivery order (canonical)

Do **not** start live-voice / full-duplex desktop work until the rows above are done enough for production chat.

```mermaid
flowchart TD
  A1[A1 Thought/reply unified contract — done]
  B[Thought/reply B1–B3 Segment loop + tools + vision captions]
  Eplus[Group chat Phase E+ llama-server warm session]
  VoiceSemi[Voice semi-duplex desktop — later]
  VoiceFull[Full-duplex — later stage]

  A1 --> B
  B --> Eplus
  Eplus --> VoiceSemi
  VoiceSemi --> Copilot[J Desktop copilot J1-J3]
  VoiceSemi --> VoiceFull
  Copilot --> VoiceFull
```

| Stage | What | Why first |
|-------|------|-----------|
| **Thought/reply B1–B3** | Tags, multi-segment turns, skill injection, optional vision one-liners | Correct **text** brain: one pipeline for chat, tasks, clarification — matches product design without `turn_mode` |
| **Phase E+** | `llama-server` (or equivalent): hot weights, session/KV across turns | Fast group rounds + foundation for **streaming** and **session rollover** (`preferSessionRollover`) |
| **Voice semi-duplex** | STT → stream LLM → stream TTS; cancel on barge-in; tools pause/resume | Needs **resident LLM** + stable segment/tool story; matches “alive” demos without REPL leakage |
| **Full-duplex** | Overlapping speak/listen, echo handling, partial intent | Android roadmap Phase 3; desktop after semi-duplex proven |

**Explicitly out of order:** Building Codacus-style interrupt + sentence TTS on top of **spawn-per-call** `llama-completion` only — works for a demo, fights group chat, reload cost, and tool continuity.

---

## 2. Two different meanings of “conversation”

### 2.1 Engine: `-cnv` / `-no-cnv` (llama.cpp)

| Flag | Meaning in llama.cpp |
|------|----------------------|
| **`-no-cnv`** | One-shot **completion**: full `--prompt` string in, tokens out, process exits. Anikai desktop text path today (`llama-completion`). |
| **`-cnv`** | **Chat-template / multi-turn session** on a long-lived process; on `llama-cli` also tends to mean **interactive REPL** (banners, `>`, slash commands). |

**Not the same as:**

- “User-visible reply” vs “thought panel” → enforced by **prompt + parser** (`behavior-contract.js`, templates), not by `-cnv`.
- “Planning uses no-cnv, reply uses cnv” → **old Anikai two-pass shortcut**, not a general rule.

### 2.2 Product: thought vs reply (Anikai)

| Layer | User sees | Enforcement |
|-------|-----------|-------------|
| **Thought panel** | Private planning, tags, future tool/code blocks | Delimiters + parser; tags only in thought |
| **Main bubble** | Plain-language reply | `final` channel / after `[End thinking]`; sanitizers strip scaffold leaks |

Same inference run (or same **server session** segment) can produce **both**; the app splits them in the UI.

### 2.3 Desktop today vs target

| | Today | After E+ |
|---|--------|----------|
| **Process** | Spawn `llama-completion` per call (vision: `llama-mtmd-cli` one-shot) | Long-lived **`llama-server`** per resident model |
| **Context** | Rebuild prompt + recent history each send | KV / chat history on server between turns |
| **Streaming** | stdout chunks → parse (cleaned cumulatively) | Server SSE/chunk API (preferred for voice) |
| **`-cnv`** | Avoid on desktop REPL; use `-no-cnv` for control | Session API replaces CLI `-cnv` semantics |

---

## 3. What “live” assistants actually optimize (reference pattern)

From the offline voice assistant pattern (Whisper, local LLM, streaming TTS, Tauri):

| Technique | User perception | Anikai mapping |
|-----------|-----------------|----------------|
| **Streaming LLM → streaming TTS** (first sentence plays in ~3–6s) | Responsive, not “batch wait” | E+ stream API + `ChunkedWavStreamingSession` (Android) / desktop voice pane |
| **Cancellation / barge-in** | Can interrupt mid-sentence | Abort inference + stop TTS; return to LISTENING |
| **Tool call without session reset** | “Alive” during tasks | Thought/reply **B2** segment loop + warm **session** (E+) |
| **Semi-duplex turn-taking** | Natural rhythm | State machine: LISTENING → THINKING → SPEAKING (Android `VoiceSessionUiState`) |

**Not required for this feel:** `llama-cli -cnv` REPL. **Required:** resident backend + orchestrator + cancel tokens.

---

## 4. Semi-duplex vs full-duplex

### 4.1 Semi-duplex (next voice milestone)

One side “has the floor” at a time; user may **interrupt** the assistant’s turn.

```mermaid
stateDiagram-v2
  [*] --> Listening
  Listening --> Thinking: end_of_speech
  Thinking --> Speaking: tokens_available
  Speaking --> Listening: turn_complete
  Speaking --> Listening: barge_in_CANCEL
  Thinking --> Listening: barge_in_CANCEL
```

- **Listening:** STT (Whisper or on-device).
- **Thinking:** LLM streaming; thought channel parsed but not spoken (optional).
- **Speaking:** TTS per sentence/chunk.
- **Barge-in:** cancel LLM generation + flush TTS queue.

Aligns with Android **Voice orchestration** and **AnikaiCustomVoiceEngineRoadmap** Phase 2–3 (latency + barge-in measurement).

### 4.2 Full-duplex (later stage)

User and assistant may **overlap** acoustically; requires echo cancellation, robust VAD, policy for partial transcripts and mid-utterance intent. Tracked on Android roadmap as **Phase 3 (quality + duplex)** — **not** a desktop prerequisite for B1 or E+.

---

## 5. Where `-cnv` / session mode *is* useful (future)

| Use case | Backend | Notes |
|----------|---------|--------|
| Fast text back-and-forth (solo/group) | `llama-server` | Amortize load; optional `preferSessionRollover` for note-taker |
| Voice semi-duplex | Same server + stream decode | Orchestrator owns states; not CLI REPL |
| Segment loop (B1) | One-shot per segment **or** next segment on same session | Prefer same session when E+ live to avoid re-uploading full thread |
| Agent tools (wallpaper, files) | B2 + session | Inject tool result as next segment context |

**Anti-pattern:** Using `llama-cli` with `-no-cnv` rejected + interactive UI streaming into chat (fixed by preferring `llama-mtmd-cli` for vision).

---

## 6. Later stages (after E+)

### 6.1 Desktop voice — semi-duplex MVP

**Depends on:** E+ streaming API, B2 skill registry (even if stub skills), companion `inferencePolicy`, desktop Voice pane (placeholder today).

**Scope sketch:**

- Push-to-talk or VAD end-of-utterance
- Stream tokens → thought panel optional / reply-only for TTS lane
- Sentence-chunked TTS + cancel
- No full-duplex overlap requirement

### 6.2 Full-duplex

**Depends on:** Semi-duplex stable; Android Phase 3 learnings; OEM/audio path diagnostics.

**Out of scope** until explicitly scheduled after §1 chain complete.

---

## 7. Comparison to “big gun” agent UIs (Cursor-style)

Cloud/local agents typically use:

- **Persistent session** (API or `llama-server`) — not spawn-per-message CLI
- **Streaming** tokens
- **Tool loop** inside one session
- Visible “thinking” as **UI layer**, not a second engine mode

Anikai equivalent:

| Their pattern | Anikai lane |
|---------------|-------------|
| Persistent thread + stream | Phase **E+** |
| Tool loop | Thought/reply **B1–B2** |
| Visible planning | Thought panel (parser) |
| Cancel / redirect | Voice cancel + abort inference (semi-duplex) |

---

## 8. Open decisions (when starting voice)

- [ ] Desktop voice: push-to-talk vs always-listening VAD for v1
- [ ] Speak **reply-only** vs brief thought summary on voice (default: reply-only)
- [ ] Same companion `inferencePolicy` for voice as text, or voice-specific caps
- [ ] `llama-server` multimodal API vs separate vision server for image-in-voice turns
- [ ] Port Android `VoiceOrchestrator` patterns to Electron main vs separate Rust helper (Tauri-like)

---

## 9. Related docs

| Doc | Topic |
|-----|--------|
| [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) | Unified thought/reply, tags, B1–B3 |
| [`group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) | Phase E+ `llama-server` |
| [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](DESKTOP_COPILOT_AND_SCREEN_AGENT.md) | Screen see/act + voice copilot (after E+ and semi-duplex) |
| [`../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) | Text gen tracker |
| `Anikai App/.../AnikaiCustomVoiceEngineRoadmap.kt` | Android voice phases |
| `anikai-desktop/main-process/gguf-completion.js` | `-no-cnv`, mtmd, stdout cleaning |
