# Mid scope todo

Multi-day work: a feature slice, one runtime path, or a vertical that does not rewire the whole app.
