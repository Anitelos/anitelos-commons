# Desktop workshop state — index (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | In progress |
| **Operations** | Mixed (see tables) |
| **Last reviewed** | 2026-05-20 |

**Purpose:** One place to see **what Anikai Desktop is becoming** as a local-first **workshop** — honest catalogues, unified registry, multi-window shell, chat inference, media lanes, and (planned) execution agent — without rereading every plan doc.

**Ops checklist (todos ↔ plans):** [`operations/OPERATIONS_INDEX.md`](../operations/OPERATIONS_INDEX.md)

**Doc index (roles, tree, familiars):** [`../WINDOWS_DESKTOP_INDEX.md`](../WINDOWS_DESKTOP_INDEX.md)

**Product lane intro:** [`WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)

---

## One sentence

Anikai Desktop is a **sovereign local workshop**: **Media Magic** is the mass-market creation front door (Get → generate → post/preprocess); companions and chat reuse the same engines; **runtime packs** make families installable once; Playground and terminal tooling serve **creators** later — all in floating windows, not one impossible pane.

**Product story:** [`../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md) · **Media Magic:** [`../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md)

---

## Engine-first strategy (long-term workshop)

Anikai’s endgame is **every engine the platform can honestly run**, composed into **user-built pipelines** (Playground). Portrait and sprite “feel right” because they stack **many ONNX stages** (depth, post, motion) on top of GGUF stills — see Android `PortraitDepthOnnxRuntime.kt` as a **thin adapter**, not a separate engine.

| Layer | You expand / tick here | User-visible |
|-------|------------------------|--------------|
| **Engines** | [`engine-inference/`](../engine-inference/) hub + runtime packs + VERIFIED smokes | Settings runtimes, honest errors |
| **Registries** | About JSON + Anikai Registry | “What exists / what’s installed” |
| **Pipelines** | Android plans first; Windows ports when engines ready | 4-shot, sprite sheet, rig test |

**Docs:** [`ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md) · [`PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md)

**Rule:** tick **one smoke per engine family** on Windows before re-building full pipeline UIs. Pipeline showcase then becomes wiring, not engine archaeology.

---

## Layer map

```mermaid
flowchart TB
  subgraph trust [Trust and catalogue]
    About[About / Sentience tabs]
    Reg[Anikai Registry table]
    Probe[Runtime probes]
  end

  subgraph shell [Shell and workspace]
    Chat[Chat HWND]
    Dock[Dock satellite]
    Panels[Panel HWNDs]
    Magnet[Magnet clusters M0]
  end

  subgraph mind [Companion mind]
    Seg[Segment orchestrator]
    Chan[Channel templates]
    Cap[Capability map + skills]
  end

  subgraph media [Media lanes]
    L1[Lane 1 DSP]
    L2[Lane 2 MIDI + SF2]
    L3[Lane 3+ neural - planned]
  end

  subgraph exec [Execution agent - planned]
    Sand[Sandbox + HITL]
    Agent[Scratchpad + roller]
    Team[Team blackboard]
  end

  About --> Reg
  Probe --> Reg
  Chat --> Seg
  Seg --> Cap
  Seg --> L1
  Seg --> L2
  Cap --> Sand
  Panels --> About
  Chat --> Dock
  Panels --> Magnet
```

| Layer | User-facing home | Status |
|-------|------------------|--------|
| **Trust & catalogue** | About → Sentience; Settings → Device → Software | **Shipping** (catalogues + registry + probes) |
| **Shell** | Chat, dock, panels (Settings, Models, Companion, Media…); **project tree M0**; **drag-magnet M0** | **Shipping**; M1+ polish (anchor ring on chat, panel→panel chains) |
| **Companion mind** | Chat thread, thought panel, tools | **Shipping** (B1–B3); policy **partial** |
| **Media lanes** | Media Magic, chat tools, About music tables | **Lane 1–2 in flight**; 3+ planned |
| **Execution agent** | Workspace tools, diff bake, team planning | **Documented, not coded** |

---

## Ships today (code truth)

### About / Sentience catalogues

Educational registries under `anikai-desktop/assets/about-guide/` — rendered in `components/about-guide.js` via `shared/about-registry-catalog.js`.

| Tab / area | Registry JSON | Notes |
|------------|---------------|--------|
| Text GGUF | `text-gguf-registry.json` | Families, stacks, preview images |
| Imaging | `imaging-registry.json` | + `imaging-education.json` |
| Sight | `sight-registry.json` | Vision / mmproj families |
| Hearing | `hearing-registry.json` | ASR families |
| Voice (speaking) | `voice-registry.json` | Piper, Kokoro, CosyVoice, XTTS, … |
| Persona / emotion | `persona-sentience-registry.json` | Moods, enmeshment; **`anikai_enmeshment`** format (not vendor “emotion fusion”) |
| Music / SFX | `music-audio-registry.json` | Tied to audio lanes overview |
| Articulations | `articulations-registry.json` | |
| Video | `video-registry.json` | |

**Android contract reference (slots, UI):**

- [`SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md`](../../../android-arm64/implementations/anikai-handover/SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md)
- [`SENTIENCE_SYSTEMS_UI_CONTRACT.md`](../../../android-arm64/implementations/anikai-handover/SENTIENCE_SYSTEMS_UI_CONTRACT.md)

Desktop uses the same **slot vocabulary** where it helps; HWND and registry UX are Windows-specific.

### Unified Anikai Registry

**UI:** Settings → Device → Software → **Anikai Registry** (`components/panels.js` → `refreshAnikaiRegistryTable()`).

**Logic:** `shared/anikai-registry-catalog.js` — buckets (text, image, music, sight, hearing, voice TTS, persona, …) + capability chips (chat, sight, hearing, tts, persona, imaging, video, music, …).

Loads About JSON catalogues + on-disk models under `%ANIKAI_HOME%`.

### Runtime probes

**UI:** Settings → Device → Software → **Check runtimes** (same panel flow).

**Code:** `main-process/sentience-runtime-probe.js` → `main.js` `buildRuntimesReport()` — probes e.g. `gguf.asr`, `voice.espeak`, `voice.onnx`, `voice.piper` under `desktop-data/runtime-packs/`.

Honest rows: installed / missing / path — no fake “ready” without binaries.

### Multi-window shell

| Piece | Behavior | Code |
|-------|----------|------|
| Chat + dock | Separate HWNDs; **coupled drag** (chat header or dock grip); frozen **layout offset** (~136px Win) — not bloated HWND width | `main.js` `syncChatChromeLayout()`, `cluster-drag:*` IPC, `dockLayoutOffsetPx` |
| **Cluster layout debug** | Terminal lines prefixed `[anikai-cluster]` when `ANIKAI_CLUSTER_DEBUG=1` | `npm run dev:cluster-debug` or `$env:ANIKAI_CLUSTER_DEBUG="1"; npm run dev` — legend prints on startup with `npm run dev` |
| Panels | Independent windows; open L/R by space | `computePanelOrigin()` |
| **Project tree M0** | Thin **left rail** on chat (folder toggle) → **Project** HWND magnetized left of chat; global project registry + per-thread tree UI state | `components/workspace-tree.js`, `main-process/projects-registry.js`, `thread-workspace-state.js` |
| Z-order | Focus chat → chat above inactive panels; no `parent:` on panels | `raiseAnikaiFloatingZOrder()` |
| Panel snap on chat move | **Removed** — opt-in magnets only | was `syncOpenPanelPositions` |
| **Drag-magnet M0** | Drag Settings/Models (etc.) onto chat edge → follow chat move; drag satellite away → unlink | `main-process/window-magnet-registry.js`, `main.js` `syncMagnetFollowers`, `attachPanelMagnetHandlers` |
| Workspace tree satellite | Built-in magnet left of chat; dock inset | `syncWorkspacePanelPosition()` |
| Detached companion | Magnet re-dock on chat header | `chat.js`, `renderer.js` |

**Doc:** [`desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md) — M1: shared placement math, chat anchor ring; M2: panel→panel chains.

### Companion chat (mind)

| Piece | Status | Doc |
|-------|--------|-----|
| Segment loop (`<tool/>`, `<done/>`, clarify) | Shipping | [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) |
| Gemma 4 `<\|channel\|>thought` / `final` | Shipping | `shared/gguf-output-templates/gemma4-channels.js` |
| Skills / capability map | Shipping | `main-process/companion-skills.js` |
| Conversation paths UI | Surfaced | [`runtime-shape/CONVERSATION_PATHS_AND_THOUGHT_ROUTING.md`](../runtime-shape/CONVERSATION_PATHS_AND_THOUGHT_ROUTING.md) |
| Workforce handoffs / media W5a | In progress | [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](WORKFORCE_AND_ORCHESTRATION_VISION.md) |

### Audio / music (workshop lanes)

| Lane | What | Status | Doc |
|------|------|--------|-----|
| **1** | Parametric DSP → WAV | In progress | [`generation/audio/AUDIO_GENERATION_LANES_OVERVIEW.md`](../generation/audio/AUDIO_GENERATION_LANES_OVERVIEW.md) |
| **2** | MIDI + FluidR3 → WAV | In progress | [`generation/audio/MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md`](../generation/audio/MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md) |
| **3+** | Neural / GGUF music | Planned | [`generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](../generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md) |

Chat tools / Media Magic wiring: `TODO_GGUF_MUSIC_DESKTOP.md`.

### Imaging / video

| Topic | Doc |
|-------|-----|
| Imaging index | [`generation/imaging/IMAGING_GENERATION_INDEX.md`](../generation/imaging/IMAGING_GENERATION_INDEX.md) |
| Runtime packs | [`runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) |

### PersonaLive (motion-sense rig test)

| Piece | Status | Code / path |
|-------|--------|-------------|
| About registries | **PYTHON** format id; Motion-sense tables | `assets/about-guide/video-registry.json` |
| **Download PersonaLive** | Weights only (~15 GB HF) → `models/personalive/pretrained_weights/`; auto-links to engine | `config/personalive-pack-registry.json`, `personalive-bootstrap.js` |
| **Bundled runtime** | `personalive-runtime/` (engine + venv) ships in installer — like `media-python-runtime` | `resources/personalive-runtime/`, `npm run stage-personalive` |
| **Run rig** | Neural `inference_offline.py` when ready; else ffmpeg PIP preview | `personalive-rig.js`, Media Magic rig tab |
| Chat prefs (future FaceTime) | ⋮ menu **PersonaLive** toggle per companion | `chat.js` → `ui.chat.companionLive` |

**User flow:** **Download PersonaLive** (once) → **Run rig** (reference still + driving video). No separate bootstrap button; no Git/pip for end users.

**Docs:** [`generation/imaging/python/models/MODEL_PERSONALIVE.md`](../generation/imaging/python/models/MODEL_PERSONALIVE.md) · [`engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Not yet:** optional ONNX/TRT in download tier; streaming / companion FaceTime.

### Project workspace tree (M0 shipped)

Left rail on chat → **Project** satellite HWND (magnet-linked); global `projects/registry.json`; per-thread `thread-workspace/*.json`. **Not** the same as drag-magnet Settings/Models clusters.

**Canonical:** [`../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md`](../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md)

---

## Workshop log / Anikai Terminal

**Living spec (extend here):** [`../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md`](../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md)

**npm dev catalog:** [`../../../../../../anikai-desktop/npm/README.md`](../../../../../../anikai-desktop/npm/README.md)

**Today:** `npm run dev:cluster-debug` · **Next (small):** chat ≡ → **Workshop Terminal** · **End-game:** PowerShell PTY + in-app **Run** for catalogued npm scripts

**Not the same as:** activity dock (one status line) · Settings **Check runtimes** · pack `appendLog` files on disk.

---

## Planned next (documented, not one blob)

| Initiative | Overview doc | Todo |
|------------|--------------|------|
| **Workshop log / Terminal** | [`../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md`](../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md) | M0 bus → M1 chat ≡ panel → M2 Overseer |
| **Familiars (reflex F1–F7)** | [`execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md`](execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md) · [`FAMILIAR_ROLES.md`](execution-agent/Familiars/FAMILIAR_ROLES.md) | [`TODO_FAMILIARS_REFLEX_DESKTOP.md`](../../todo/mid-scope/TODO_FAMILIARS_REFLEX_DESKTOP.md) |
| **Roles index** (manager, specialty, session role) | [`execution-agent/ROLES_INDEX.md`](execution-agent/ROLES_INDEX.md) · [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) | — |
| **Project workspace tree** | [`../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md`](../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md) | [`TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md`](../../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md) |
| **Drag-magnet panels (M0 shipped)** | [`MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md) | same todo (M1+) |
| **Execution agent (sandbox → agentic → team)** | [`execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md) | [`TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md) |
| **E+ multi-resident** | [`engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Group chat todo |
| **Screen copilot** | [`DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](DESKTOP_COPILOT_AND_SCREEN_AGENT.md) | After E+ + voice |
| **Group mate network** | [`group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) | [`TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md`](../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md) |
| **Motion-sense engines** | About → Sentience → Motion-sense tables · PersonaLive primary | [`TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md`](../../todo/mid-scope/TODO_MOTION_SENTIENCE_ENGINES_DESKTOP.md) |

---

## Execution agent — how it fits the workshop

Not a separate product — it **extends** the segment loop with safe PC access:

| Track | Adds | Phase |
|-------|------|-------|
| **A Sandbox** | Workspace root, HITL shell, shadow diff, SEARCH/REPLACE | P0–P1 |
| **B Agentic memory** | Scratchpad, TODO, context roller, journal | P2–P4 |
| **C Team blackboard** | Parallel small models, Freeze & Approve, DAG | P5–P6 (needs E+) |
| **D Copilot** | Screen see/act — shared validator with A | P7 |

Detail: [`execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md`](execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md), [`AGENTIC_CONTROL_LOOP_AND_PERSISTENT_MEMORY.md`](execution-agent/AGENTIC_CONTROL_LOOP_AND_PERSISTENT_MEMORY.md), [`TEAM_BLACKBOARD_ORCHESTRATION.md`](execution-agent/TEAM_BLACKBOARD_ORCHESTRATION.md).

---

## Recommended read order

**New to the desktop lane**

1. [`WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)
2. This page
3. [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md)
4. [`RUNTIME_PACKS_AND_INSTALLER.md`](../runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md)

**Trust / models / “what can I install?”**

1. About Sentience tabs (in app) + registry JSON list above
2. [`MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)
3. Android slot schema (reference only)

**Media workshop**

1. [`AUDIO_GENERATION_LANES_OVERVIEW.md`](../generation/audio/AUDIO_GENERATION_LANES_OVERVIEW.md)
2. Active lane plan (MIDI or GGUF music todo)

**Power-user workspace**

1. [`PROJECT_WORKSPACE_TREE.md`](../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md) (tree M0 shipped)
2. Magnet overview → implementation plan (drag-magnet — planned)
3. Execution architecture overview → sandbox doc

**Building / closing loops**

1. [`operations/OPERATIONS_INDEX.md`](../operations/OPERATIONS_INDEX.md)
2. Matching `todo/mid-scope/TODO_*.md`

---

## Key code paths (quick)

| Concern | Path |
|---------|------|
| About UI | `anikai-desktop/components/about-guide.js` |
| Registry table | `anikai-desktop/components/panels.js` |
| Registry merge | `anikai-desktop/shared/anikai-registry-catalog.js` |
| Runtime report | `anikai-desktop/main-process/sentience-runtime-probe.js`, `main.js` |
| Chat turn | `anikai-desktop/components/chat.js` (`runGgufThoughtTurn`) |
| Completion | `anikai-desktop/main-process/gguf-completion.js` |
| Window policy | `anikai-desktop/main.js` |
| Project tree | `anikai-desktop/components/workspace-tree.js`, `main-process/projects-registry.js` |
| PersonaLive rig | `anikai-desktop/main-process/personalive-rig.js`, `personalive-bootstrap.js` |
| Music handoff | `anikai-desktop/main-process/generate-music-handoff.js`, `midi-composer.js`, `parametric-wav-composer.js` |

---

## What this doc is not

- **Not** a replacement for per-lane implementation plans (GGUF text, imaging, music, group chat).
- **Not** a commit log — use git + todo checkboxes for slice completion.
- **Not** Android UX spec — handover docs stay on the arm64 lane.

Update this page when a **user-visible workshop capability** lands (new About tab, registry bucket, lane ship, shell behavior).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial workshop state index: Sentience catalogues, registry, probes, shell fixes, magnets + execution-agent pointers, audio lanes. |
| 2026-05-20 | PersonaLive bootstrap + rig test wiring; project workspace tree M0 (global registry, per-thread state, magnet panel, chat left rail). |
| 2026-05-20 | Drag-magnet M0: panel→chat link table, follow on chat move, detach on satellite drag; `smoke-magnet-panels.cjs`. |
| 2026-05-20 | PersonaLive **full HF download** (huaichang/PersonaLive `*.pth` + sidecars), engine link + venv bootstrap, docs aligned to upstream `pretrained_weights/` layout. |
| 2026-05-20 | PersonaLive **bundled runtime** (`personalive-runtime/` like media-python); single **Download PersonaLive** button links weights after fetch — no user Git/pip. |
| 2026-05-20 | Doc tighten: [`WINDOWS_DESKTOP_INDEX.md`](../WINDOWS_DESKTOP_INDEX.md); Familiars F1–F7 + project tree M0 indexed. |
| 2026-05-22 | [`../the-terminal/`](../the-terminal/) living spec + `anikai-desktop/npm/` script catalog for Workshop Terminal. |
