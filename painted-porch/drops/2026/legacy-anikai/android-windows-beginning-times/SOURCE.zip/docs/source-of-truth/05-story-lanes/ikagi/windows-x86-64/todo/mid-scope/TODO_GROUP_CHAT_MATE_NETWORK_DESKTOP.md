# TODO — Group chat & mate network (Windows desktop, mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-15 |

---

## Source implementation docs

- [`../../implementations/companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../../implementations/companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md)
- [`../../implementations/operations/OPERATIONS_INDEX.md`](../../implementations/operations/OPERATIONS_INDEX.md)
- [`../../implementations/generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../../implementations/generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md)

---

## Intent

Ship **multi-companion group discussion** on Anikai Desktop: round-robin turns, `@solo` mentions, **focus roles** with per-companion context caps, **living plan MD** (note-taker), and **global multi-model residency** with RAM/VRAM guards—building on the existing GGUF + thought-stream solo path.

---

## Phase A — Roles & context policy

- [x] Extend companion JSON: `groupRole`, `contextPolicy`, `inferencePolicy`
- [x] Companion editor: group focus role dropdown + cap hint
- [x] `buildGroupTurnPrompt` in `gguf-prompt-shaper.js`
- [x] Group vs solo sliding history defaults in user settings (General tab)
- [x] Align planning pass `-c` with conversation pass (Gemma 8192)

## Phase B — `@mention` solo

- [x] Parse `@DisplayName` / `@id` in composer
- [x] Solo infer path (skip round queue)
- [x] Member autocomplete in group threads

## Phase C — Group round-robin (chat-only)

- [ ] `group-threads/` on-disk layout + thread CRUD
- [ ] Turn order: creation (default) + alphabetical setting
- [ ] Sequential turns + IPC stream events
- [ ] Round partial transcript per speaker
- [ ] End-of-cycle UI (no plan write yet)
- [ ] Missing note-taker banner

## Phase D — Plan focus & note-taker

- [ ] `plan/draft.md` + focus block in prompts
- [ ] Lock plan → revision + anchor refresh
- [ ] Note-taker dedicated infer pass
- [ ] Optional chair summary
- [ ] Session rollover spike (note-taker only)

## Phase E — Global multi-resident inference

- [ ] Settings: single vs multi, max N, idle unload
- [ ] RAM / VRAM guard thresholds
- [ ] Residency manager + LRU eviction
- [ ] Queue UI when model cold or blocked

## Phase F — Later

- [ ] Persona packs (Android shaper parity)
- [ ] Archivist retrieval
- [ ] Roaming / scheduled group turns

---

## Linked operations

- [`../../implementations/operations/OPERATIONS_INDEX.md`](../../implementations/operations/OPERATIONS_INDEX.md)
- [`TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](TODO_GGUF_TEXT_GENERATION_DESKTOP.md)
- [`TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-15 | Created mid-scope todo; phases A–F mirror parent implementation plan. |
