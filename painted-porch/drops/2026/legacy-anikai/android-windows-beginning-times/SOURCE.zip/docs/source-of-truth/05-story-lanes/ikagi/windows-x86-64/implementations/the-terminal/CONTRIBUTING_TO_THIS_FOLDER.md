# Contributing to The Terminal docs

This folder is **intentionally open-ended**. Users, companions (via chat), and developers may propose additions here before code exists.

---

## What to edit

| File | Add when you… |
|------|----------------|
| [`ANIKAI_TERMINAL_LIVING_SPEC.md`](ANIKAI_TERMINAL_LIVING_SPEC.md) | Change vision, phases, log domains, Overseer rules, UI placement |
| [`npm/README.md`](npm/README.md) | Dev checks hub, runbook, regression guardrails |
| [`anikai-desktop/npm/README.md`](../../../../../../../anikai-desktop/npm/README.md) | Add or document an `npm run …` script |
| [`anikai-desktop/npm/scripts-registry.json`](../../../../../../../anikai-desktop/npm/scripts-registry.json) | Canonical machine-readable row; mirror in [`npm/scripts-registry.json`](npm/scripts-registry.json) |
| [`DESKTOP_WORKSHOP_STATE.md`](../anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md) | Only a **one-paragraph** pointer + link here (avoid duplicating the full spec) |

---

## Adding an npm script (checklist)

1. Implement under `anikai-desktop/scripts/<name>.cjs` (or justified subfolder).
2. Register in `anikai-desktop/package.json` → `"scripts"`.
3. Add a row to `anikai-desktop/npm/README.md` (human) and `scripts-registry.json` (machine); sync mirror under `the-terminal/npm/scripts-registry.json` and runbook if the script is a dev check.
4. Set `terminalVisible: true` if the Workshop Terminal should offer a **Run** button later.
5. Add a line to **Changelog** in `ANIKAI_TERMINAL_LIVING_SPEC.md` (date + one sentence).

---

## Adding a log domain (checklist)

1. Pick `domain` id: `hw`, `infer.gguf`, `shell`, … (see living spec table).
2. Document **who emits** (main-process file) and **example line**.
3. Note default **level** (`debug` | `info` | `warn` | `error`).
4. Say whether **Overseer** may include it in default snapshots.

---

## AI agents

When implementing terminal-related code:

- Read **`ANIKAI_TERMINAL_LIVING_SPEC.md`** phases — do not ship PowerShell PTY before M0/M1 unless explicitly requested.
- Prefer `workshopLog.emit()` over new ad-hoc `console.log` prefixes.
- Link PRs to the spec changelog row.

---

## Users / designers

Open an issue or append to **Open questions** in the living spec:

- Filter labels you need (plain English).
- Whether a control belongs in chat ≡ menu vs Settings vs dock.

No code required to contribute ideas here.
