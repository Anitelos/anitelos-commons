# Model sheet — unsloth / ERNIE-Image-Turbo-GGUF

| Field | Value |
|-------|-------|
| **Pack family** | `flux2_llm_vae` |
| **HF DiT** | [unsloth/ERNIE-Image-Turbo-GGUF](https://huggingface.co/unsloth/ERNIE-Image-Turbo-GGUF) |
| **LLM (sd.exe)** | [Comfy-Org/ERNIE-Image `text_encoders/ministral-3-3b.safetensors`](https://huggingface.co/Comfy-Org/ERNIE-Image/tree/main/text_encoders) |
| **VAE** | [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae) → `flux2_ae.safetensors` |

**Get pack (3 roles):** Turbo DiT `.gguf` in `models/ernie-image-turbo-unsloth/` + shared `vae/flux2_ae.safetensors` + shared `ministral-3-3b.safetensors`.

Baidu `text_encoder/model.safetensors` is **not** the sd.cpp LLM — do not use it as `--llm`.

**Defaults:** 1024², 8 steps, cfg 1 · sd.cpp: [`ernie_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/ernie_image.md)
