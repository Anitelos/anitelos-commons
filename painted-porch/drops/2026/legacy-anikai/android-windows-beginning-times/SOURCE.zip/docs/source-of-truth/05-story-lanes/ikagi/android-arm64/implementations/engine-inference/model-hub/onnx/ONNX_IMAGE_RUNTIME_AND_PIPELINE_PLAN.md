# ONNX image runtime and pipeline plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Purpose: isolate the ONNX plan from `LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md` so ONNX decisions are readable as one implementation contract, not scattered through one mega-log.

---

## Scope

This file covers ONNX for:

- engine inference ownership and adapter boundaries,
- generation roles (primary vs post-pass),
- Sprite Maker / sheet flow integration,
- pipeline DAG placement and gates.

This file does **not** replace:

- visual quality contract (`SPRITE_QUALITY_FLOOR.md`),
- portrait slot and pack contracts (`PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`, `PORTRAIT_PACK_SCHEMA.md`),
- global anti-drift execution log (`LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`).

---

## ONNX role model (single truth)

| Role | ONNX ownership |
|------|-----------------|
| **Primary generation (S1/S2)** | Allowed when ANIKAI ships a validated fixed-shape ORT graph (txt2img/img2img) behind a named adapter id. |
| **Post generation (S3/S4)** | Preferred: upscale/restore/detail graphs after primary bytes exist. |
| **Packaging (S5/S6)** | Not ONNX by default; app packer + optional ONNX helper where justified. |

Rule: file-on-disk is not enough. ONNX is active only when adapter + manifest + session init succeed.

---

## Engine inference plan (ONNX lane)

1. **Adapter registration**
   - register ONNX adapter ids in the local image registry,
   - bind each id to explicit graph manifest metadata.
2. **Manifest schema (minimum)**
   - opset range,
   - input tensor shape contract,
   - output tensor contract,
   - quant/fp precision flags,
   - recommended preset lane (`FAST`/`BALANCED`/`QUALITY`).
3. **Runtime guards**
   - reject graph when shape/opset mismatch,
   - expose visible fail reason (not silent fallback masquerading as success),
   - gate heavy profiles by device class/thermal policy.

---

## Generation plan (Sprite/Creations)

### A) Primary ONNX path (optional but supported)

- Use one curated ORT primary graph for `FAST`/`BALANCED` if device fit allows.
- Keep prompt logic in one place; swap runner, not prompt architecture.
- If primary ONNX is not yet valid on device, preserve ONNX as post-pass-only role.

### B) Post-pass ONNX path (required for QUALITY stack)

- Chain at least one sharpen/upscale graph after primary bytes.
- Validate each graph with small conformance tests before exposing QUALITY.
- Keep post chain in pipeline metadata so one-button flows stay deterministic.

---

## Sprite Maker / sheet integration

For Sprite Maker one-button operation:

1. Generate facing stills via primary adapter (JNI diffusion or ONNX primary when valid).
2. Apply ONNX post-pass chain for QUALITY.
3. Write outputs + metadata with runtime id and preset trail.
4. Continue to strip/sheet staging.

Operational pass condition (current direction):

- valid picture output from at least one accepted primary path,
- ONNX post-pass available for QUALITY lane,
- Swarm pipeline invokes the same adapter registry.

---

## Pipeline mapping (aligned to imaging stack)

| Stage | ONNX expectation |
|-------|-------------------|
| **S1/S2 primary + consistency** | Optional ONNX primary if validated export exists. |
| **S3 sharpen/upscale** | Core ONNX responsibility. |
| **S4 palette/outline unify** | ONNX optional; CPU fallback allowed with explicit labeling. |
| **S5/S6 pack + frame animation prep** | Mostly app pipeline; ONNX helper only if justified. |

Primary reference for stage semantics:
`implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`

---

## Open decisions (keep visible)

- whether first ship-quality primary path is ONNX-first or JNI-diffusion-first,
- minimum graph set for QUALITY before labeling as operational,
- device gating policy for heavy ONNX models.

---

## Linked todos

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`

---

## Related engine plans

- Motion-specific ONNX (Qualcomm FOMM detector/generator): [`../fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Cross-link to FOMM engine inference plan (motion ONNX distinct from generic SR adapter). |
| 2026-05-06 | Initial ONNX runtime + pipeline split from local media mega-log. |
