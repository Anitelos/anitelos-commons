# Model sheet — SDXL anime · Illustrious ecosystem (GGUF)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Shipped (select stacks) |
| **Last reviewed** | 2026-06-05 |

## Summary

**Illustrious XL** and its popular merges (NoobAI, WAI-Illustrious, Hassaku, …) are **SDXL-architecture** checkpoints. In Anikai they route through the same engine path as generic SDXL: **`sdxl_single_m`** + **`sd.exe`**.

**Pony Diffusion** is a separate SDXL anime ecosystem with its own LoRA library — **not catalogued** in Anikai’s Get pack list (users may still sideload; we do not promote it).

**Animagine XL** is another SDXL anime line (retrained from SDXL 1.0) with **its own LoRAs** — listed separately.

## Pack family

`sdxl_single_m` — [`MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md`](./MODEL_GGUF_FAMILY_SDXL_SINGLE_FILE.md)

## Catalogue stacks (imaging-registry)

| Stack id | Role | Get pack |
|----------|------|----------|
| `illustrious-xl-v2-gguf` | OnomaAI Illustrious XL v2 base | Shipped |
| `noobai-xl-vpred-gguf` | Illustrious-derived character knowledge | Shipped |
| `illustrious-calcuis-gguf` | VRAM-friendly quants (calcuis) | Shipped |
| `wai-illustrious-gguf` | Illustrious merge | Planned sideload |
| `hassaku-xl-illustrious-gguf` | Illustrious merge | Planned sideload |
| `animagine-xl-4` | Separate SDXL anime ecosystem | Planned |

## LoRAs (CivitAI)

1. Pick a **checkpoint** from the Illustrious family above.
2. Download LoRAs whose **Base model** tag matches (**Illustrious**, not Pony).
3. Place weights under `models/loras/` with optional sidecar:

```json
{
  "label": "My style LoRA",
  "baseModelStackId": "sdxl-illustrious-ecosystem",
  "formats": ["safetensors"]
}
```

4. Enable in Media Magic → Image LoRAs when your main model is an Illustrious-family GGUF.

LoRAs trained on **vanilla SDXL 1.0** may load but often look wrong on Illustrious. LoRAs trained on **Pony** will not transfer.

## Prompting (typical)

- Quality: `masterpiece, best quality, …`
- Resolution: 1024×1024 or aspect presets (~1216×832) per model card
- Sampler: Euler a · CFG ~5–7 (Illustrious v2 card)

## FHDR / FLUX note

**FHDR** remains the catalogue’s painterly FLUX finetune (separate family `flux1_clip_t5`). It is not part of the Illustrious LoRA ecosystem.

## Checklist

- [x] Router: illustrious / noobai / hassaku / animagine → `sdxl_single_m`
- [x] Imaging registry stacks + Get pack (Illustrious v2, NoobAI, calcuis)
- [ ] E2E smoke on RTX-class GPU for each shipped stack
- [ ] Animagine GGUF Get pack when stable quant is chosen

## Links

- [OnomaAI Illustrious XL v2](https://huggingface.co/OnomaAIResearch/Illustrious-XL-v2.0)
- [btaskel Illustrious GGUF](https://huggingface.co/btaskel/Illustrious-XL-v2.0-GGUF)
- [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)

---

## Changelog

| Date | Note |
|------|------|
| 2026-06-05 | Initial sheet — Illustrious family catalogue; Pony excluded from promotion. |
