# Model sheet — Stable Diffusion 3.5 Large (GGUF / safetensors)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Shipped (router) |
| **Last reviewed** | 2026-05-18 |

## HF

- Base: [stabilityai/stable-diffusion-3.5-large](https://huggingface.co/stabilityai/stable-diffusion-3.5-large)  
- Encoders: [Comfy-Org/stable-diffusion-3.5-fp8](https://huggingface.co/Comfy-Org/stable-diffusion-3.5-fp8)  
- sd.cpp: [`sd3.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/sd3.md)  

## Pack family

`sd3_clip_stack`

## Product

- **Preset id:** `sd35_large_gguf`  
- **Profile (proposal):** `sd35_large` — 1024², cfg 4.5  

## Anikai router

`shipped` — shared with SD3 medium; detect `sd3.5` in basename.

## Checklist

- [x] Router + probe  
- [ ] E2E smoke (your GPU)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
