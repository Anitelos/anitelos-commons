# TODO — NCNN engine inference integration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Track NCNN as a native engine family with explicit JNI/runtime ownership.
- Move NCNN mentions from backlog text into staged implementation work.
- Keep Vulkan/CPU policy and Swarm integration rules visible and testable.

---

## Checklist (working)

- [ ] Finalize NCNN packaging strategy (native libs + model assets + ABI matrix).
- [ ] Implement NCNN JNI bridge and adapter registration.
- [ ] Deliver first operational NCNN helper lane with artifact output validation.
- [ ] Define Vulkan preferred path and CPU fallback policy by device class.
- [ ] Bind one specialist lane to NCNN adapter with explicit fail/degraded states.
- [ ] Validate lifecycle cleanup and repeated-run stability.

---

## Linked operations

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through inference maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created NCNN engine inference integration todo during model-family split pass. |
