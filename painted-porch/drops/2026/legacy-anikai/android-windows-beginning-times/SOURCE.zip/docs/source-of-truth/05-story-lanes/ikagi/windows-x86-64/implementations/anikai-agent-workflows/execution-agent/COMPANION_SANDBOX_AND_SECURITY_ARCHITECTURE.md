# Companion sandbox & security architecture (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Overview:** [`COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](./COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md)

**Todo:** [`../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md) (Track A slices)

**Workspace root (shipped):** [`../../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md`](../../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md)

**Promoted from:** `companion_sandbox_security_architecture.md` (Antigravity brain export).

---

## Goal

Allow the companion to **read/write files** and **run terminal commands** on the user’s PC without compromising system integrity or losing work when the model **truncates** mid-edit.

---

## 1. System risks & threat modeling

Giving an AI companion direct access to execute shell commands, read/write files, and interact with external systems introduces significant risks.

```mermaid
graph TD
    A[LLM / segment loop] -->|tool actions| B[Execution engine]
    B -->|shell| C[Host OS]
    B -->|files| D[Workspace tree — see PROJECT_WORKSPACE_TREE.md]

    style C fill:#ffcccc,stroke:#ff0000,stroke-width:2px
    style D fill:#ffe6cc,stroke:#d79b00,stroke-width:2px
```

### Key hazards

| Risk | Threat | Local impact |
|------|--------|--------------|
| **Destructive commands** | `rm -rf`, format, kill system processes | Data loss, OS damage |
| **Indirect prompt injection** | Malicious instructions inside read files, commits, web fetches | Hijacked tool runs |
| **Data exfiltration** | Read `.env`, SSH keys, send off-machine | Credential theft |
| **Resource exhaustion** | Infinite loops, huge writes, process storms | Lockups, disk full |

**Anikai stance:** Local-first desktop — exfiltration risk is still real if we add **any** network tool without policy; default deny outbound from execution engine until explicitly designed.

---

## 2. Safety patterns (baseline)

Patterns from Cursor-class agents, adapted for **local Electron**:

### A. Human-in-the-loop (HITL)

- **No silent shell** except an allowlisted read-only set (e.g. `node -v`, `git status`) configured per workspace.
- UI shows: **command**, **cwd**, **why** (companion explanation from thought/tool metadata).
- User: Approve once / Approve session / Deny.

### B. Workspace boundary (sandbox)

| Control | Behavior |
|---------|----------|
| **Root lock** | Resolve all paths under `workspaceRoot`; reject `..` escapes and `C:\Windows`, `%AppData%`, etc. |
| **Allow file** | Optional `.anikai/workspace.json` declares root + extra allowed roots |
| **Virtualization (later)** | Docker / restricted user / Firecracker-class — **not** P0; document as P7+ |

### C. Prompt guardrails

System + behavior contract: never access paths outside workspace; refuse destructive patterns even if user message asks.

**Implementation home:** extend `behavior-contract.js` + skill registry — not a second prompt stack.

---

## 3. Shadow staging (“shadow & bake”)

**Problem:** Truncation or crash while writing live files corrupts the repo.

**Pattern:** Never write production files until user bakes.

```mermaid
sequenceDiagram
    autonumber
    participant LLM as Companion
    participant Stage as Shadow stager
    participant Diff as Diff UI
    participant Live as Live file

    LLM->>Stage: Proposed content
    Stage->>Diff: Unified diff
    Note over Diff: User reviews
    Diff->>Live: Bake on accept
    Stage->>Stage: Cleanup temp
```

### Pipeline (Anikai)

1. **Write to staging** — `.anikai/staging/<hash>/` mirror or in-memory buffer keyed by target path.
2. **Compute patch** — unified diff vs live file.
3. **UI review** — side-by-side diff (VS Code–class); link from chat tool result card.
4. **Bake** — atomic replace on accept; rollback pointer kept until next successful bake.

**Truncation safety:** Only staging corrupts; live tree untouched.

**Pre-bake checks (optional P1+):** ESLint / `node --check` / language-specific syntax on staging copy.

---

## 4. Edit formats: SEARCH/REPLACE vs whole file

| Technique | Pros | Cons | Use when |
|-----------|------|------|----------|
| **Whole file** | Simple | Tokens, truncation on large files | New small files |
| **SEARCH/REPLACE blocks** | Fast, cheap | Ambiguous match breaks | Most edits |
| **AST refactor** | Safe syntax | Per-language cost | Later automation |

### Canonical block format (tool / thought output)

```text
<<<<<<< SEARCH
const oldCode = true;
=======
const newCode = true;
>>>>>>> REPLACE
```

**Applier rules:**

- Exact single match required; else return `ambiguous_match` / `not_found` to segment loop.
- Apply to **staging copy** first; diff UI shows result.
- Align with existing `<tool name="patch_file" …/>` vocabulary in [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) when added.

---

## 5. Workspace integration guidelines

1. **No blind shell strings** — `execFile` / argv arrays; never `shell: true` with model-generated strings.
2. **Git as safety net** — When repo present, user can `git diff` / discard; still use staging for non-git trees.
3. **Workspace locks** — Deny paths outside declared roots; log denials to thought-only diagnostics.

---

## Implementation slices (Track A)

| Slice | Deliverable |
|-------|-------------|
| **A0** | `workspaceRoot` + path validator; read-only `list_dir` / `read_file` skills |
| **A1** | HITL modal for `run_command` + allowlist |
| **A2** | Staging dir + diff IPC + bake transaction |
| **A3** | SEARCH/REPLACE parser + staging applier |
| **A4** | Injection heuristics on read text (warn in UI, optional strip) |

**Expected modules:** `main-process/workspace-sandbox.js`, `main-process/shadow-stager.js`, renderer diff panel (new or Playground-adjacent).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Promoted from Antigravity export; scoped slices A0–A4. |
