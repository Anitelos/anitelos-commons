# Model sheet — leejet / FLUX.2-klein-9B-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Complete |
| **Operations** | Shipped (GGUF E2E verified) |
| **Last reviewed** | 2026-05-20 |

## HF

- Repo: [leejet/FLUX.2-klein-9B-GGUF](https://huggingface.co/leejet/FLUX.2-klein-9B-GGUF)  
- Base: [black-forest-labs/FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B)  
- VAE (ungated): [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae)  
- LLM encoder (catalogue default): [unsloth/Qwen3-8B-GGUF](https://huggingface.co/unsloth/Qwen3-8B-GGUF) — same triple-pack role as Unsloth diffusion lineage  
- Unsloth quant sibling: [`MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](./MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md)  

## Pack family

`flux2_llm_vae` — Qwen3 **8B** LLM + FLUX.2 dev VAE + klein DiT GGUF (**not** FLUX.1 `clip_l` / `t5xxl` split-pack).

## Weight layout

```text
models/flux2-klein-9b-leejet/
  flux-2-klein-9b-Q4_0.gguf          # or leejet / Unsloth naming aliases
  vae/flux2_ae.safetensors
  text_encoders/qwen_3_8b-Q4_K_S.gguf   # Unsloth Qwen3-8B (Get pack default)
```

## Anikai router

**shipped** — `flux2_llm_vae` probe + CLI builder in `gguf-completion.js`; filename heuristics accept leejet `flux-2-klein-9b-*.gguf` and `FLUX.2-klein-9B-*.gguf` aliases. Catalogue stack: **`klein-9b-leejet`**.

## Product

- **Preset id:** `flux2_klein_9b_gguf_leejet`  
- **Profile:** `flux2_klein_9b_gguf` — ~4 steps, 1024², CFG 1.0 (klein / sd.cpp defaults)  

## Verification (2026-05-20)

- Media Magic **Text→Image** + **Image→Image** on author GPU with staged `sd.exe`, split triple-pack, and Qwen3-8B encoder beside the leejet diffusion GGUF.  
- About guide: router **shipped**; doc sheet **Complete**.

## Checklist

- [x] Smoke leejet file on staged `sd.exe`  
- [x] Lane index tick (leejet row; shares `flux2_llm_vae` family with Unsloth when either quant is green)  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- Family detail: [`MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](./MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md)  
- GGUF imaging: [`../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
| 2026-05-20 | Marked **Complete** — GGUF E2E verified (leejet diffusion + Unsloth Qwen3-8B encoder pack). |
