# GGUF engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Purpose: define GGUF runtime implementation inside ANIKAI as an engine family contract (text, multimodal understanding, and diffusion-native lane boundaries), with explicit Android/JNI build gates and honest capability routing.

---

## Scope

This file covers GGUF for:

- companion text/runtime lane implementation,
- multimodal understanding lane (`mmproj`-style projector sidecars),
- GGUF-bound native diffusion lane ownership boundaries (where applicable),
- runtime profile and capability manifest integration in app.

This file does **not** replace:

- generation quality contracts in `generation/imaging/`,
- pipeline choreography contracts in `pipelines/`,
- anti-drift runtime history in `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`.

---

## What GGUF is (in ANIKAI terms)

GGUF is a model container/runtime family most visible in ANIKAI through `llama.cpp` style bindings. It can power:

- primary text reasoning/chat lanes,
- multimodal input understanding when projector sidecars and runtime support exist,
- specialized decode lanes only when an adapter explicitly supports output type (for example native diffusion path attempts).

Rule: `.gguf` file presence is not execution. Runtime capability is only real after adapter + manifest + session init + successful output contract.

---

## Role model (single truth)

| GGUF lane | Ownership |
|-----------|-----------|
| **Companion text brain** | Core GGUF ownership when selected in runtime matrix. |
| **Companion multimodal understanding** | Allowed with required projector sidecars and capability flags (`vision_understanding`, `audio_understanding`). |
| **Generative image pixels** | Not automatic from text GGUF lane; requires explicit diffusion-capable adapter path (native/JNI) and output contract. |
| **Swarm specialist heavy jobs** | Allowed if Swarm lane binds explicit GGUF-capable adapter id and pass criteria. |

---

## Android implementation plan (runtime + JNI)

### 1) Session/runtime ownership

- keep GGUF runtime load path explicit in companion runtime selector,
- ensure one source of truth for load config (threads, context, batching, mmap/mlock/offload options),
- expose capability probe result to app logic (do not infer by model name).

### 2) Native/JNI checklist (required for non-trivial GGUF lanes)

- [ ] Native target(s) declared and ABI-gated in CMake.
- [ ] JNI bridge classes mapped to specific GGUF lane functions (chat, multimodal encode/decode, diffusion where enabled).
- [ ] Input/output contracts documented per bridge (tokens, embeddings, image bytes, structured JSON).
- [ ] Cancellation/teardown lifecycle stable (foreground stop, app backgrounding, thermal abort).
- [ ] Runtime errors mapped to visible app states (no "fake success" fallbacks).

### 3) Capability manifest contract

Each GGUF bundle row should declare:

- model id + adapter id,
- required sidecars (`mmproj` and equivalents),
- capability flags (`text_generation`, `vision_understanding`, `audio_understanding`, `diffusion_decode` if real),
- profile guardrails (memory floor, thread caps, offload hints),
- lane eligibility (companion primary, swarm callable, pipeline helper).

---

## App integration map

### A) Companion lane

- GGUF remains a first-class primary brain option in local-first runtime selection.
- Interruption and single-lane foreground policy follows live runtime spec.
- Capability flags control UI affordances (for example showing image-analysis attach path only when supported).

### B) Multimodal understanding lane

- Require sidecar availability check before enabling image/audio understanding claims.
- Route outputs as text/tool plans; do not conflate with generative media execution.
- Keep provider/model naming abstracted behind capabilities.

### C) Diffusion/native GGUF lane (current in-progress area)

- Keep diffusion path as explicit specialized adapter (separate from generic text chat lane).
- Declare pass only after canonical output decode path is validated on device and artifacts persist correctly.
- Integrate runtime tuning knobs from User Access only where native lane supports them.

### D) Swarm integration

- `text_to_image` / `image_to_image` or other specialist actions can bind GGUF adapters only when capability flag and pass criteria match.
- Failed adapter resolution must surface as explicit degraded/not-operational state.

---

## Phased delivery

### Phase 0 - baseline runtime hardening

- lock capability manifest schema for GGUF,
- align load config mapping and diagnostics for chat lane.

### Phase 1 - multimodal clarity

- enforce sidecar checks and capability-driven UI/routing,
- verify one stable image/audio understanding flow with honest labeling.

### Phase 2 - diffusion lane completion

- finalize canonical output decode contract for GGUF diffusion path,
- complete `IMAGE_TO_IMAGE` mode and lane-level verification gates,
- ensure Swarm uses same adapter registry pass/fail logic.

### Phase 3 - cross-engine parity

- keep GGUF tuning UX aligned with LiteRT/ONNX/other engine families,
- maintain consistent fallback transparency and thermal behavior.

---

## Verification gates (before "operational" claims)

- GGUF chat lane stable under repeated session start/stop.
- Capability flags and sidecar requirements are enforced (not optional).
- Any multimodal claim has an observed on-device success case and explicit failure path.
- GGUF diffusion claim requires successful PNG artifact output + readable persisted file + visible fail reason when not met.

---

## Linked generation/pipeline boundaries

- FLUX 1/2 graph/export and image-quality specifics belong in generation imaging plans.
- Multi-model sequence execution belongs in pipeline plans.
- This file governs GGUF engine implementation behavior and lane eligibility only.

---

## Open decisions

- first "operational" multimodal GGUF bundle target,
- minimum stable runtime profile presets by device class,
- hard gate policy for diffusion lane when decode contract is uncertain.

---

## Linked todos

- `todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`
- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial GGUF engine inference plan split from local media mega-log, including chat/multimodal/diffusion lane boundaries and JNI checklist. |
