# Dev checks runbook — power-user npm

Run from **`anikai-desktop/`** unless noted. Goal: catch **shell layout** and **runtime lane** regressions before they cost a day.

---

## Golden rule after UI glue changes

If you touched any of:

- `main.js` (chat/dock/panel bounds, sync, IPC)
- `components/dock.js`, `components/chat.js`, `components/panels.js`
- `styles/dock.css`, `styles/chat.css`, `styles/panels.css`
- `preload.js` cluster-drag or layout IPC

**Then:**

```bash
cd anikai-desktop
npm run dev:cluster-debug
```

Watch the OS terminal for `[anikai-cluster]` lines while you:

1. Drag the dock pill — chat should move with it; dock width should stay ~58px, not thousands.
2. Open/close magnet panels — trees should not grow unbounded.
3. Toggle chat collapse — dock should not vanish or jitter off-screen.

Set `ANIKAI_CLUSTER_DEBUG=1` manually if you already have Electron running another way.

---

## Daily dev

| Command | When |
|---------|------|
| `npm run dev` | Normal coding; prints `[anikai-shell]` legend once at startup |
| `npm run start` | Production-like (no `--dev` banner) |

---

## Headless smokes (fast, no windows)

Run before/after refactors that touch listed areas.

| Command | Touches | ~time |
|---------|---------|-------|
| `npm run smoke-magnet-panels` | `window-magnet-registry`, panel magnet math | seconds |
| `npm run smoke-onnx-imaging` | ONNX imaging operators / packs | minutes |
| `npm run smoke-midi-render` | FluidSynth MIDI → WAV | minutes |
| `npm run smoke-midi-composition` | MIDI composition lane | minutes |
| `npm run smoke-generate-music` | Music generation | minutes |
| `npm run smoke-generate-music-dsp` | DSP music lane | minutes |

**Layout day minimum:** `smoke-magnet-panels` + `dev:cluster-debug` manual pass.

---

## Runtime staging (installer / resources)

| Command | When |
|---------|------|
| `npm run stage-llama-runtime` | Before testing local GGUF / llama.cpp path |
| `npm run stage-media-python` | Media Python lane |
| `npm run stage-personalive` | PersonaLive bundle |
| `npm run stage-fluidsynth` / `stage-fluidr3-gm` | MIDI audio |
| `npm run stage-audio-midi` | Both audio stages |
| `npm run stage-runtimes` | Full bundle before `dist:full` |
| `npm run pack` | Unpacked build smoke |
| `npm run dist` | Windows installer |
| `npm run dist:full` | stage-runtimes + dist |

---

## Environment variables (manual overrides)

| Variable | Effect |
|----------|--------|
| `ANIKAI_CLUSTER_DEBUG=1` | `[anikai-cluster]` layout trace (dock width, chat sync, heal) |
| `ANIKAI_SIMPLE_STACK=1` | Disables always-on-top / z-order glue — isolate stacking bugs |

---

## Future: in-app Run (M1)

Workshop Terminal will load `scripts-registry.json` and offer **Run** with stdout in the workshop log (`domain=npm`). Until then, this runbook + OS terminal is the source of truth.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05-22 | Initial runbook; magnet-panels registered in package.json |
