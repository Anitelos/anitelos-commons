# Playground — node editor direction (Rete + Anikai graph)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Direction — implementation spikes next |
| **Last reviewed** | 2026-05-22 |
| **Status** | Phase 0–1 shipped; **Phase 2** imaging edit wires + Save graph in Playground |

**Purpose:** Lock the **Playground** vision — Anikai’s own node-based pipeline editor — without committing to the wrong third-party runtime or over-building storage. Media Magic stays the fast workshop; Playground is where graphs become **durable, reusable, and deep**.

**Parent vision:** [`../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)

**Related:**

| Topic | Doc |
|-------|-----|
| Record → list → replay (imaging) | [`./IMAGING_PIPELINE_RECORD_PLAYGROUND.md`](./IMAGING_PIPELINE_RECORD_PLAYGROUND.md) |
| Compose / Suno sources + edges | [`./COMPOSE_PIPELINE_SOURCES_AND_ROUTING.md`](./COMPOSE_PIPELINE_SOURCES_AND_ROUTING.md) |
| Curated examples | [`./CURATED_PIPELINES_INDEX.md`](./CURATED_PIPELINES_INDEX.md) · [`./CURATED_SUNO_CLONE_PIPELINE.md`](./CURATED_SUNO_CLONE_PIPELINE.md) |
| Engine readiness per stage | [`../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md`](../engine-inference/PIPELINE_ENGINE_DEPENDENCY_MATRIX.md) |
| Chat tools (generate without opening Media Magic) | [`../anikai-agent-workflows/`](../anikai-agent-workflows/) |
| Comfy vs curated lanes, expert toggles, UE metaphor | [`./COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md`](./COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md) |
| Terminal / workshop log (future graph nodes) | [`../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md`](../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md) |

---

## Two surfaces, one spine

| Surface | Role | Primary user moment |
|---------|------|---------------------|
| **Media Magic** | Fast, themed creation — one source + ref → many consistent assets (sprites, beds, cutscenes later). | “Make the next character in the same style.” |
| **Pipelines → Playground** | Durable graph — record, edit, name functions, rerun at scale. | “Run this pack on every NPC source folder.” |

**Record in Media Magic is secondary marketing for Playground**, not the main UX burden: users succeed in Media Magic first; **Record / Stop** proves the flow can be saved and replayed.

```text
Media Magic (generate) ──Record──► pipeline schema JSON
                                        │
Pipelines panel ◄── list ◄──────────────┘
       │
       ├─ Create pipeline  →  empty or template graph
       └─ Open Playground  →  graph view (simple ⟷ blueprint)
                │
                └─ Run  →  main-process runners (existing IPC)
```

**Chat** is already a thin spine (`generate_music`, `generate_image`, …). Playground does not replace chat; it **materializes** what chat improvised into a graph the user owns.

---

## North star (honest scope)

Long term, Playground should feel like **Unreal Blueprint depth for workshop work** — not only media:

- Wire **imaging, audio, voice, video, code, terminal, agent** steps on one canvas.
- **Subgraphs as named functions** — “Character sheet pack”, “Battle theme variation”, “Cutscene block”.
- **Simple view** (stepped story: 1, 2, 2a, 12b) and **blueprint view** (typed pins) — same graph, two densities ([`WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)).
- Optional **3D spatial graph** later (Z-axis, preview-in-node) — not required for first wow.

**Not in v1:** compile arbitrary graphs to shipping AAA game binaries in every language. That is **Layer 5 (targets)** — export nodes appear after Layer 1–4 are trustworthy.

---

## Why Rete (UI layer only)

After reviewing [awesome-node-editors](https://github.com/flowrails/awesome-node-editors) and alternatives:

| Library | Verdict |
|---------|---------|
| **Rete.js** | **Chosen for spikes** — typed sockets, plugin renderers, path to 3D plugins; framework-agnostic core. |
| React Flow | Strong 2D; good fallback if Rete integration cost is high. |
| LiteGraph / ComfyUI graph | Wrong product — Comfy execution model fights Anikai runners. |
| Drawflow | Too light for typed ports + subgraphs at scale. |
| Flume / built-in runtimes | Do not let the editor own execution. |

**Contract:**

1. **Rete** = pan/zoom, nodes, connections, selection, optional 3D view plugins.
2. **Anikai** = node definitions, port types, validation, serialize graph, **run** via existing main-process modules.
3. **Never** silently route graph execution to a library’s internal engine.

Reference: [Rete.js](https://retejs.org/) documentation for v2 plugin model.

---

## Architecture — five layers

Everything in one app works because layers stay separate:

```text
┌─────────────────────────────────────────────────────────────┐
│  L5 Targets (later) — export repo, CI, game pack, npm script │
├─────────────────────────────────────────────────────────────┤
│  L4 Runners — imaging-pipeline-runner, compose-*, suno-clone │
├─────────────────────────────────────────────────────────────┤
│  L3 Graph — nodes, edges, subgraphs, templates (JSON on disk)│
├─────────────────────────────────────────────────────────────┤
│  L2 Steps — registry: pre | main | post | lane4 | voice | …  │
├─────────────────────────────────────────────────────────────┤
│  L1 Artifacts — paths + handles under ANIKAI_HOME            │
└─────────────────────────────────────────────────────────────┘
         ▲                              ▲
         │                              │
   Runtime packs                   Model weights
   (ffmpeg, gguf, media-python)     (models/, HF Get pack)
```

### L1 — Artifacts (universal payloads)

Edges move **references**, not raw tensors in the UI thread.

| Type id | Example | Stored as |
|---------|---------|-----------|
| `image/png` | Hero still, mask | Path under `generated-media/` |
| `audio/wav` | Bed, voice stem | Path + optional `compare.json` |
| `text/plain` | Lyrics, plan JSON | String or file |
| `json/plan` | Suno S1 plan | `s1-plan.json` |
| `mesh/gltf` | Future 3D preview | Path (later) |
| `code/ref` | Future terminal node | Workspace path + range (later) |

Compose graph already uses `outputRef` / `inputSlot` ([`compose-pipeline-graph-schema.js`](../../../../../../../anikai-desktop/shared/compose-pipeline-graph-schema.js)). Playground v2 should **unify** imaging `steps[]` and compose `nodes[]` + `edges[]` into one schema family (versioned).

### L2 — Step registry

Each node `type` maps to:

- **Engine family** (gguf, diffusers, onnx, media-python, ffmpeg, agent-tool, …)
- **Runtime pack probes** (from `runtime-packs-registry.json`)
- **Live status** — `ready` | `partial` | `gap` | `planned` | `blocked` (see [`CURATED_SUNO_CLONE_PIPELINE.md`](./CURATED_SUNO_CLONE_PIPELINE.md))

Nodes with **gap** (e.g. Suno S3 singing) render but **run** emits disclaimer + skip — never Kokoro-as-singing.

### L3 — Graph document

On disk (today):

| Kind | Location |
|------|----------|
| Imaging linear + future graph | `ANIKAI_HOME/runtime/pipeline-schemas/` |
| Compose / Suno template | `compose-pipeline-graph-schema` + `assets/curated-pipelines/suno-clone-v1.json` |

Playground saves: `{ version, id, name, nodes[], edges[], subgraphs?, meta }`.

### L4 — Runners (already shipping)

Topological sort → call existing IPC. No rewrite of Lane 4, Kokoro, or `sd.exe` inside Rete.

### L5 — Targets (future)

Nodes that write `CMakeLists.txt`, run `npm run`, or open PRs — **after** media graphs feel inevitable.

---

## UI modes (same graph)

| Mode | Audience | Behavior |
|------|----------|----------|
| **Simple** | Indie creator, repeat content | Collapsed steps, plain-language inspector |
| **Blueprint** | Power user | Full pins, types, optional conditions |
| **3D canvas** (later) | Huge graphs + spatial memory | Rete 3D plugin or sidecar Three/WebGPU viewport |
| **2.5D** (later) | Layered depth between 2D and full 3D — primary UX target after 2D ships | CSS transforms / pseudo-isometric layout on Rete area, then WebGPU depth |

**View toolbar (shipped stub):** Pipelines Playground shows **2D** active; **2.5D** and **3D** disabled until layout plugins land.

**Step inspector:** purpose, connections, which runtime pack, link to About catalogue row.

---

## Phased delivery

| Phase | User-visible | Tech |
|-------|--------------|------|
| **0 — shipped** | Pipelines list, linear Run, Suno Phase 0, Media Magic Record | `imaging-pipeline-schema.js`, `pipelines-panel.js` |
| **1** | **Create pipeline** → read-only graph from saved JSON | Rete or minimal canvas; no edit wires yet |
| **2** | Edit connections, save, rerun; port validation errors | Rete 2.x in Playground panel (React island in Electron OK) |
| **3** | Subgraph → **function** node; templates (sprite pack, Suno) | Graph schema `subgraphs[]` |
| **4** | Chat patches graph (“add upscale after Kontext”) | Agent emits graph diff JSON |
| **5** | 3D view + preview-in-node (mesh/video frame) | Rete 3D plugin + Three/WebGPU sidecar |
| **6** | Terminal / code nodes | [`ANIKAI_TERMINAL_LIVING_SPEC.md`](../the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md) |

**Rete spike (Phase 1):** load one recorded imaging schema → render nodes for `pre` / `main` / `post` / `bake_save` → linear edges from `inputs.sourceId` / `maskFromStep` / `inputFromStep`.

---

## Pipelines panel UX (target)

```text
┌─ Pipelines ─────────────────────────────────────┐
│  [ Create pipeline ]  [ Open Playground ]       │
│  Curated — Suno-clone (run form)                │
│  ─────────────────────────────────────────────  │
│  Compose graphs                                 │
│  Imaging pipelines (from Record)                  │
└─────────────────────────────────────────────────┘
```

**Create pipeline** → new graph doc (blank or template) → switches main area to **Playground** (not a third app).

---

## Media Magic demos that sell Playground

| Story | Media Magic today | Playground tomorrow |
|-------|-------------------|---------------------|
| Game sprites | Image weaving + same ref/style | Graph: mask → Kontext → upscale → bake; rerun per character folder |
| Battle theme | Compose instrumental + voice preset | Graph: lyrics → Lane 4 → assembly; swap only prompt per fight |
| Cutscene block | Video weaving + shaders (scaffold) | Graph: plates + shader tracks → mux (ffmpeg pack) |

Theme consistency is the **product**; the graph is how studios **industrialize** it.

---

## Non-goals (v1 Playground)

| Non-goal | Why |
|----------|-----|
| Embed ComfyUI as editor + runtime | Second graph language; docs treat Comfy as weight lineage only |
| Neo4j / Pinecone / cloud object store as required | `ANIKAI_HOME` + JSON + files suffice until search/RAG nodes ship |
| Rete executes inference | VRAM and probes stay in main process |
| Replace Media Magic | Front door stays simple |
| Claim Suno-tier S3 until Lane 5 exists | **gap** on node, always |

---

## Downloadable runtimes (why one app is hard — and your edge)

Users install **packs when needed** (`pack.gguf`, `pack.media.anikai`, `pack.voice.espeak`, `pack.media.tools`, …) — see [`../runtime-shape/RUNTIME_PACKS_CATALOGUE.md`](../runtime-shape/RUNTIME_PACKS_CATALOGUE.md).

Playground nodes surface:

- **Probe state** on the node (OK / partial / blocked)
- **Stage script** link (`npm run stage-…`) in inspector
- **Get pack** for weights (HF flow)

That combination — **honest graph + optional runtimes + companion chat** — is why “one workshop app” is rare: incumbents split **IDE, Comfy, DAW, chat, and game engine**. You are merging **orchestration UX**, not every model into one binary.

You are not “late”; the category (**local-first, companion-native, pack-probed pipeline editor**) barely exists as a single product.

---

## Implementation checklist (Rete spike)

- [x] `npm run build:playground` → `components/playground-rete.bundle.js` (Rete 2 + React island)
- [x] `playground/graph-adapter.mjs` — imaging + compose → nodes/edges
- [x] `components/playground-panel.js` — mount bundle, view toolbar (2D / 2.5D / 3D stub)
- [x] **Create pipeline** + **Open Playground** in `pipelines-panel.js` (no `window.prompt` — Electron-safe)
- [x] Editable wires + **Save graph** for imaging (`exportActiveGraphModel` → `schemaFromImagingGraph`)
- [ ] Port type enum + connection validator (stricter Phase 2b)
- [ ] Node chrome: engine badge, status chip (`partial` / `gap`) from live probes
- [ ] Inspector panel: plain + technical tabs
- [ ] 2.5D layout mode
- [ ] 3D spatial view (Rete 3D plugin or Three sidecar)

Code anchors:

| Piece | Path |
|-------|------|
| Imaging schema | `anikai-desktop/shared/imaging-pipeline-schema.js` |
| Compose graph | `anikai-desktop/shared/compose-pipeline-graph-schema.js` |
| Store | `anikai-desktop/main-process/imaging-pipeline-store.js`, `compose-pipeline-store.js` |
| Run | `anikai-desktop/main-process/imaging-pipeline-runner.js` |
| Live status | `anikai-desktop/main-process/curated-pipeline-status.js` |
| Panel | `anikai-desktop/components/pipelines-panel.js` |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Phase 1 shipped: Rete read-only bundle, Create pipeline, Open Playground, 2D view toolbar |
| 2026-05-22 | Initial direction: Rete as UI layer, five-layer architecture, phases 0–6, Media Magic vs Playground |
