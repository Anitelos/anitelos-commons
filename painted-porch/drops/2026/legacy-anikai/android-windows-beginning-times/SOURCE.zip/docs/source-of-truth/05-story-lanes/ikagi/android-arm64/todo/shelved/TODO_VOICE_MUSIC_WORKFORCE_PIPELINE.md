# TODO — voice+music workforce pipeline (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

---

## Intent

- Turn existing music workforce specialist lanes into a real execution pipeline.
- Bridge music generation and voice output where needed for dynamic NPC/showcase paths.
- Keep this todo separate from generic voice-engine bring-up and generic imaging work.

---

## Checklist (working)

- [ ] Confirm current behavior from code and lock baseline (what is config-only vs executed).
- [ ] Define lane outputs for `music_generator`, `lyric_weaver`, `audio_stem_mixer` (artifact contracts).
- [ ] Route music requests through workforce pipeline when lane assignments are present.
- [ ] Add optional voice-over stage with `VoiceOrchestrator` and emotion/prosody controls.
- [ ] Persist metadata + provenance tags for each stage so replay/debug is deterministic.
- [ ] Add visible fallback policy (provider/fallback tone vs workforce path) with honest status labels.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created dedicated todo for mixed voice+music workforce pipeline implementation. |
