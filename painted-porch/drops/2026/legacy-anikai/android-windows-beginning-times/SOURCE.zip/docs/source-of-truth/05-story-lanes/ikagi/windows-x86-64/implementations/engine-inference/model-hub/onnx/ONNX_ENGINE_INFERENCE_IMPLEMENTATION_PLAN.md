# ONNX engine inference implementation plan (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-10 |

Purpose: define **ONNX Runtime** on Windows as a first-class **engine family** for graphs shipped as `.onnx` (and optional external weights), with explicit **execution provider** strategy (CPU, DirectML, optional CUDA where you choose to support it), **manifest** contracts, and clear boundaries vs **GGUF** text and **GGUF** diffusion where both exist.

**Android parity (imaging-heavy ONNX story):** [`../../../../../android-arm64/implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](../../../../../android-arm64/implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md)

**Model paths / import (desktop):** [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)

**Hub index (Windows):** [`../MODEL_HUB_INDEX.md`](../MODEL_HUB_INDEX.md)

---

## Scope

This file covers ONNX on Windows for:

- **Inference ownership:** session lifecycle, EP selection, tensor shape contracts, visible failures.
- **Primary tasks:** imaging graphs (txt2img / img2img / post-process), optional **vision** encoders, future **text** graphs if promoted under a separate generation doc.
- **Desktop integration:** where ONNX sits next to GGUF in the companion + panels story (registry, manifest, no silent fallback).

This file does **not** replace:

- per–modality **generation** product docs (`generation/imaging/IMAGING_GENERATION_INDEX.md`, `generation/imaging/models/…`, `generation/audio/…`),
- pixel-quality contracts (add under `generation/imaging/` when promoted),
- GGUF engine rules (see [`../gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)).

---

## Execution providers (Windows policy)

| EP | When to prefer | Risk |
|----|----------------|------|
| **CPU** | Baseline, widest compatibility | Latency / large graphs |
| **DirectML** | GPU acceleration on Windows without tying to one vendor’s CUDA stack | EP availability + driver variance |
| **CUDA** (optional) | When you explicitly ship a CUDA-enabled ORT build and manifest row allows it | Distribution + binary size |

Rule: **manifest declares allowed EPs**; runtime picks the best **allowed** EP after probe. Do not infer EP from filename.

---

## Task matrix (engine-level)

| Task id | Description | ONNX must declare |
|---------|-------------|-------------------|
| `image_primary` | Fixed-shape decode path producing raster bytes | `image_generation` + input/output tensor contract |
| `image_post` | Upscale / refine / restore on existing bytes | `image_postprocess` |
| `vision_encode` | Image → tensor features for downstream text (if used) | `vision_encoding` |
| `text_decode` (future) | Text graph via ORT | `text_generation` | Only when a Windows text plan exists and graph is validated |

---

## Manifest contract (minimum)

Each ONNX bundle row should include:

- `adapter_id`, `model_id`, file paths (`.onnx` + external data if split),
- **opset** range and **fixed** input shapes (or dynamic axes policy explicitly tested),
- **allowed_eps**: `["cpu"]` | `["cpu","dml"]` | …,
- **capabilities** aligned with the task matrix,
- **lanes** (companion helper, pipeline step, background job).

---

## Verification gates

- One **primary** imaging graph runs end-to-end on a reference Windows machine with declared EP.
- Shape mismatch → user-visible error, not blank output.
- Post graph chain documented in pipeline metadata when used for quality stacks (align intent with Android ONNX plan).

---

## Linked docs

| Topic | Path |
|-------|------|
| GGUF engine (Windows) | [`../gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| GGUF imaging (generation) | Lane index [`../../../generation/imaging/IMAGING_GENERATION_INDEX.md`](../../../generation/imaging/IMAGING_GENERATION_INDEX.md); GGUF lane [`../../../generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../../../generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) |

---

## Linked todos

| Todo | Path |
|------|------|
| ONNX engine desktop (Windows) | [`../../../../todo/mid-scope/TODO_ONNX_ENGINE_INFERENCE_DESKTOP.md`](../../../../todo/mid-scope/TODO_ONNX_ENGINE_INFERENCE_DESKTOP.md) |
| Local media / imaging pipeline (Android parity) | [`../../../../../android-arm64/todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`](../../../../../android-arm64/todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md) |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-10 | Initial Windows ONNX engine plan: EP policy, task matrix, manifest, links to Android ONNX imaging plan and GGUF imaging generation doc. |
