# Android arm64 runtime-generation matrix

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Purpose: one control-panel map for Android arm64 showing how **engine inference families**, **generation plans**, **pipeline contracts**, and **active todos** connect.

This matrix links to the active implementation lane currently living under:
`05-story-lanes/ikagi/android-arm64/`.

---

## 1) Engine inference families (how ANIKAI runs models)

| Engine family | Implementation doc | Primary use recommendation | Todo bridge | Status |
|---------------|--------------------|----------------------------|-------------|--------|
| **GGUF** | [`GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Companion text, multimodal understanding, scoped diffusion lane | [`TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md) | In progress |
| **ONNX** | [`ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md) | Primary/post generation runtime lane with strict graph contracts | [`TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md) | In progress |
| **LiteRT** | [`LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Lightweight helper and portable edge packs | [`TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **MediaPipe** | [`MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Real-time perception pipelines (segmentation/landmarks/gesture) | [`TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **NCNN** | [`NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Native/Vulkan helper inference and fast CV lanes | [`TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **ExecuTorch** | [`EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | PyTorch-first model intake on device | [`TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **MNN** | [`MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Wildcard runtime for difficult model/device combos | [`TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md) | Not started |
| **QNN/SNPE** | [`QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | Snapdragon NPU low-thermal acceleration lane | [`TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md) | Not started |

---

## 2) Generation imaging plans (what media outcomes we want)

| Generation track | Implementation doc | Use recommendation | Todo bridge | Status |
|------------------|--------------------|--------------------|-------------|--------|
| **FLUX generation** | [`FLUX_GENERATION_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md) | Flux 1 baseline, Flux 2 gated expansion, ONNX post chain | [`TODO_FLUX_GENERATION_IMAGING_PLAN.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_FLUX_GENERATION_IMAGING_PLAN.md) | Not started |
| **ONNX generation** | [`ONNX_GENERATION_IMPLEMENTATION_PLAN.md`](../../ikagi/android-arm64/implementations/generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md) | ONNX primary/post generation outcomes by profile/device | [`TODO_ONNX_GENERATION_IMAGING_PLAN.md`](../../ikagi/android-arm64/todo/mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md) | Not started |
| **Sprite quality contract** | [`SPRITE_QUALITY_FLOOR.md`](../../ikagi/android-arm64/implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) | Visual pass/fail floor at intended output size | (tracked in imaging todos) | Needs work |
| **Portrait contracts** | [`PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](../../ikagi/android-arm64/implementations/generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md), [`PORTRAIT_PACK_SCHEMA.md`](../../ikagi/android-arm64/implementations/generation/imaging/PORTRAIT_PACK_SCHEMA.md) | Creator flow and pack schema authority | (tracked in imaging todos) | Started |

---

## 3) Pipeline authority (how stages are chained)

| Contract | Doc | Why it matters |
|----------|-----|----------------|
| **Imaging pipeline stage ownership** | [`IMAGING_PIPELINE_QUALITY_STACK.md`](../../ikagi/android-arm64/implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md) | Declares S0-S6 jobs and which engine families own them. |
| **Ops board** | [`OPERATIONS_INDEX.md`](../../ikagi/android-arm64/implementations/OPERATIONS_INDEX.md) | Canonical checklist linking docs to active todos. |
| **Anti-drift registry** | [`LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`](../../ikagi/android-arm64/todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md) | Truth log for runtime state, handoff notes, and split history. |

---

## 4) Recommended next focus order

1. FLUX generation phase 1 baseline (`TODO_FLUX_GENERATION_IMAGING_PLAN.md`)
2. ONNX generation phase 1 baseline (`TODO_ONNX_GENERATION_IMAGING_PLAN.md`)
3. MediaPipe first operational helper task
4. GGUF diffusion decode/output gate completion

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial master matrix added under `anikai-ip/android-arm64 runtimes` linking engine-inference, generation, pipeline, and todo tracks. |
