# SmolLM2-Rethink-360M — Familiar & classifier candidate

| Field | Value |
|-------|-------|
| **Doc staging** | Reference |
| **Operations** | Classifier familiar (F4) |
| **Last reviewed** | 2026-05-20 |

**HF:** [prithivMLmods/SmolLM2-Rethink-360M-GGUF](https://huggingface.co/prithivMLmods/SmolLM2-Rethink-360M-GGUF)

**Familiars:** [`../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md`](../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md) · [`FAMILIAR_ROLES.md`](../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md)

**Turn classifier plan:** [`../CHAT_TURN_TIMELINE_PHASED_PLAN.md`](../CHAT_TURN_TIMELINE_PHASED_PLAN.md) Phase 5

---

## Summary

| Property | Value |
|----------|--------|
| Params | ~360M |
| Architecture | **llama** (GGUF via llama.cpp) |
| Training | Experimental lightweight reasoning (Celestia3 / DeepSeek-R1-style distilled data) |
| Base | SmolLM2-360M-Instruct lineage |
| License | Apache-2.0 (per model card — verify file before ship) |

Good fit for Anikai because it uses the **same** `llama-completion` path as companions — no second runtime.

---

## Suggested quants (desktop)

| Quant | Size (approx) | Use |
|-------|---------------|-----|
| **Q4_K_M** | ~271 MB | Default balance |
| Q4_K_S | ~260 MB | Slightly smaller |
| Q8_0 | ~386 MB | Quality-sensitive classifier |

---

## Anikai roles

| Role | Behavior |
|------|----------|
| **Familiar “router”** | Dedicated familiar with one script: emit single-line `<complexity …/>` or JSON for turn caps |
| **Global classifier** | Optional pre-pass before main Gemma E4B (see phased plan) |
| **Not** | Main companion chat weight (too small for long persona turns) |

---

## Prompt shape (classifier)

Keep prompts **tiny** — max **64–128** output tokens:

```text
[System]
You classify the user's next message for a local assistant.
Reply with ONE line only:
<complexity temp_bias="0.0-1.0" thought_pct="0.1-0.9" reply_pct="0.2-1.0" task="greeting|math|code|creative|critique|vision"/>

[User]
<user message>
```

Parse with existing `ThoughtSegmentTags.parseComplexityTag`.

---

## Limits

| Limit | Mitigation |
|-------|------------|
| Weaker than 1B+ on nuanced `task` labels | Fallback to heuristic `classifyTurnDemand` |
| Not Gemma channel-native | Do not use Gemma `<\|channel\|>` template for this file |
| Reasoning-style training may over-plan | Low temperature; strict one-line contract |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial note for Familiars + classifier |
