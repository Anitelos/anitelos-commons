# Video weaving & ShaderToy-style effects (direction)

**Status:** **Phase 2b shipped (scaffold)** — **Media Magic → Video → Video weaving** (track tree, WebGL2 preview, shader generate, companion tool). **Image weaving** is the still compositor sibling under **Image → Image weaving**. Full timeline export and real `iChannel` texture feeds are next.

**Related:** [`IMAGING_PIPELINE_RECORD_PLAYGROUND.md`](./IMAGING_PIPELINE_RECORD_PLAYGROUND.md), [`../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md), [`../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md).

**Runtime note:** Shader preview uses **Electron WebGL2** only — **no runtime pack** to vendor for GLSL (see § Runtime packs).

---

## Shipped today (desktop)

| Area | Behaviour |
|------|-----------|
| **Tracks** | Clips (`.mp4`, `.webm`, …), stills, shader files (`.glsl`, `.frag`, `.fs`, `.txt`, …). **+** → **Add file** or **Weave shader**. |
| **Shader groups** | Drag one shader onto another → **group** (top slot = **iChannel0**, bottom = **iChannel3**). Reorder inside group; right-click → assign channel. |
| **Preview** | Solo shader, **grid** (all channels), or **shift+stack** blend. `mainImage` → `main()` rewrite; auto `precision highp float` + ShaderToy uniforms. |
| **Shader tools** (tracks column) | **iChannel0–3**, **Undo / Redo / Save** — visible only when a **shader track** is selected. **◧** strip toggles source editor. |
| **Weave shader prompt** | Strip under preview (like console expand): four effect dropdowns (motion, color, shape, mood), channels 1–4, prompt + shaper → saves to `generated-media/shaders/`. |
| **Recents** | Shader thumbs **hover to animate**; drag into tracks. |
| **Console** | GLSL compile errors log to **Anikai media console**, not under the preview. |
| **Chat** | `<tool name="generate_shader" …/>` + `<choices>` intake (channels, intensity). |
| **Delete** | **Del** removes selected track or group. |

---

## What ShaderToy gives us

[ShaderToy](https://www.shadertoy.com/) shaders are **GLSL fragment programs** driven by uniforms: `iTime`, `iResolution`, `iMouse`, custom floats/vectors, and optional buffers (`iChannel0`–`3`). Most demos are **procedural loops** — skies, water, nebula, glitch, CRT — ideal for:

- **Looped scenery** behind characters (no video file required).
- **Full-screen post** on generated stills or video frames.
- **Mask-aware compositing** when we feed alpha / depth from ONNX lanes (planned).

They compile in a **WebGL2** runtime with a fixed uniform contract (`media-shader-preview.js`, `media-shader-weaving.js`).

---

## Tunable sliders (product + shipped basics)

| ShaderToy concept | ANIKAI control (today / planned) |
|-------------------|----------------------------------|
| Hard-coded `float` in source | **Effect tuning** flyout + literal replacement when generating |
| `iTime` speed | Time speed slider + `generate_shader` |
| `iResolution` | Preview size (auto) |
| Buffer A/B/C/D | **Group slots** + future real texture bind |
| Four effect axes | Motion / color / shape / mood dropdowns on generate panel |

**Preset JSON** (planned) next to `.glsl`:

```json
{
  "shaderPath": "generated-media/shaders/nebula-loop-2026-05-22_120000.glsl",
  "uniforms": {
    "uSpeed": { "type": "float", "default": 0.4, "min": 0, "max": 2, "label": "Drift speed" }
  }
}
```

---

## Video weaving = timeline north star

Extends **Image weaving** into time under Media Magic (or Playground nodes):

| Track type | Source |
|------------|--------|
| **Video** | Local gens, imports, PersonaLive output |
| **Image** | Stills, sprite sheets |
| **Shader** | GLSL layer (looping) — groups map to iChannels |
| **Audio** | WAV/MP3 from music lane |
| **Text** | Titles, captions (later) |

**Per-clip:** position, scale, opacity, blend, keyframes, in/out on timeline (scaffold strip today).

---

## Technical stack

| Layer | Implementation |
|-------|----------------|
| **Preview** | WebGL2 canvas in renderer; `requestAnimationFrame` |
| **Import** | `mainImage` rewrite; precision + uniform injection |
| **Multi-channel** | Per-slot FBO render → grid/stack composite shaders |
| **Generate** | `main-process/generate-shader-handoff.js` (procedural packs) |
| **Bake** | GPU readback → ffmpeg (planned) |
| **Pipeline** | `video_weaving` / `shader_pass` step type (planned) |

**Code map**

| Piece | Path |
|-------|------|
| UI | `anikai-desktop/components/media.js`, `media-pane-templates.js` |
| Preview | `anikai-desktop/components/media-shader-preview.js` |
| Weaving helpers | `anikai-desktop/components/media-shader-weaving.js` |
| Generate IPC | `media:generate-shader` in `main.js` |
| Chat tool | `generate_shader` in `companion-media-resolution.js` |

---

## Runtime packs

| Need pack? | Why |
|------------|-----|
| **No** | Shaders run in **Chromium WebGL2** already inside Electron. |
| **No** | Procedural shader **generation** is TypeScript in the app — not a native binary. |
| **Optional later** | **ffmpeg** for bake/mux (often same pack as future `media.tools` / ffmpeg staging). |
| **Separate** | **PersonaLive** / video **generation** weights use their own packs — not the shader editor. |

---

## Phasing

| Phase | Deliverable | Status |
|-------|-------------|--------|
| **2a** | Image weaving layers + dock | shipped |
| **2b** | Video weaving tree, preview, generate, chat tool | **shipped (scaffold)** |
| **2c** | Image weaving bake PNG | planned |
| **3** | Real `iChannel` textures from images/video; export loop | planned |
| **4** | Multi-track timeline + audio | planned |
| **5** | Companion edits timeline + shader params | planned |

---

## Risks

- **License:** ShaderToy uploads are user-supplied — do not redistribute.
- **GPU:** Heavy shaders need frame budget; preview may downgrade resolution.
- **Security:** Load shaders from user paths only; no remote `eval` without trust gate.
- **GLSL dialect:** Always inject `#version 300 es` + `precision highp float` for ShaderToy paste-ins.
