# Curated pipeline — Suno-clone (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Started (Phase 0) |
| **Last reviewed** | 2026-05-22 |
| **Pipeline status** | Phase 0 partial — S0–S1 ready; S2 Lane 4 + Compose I2A/A2A; S3 **gap** (singing); S4 ffmpeg mix partial; S5 export partial |

Purpose: describe the **multi-stage pipeline** that produces a Suno-style result locally — lyrics + style → full song. This is a **curated example**, not a feature of any single model. The app ships and validates **working models**; the user composes the graph.

This doc does **not** replace:

- audio lane teaching: [`../generation/audio/AUDIO_GENERATION_LANES_OVERVIEW.md`](../generation/audio/AUDIO_GENERATION_LANES_OVERVIEW.md)
- **Voice Weaving** (engines vs presets, Compose consumer): [`../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md`](../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md)
- engine-specific plans under `../generation/audio/.../*_IMPLEMENTATION_PLAN.md`
- **Compose sources + graph routing:** [`./COMPOSE_PIPELINE_SOURCES_AND_ROUTING.md`](./COMPOSE_PIPELINE_SOURCES_AND_ROUTING.md)
- the curated index: [`./CURATED_PIPELINES_INDEX.md`](./CURATED_PIPELINES_INDEX.md)

---

## Why this is a pipeline, not a model

Proprietary services like Suno / Udio do **not** run a single model. Internally they chain at least:

1. an LLM-style **plan / lyrics** step,
2. a giant **instrumental codec-token transformer**,
3. a **separate singing voice model** conditioned on lyrics + melody + timbre,
4. a **codec decoder + mix** pass.

Anikai exposes that same shape as an editable graph. Quality depends on which model files the user installs at each step, not on a single Anikai feature flag.

---

## Status labels — what partial, gap, and planned mean

The DAG table and **Pipelines → Run Suno-clone** UI use the same vocabulary as `assets/curated-pipelines/suno-clone-v1.json`. At run time, `curated-pipeline-status.js` probes your machine and may **upgrade or downgrade** the label (e.g. S2 becomes `blocked` if Media Python is missing).

| Label | Meaning for you | What Anikai does with engines |
|-------|-----------------|-------------------------------|
| **ready** (`shipped` in JSON) | Stage is wired; no honesty disclaimer beyond normal model downloads. | Calls the documented engine (e.g. `llama-completion` for S1). |
| **partial** | Code path runs, but capability is incomplete, first-run heavy, or manual packs needed. | Invokes the engine; you may need `stage-media-python`, HF weights, or accept a fallback (e.g. Lane 2 MIDI if Lane 4 fails in Suno runner). |
| **gap** | Known missing product tier — we **do not** substitute a weaker engine class. | **Skips** true singing (S3). Compose may still run **spoken** TTS (Kokoro / LongCat) with an explicit “not Suno-grade singing” message. |
| **planned** | Schema + UI slot exist; runner stub or export-only. | Does not claim neural quality; may write placeholders in `run.json`. |
| **blocked** (live only) | Hard dependency missing (no Media Python, no ffmpeg). | Stage fails fast with staging hint — no silent swap to cloud APIs. |

**Engines are not downloaded per model.** Anikai stages **runtime packs** (`pack.gguf`, `pack.media.anikai` / Media Python, `pack.media.tools` / ffmpeg, `pack.voice.espeak` for Piper/XTTS phonemes). **Weights** live under `models/` and are chosen per stage (Lane 4 HF repo, Kokoro ONNX, chat GGUF, etc.).

**Phonemes:** Speaking stages (Compose Voice, future companion TTS) use G2P → vocoder. **S3 singing** needs phonemes **plus pitch and duration** — that is why S3 stays a **gap** until a DiffSinger-class backend ships; Kokoro is not promoted to S3.

---

## Pipeline DAG (Suno-clone)

| Stage | Job | Role | Required model file | Engine | Status |
|-------|-----|------|---------------------|--------|--------|
| **S0 — Intent normalize** | User prompt + lyrics + style tags → run spec (BPM, key, length, structure). | App / Playground | — | App | partial (Compose song plan: BPM + bars/seconds) |
| **S1 — Lyrics + structure plan** | Verse / chorus shape, lyric timing, melodic intent (key, mood). Output is text + JSON. | Reading (chat / reasoning LLM) | any GGUF chat model the user already runs (Qwen / Ministral / Gemma class) | `llama-completion.exe` | shipped |
| **S2 — Instrumental generation** | Prompt + style + structure → instrumental audio; optional **I2A** / **A2A** in Compose. | Audio Lane 4 (codec-token / latent diffusion) | Stable Audio Open, MusicGen, **MusicGen Melody** (A2A), AudioLDM 2 | Media Python (`run_lane4_audio.py`) | partial |
| **S3 — Singing voice render** | Lyrics + melody + voice timbre → vocal track aligned to S2. | Articulations / Lane 5 | DiffSinger / VITS-singing / RVC-class | tba | **gap** — picker + stub only; no Suno-grade render |
| **S4 — Mix / master** | Combine stems; basic ffmpeg amix today. | DSP + `pack.media.tools` | — | ffmpeg (staged) | partial |
| **S5 — Pack / export** | Final `.wav` + `run.json` + stem paths. | App | — | App | partial |

Outputs land under `…/generated-media/audio/<pipeline-run>/` with a folder structure that holds master, stems, and a `run.json` describing every stage’s model + parameters.

### Phase 0 (desktop — shipped)

| Piece | Location |
|-------|----------|
| Schema | `anikai-desktop/shared/suno-clone-pipeline-schema.js` |
| Runner | `anikai-desktop/main-process/suno-clone-pipeline-runner.js` |
| Preset | `anikai-desktop/assets/curated-pipelines/suno-clone-v1.json` |
| UI | **Pipelines** panel → **Run Suno-clone** (prompt, lyrics, Lane 2 fallback checkbox) |
| IPC | `curated-pipeline:run-suno-clone`, `curated-pipeline:suno-clone-preset` |

**Phase 0 S2 behavior:** Default is **Lane 4 compare-all** (Stable Audio Open, MusicGen, **MusicGen Melody**, AudioLDM 2) when Media Python is installed. Optional Lane 2 MIDI fallback if neural generation fails (labeled in `run.json`). **Compose** compare-all runs shared source prep once; reference audio is passed **only** to `musicgen_melody`; I2A compare pick prefers `audioldm2`. S3 always skips with the singing-voice gap disclaimer.

**Media Magic → Audio:**

| Tab | Role |
|-----|------|
| **Compose** | Lyrics → Voice → Instrumental (shared **song plan**: BPM, bars/seconds, order chip) — **consumes** voice presets from Voice Weaving |
| **Voice Weaving** | Author clones and custom voices (LongCat, XTTS, CosyVoice, Kokoro presets, …) — see [`../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md`](../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md) |
| **Assembly** | Stem paths, per-stem gain, ffmpeg **Analyze → console**, **Export mix** (amix) |
| **Synth / MIDI** | Lane 1–2 sketches |
| **SFX** | Lane 3 one-shots (separate from song compose) |
| **Games** | Sprite sheet (moved from Image); future game maker |

Full graph runner: **Pipelines → Run Suno-clone** (linear Phase 0; not the same UI as Compose per-stage Generate).

---

## Compose — dynamic sources (100% clarity)

Compose is a **per-stage pipeline**, not one model. Each **Generate** runs only that section’s steps; **Generate full song** (Compose footer) chains lyrics → voice + bed (order chip) → ffmpeg mix.

### Shared song plan

- **BPM**, **time signature**, **bars ↔ seconds** at the top of Compose.
- **Order chip** (beside Audio sub-tabs): **Lyrics & voice first** ⟷ **Instrumental first** — reorders collapsible stage numbers only; same plan fields apply to both lyrics and instrumental when **Match Compose** is checked on Instrumental.

### Lyrics stage

| Field | Purpose |
|-------|---------|
| **Companion** | Chat GGUF for lyric planning (same pool as MIDI arranger / prompt shaper) |
| **About (prompt)** | User intent — e.g. “ending theme for an RPG with powerful lyrics” |
| **Style / Mood** | Merged into the lyric planner prompt (user wins if they intentionally conflict) |
| **From image** | Dropdown — see below |
| **From audio** | Dropdown — see below |
| **Clarity** | Companion reads prompt + style + mood + source modes/paths (+ optional ffmpeg profile) and reports **conflicts** vs intent |
| **Generate with clarity** | Appears after Clarity — applies suggested topic/style/mood fixes, then runs the lyrics pipeline |
| **Generate lyrics** | Full pipeline: optional sources → lyric GGUF (`[Verse]` / `[Chorus]` labels) |
| **Singing model** (planned) | Picker from **Articulations** catalogue — entries tagged `singing-voice` (DiffSinger, VITS singing, Cantio S3, …) — distinct from Compose **Voice** speaking presets |
| **Est. context** | Rough token estimate; companion context cap applied before lyric GGUF |

#### Lyrics — From image

| Mode | Model dropdown shows (HF task tags) | Behavior |
|------|-------------------------------------|----------|
| **None** | *(disabled)* | Text-only |
| **Vision → lyric brief** | **Image-to-text** (and related vision tags on the GGUF in Models) | Vision GGUF + **mmproj** reads screenshot → bullet brief merged into **About** (scene, characters, monsters) — does not paste raw OCR as final lyrics |

#### Lyrics — From audio

| Mode | Model dropdown shows | Behavior |
|------|----------------------|----------|
| **None** | *(disabled)* | — |
| **Use lyrics from source** | **Audio-to-text** (Whisper ASR, `automatic-speech-recognition`, audio-text multimodal GGUFs when tagged) | Transcribe reference audio; if prompt/style/mood empty → lyrics = transcript only; if user also typed fields → transcript **blended** into lyric GGUF brief (not verbatim-only) |
| **Grab theme / genre / mood** | **Audio-to-text** + **audio understanding** tags | **ffmpeg/ffprobe** loudness/duration profile + optional short ASR snippet → chat GGUF returns **style/mood/theme JSON only** — **does not** import source lyrics |

Selected **audio-to-text** model is the preferred ASR path when set; otherwise bundled Whisper after `npm run stage-compose-tools`.

### Instrumental stage

| Field | Purpose |
|-------|---------|
| **Match Compose** | When checked: copies lyric **topic/style/mood** into bed planning and uses **song-plan duration** for Lane 4 |
| **Style / Mood** | Instrumental-specific (can disagree with lyric fields — user choice) |
| **Bed prompt** | Lane 4 text prompt; source-derived text is **appended** as “what the bed should reference” |
| **From image / From audio** | Same pattern as lyrics — different mode lists |
| **Model** | Lane 4 backend or **Compare all** (three passes, shared compose sources — see routing doc) |
| **Compare pick** | After compare-all, choose which backend WAV to hand off (manifest under `compose-instrumental-compare/`) |
| **Singing model (S3)** | Articulations catalogue (`singing-voice`) — selection saved; render planned |

#### Instrumental — From image

| Mode | Model dropdown | Behavior |
|------|----------------|----------|
| **None** | disabled | Prompt-only bed |
| **Vision → bed brief** | Image-to-text | Vision describes scene/energy → appended to **bed prompt** |
| **Image → audio** | **Image-to-text** vision GGUF + mmproj (picker: `instrumental_vision`) | Vision caption → bed prompt → Lane 4 (**AudioLDM 2** default; BLIP augments non-AD2 backends) |

#### Instrumental — From audio

| Mode | Model dropdown | Behavior |
|------|----------------|----------|
| **None** | disabled | — |
| **Audio → text** | Audio-to-text | ffmpeg profile + transcript snippet → **bed prompt** (“reference this feel…”) |
| **Audio → audio** | Audio-to-audio | **MusicGen Melody** — neural conditioning on reference clip (`referenceAudioPath`). Legacy ffmpeg `amix` is opt-in only (`legacyA2aBlend`), not the default label |

[AudioLDM 2](https://audioldm.github.io/audioldm2/) is the reference for unified text/music/SFX and image-to-audio research direction.

### Voice stage (Compose — consumer)

Compose **selects** a voice preset; it does **not** author clones. Authoring moves to **Voice Weaving** — full architecture: [`../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md`](../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md).

| Today | Next |
|-------|------|
| Voice Weaving tab; grouped preset picker | Missing-pack grey labels per engine folder |
| **Kokoro** presets (phonemes via `kokoro-onnx` pip) | Emotion / 8-voice companion UX |
| **LongCat** adapter | Full clone path when repo staged |
| User presets in `voices/presets/*.json` | XTTS / CosyVoice adapters |

| Engine (priority) | Role in Compose | Staging |
|-------------------|-----------------|---------|
| **Kokoro** | Spoken lines in song graph (preset timbre) | `models/voices/kokoro/` + Media Python; phonemes via pip (`espeakng-loader`) |
| **LongCat-AudioDiT** | TTS + clone | `npm run stage-longcat-voice` |
| **XTTS / CosyVoice** | Clone + TTS (planned) | Per runtime plan; **G2P** uses `pack.voice.espeak` when native |
| **Piper** | Lightweight TTS (planned in Compose) | `voice.espeak` + `voice.onnx` packs |

**Missing pack UX (target):** preset visible but disabled — e.g. *“This pack is missing from your kokoro folder”* (same as Android Kokoro preset list).

### Assembly (own tab)

| Feature | Status |
|---------|--------|
| Stem path fields, **Pull from Compose** | Shipped |
| ffmpeg analysis → **media console** | Shipped |
| **Export mix** (amix) | Shipped |
| Timeline / ducking UI | Planned |

### Model discovery (plug-and-play)

Compose model dropdowns scan the **Models** library for HF **task type** tags (`image-to-text`, `automatic-speech-recognition`, `audio-to-audio`, etc.). Tag GGUFs in the Models panel to populate pickers. **Auto** uses companion chat GGUF or default Whisper/Lane paths.

### Intentional conflicts

If the user sets **mood: dreamy** but **prompt: aggressive battle anthem**, or refs that fight the prompt, **that is allowed** — Clarity explains the tension; **Generate with clarity** only applies when the user accepts the suggestion.

### Shipped (compose wave 2–3)

- **Generate full song** — Compose footer; `compose:run-full-pipeline` runs lyrics → voice + bed (order chip) → ffmpeg assembly mix
- **Audio-text models** — Whisper ASR + native GGUF `--audio` via mtmd (`compose-audio-multimodal.js`)
- **Image → audio (I2A)** — vision GGUF caption + Lane 4; compare-all prefers AudioLDM 2
- **Audio → audio (A2A)** — **MusicGen Melody** default; compare-all selects Melody when reference audio is set
- **Voice Weaving** + Kokoro / LongCat preset paths; **S3 singing** render stub with gap disclaimer (`compose-singing-render.js`)
- **Singing model picker** on Lyrics (catalogue only until Lane 5 lands)

### Still planned

- **S3 render** — DiffSinger-class Lane 5 backend wired to Articulations picker
- Gemma-class **native audio mmproj** without Whisper hop (when desktop mtmd supports it)
- Dedicated **image-conditioned** I2A weights beyond caption → prompt
- Playground canvas graph mirroring this DAG — **output → source** edges (see routing doc)
- Suno runner S2 using Compose source prep for I2A/A2A (today: prompt-only Lane 4 compare in runner)

---

## Role map vs Anikai’s About taxonomy

| Stage | Where this is documented in About |
|-------|------------------------------------|
| S1 | **Sentience → Reading (chat)** — any chat / reasoning model. The **Musician** / **Audio engineer** persona presets (already shipped) bias prompt planning; they do not gate the tool. |
| S2 | **Generating media → Audio → How music actually works** (Lane 4 explanation). |
| S3 | **Generating media → Articulations** — singing voice (Lane 5). *Distinct* from **Sentience → Voice (speaking)** and from **Voice Weaving** speaking/clone presets — [`../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md`](../generation/audio/voice/VOICE_WEAVING_MEDIA_MAGIC.md). |
| S4 | DSP — Playground node (no model). |
| S5 | App / storage contract. |

---

## Honest gaps

| Gap | What it means |
|-----|----------------|
| **No open singing model at Suno tier.** | S3 will produce noticeably weaker vocals than Suno until the open ecosystem catches up. Anikai must label vocal output as “singing-voice (open)” and never silently fall back to TTS. |
| **Dataset asymmetry.** | Suno’s edge is partly massive scraped commercial music. Local open-weight Lane-4 models trained on permissive data will not match style range. |
| **Cloud lane is out of scope (for now).** | Routing S2 or S3 to Suno / ElevenLabs / similar APIs is a future, **explicitly labeled** lane — never substituted into a graph that claims local generation. |

---

## Promotion checklist (planned → shipped)

- [x] Phase 0 runner + `run.json` per run under `generated-media/audio/suno-*`.
- [x] Pipelines panel entry with vocal-gap disclaimer and Lane 2 fallback label.
- [x] Lane 4 backends wired (Stable Audio Open, MusicGen, **MusicGen Melody**, AudioLDM 2) — compare-all in Pipelines + Compose.
- [x] Compose neural A2A (MusicGen Melody) + vision-guided I2A; compare pick rules for Melody / AudioLDM 2.
- [ ] Lane 5 backend picked, labeled by quality tier, with a per-model About page.
- [x] Voice Weaving tab + preset manifest; Compose voice picker grouped by engine (LongCat).
- [x] Compose Lyrics singing-articulation picker (catalogue; S3 render still planned).
- [x] Instrumental compare-all runs full compose source prep per backend pass + `compare.json` manifest.
- [ ] Playground node graph (canvas) for the same DAG — panel runner is linear only for now.
- [ ] DSP mix node implemented (ducking + bus chain).
- [ ] About → Pipelines → Curated sub-tab shows live status (partial vs planned).
- [x] Vocal-output labeling and disclaimer surface every time S3 runs (skipped with disclaimer).

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-22 | Status legend (partial/gap/planned vs engines); MusicGen Melody A2A; I2A vision path; Kokoro voice; S4 partial |
| 2026-05-24 | Compare-all via compose pipeline + manifest; singing articulation picker; full-song Clarity checkbox; source routing doc. |
| 2026-05-24 | Voice Weaving architecture doc; engine vs preset; tie-in to Compose Voice + Lyrics singing picker. |
| 2026-05-22 | Compose wave 2: full-song button, Lane 4 image/reference args, audio-text ASR routing. |
| 2026-05-23 | Compose dynamic sources doc: From image/audio modes, model categories, Clarity, Assembly tab, staging npm scripts. |
| 2026-05-23 | Media Magic → Audio → Compose UI (BPM plan, stage collapsibles, lyrics/voice/instrumental, order chip; Assembly own tab). |
| 2026-05-23 | Phase 0: schema, runner, Pipelines panel UI, Lane 2 instrumental fallback with explicit labeling. |
| 2026-05-19 | Initial Suno-clone pipeline plan: DAG, role/format map, honest gaps, promotion checklist. |
