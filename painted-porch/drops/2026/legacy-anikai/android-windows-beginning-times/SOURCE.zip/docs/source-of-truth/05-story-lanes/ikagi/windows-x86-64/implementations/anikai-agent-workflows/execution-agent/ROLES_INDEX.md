# Execution agent — roles & workspace index

Quick map for Windows desktop **who does what** and **where files live**. Prefer linking here (or [`../../WINDOWS_DESKTOP_INDEX.md`](../../WINDOWS_DESKTOP_INDEX.md)) instead of re-explaining in every plan.

| Topic | Doc |
|-------|-----|
| **Full desktop doc index** | [`../../WINDOWS_DESKTOP_INDEX.md`](../../WINDOWS_DESKTOP_INDEX.md) |
| **Project tree (M0)** | [`../../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md`](../../companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md) |
| **Familiar reflex roles** (guard, classifier, time, …) | [`Familiars/FAMILIAR_ROLES.md`](Familiars/FAMILIAR_ROLES.md) |
| **Familiar system** (UI, phases F1–F7) | [`Familiars/FAMILIARS_REFLEX_SYSTEM.md`](Familiars/FAMILIARS_REFLEX_SYSTEM.md) |
| **Companion crafts + session roles** (**manager**) | [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) |
| **Workforce vision** (automation, capability map) | [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](WORKFORCE_AND_ORCHESTRATION_VISION.md) |
| **Team blackboard** | [`TEAM_BLACKBOARD_ORCHESTRATION.md`](TEAM_BLACKBOARD_ORCHESTRATION.md) |

**Manager:** specialty `manager` on a **companion** — see Specialists § Manager (not familiar **guard**, not group **Lead**).
