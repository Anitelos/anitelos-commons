# TODO — Engine inference capability platform (high scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-09 |

Build ANIKAI's parent inference capability platform so runtime families, model packs, sidecars, probes, Swarm roles, and UI controls all use the same source of truth.

---

## Source implementation doc

- [`../../implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)
- [`../../implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md`](../../implementations/engine-inference/model-hub/MODEL_HUB_INDEX.md)

---

## Intent

- Make ANIKAI capability-native instead of model-name-native.
- Prevent placeholder UI from claiming unavailable runtime features.
- Let users install many model families and assign them to Swarm/Soul roles by proven capabilities.
- Keep individual engine docs as their own source-of-truth while this todo tracks the parent platform operation.

---

## Parent checklist

- [ ] Define v1 model pack manifest schema for runtime, files, sidecars, license, profile, and capability flags.
- [ ] Create a runtime adapter registry contract shared by GGUF, ONNX, LiteRT, MediaPipe, NCNN, QNN/SNPE, ExecuTorch, MNN, and FOMM lanes.
- [ ] Define readiness states (`INSTALLED`, `SUPPORTED`, `LOADABLE`, `VERIFIED`, `DEGRADED`, `UNAVAILABLE`) and visible failure reasons.
- [ ] Gate User Access/runtime UI controls from readiness state rather than placeholders.
- [ ] Add Swarm/Soul role binding by capability, not hardcoded model names.
- [ ] Route handover packets with model id, runtime family, adapter id, capability, latency, and fallback/degraded state.
- [ ] Verify first vertical slice: GGUF text, GGUF multimodal sidecar check, ONNX voice/helper readiness, and one capability-backed Swarm role.

---

## Model fusion checklist (separate tracker)

- [ ] Ensure each assigned model has manifest service eligibility tags (`sentience`, `swarm`, `soul`, `voice` as needed).
- [ ] Enforce required sidecars/artifacts before role assignment (`mmproj`, tokenizer, config, graph assets).
- [ ] Require readiness progression (`INSTALLED` -> `SUPPORTED` -> `LOADABLE` -> `VERIFIED`) before enabling assignment controls.
- [ ] Track role-level primary/fallback chain for sentience and swarm independently.
- [ ] Ensure degraded/fallback path is always visible in app surfaces and logs.
- [ ] Add handover fields for `servicePlane` and capability ids across delegated tasks.
- [ ] Verify shared model pool consumption by Sentience Systems and Swarm (no duplicate registration paths).
- [ ] Validate safe disable/unassign behavior for sentience roles (`eyes`, `ears`, `turn`, `touch`, `emotion`) and swarm roles.

---

## Future engine stubs (documentation only)

Vendor NPU, OS-level AI, and alternative cross-platform engines have stub implementation plans under `implementations/engine-inference/model-hub/` (NeuroPilot, Samsung ENN, HiAI, AICore, NNAPI direct, Paddle Lite, TVM, Tengine, OpenCV DNN, Skia/graphics). No dedicated todos until an engine moves from stub to active integration.

---

## Child operation checklist

- [ ] **GGUF engine runtime**  
  Implementation: [`../../implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`](../mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md)

- [ ] **ONNX image/runtime lane**  
  Implementation: [`../../implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`](../../implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md)  
  Todo: [`../mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md`](../mid-scope/TODO_ONNX_GENERATION_IMAGING_PLAN.md)

- [ ] **LiteRT engine integration**  
  Implementation: [`../../implementations/engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md`](../mid-scope/TODO_LITERT_ENGINE_INFERENCE_INTEGRATION.md)

- [ ] **MediaPipe engine integration**  
  Implementation: [`../../implementations/engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`](../mid-scope/TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md)

- [ ] **NCNN engine integration**  
  Implementation: [`../../implementations/engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/ncnn/NCNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md`](../mid-scope/TODO_NCNN_ENGINE_INFERENCE_INTEGRATION.md)

- [ ] **QNN/SNPE engine integration**  
  Implementation: [`../../implementations/engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/qnn/QNN_SNPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md`](../mid-scope/TODO_QNN_SNPE_ENGINE_INFERENCE_INTEGRATION.md)

- [ ] **ExecuTorch engine integration**  
  Implementation: [`../../implementations/engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/executorch/EXECUTORCH_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md`](../mid-scope/TODO_EXECUTORCH_ENGINE_INFERENCE_INTEGRATION.md)

- [ ] **MNN engine integration**  
  Implementation: [`../../implementations/engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/mnn/MNN_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Todo: [`../mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md`](../mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md)

- [ ] **FOMM motion inference lane**  
  Implementation: [`../../implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)  
  Related todo: [`../mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`](../mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md)

---

## Current interpretation

- Start with the shared capability platform, not every engine at once.
- The first real slice should prove manifest/probe/role binding with a small set of existing lanes.
- Individual runtime docs continue to hold engine-specific details and changelogs.
- This high-scope todo is the parent execution tracker and can move to completed later without moving the implementation plan.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-08 | Created high-scope parent todo for the engine inference capability platform and linked child runtime docs/todos. |
| 2026-05-08 | Added separate model fusion checklist tracker for Sentience/Swarm shared model-pool readiness. |
| 2026-05-09 | Linked model hub index and documented future engine stub strategy (docs-only until activated). |
