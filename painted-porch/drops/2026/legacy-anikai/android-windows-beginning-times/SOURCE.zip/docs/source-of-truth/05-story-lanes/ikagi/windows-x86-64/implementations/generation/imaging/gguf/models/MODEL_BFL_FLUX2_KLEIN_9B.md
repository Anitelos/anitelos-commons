# Model sheet — black-forest-labs / FLUX.2-klein-9B (full stack)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-14 |

## HF

- Repo: [black-forest-labs/FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B)  
- VAE (ungated): [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae)  

## What it is

**Full** FLUX.2 Klein text-to-image weights (DiT + text side as shipped by BFL). This is the baseline we want before any **optional** swap to the [ponpoke uncensored text encoder](https://huggingface.co/ponpoke/flux2-klein-9b-uncensored-text-encoder) (documented as **phase 2** in [`MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md`](./MODEL_PONPOKE_FLUX2_KLEIN_UNCENSORED_TEXT_ENCODER.md)).

## Intended inference family (Windows desktop)

- **Diffusers / PyTorch sidecar** (or upstream-documented server), not `sd.exe` GGUF.

## Product notes

- **Preset id (future):** `flux2_klein_9b_bfl` (proposal).  
- **Phase 2:** same preset shape + alternate `text_encoder` / CLIP path for ponpoke weights once baseline is green.

## Implementation checklist (Anikai Desktop)

- [ ] Add manifest row + pipeline class once we lock the exact `diffusers` entrypoint for this checkpoint.  
- [ ] VRAM / offload policy documented.  
- [ ] Lane index checkbox updated when green.  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- Diffusers family plan: [`../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  
- GGUF alternative (same model family): [`MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](./MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-14 | Added to separate “full FLUX2” target from encoder-only repo. |
