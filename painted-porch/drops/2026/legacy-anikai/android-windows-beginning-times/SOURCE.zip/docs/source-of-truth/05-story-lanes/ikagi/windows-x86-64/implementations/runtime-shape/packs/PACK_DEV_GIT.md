# Dev portable Git pack

| Field | Value |
|-------|-------|
| **Pack id** | `pack.dev.git` |
| **Tier** | B |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Snapshots, pipeline versions, companion-suggested branches without user PATH git.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

PortableGit for Windows minimal slice.

## Staging path

`desktop-data/runtime-packs/dev.git/`

## Unlocks (no model weights)

workspace-snapshot, pipeline-version-tag

## Verification smoke

git --version; init test repo.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
