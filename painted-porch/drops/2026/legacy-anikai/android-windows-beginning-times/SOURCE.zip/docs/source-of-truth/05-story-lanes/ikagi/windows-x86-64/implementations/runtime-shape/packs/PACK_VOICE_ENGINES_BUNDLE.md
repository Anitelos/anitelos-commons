# Voice engines bundle (speaking + articulations)

| Field | Value |
|-------|-------|
| **Pack ids** | `pack.voice`, `pack.articulations.engines` |
| **Tier** | active |
| **Manifest** | `anikai-desktop/assets/about-guide/voice-engines-bundle.json` |
| **Last reviewed** | 2026-05-22 |

**Purpose:** One staging command for all **Sentience → Voice (speaking)** Python engines and **Articulations (singing)** score helpers — so you do not chase four separate npm scripts during workshop bring-up.

---

## One command

```bash
cd anikai-desktop
npm run stage-voice-engines
npm run smoke-voice-engines
```

Runs in order:

1. `stage-media-python` — shared venv
2. `stage-voice-espeak` — eSpeak-NG exe + `espeak-ng-data/`
3. `stage-kokoro-voice` — `kokoro-onnx` pip
4. `stage-longcat-voice` — Diffusers LongCat TTS (+ optional audiodit clone)
5. `stage-xtts-voice` — Coqui TTS / XTTS
6. `stage-cosyvoice-voice` — CosyVoice pip
7. `stage-articulations-voice` — `mido`, `librosa` for score/MIDI prep

`npm run stage-runtimes` includes `stage-voice-engines` (replaces individual voice stage lines).

---

## Lanes (honest split)

| Lane | About tab | Engines staged | Weights |
|------|-----------|----------------|---------|
| **Speaking** | Sentience → Voice | eSpeak, Kokoro, LongCat, XTTS, CosyVoice | `models/voices/`, `models/longcat-*`, HF Get pack |
| **Articulations** | Generating media → Articulations | LongCat (lyric), score prep | DiffSinger / RVC — **planned**, separate Get pack |

Singing **neural S3** (DiffSinger-class) is catalogue-only until the router ships. LongCat + Kokoro cover **spoken/lyric** lines today without pretending to be Suno-grade singing.

---

## Check runtimes

**Settings → Device → Software → Check runtimes**

- **Voice engines bundle** — `pack.voice` (eSpeak row + Python engine pip checks)
- **Articulations engines bundle** — `pack.articulations.engines`

Detailed per-engine readiness (weights on disk): IPC `voice:get-engines-bundle-status` / `window.anikai.getVoiceEnginesBundleStatus()`.

---

## Registries

- Speaking stacks: `assets/about-guide/voice-registry.json`
- Singing stacks: `assets/about-guide/articulations-registry.json`
- Bundle manifest: `assets/about-guide/voice-engines-bundle.json`

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial bundle — `stage-voice-engines`, probes, manifest |
