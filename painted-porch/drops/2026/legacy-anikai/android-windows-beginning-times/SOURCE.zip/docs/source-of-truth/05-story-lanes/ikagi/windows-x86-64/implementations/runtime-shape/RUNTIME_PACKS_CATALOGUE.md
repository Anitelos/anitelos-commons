# Runtime packs catalogue (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-22 |

**Purpose:** One index for every **runtime pack** (binaries / venvs / data trees — not HF weights). Each pack has its own plan under [`packs/`](./packs/). About → **In the works** and **Engines → Runtime packs** read `runtime-packs-registry.json`.

**Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](./RUNTIME_PACKS_AND_INSTALLER.md)

---

## Tiers (vendoring priority)

| Tier | Meaning | When to vendor |
|------|---------|----------------|
| **shipped** | In installer or `resources/` today | Maintain in CI |
| **active** | Probed on Software tab; partial or staging path exists | Finish staging + verify smoke |
| **A** | Workshop plumbing — unlocks Media Magic / weaving without new AI EP | **Soon** — wire after stage |
| **B** | Trust + memory + dev power — not inference EPs | After Tier A voice/hearing |
| **promote-later** | Model-hub EP — only when a **named pipeline** needs it | Do not hoard DLLs early |

---

## Shipped & active (probed today)

| Pack id | Doc |
|---------|-----|
| `pack.gguf` | [`packs/PACK_GGUF.md`](./packs/PACK_GGUF.md) |
| `pack.media.anikai` | [`packs/PACK_MEDIA_ANIKAI.md`](./packs/PACK_MEDIA_ANIKAI.md) |
| `pack.onnx` | [`packs/PACK_ONNX_RUNTIME.md`](./packs/PACK_ONNX_RUNTIME.md) |
| `pack.onnx.imaging` | [`packs/PACK_ONNX_IMAGING.md`](./packs/PACK_ONNX_IMAGING.md) |
| `pack.cuda` | [`packs/PACK_CUDA.md`](./packs/PACK_CUDA.md) |
| `pack.personalive` | [`packs/PACK_PERSONALIVE.md`](./packs/PACK_PERSONALIVE.md) |
| `pack.rig.anikai` | [`packs/PACK_RIG_ANIKAI.md`](./packs/PACK_RIG_ANIKAI.md) |
| `pack.voice.espeak` | [`packs/PACK_VOICE_ESPEAK.md`](./packs/PACK_VOICE_ESPEAK.md) |
| `pack.media.tools` | [`packs/PACK_MEDIA_TOOLS.md`](./packs/PACK_MEDIA_TOOLS.md) |

---

## Tier A — workshop plumbing (vendor next)

| Pack id | Doc | Unlocks (summary) |
|---------|-----|-------------------|
| `pack.media.libvips` | [`packs/PACK_MEDIA_LIBVIPS.md`](./packs/PACK_MEDIA_LIBVIPS.md) | Fast resize/crop/EXIF, image weave bake |
| `pack.media.wasapi` | [`packs/PACK_MEDIA_WASAPI.md`](./packs/PACK_MEDIA_WASAPI.md) | Loopback capture — live transcribe, music react |

**Note:** FluidSynth + default SoundFont ship inside `pack.media.anikai` (MIDI lane), not a separate pack.

---

## Tier B — memory, OCR, dev tooling

| Pack id | Doc |
|---------|-----|
| `pack.memory.sqlite` | [`packs/PACK_MEMORY_SQLITE.md`](./packs/PACK_MEMORY_SQLITE.md) |
| `pack.ocr.tesseract` | [`packs/PACK_OCR_TESSERACT.md`](./packs/PACK_OCR_TESSERACT.md) |
| `pack.dev.treesitter` | [`packs/PACK_DEV_TREESITTER.md`](./packs/PACK_DEV_TREESITTER.md) |
| `pack.dev.git` | [`packs/PACK_DEV_GIT.md`](./packs/PACK_DEV_GIT.md) |

---

## Active pipeline — voice, hearing, motion

| Pack id | Doc |
|---------|-----|
| `pack.voice` | [`packs/PACK_VOICE_RUNTIME.md`](./packs/PACK_VOICE_RUNTIME.md) |
| `pack.hearing` | [`packs/PACK_HEARING.md`](./packs/PACK_HEARING.md) |
| `pack.motion.python` | [`packs/PACK_MOTION_PYTHON.md`](./packs/PACK_MOTION_PYTHON.md) |

---

## Promote later (model-hub EPs)

| Pack id | Doc |
|---------|-----|
| `pack.mediapipe` | [`packs/PACK_MEDIAPIPE.md`](./packs/PACK_MEDIAPIPE.md) |
| `pack.opencv_dnn` | [`packs/PACK_OPENCV_DNN.md`](./packs/PACK_OPENCV_DNN.md) |
| `pack.ncnn` | [`packs/PACK_NCNN.md`](./packs/PACK_NCNN.md) |
| `pack.mnn` | [`packs/PACK_MNN.md`](./packs/PACK_MNN.md) |
| `pack.litert` | [`packs/PACK_LITERT.md`](./packs/PACK_LITERT.md) |
| `pack.executorch` | [`packs/PACK_EXECUTORCH.md`](./packs/PACK_EXECUTORCH.md) |
| `pack.paddle` | [`packs/PACK_PADDLE.md`](./packs/PACK_PADDLE.md) |
| `pack.tvm` | [`packs/PACK_TVM.md`](./packs/PACK_TVM.md) |
| `pack.tengine` | [`packs/PACK_TENGINE.md`](./packs/PACK_TENGINE.md) |

---

## Not a runtime pack

| Capability | Why omitted |
|------------|-------------|
| Video weaving / ShaderToy | Electron WebGL2 — see [`../pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md`](../pipelines/VIDEO_MIX_SHADERTOY_DIRECTION.md) |
| Chat / coding GGUF | `pack.gguf` + model roles |
| HF weights | `models/` + Get pack only |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial catalogue + per-pack docs; Tier A/B/promote-later split |
| 2026-05-22 | `stage-voice-espeak` — bundle eSpeak-NG for Piper/XTTS phoneme path |
| 2026-05-22 | Moved `pack.voice.espeak` + `pack.media.tools` to shipped & active (staged on desktop) |
