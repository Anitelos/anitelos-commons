# Portrait rig & motion strategy (cross-platform intent)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress (Android Stage A) |
| **Last reviewed** | 2026-05-20 |

**Rig test plan (Android implementation):** [`CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`](CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md)

**4-shot stills:** [`../generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](../generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md)

**PersonaLive engine:** [`../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**FOMM engine (alternate neural):** [`../engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

---

## Product intent (one paragraph)

The persona **looks like the generated portrait** and **moves while speaking** — mouth, eyes, brows, and head driven by **phonemes, TTS timing, mood, and emotion** — without baking flipbook animations or maintaining per-shot **2D mouth/eye slices**. Optional neural motion (**PersonaLive** or FOMM-class) enhances fluidity; a **deterministic rig** remains the always-on baseline.

---

## Phased path (do not skip order)

```mermaid
flowchart TB
  A[Stage A — Rig signals from speech] --> B[Stage B — Bind one persona still]
  B --> C1[Stage C-lite — Front-only neural face]
  C1 --> C2[Stage C — Multi-view yaw optional]
  C2 --> D[Stage D — Body in space optional]
```

| Stage | What | Engines | 2D slice approach |
|-------|------|---------|-------------------|
| **A** | Phoneme/mood → rig channels; preview voice | Kokoro + app rig | **No** persona texture slices |
| **B** | Single `hero_close` still + rig overlay or depth hint | GGUF/Flux still + optional ONNX depth | Composite or depth only |
| **C-lite** | Neural face on still: driver stream → PersonaLive | `personalive` sidecar | **Retire** mouth/eye atlases for this lane |
| **C** | Turn left/right: swap reference or neural pose | 8-dir stills **or** front/back only | PersonaLive may reduce need for 8 GGUF gens |
| **D** | Torso/arms in “3D space” | 8-dir NESW like sprite **or** driver video pose | Defer until C-lite stable |

**Android today:** Stage A is live in `PersonaRigTestScreen` (rig + phonemes + TTS). **Next product slice:** Stage B + driver bridge for PersonaLive.

---

## Motion lanes (always label in UI)

| Lane id | Name | Input | Output |
|---------|------|-------|--------|
| `rig_deterministic` | Rig v0 | Phoneme buckets, mood, energy | Vector rig + optional overlay on still |
| `personalive` | PersonaLive | Persona still + **driving frame stream** | Animated RGB frames |
| ~~`fomm`~~ | *(removed from plan)* | — | Legacy Android experiment only — **not** a product lane |

**Rule:** phonemes → **rig** → (optional) **synthetic driving video** → PersonaLive. Not phonemes → PersonaLive directly.

---

## Driving stream bridge (the missing adapter)

PersonaLive expects **Portrait** + **Driving** (see upstream demo). Anikai already computes:

- `mouthShape`, `blinkState`, `browState`, `headNodTilt`, … ([`CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`](CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md) § Motion control contract)

**New work:** `PhonemeDriverFrameSynth` (name TBD):

1. At TTS frame time, render a small **driver face** (256²) from rig signals — stick figure, blurred template, or landmark dots.
2. Push frames into PersonaLive **online** queue (same role as webcam).
3. Persona still = 4-shot `hero_close` or user-approved portrait.

This preserves your **emotion + mood + phoneme** story without manual sprite slicing.

**v0 shortcut for engine smoke:** use a **stock driving.mp4** + persona still (prove PersonaLive pack). Swap in synth driver in v1.

---

## Multi-view: 8-dir vs front/back

| Approach | When |
|----------|------|
| **8 directional GGUF stills** (sprite pattern) | Discrete yaw buckets; swap texture when rig says “turn NE” |
| **Front + back only** | If PersonaLive driving carries enough head pose — **validate on device** before committing to 8 gens |
| **Start** | **One front still** + neural face (C-lite) |

Do not start Stage C multi-view until C-lite talking face is credible.

---

## ONNX tables — what to fill (and what not to)

| Engine | Registry bucket | Manifest shape |
|--------|-----------------|----------------|
| Depth overlay | `onnx.portrait.depth` | Single `.onnx`, NCHW — like `PortraitDepthOnnxRuntime` |
| Sprite post x4 | `onnx.image.post` | Single-graph post |
| FOMM | `onnx.motion.fomm` | detector + generator tokens |
| **PersonaLive** | **`personalive.*`** | Multi-`.pth` + SD bundles + optional `onnx/unet_opt` — **separate table** |

Filling the generic ONNX imaging table alone will **not** document PersonaLive; add hub family + About row first.

---

## GGUF image status (Windows)

Three verified registry rows — good. FHDR preview asset is **catalogue polish**, not blocking motion.

**Next engine work (aligned with this doc):**

1. PersonaLive manifest + `python.personalive` pack stub.  
2. Offline smoke: still + driving video → short MP4.  
3. Android: wire driver bridge from rig → synth frames.  
4. Optional: ONNX depth on Windows (parallel, smaller than PersonaLive).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Strategy doc: PersonaLive vs FOMM vs rig; phoneme bridge; staged views. |
