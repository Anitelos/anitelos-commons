# Media Magic phased creative flow plan (Windows)

| Field | Value |
|-------|-------|
| **Status** | Proposed phased implementation + validation plan |
| **Scope** | End-to-end Image -> Video/Fashion -> 3D/Sprite creation flow |
| **Audience** | Product, UX, runtime, QA, and showcase planning |

---

## Why this doc exists

This plan operationalizes the target creative workflow:

1. Design character in Image designers.
2. Generate motion clips in Video engines (e.g., character walking in a park).
3. Design outfits and apply them to the character/video path.
4. Convert final character/outfit outputs to 3D and/or sprites for game/animation/print pipelines.

The goal is to phase this in safely, then run showcase-grade end-to-end tests.

---

## Target "golden flow"

1. **Character designer** creates clean full-body character references.
2. User hands off to **Video specialist engine** (Lance initially) for motion shots.
3. **Outfit designer** creates standalone cropped outfits (garment-first references).
4. User hands off to **Fashion** video lane for garment application/customization.
5. User approves final look and sends output to:
   - **3D lane** (LiTo / SHARP / mesh stacks as available)
   - **Games sprite lane** (whole character sheet or segmented costume parts)

---

## User guidance contract (important)

For highest success in outfit/fashion and 3D handoff:

- keep outfit assets as standalone cropped references
- keep character refs single-subject and clean background
- prefer full-body framing for downstream motion/3D

This guidance should appear as inline helper text in relevant tabs.

---

## Task board (single source)

Keep this board as the execution tracker to avoid document sprawl.

### Now

- [x] Apply Image mode IA in UI: `Generation | Image weaving | Others`.
- [x] Keep `Standard` first under `Generation`.
- [x] Add designer footer handoff links with readiness badges (`Runnable` / `Coming soon`).
- [x] Add `Concept scene` timeline with persistent prompt cards and `Play/Pause`.
- [x] Surface `Send to Video -> Fashion` as visible `Coming soon` path.

### Next

- [x] Video IA scaffolding: `Generation | Video weaving | Others` with engine dropdown (Standard, Lance, Fashion, CogOmni).
- [x] 3D IA scaffolding: `Generation | 3D weaving | Others` with per-engine dropdown.
- [x] Top-level **Others** kind (Games under Others; future web/app/manga stubs).
- [x] Wire Video → Standard character + scene ref slots (dynamic empty-slot rules).
- [x] Video Standard workspace: prompt, shaper, preview, video-only model picker (`MEDIA_STACK_CATALOG`; Lance multimodal; no image-only GGUF such as SD 3.5 on Video tab).
- [x] Lance inference runner: `stage-lance` + `anikai_lance_infer.py` + `media:generate-lance` (Image T2I / Video T2V; refs → image_edit when a still is attached).
- [ ] Pass video refs into full I2V conditioning (beyond image_edit on still) when upstream supports it in one-shot API.
- [ ] Build Fashion tab in watch mode using the requirements in `VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`.
- [ ] Implement Character -> Lance handoff preset for walk-cycle baseline.
- [ ] Add Outfit crop-quality checks before Fashion handoff.
- [ ] Enable Concept scene timeline ingestion into Video weaving timeline.

### Later

- [ ] Graduate Fashion watch tab to runnable local engine mode.
- [ ] Add engine-specific renderer activation for archviz/world models.
- [ ] Complete in-app 3D viewport upgrades for LiTo/TRELLIS-class outputs.
- [ ] Build showcase script and canned assets for full golden-flow demo.

---

## Phase plan

## Phase 0 — IA scaffolding and handoff links

Deliverables:

- Image IA split (`Generation` + `Image weaving` + `Others`)
- Video IA split (Specialist engines / Curated experiments / Video weaving)
- designer footer links (`Send to Video`, `Send to 3D`, `Send to Games`)
- source reference handoff payload contract

Exit criteria:

- user can move assets between tabs without manual file hunting
- handoff metadata (source image + prompt note) persists

## Phase 1 — Character -> Video baseline

Deliverables:

- Character designer v1 (clean full-body output contract)
- Lance video tab stable for character motion baseline prompts
- quick "walk in park" preset template for smoke tests

Exit criteria:

- repeatable character-motion generation with identifiable character continuity

## Phase 2 — Outfit branch and fashion lane

Deliverables:

- Outfit designer v1 (standalone garment concepts)
- Fashion tab (visible `Coming soon` watch mode -> runnable mode when local runtime available)
- apply-outfit flow with reference validation (garment crop checks)

Exit criteria:

- user can generate outfit variants and apply selected outfit to character/video branch

## Phase 3 — 3D and sprite downstreams

Deliverables:

- "Send to 3D" hooks from character/outfit/final output cards
- in-app 3D viewport integration improvements (beyond file reveal)
- "Send to Games" hooks for sprite sheet and costume-part workflows

Exit criteria:

- final styled character can be routed to 3D and sprite lanes in one session

## Phase 4 — Concept scene timeline and production chaining

Deliverables:

- Concept Scene Designer timeline (persistent prompts, shot notes, duration)
- timeline playback preview with `Play/Pause`
- promote-shot-to-polished-reference action
- ingest timeline outputs into Video weaving

Exit criteria:

- user can previsualize scene sequences and carry them into final video mix

## Phase 5 — Showcase readiness

Deliverables:

- golden-flow demo script + canned prompts/assets
- reliability matrix (pass/fail reasons per stage)
- known-limitations list and user-safe fallbacks

Exit criteria:

- team can run end-to-end demo with predictable outcomes and clear fallback paths

---

## Validation matrix (for QA and showcase)

| Flow id | Scenario | Expected outcome |
|---|---|---|
| F1 | Character designer -> Lance walk clip | character identity preserved in motion |
| F2 | Outfit designer -> Fashion apply | outfit transfer visually coherent |
| F3 | Styled final -> LiTo/SHARP | 3D handoff succeeds with clean subject extraction |
| F4 | Styled final -> Games sprite | usable sprite outputs (whole + segmented variants) |
| F5 | Concept scene timeline -> Video weaving | shot order, prompts, and timing persist end-to-end |

---

## Risks and mitigations

| Risk | Impact | Mitigation |
|---|---|---|
| Character drift across video frames | weak continuity | enforce cleaner reference contracts + engine presets |
| Outfit refs too noisy | poor garment transfer | inline crop/background checks before apply |
| 3D failures on cluttered backgrounds | broken meshes/splats | default 3D-ready prompts + optional auto background removal |
| Engine readiness mismatch | blocked handoff links | readiness-gated links with fallback guidance |
| Over-complex UI too early | user confusion | ship per phase; hide advanced controls until needed |
| Too many planning docs | decision drift | keep active task board in this document only |

---

## External watch dependencies

These can power future phases once local-ready:

- Fashion video customization: [FashionChameleon](https://github.com/quanjiansong/FashionChameleon)
- Archviz panorama/world modeling: [PanoWorld](https://github.com/jjrCN/PanoWorld)
- Controllable storyboard-like video generation: [CogOmniControl](https://um-lab.github.io/CogOmniControl/)

---

## Related docs

- `MEDIA_MAGIC_GENERATION_IA_AND_DESIGNERS.md`
- `../generation/video/VIDEO_GENERATION_IA_AND_ENGINE_MAP.md`
- `../generation/threed/THREED_GENERATION_INDEX.md`
- `../generation/WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md`

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05-28 | Added single-source task board and aligned phases with decisions: `Image weaving` top-level mode, Fashion `Coming soon`, and timeline `Play/Pause` |
| 2026-05-28 | Initial phased plan for Character -> Video/Fashion -> 3D/Sprite flow and showcase validation |

