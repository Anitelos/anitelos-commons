# Workshop Terminal — npm dev checks (docs home)

This folder is the **forever home** for *when* and *why* to run Anikai dev commands — especially after **one-line** shell/layout changes that can silently wreck the whole UI.

**Machine-readable registry (sync with code):** [`../../../../../../../../../anikai-desktop/npm/scripts-registry.json`](../../../../../../../../../anikai-desktop/npm/scripts-registry.json)

**Human catalog in repo root:** [`../../../../../../../../../anikai-desktop/npm/README.md`](../../../../../../../../../anikai-desktop/npm/README.md)

**Living spec:** [`../ANIKAI_TERMINAL_LIVING_SPEC.md`](../ANIKAI_TERMINAL_LIVING_SPEC.md)

---

## Start here

| Doc | Use when |
|-----|----------|
| [`DEV_CHECKS_RUNBOOK.md`](DEV_CHECKS_RUNBOOK.md) | You changed layout, panels, dock, chat chrome, or `main.js` window glue |
| [`REGRESSION_GUARDRAILS.md`](REGRESSION_GUARDRAILS.md) | Before merging — checklist + known one-line failure modes |
| [`scripts-registry.json`](scripts-registry.json) | Mirror of desktop registry for agents / future in-app Run picker |

---

## Chat UI entry (shipped stub)

Chat header **≡ menu** → **Workshop Terminal (soon)** shows a hint with `dev:cluster-debug` and this folder path. Full panel is **M1** in the living spec.

---

## How this folder grows

1. Add runbook rows when a regression class appears (date + symptom + npm command).
2. When adding `package.json` scripts, update **both** `anikai-desktop/npm/*` and this folder’s mirror registry.
3. Do not duplicate the full living spec here — link it.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05-22 | Initial npm dev-checks hub + runbook + guardrails + registry mirror |
