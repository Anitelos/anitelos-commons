# Low scope todo

Short bursts: UI polish, single-file fixes, copy tweaks tied to a lane.
