# Model sheet — leejet / FLUX.2-klein-4B-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [leejet/FLUX.2-klein-4B-GGUF](https://huggingface.co/leejet/FLUX.2-klein-4B-GGUF)  
- Base: [black-forest-labs/FLUX.2-klein-4B](https://huggingface.co/black-forest-labs/FLUX.2-klein-4B)  
- Also: [FLUX.2-klein-base-4B-GGUF](https://huggingface.co/leejet/FLUX.2-klein-base-4B-GGUF) (more steps, cfg 4)  
- VAE (ungated): [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae)  

## Pack family

`flux2_llm_vae` — Qwen3 **4B** LLM (not 8B). See [`flux2.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/flux2.md).

## Weight layout

```text
models/klein-4b/
  flux-2-klein-4b-Q4_K.gguf
  vae/flux2_ae.safetensors
  text_encoders/qwen_3_4b-….gguf
```

## Product

- **Preset id:** `flux2_klein_4b_gguf_leejet`  
- **Profile (proposal):** `flux2_klein_4b_gguf` — 1024², 4 steps, cfg 1 (distilled); base variant 20 steps / cfg 4  

## Anikai router

`planned` — generalize `buildFlux2KleinSdArgs` → `buildFlux2LlmPackArgs` with LLM size detection.

## Checklist

- [ ] Router + probe (4B LLM candidates)  
- [ ] E2E smoke  

## Links

- [`MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](./MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
