# Pipeline ↔ engine dependency matrix (Windows + Android reference)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Living matrix |
| **Last reviewed** | 2026-05-20 |

**Platform plan:** [`ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

**Android pipelines:** [`../../../android-arm64/implementations/OPERATIONS_INDEX.md`](../../../android-arm64/implementations/OPERATIONS_INDEX.md)

---

## How to use this table

- **Engine column:** runtime family to bring to **VERIFIED** before pipeline showcase on that platform.
- **Platform:** where the pipeline **authoritative** implementation lives today.
- **Windows tick:** update when smoke passes — not when doc exists.

---

## Portrait / avatar lane

| Stage | Engine(s) | Android | Windows tick | Notes |
|-------|-----------|---------|--------------|-------|
| 4-shot still planner | **GGUF** text (chat brain) | Active | Partial (chat) | [`PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](../../../android-arm64/implementations/generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md) |
| Still generation | **GGUF** image (`sd.exe`) or **Flux** path | Active | Infra shipped; model E2E open | Imaging index |
| Depth overlay (optional) | **ONNX** depth graph | **VERIFIED** (`PortraitDepthOnnxRuntime`) | Not started | `Profiles/portrait-onnx/depth.onnx` |
| Pack manifest | App schema | Active | Port schema | [`PORTRAIT_PACK_SCHEMA.md`](../../../android-arm64/implementations/generation/imaging/PORTRAIT_PACK_SCHEMA.md) |
| Rig test (deterministic) | App rig (no NN) | Active | Not started | [`CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`](../../../android-arm64/implementations/pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md) |
| Motion enhance | **PersonaLive** (`python.personalive` sidecar) | Not started | Desktop-first | [`personalive/...`](../../../android-arm64/implementations/engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) · registry: `motion-sentience-registry.json` |
| ~~FOMM~~ | *(deprecated)* | Legacy probe | — | Not in product plan |
| Phoneme → driving bridge | App synth frames | Not started | Not started | [`PORTRAIT_RIG_MOTION_STRATEGY.md`](../../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md) |
| Animate / presence | App + workers | `PortraitAnimationWorker.kt` | Not started | Reuse contracts; feed PersonaLive stream |

**Kotlin reference (layer 3 adapters):** `Anikai App/.../home/avatar/` — `PortraitDepthOnnxRuntime.kt`, `PortraitPackManifest.kt`, `AnimaAvatarPack.kt`, …

**Home workforce:** `PortraitPipelineWorkforce.kt`, `PortraitWorkforceSwarmCoordinator.kt`

---

## Sprite / Game Maker lane

| Stage | Engine(s) | Android | Windows tick | Notes |
|-------|-----------|---------|--------------|-------|
| Concept → tidy still | **GGUF** Flux-class + optional vision | Active | GGUF infra | [`SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md) |
| Post upscale / refine | **ONNX** x4-class | Active | Not started | Android ONNX generation plan |
| Sheet / motion planning | **GGUF** text + app logic | Active | Not started | |
| Motion / FOMM | **FOMM** ONNX pack | Readiness in settings | android-only | `SpriteMakerModelReadiness.kt` |
| Export | App | Active | Not started | Game Maker direction on Windows |

**Kotlin reference:** `SpriteSheetMakerScreen.kt`, `SpriteMakerModelReadiness.kt`, `SpecialistDownloadAssign.kt`

---

## Voice / speaking (Sentience)

| Stage | Engine(s) | Android | Windows tick | Notes |
|-------|-----------|---------|--------------|-------|
| Companion TTS reply | **Piper / Kokoro / ONNX voice** / etc. | Partial | Probes only | `voice-registry.json`; `sentience-runtime-probe.js` |
| Singing / articulations | **ONNX** + future lanes | Planned | Planned | Lane 5 gap in audio overview |

---

## Chat / reasoning (cross-cutting)

| Stage | Engine(s) | Android | Windows tick | Notes |
|-------|-----------|---------|--------------|-------|
| Segment loop | **GGUF** `llama-server` | Active | Active | Thought/final pipeline |
| Vision attach | **GGUF** + mmproj | Active | Active | mtmd path |
| ASR / hearing | **GGUF** whisper-class | Partial | Probe | `hearing-registry.json` |

---

## Curated multi-lane (Suno-class)

| Stage | Engine(s) | Android | Windows tick | Notes |
|-------|-----------|---------|--------------|-------|
| Quick music | DSP + MIDI | Partial | **Lane 1–2 shipped** | [`CURATED_SUNO_CLONE_PIPELINE.md`](../pipelines/CURATED_SUNO_CLONE_PIPELINE.md) |
| Neural music | **Python** + codec model | Planned | Planned | Lane 4 |

---

## Engine family platform fit (Windows hub)

| Family | Windows | Notes |
|--------|---------|-------|
| **GGUF** | **active** | Primary desktop stack |
| **ONNX Runtime** | **active** (bring-up) | Portrait depth, sprite post, voice — not imaging-only |
| **FluidSynth / MIDI** | **active** | Lane 2 |
| **Voice packs** (Piper, …) | **active** (staged) | Separate from ORT unless graph is `.onnx` |
| **Python media** | **active** (sidecar) | Diffusers / neural audio |
| **FOMM** | **stub → policy** | May use ORT on Windows; Android uses QNN path — do not assume identical pack |
| **PersonaLive** | **active (bring-up)** | PyTorch sidecar + weights; not generic ORT — portrait + driving stream |
| **LiteRT, QNN, HiAI, Samsung ENN, AICore, NNAPI** | **android-only** | Document in hub; no Windows implementation |
| **NCNN, OpenCV DNN, MNN, TVM, …** | **stub** | Promote when a pipeline needs them |

---

## Suggested tick order (Windows)

1. **GGUF image** — one txt2img **VERIFIED** (enables 4-shot stills later).
2. **ONNX runtime adapter** — EP probe + one post graph **VERIFIED**.
3. **ONNX depth** — port `PortraitDepthOnnxRuntime` behavior (smoke: overlay from `depth.onnx`).
4. **Voice runtime pack** — one TTS family **VERIFIED** (Kokoro or Piper).
5. **FOMM policy doc** — decide Windows pack layout before sprite motion showcase.
6. **Pipeline UI ports** — 4-shot, then sprite, then rig (mostly layer 3).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial matrix from Android portrait/sprite/avatar code layout + Windows workshop strategy. |
