# TODO — Game Maker showcase orchestration (high scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Game Maker is the parent showcase operation: prompt-first UX with deep, chained media workflows (image, audio, workspace, and later awareness-driven character behavior).

---

## Parent operation status model (no finality lock)

- `Not started`
- `In progress`
- `Operational`
- `Needs revisit`

`Operational` means "works at current bar." It does not mean final or perfect.

---

## Dependency checklist (child operations)

- [ ] **Local media execution backbone is operational**  
  Source: [`../../../../../../02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`](../../../../../../02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md)

- [ ] **Sprite/character visual bar is operational**  
  Source: [`../../implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](../../implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md)

- [ ] **Imaging pipeline stages are operational (S1 diffusion -> S3 ONNX post -> one-button path)**  
  Source: [`../../implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`](../../implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md)  
  Child todo: [`../mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`](../mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md)

- [ ] **Portrait creator flow is operational (4-shot -> animation handoff)**  
  Source: [`../../implementations/generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](../../implementations/generation/imaging/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md)

- [ ] **Pack/output schema is operational for runtime ingestion**  
  Source: [`../../implementations/generation/imaging/PORTRAIT_PACK_SCHEMA.md`](../../implementations/generation/imaging/PORTRAIT_PACK_SCHEMA.md)

- [ ] **Kokoro lane is operational at current quality bar**  
  Source: [`../../implementations/generation/audio/voice/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md`](../../implementations/generation/audio/voice/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md)

- [ ] **Kitten lane is operational at current quality bar**  
  Source: [`../../implementations/generation/audio/voice/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md`](../../implementations/generation/audio/voice/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md)

- [ ] **Voice+music workforce pipeline is operational (lyric -> generation -> mix -> optional voice layer)**  
  Source: [`../../implementations/pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`](../../implementations/pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md)  
  Child todo: [`../shelved/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md`](../shelved/TODO_VOICE_MUSIC_WORKFORCE_PIPELINE.md)

- [ ] **Operations board stays synced while subjects change**  
  Source: [`../../implementations/OPERATIONS_INDEX.md`](../../implementations/OPERATIONS_INDEX.md)

---

## Current interpretation (tonight scope)

- Game Maker remains **parent** to local media and other deep tracks.
- Implementation docs stay the story source.
- Todos are execution handles linked directly to those implementation docs.
- If subject changes, log it here and add/retarget child todo rows rather than creating new doc mazes.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created parent high-scope Game Maker operation todo and linked direct child implementation sources. |
| 2026-05-06 | Added voice runtime parity dependency for dynamic NPC and companion voice depth. |
| 2026-05-06 | Added mixed voice+music workforce pipeline dependency with dedicated child todo. |
| 2026-05-06 | Split voice dependencies into per-engine checkboxes (Kokoro/Cosy/XTTS) and repointed mixed pipeline source to `implementations/pipelines/`. |
| 2026-05-06 | Added Kitten/VITS/cloud provider dependencies to parent Game Maker checklist. |
| 2026-05-06 | Trimmed mobile Game Maker voice lanes to lean pair (Kokoro + Kitten) to avoid todo bloat. |
