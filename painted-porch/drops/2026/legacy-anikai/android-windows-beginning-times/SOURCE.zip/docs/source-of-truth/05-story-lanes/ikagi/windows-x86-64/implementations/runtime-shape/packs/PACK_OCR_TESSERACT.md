# OCR runtime pack (Tesseract)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.ocr.tesseract` |
| **Tier** | B |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Screen/PDF text without running 7B VLM every time; copilot + document ingest.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

tesseract.exe + traineddata subset (eng default).

## Staging path

`desktop-data/runtime-packs/ocr.tesseract/`

## Unlocks (no model weights)

screen-ocr, pdf-text-layer

## Verification smoke

OCR test PNG fixture.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
