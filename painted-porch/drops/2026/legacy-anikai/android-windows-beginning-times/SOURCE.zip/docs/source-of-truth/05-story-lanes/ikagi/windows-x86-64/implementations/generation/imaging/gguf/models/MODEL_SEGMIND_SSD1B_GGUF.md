# Model sheet — Segmind SSD-1B (distilled SDXL, GGUF)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [segmind/SSD-1B](https://huggingface.co/segmind/SSD-1B)  
- sd.cpp: [`distilled_sd.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/distilled_sd.md)  

## Pack family

`distilled_sdxl` — often loads as **`sdxl_single_m`** or single `-m` if converted to GGUF; smaller UNet, faster inference.

## Product

- **Preset id:** `ssd1b_gguf`  
- **Profile:** share `sdxl_gguf` with note for fewer steps  

## Anikai router

`planned` — detect `ssd-1b`, `ssd1b` in basename → `distilled_sdxl` or `sdxl_single_m`.

## Checklist

- [ ] Convert/smoke GGUF if not pre-quantized  
- [ ] E2E  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
