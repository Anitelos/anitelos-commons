# MNN engine inference implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define MNN as ANIKAI's optional high-performance mobile inference lane with auto-tuning/device-adaptive execution strategy for model families that are stubborn or suboptimal on current ONNX/LiteRT paths.

---

## Scope

This file covers MNN for:

- general-purpose mobile inference fallback/alternative lane,
- device-adaptive backend tuning strategy (CPU/GPU/Vulkan/OpenCL as supported),
- helper and specialist task packs in model hub,
- lane-level integration for Swarm/Curiosity surfaces.

This file does **not** replace generation or pipeline contracts.

---

## Why this runtime matters for ANIKAI

MNN is a pragmatic wildcard runtime when existing lanes are inconsistent for a target model/device combo.

ANIKAI value:

- additional route for models that underperform on ONNX/LiteRT,
- device-tuned execution policy that supports the "UI forms around your hardware" vision,
- stronger per-device sovereignty without forcing one runtime everywhere.

Rule: MNN claims are valid only with adapter + manifest + tuning/session pass + explicit output schema.

---

## Role model (single truth)

| MNN lane | Ownership |
|----------|-----------|
| **Companion primary text** | Optional, only if quality/latency validated. |
| **Vision/helper specialists** | Strong candidate lane. |
| **Swarm specialist tasks** | Allowed with explicit adapter resolution and pass criteria. |
| **Generative primary media** | Only when explicitly proven and documented per target. |

---

## Android implementation plan

### 1) Runtime strategy

- define when MNN is preferred over ONNX/LiteRT for a pack,
- capture auto-tuning output as diagnostics metadata,
- expose tuning fallback behavior to maintain trust.

### 2) Adapter/session checklist

- [ ] MNN adapter family registered in engine model hub.
- [ ] Session init validates tensor contracts and output schemas.
- [ ] Tuning/benchmark path has timeout and fallback policy.
- [ ] Lifecycle and cancellation are stable under repeated runs.
- [ ] Degraded states are explicit and user-visible.

### 3) Manifest contract

Each MNN pack row includes:

- adapter id + task family,
- backend/tuning policy hints,
- expected model format/version constraints,
- input/output schema requirements,
- lane eligibility and preset suggestions.

---

## App integration map

### A) Model hub and capability packs

- show `MNN` engine badge and capability badges,
- surface runtime placement and per-device suitability hints,
- keep role count and lane bindings visible.

### B) Swarm + Curiosity integration

- bind MNN packs to specialist lane ids where useful,
- ensure sensory features appear only when packs are installed/passing,
- retain explicit source labels in outputs/logs.

### C) Runtime policy coherence

- align MNN fallback semantics with GGUF/ONNX/LiteRT/NCNN policies,
- prevent silent runtime switching that hides degraded quality.

---

## Phased delivery

### Phase 0 - schema and policy

- define MNN manifest fields and runtime policy table.

### Phase 1 - first operational helper pack

- ship one end-to-end helper pack with artifact validation.

### Phase 2 - tuning and device class hardening

- stabilize auto-tuning behavior and fallback boundaries.

### Phase 3 - model-family expansion

- broaden MNN pack catalog where it outperforms existing lanes.

---

## Verification gates (before "operational" claim)

- at least one MNN pack operational on target device classes,
- output artifact/schema is consumable by lane contract,
- tuning/fallback behavior deterministic and logged,
- no hidden cloud substitution for failed local run.

---

## Open decisions

- first operational MNN pack target,
- tuning timeout and caching strategy,
- criteria for preferring MNN over ONNX/LiteRT by lane.

---

## Linked todos

- `todo/mid-scope/TODO_MNN_ENGINE_INFERENCE_INTEGRATION.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial MNN engine inference implementation plan added for runtime-family coverage. |
