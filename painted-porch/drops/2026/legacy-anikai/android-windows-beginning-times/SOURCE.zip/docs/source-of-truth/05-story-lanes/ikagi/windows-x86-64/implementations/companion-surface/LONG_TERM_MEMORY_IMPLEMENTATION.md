# Long-term memory (LTM) — implementation spec (Windows desktop)

**Status:** Phase A shipped · Phase B in progress (persona refresh, LTM %, journal refs, greeting journal).  
**Owner lane:** `ikagi / windows-x86-64 / companion-surface`  
**Backlog:** [COMPANION_DEFERRED_BACKLOG.md](./COMPANION_DEFERRED_BACKLOG.md) §1 (priority #1)  
**Related:** [BOND_JOURNAL_IMPLEMENTATION.md](./BOND_JOURNAL_IMPLEMENTATION.md) (bond MD + soul metrics — **separate store**) · [SUPER_COMPANION_ROADMAP.md](./SUPER_COMPANION_ROADMAP.md) §7

> **Reply / inject authority:** [`anikai-desktop/docs/COMPANION-INFERENCE-SPEC.md`](../../../../../../anikai-desktop/docs/COMPANION-INFERENCE-SPEC.md). LTM inject is a **lean feel block** on eligible turns only — not full transcript replay, not persona re-dump on KV-warm steady chat. Tool turns use task lane (journal/LTM blocks in thought), not full voice/persona inject.

---

## 1. Goal

Give each companion a **distilled continuity layer** that survives context compress, thread rollover, and app restart — so they still *feel* like they know you without replaying the transcript or dumping raw journal files into every prompt.

LTM is **not** a second bond journal. Bond journal = companion-authored life prose (categories, diary, milestones). LTM = **compact, inject-oriented facts and working patterns** shaped like Notes (feel, don’t recite).

Phase A proves: **write → promote → inject → survive compress**.

---

## 2. Bond journal vs LTM

| | Bond journal (`journal/`) | Long-term memory (`long-term/`) |
|--|---------------------------|----------------------------------|
| **Tone** | Poetic life log, dated MD sections | Plain distilled lines + one inject summary |
| **Author** | Companion via `journal_*` tools | Companion via `memory_distill` + system promotion hooks |
| **Prompt use** | Category map + index summary on eligible turns | **Short inject block** (~400–700 chars) on eligible turns |
| **UI** | Studio → Journal tab | Studio → Metrics (read-only v1) + future chat panel |
| **After reset chat** | Kept | Kept |
| **Survives compress** | Files yes; *chat* may forget until re-injected | **Purpose-built** to re-inject after compress |

**Rule:** Journal can be long; LTM must stay **lean**. Promote summaries, not whole MD files.

---

## 3. Storage layout

Root: `{ANIKAI_HOME}/companions/{companion-id}/long-term/`

```
companions/{companion-id}/
  journal/                 # unchanged — bond MD, soul-metrics.json, handoffs
  long-term/
    index.json             # entry registry + stats
    profile.json           # inject snapshot (regenerated from entries + soul metrics)
    entries.jsonl          # one JSON object per line — durable goodies
```

### `entries.jsonl` row (schema `anikai.ltmEntry.v1`)

```json
{
  "id": "ltm_20260614_a1b2",
  "at": "2026-06-14T18:30:00.000Z",
  "kind": "preference",
  "text": "Jay prefers preview image runs first, full quality only when he asks.",
  "source": "tool:memory_distill",
  "sourceRef": "journal/interests/image-workflow.md",
  "threadScope": "any",
  "confidence": 0.85,
  "supersedes": null,
  "journalRef": { "file": "interests/jay.md", "lines": [120, 130] },
  "mentions": 3,
  "lastMention": "2026-06-14T20:00:00.000Z",
  "eventDate": null
}
```

| Field | Values |
|-------|--------|
| `kind` | `preference` \| `working_pattern` \| `fact` \| `relationship` \| `project` \| `boundary` \| `milestone` |
| `source` | `tool:memory_distill` \| `promote:journal_write` \| `promote:compress_sweep` \| `promote:milestone` \| `import:bond_bootstrap` |
| `threadScope` | `any` (v1 default) — Phase B adds `solo` \| `group` gating for inject |
| `journalRef` | Optional link to bond journal file + line range — model may `journal_read` when relevant, not every turn |
| `mentions` | Repeat-topic counter (dedup bumps within 7 days) — inject summary may note "mentioned 3×" for persona reactions |
| `eventDate` | ISO date for `milestone` entries (special days linked to journal prose) |

**Dedup:** Same normalized `text` (trim, lower, collapse space) within 7 days → update `at`, bump `mentions` + `lastMention`, no duplicate line.

**Supersede:** New entry may set `supersedes: "ltm_…"`; old row stays on disk but excluded from inject.

### `profile.json` (schema `anikai.ltmProfile.v1`)

```json
{
  "schema": "anikai.ltmProfile.v1",
  "companionId": "uuid",
  "updatedAt": "2026-06-14T18:30:00.000Z",
  "entryCount": 12,
  "injectSummary": "Working with Jay: equal teammate energy; he likes synthwave and direct image runs after we've shipped a few things together. Don't reopen helpdesk tone. Propose first on big multi-character sets unless he says go.",
  "soulMirror": {
    "relationshipLabel": "Long friends",
    "affinityScore": 68
  },
  "stanceHints": {
    "planningMode": "propose",
    "notes": "Derived soft hint only — Notes field always wins."
  }
}
```

- `injectSummary` — **only** field intended for chat prompt (regenerated, max **700** chars).
- `soulMirror` — copied from `journal/soul-metrics.json` on regenerate (read-only mirror).
- `stanceHints.planningMode` — soft signal for future §9 work plans (`propose` \| `execute` \| `auto`); Phase A sets from affinity bands only (see §6).

### `index.json`

```json
{
  "schema": "anikai.ltmIndex.v1",
  "version": 1,
  "companionId": "uuid",
  "updatedAt": "…",
  "entryCount": 12,
  "lastPromoteAt": "…",
  "lastInjectAt": null
}
```

---

## 4. Phase A — Foundation (implement first)

**Outcome:** Companions and the compress hook can distill durable lines; chat receives a lean LTM block on eligible turns; compress no longer amnesia-wipes working relationship feel when journal + LTM exist.

### 4.1 Main-process store

| Task | Detail |
|------|--------|
| Layout | `ensureLongTermLayout(anikaiHome, companionId)` — create `long-term/`, empty `entries.jsonl`, default `profile.json`, `index.json` |
| Paths | Extend `main-process/companion-paths.js` with `companionLongTermHome()` |
| CRUD | `main-process/companion-long-term-memory.js` — append entry, list recent, read profile, regenerate profile, bootstrap import |
| Regenerate | `regenerateInjectSummary(entries, soulMetrics, personaNote?)` — deterministic v1: top 8 entries by kind priority + affinity band text; cap 700 chars |
| Bootstrap | One-time optional `importFromBondJournal()` — scan journal index for `interests`, `goals`, `bond/user-preferences.md`; create `import:bond_bootstrap` rows (max 20, user-visible count in Metrics) |

### 4.2 Shared module

`shared/companion-long-term-memory.js`:

- Schema constants, kind enums, normalize entry, dedup key
- `formatLongTermMemoryPromptBlock(profile, opts)` — wrapper:
  ```
  Long-term memory (feel only — never quote verbatim):
  {injectSummary}
  ```
- `detectLongTermMemoryEligibleTurn(userText, ctx)` — mirror bond eligibility, **exclude** casual solo/group “hi”
- `buildLtmCompressSweepInstructionBlock()` — system-side sweep text (paired with journal refresh)

### 4.3 Companion tools (Phase A: one write tool)

| Tool | Purpose | Key attrs |
|------|---------|-----------|
| `memory_distill` | Append distilled LTM entry | `text` (required), `kind?`, `threadScope?`, `confidence?` |

- Registered in `companion-skills.js` + `executeThoughtSegmentTools` path (same as journal tools).
- On success: regenerate `profile.json`; optional chat ack line: ``Noted (long-term) → `long-term/entries.jsonl` `` (monospace, no wall of text).

**Not in Phase A:** `memory_list`, `memory_forget`, user edit UI — defer to Phase C.

### 4.4 Promotion hooks

| Hook | When | Action |
|------|------|--------|
| **Journal write** | `journal_write` / `journal_create` success with category `interests`, `goals`, or `bond` + attr `durable="true"` | Append `promote:journal_write` row: first sentence of `text`, max 200 chars |
| **Context refresh @ 90%** | Existing journal sweep pass (`companion-context-refresh.js`) | Append `buildLtmCompressSweepInstructionBlock()` — companion may emit `memory_distill` for facts that would die in compress |
| **Milestone** | `journal_milestone` success | Append `promote:milestone` row from `title` + `note` |

Order on compress trigger: **journal sweep instruction → LTM sweep instruction → compress history** (same turn/system pass, not user-visible).

### 4.5 Chat inject

In `buildGgufPlanningPrompt` (`chat.js`):

- Fetch block via IPC `ltm:prompt-block` when `detectLongTermMemoryEligibleTurn` true (including casual bonding turns — no `socialOnlyTurn` gate).
- Inject **after** persona/Notes, **before** bond journal map (LTM is shorter; journal stays for reflective deep turns).
- Skip inject only on `creativeContentTurn` (fiction/story mode) or when detector returns false.
- Max inject: 700 chars summary + wrapper (~750 total).
- **Capability map** (separate from LTM): pinned once per companion per thread; full JSON reinjected on map change, context compress/rollover, or media-intent turns — not every message.

Eligible (Phase A):

- Reflective / bonding tone (same detector family as bond journal)
- Post-compress turn (flag from context refresh)
- Explicit memory ask (“remember”, “what do you know about me”)
- Session continuity block present with gap bucket ≠ `same_session` (re-entry)
- Media project continuation (thread had recent media + user continues topic)

### 4.6 Affinity → stance hint (soft, Phase A only)

When regenerating profile:

| `affinityScore` | `stanceHints.planningMode` |
|-----------------|----------------------------|
| 0–34 | `propose` |
| 35–64 | `propose` |
| 65–84 | `propose` (Phase D may flip to `auto` when Notes allow) |
| 85+ | `execute` hint only if ≥3 LTM `working_pattern` or `project` entries exist |

**Never** auto-run tools from LTM in Phase A — hint is prompt-only for future §9.

### 4.7 IPC

| Channel | Purpose |
|---------|---------|
| `ltm:ensure-layout` | Create folders |
| `ltm:list-entries` | Recent entries for Metrics UI |
| `ltm:get-profile` | Full profile.json |
| `ltm:prompt-block` | Lean block for chat |
| `ltm:distill` | Main-process append (tool handler) |
| `ltm:regenerate-profile` | Force rebuild inject summary |
| `ltm:bootstrap-from-journal` | One-time import |

Preload: mirror names on `window.anikai.*`.

### 4.8 Studio UI (read-only v1)

**Location:** Companion Studio → **Metrics** tab — new subsection **Long-term memory** (below soul metrics).

- Show `injectSummary` (read-only textarea or pre)
- Entry count + last updated
- Expandable list: last 10 `entries.jsonl` rows (kind + text + date)
- Button: **Rebuild summary** → `ltm:regenerate-profile`
- Button: **Import from bond journal** (once) → bootstrap
- **No delete/edit** in Phase A (Phase C)

### 4.9 Smoke test

`scripts/smoke-companion-ltm.cjs`:

1. Ensure layout for temp companion id
2. Append 3 entries via distill API
3. Regenerate profile — injectSummary non-empty, ≤700 chars
4. Dedup same text twice → one row updated
5. `formatLongTermMemoryPromptBlock` contains summary, not raw jsonl
6. Bootstrap from fake journal index → ≤20 rows

### 4.10 Files to add/touch

| Area | Path |
|------|------|
| Spec (this doc) | `implementations/companion-surface/LONG_TERM_MEMORY_IMPLEMENTATION.md` |
| Store | `main-process/companion-long-term-memory.js` |
| Shared | `shared/companion-long-term-memory.js` |
| Paths | `main-process/companion-paths.js` |
| Context refresh | `shared/companion-context-refresh.js` (LTM sweep line) |
| Skills | `main-process/companion-skills.js`, `shared/thought-segment-tags.js` (tool name) |
| Chat | `components/chat.js` |
| Metrics UI | `components/panels.js` |
| IPC | `main.js`, `preload.js` |
| Smoke | `scripts/smoke-companion-ltm.cjs` |

### 4.11 Phase A acceptance

1. User tells Rose a preference → companion `memory_distill` → row in `entries.jsonl` + profile regenerated.
2. After simulated compress (history limits shrunk), next eligible turn injects LTM block — companion reply reflects preference without transcript replay.
3. `journal_write` with `durable="true"` promotes one LTM line automatically.
4. Context refresh @ 90% includes LTM sweep instruction alongside journal sweep.
5. Casual “hi” turn has **no** LTM block in prompt (token check).
6. Reset chat does **not** delete `long-term/`.
7. Metrics tab shows inject summary + entries.
8. `node scripts/smoke-companion-ltm.cjs` passes.

### 4.12 Phase A out of scope

- Cross-thread privacy tiers (`threadScope` stored but not enforced — Phase B)
- Chat collapsible LTM inspector panel (Phase C)
- Merge/conflict UI when user changes mind (Phase B)
- Affinity-gated auto-execute / in-flight innovation (deferred backlog §10)
- User “clear long-term memory” (Phase C with confirm)
- Familiars get LTM (companions only, same as bond journal)

---

## 5. Phase B — Context-smart inject & journal linking (in progress)

**Depends on Phase A.** Implements the "feel the snap on rollover" vision without dumping persona + notes every turn.

| Feature | Behavior |
|---------|----------|
| **LTM % in context meter** | `meta.ltmTokens` / `ltmPct` on inference meta; context ring tooltip shows LTM slice vs window |
| **Persona refresh buckets** | Full persona pack + Notes on session opener, context refresh @ 90%, and every **10%** context bucket; between refreshes inject **Notes-only** compact block |
| **Greeting journal + LTM** | First hello (`priorAiInThread < 2`): bond journal tool hint + compact LTM inject (if profile exists) — companions may `journal_write` casual first entry in thought |
| **LTM `journalRef` + `mentions`** | `memory_distill` attrs `journalRef="file:lines"`; dedup bumps `mentions`; inject summary surfaces repeat topics |
| **`milestone` kind** | `journal_milestone` promotes with `eventDate`; special days as dated LTM rows linking journal prose |
| **Session-end journal** | `buildSessionEndJournalInstruction` for GPU-idle queue (Anam Cara / break) — deferred wiring to availability break hook |
| **Companion own interests** | `journal_write` with `about="self"` + category `interests` — distills to LTM on `durable="true"` promote |
| **Tone drift from LTM** | Affinity + relationship + mention-rich LTM lines shape inject summary; Notes still win; demoness teasing may soften when LTM captures shared success (prompt-only, no auto-behavior) |

**Not Phase B:** Archivist daily report companion, forced journal file scans, cross-companion bond store.

---

## 6. Phase C — Compress amnesia & merge

**Depends on Phase A.**

- Smart merge when new entry contradicts old (`supersedes` chain; inject excludes superseded)
- Post-compress **mandatory** profile regenerate if any `memory_distill` ran in sweep turn
- Journal index reconciliation job (orphan promote flags)
- Enforce `threadScope` on inject (solo thread vs group thread)
- See deferred backlog §2

---

## 7. Phase D — User-facing memory UI

- Chat thread collapsible **Memory** panel (like thought/tools) — shows inject summary + recent entries
- Studio: edit/delete entry with confirm
- **Clear long-term memory** (companion-scoped, confirm string)
- Optional: pin entry to always include in inject

---

## 8. Phase E — Affinity & work-plan gates

**Depends on Phase A + specialist work plans (backlog §9).**

- `stanceHints.planningMode` drives propose vs execute vs auto in work-plan runner
- High affinity + Notes permission → companion may skip proposal (backlog §10)
- LTM records successful project count (“shipped 3 image batches with Jay”)

---

## 9. Integration with existing systems

| System | Interaction |
|--------|-------------|
| Bond journal | Source for promotion; soul-metrics mirrored into profile |
| Context refresh | LTM sweep before compress |
| Session continuity | Eligible-turn signal for inject |
| Notes | Notes win over LTM stance; LTM never copies Notes verbatim into inject |
| Reset chat | Does not wipe LTM |
| Reset bond (future) | Optional separate confirm; Phase A does not implement |

---

*Last updated: 2026-06-15 — Phase B in progress (LTM %, persona buckets, journal refs, greeting journal).*
