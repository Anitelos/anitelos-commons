# Model sheet — GFPGAN (face restore ONNX)

| Field | Value |
|-------|-------|
| **Family** | `onnx_face_restore` |
| **Get pack** | [HowToSD/GFPGAN-ONNX](https://huggingface.co/HowToSD/GFPGAN-ONNX) → `models/onnx/gfpgan/GFPGANv1.4.onnx` |
| **Upstream** | [TencentARC/GFPGAN](https://github.com/TencentARC/GFPGAN) (original weights) |

Optional face cleanup after txt2img or before portrait motion. **Media Magic → Image** post-process row: **Face restore** (`onnx_gfpgan`). Runs at 512² infer, writes full-resolution PNG.
