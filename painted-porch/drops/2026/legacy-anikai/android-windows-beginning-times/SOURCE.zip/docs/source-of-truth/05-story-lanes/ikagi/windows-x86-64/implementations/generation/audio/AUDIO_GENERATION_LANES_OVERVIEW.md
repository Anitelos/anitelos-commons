# Audio generation lanes overview (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-20 |

Purpose: explain — in plain language — **how audio generation actually works on a local-first stack**, so the About guide, panels, and pipeline docs can all point to the same mental model. This is the teaching doc; capability tables, manifests, and per-engine plans live in their own files and link here.

This doc does **not** replace:

- the GGUF music lane plan: [`./music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](./music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md)
- Android music reference: [`../../../../../android-arm64/implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](../../../../../android-arm64/implementations/generation/audio/MUSIC_GENERATION_IMPLEMENTATION_PLAN.md)
- the curated pipeline docs under [`../../pipelines/`](../../pipelines/)

---

## Mental model — three flows

Every audio generator (Anikai’s or anyone else’s) is one of these:

| Flow | What the “brain” outputs | What turns that into sound |
|------|--------------------------|----------------------------|
| **Symbolic** | Notes, chords, tempo, lyrics — text-like instructions | A separate **renderer** (synth, sampler, or soundfont) plays the instructions |
| **Codec-token (neural)** | Compressed “audio tokens” — discrete IDs in a learned vocabulary | A **neural codec decoder** expands tokens back into a PCM waveform |
| **Waveform direct** | The PCM samples themselves | Nothing — it is already audio |

Everything below maps onto one of those three.

---

## The lanes Anikai will ship (ordered cheapest → richest)

### Media Magic → Audio → Compose (UI)

The desktop **Compose** sub-tab mirrors the Suno-clone graph: shared **BPM + bars/seconds**, then **Lyrics → Voice → Instrumental** (collapsibles). **Assembly**, **Voice Weaving** (authoring), and **SFX** are separate Audio sub-tabs. A header chip reorders **instrumental-first** vs **lyrics & voice first**. See [`../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md`](../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md), [`./voice/VOICE_WEAVING_MEDIA_MAGIC.md`](./voice/VOICE_WEAVING_MEDIA_MAGIC.md), and [`../../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](../../companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md).

### Tool vs model

Lanes 1 and 2 are **tools** — pure code (DSP) and renderers (FluidSynth-class) that operate on parameters or MIDI. Any companion with a chat / reasoning model can call them. Persona presets like **Musician** and **Audio engineer** (already shipped) bias *how* the prompt is planned; they do not gate access. Lanes 3–5 require model files and may be slotted per companion.

### Lane 1 — Parametric / DSP composer

- **No AI model. A tool.** Pure code-driven music theory.
- Pick `tempo / scale / mood / length` → code generates chord progressions, drum patterns, bass lines.
- Code runs DSP — oscillators (sine / saw / square) + envelopes + reverb / delay → `.wav`.
- This is how 1980s synthesizers and 1990s game music actually worked.
- **Ship value:** zero download, runs on a potato, deterministic, guaranteed-local. Honest baseline even with no model installed.
- **Limits:** no learned timbre, no vocals, no production polish.

### Lane 2 — MIDI + soundfont / SFZ

- MIDI is *instructions* (“play C3 with velocity 80 on channel 1 for 0.25s”).
- A **soundfont** (`.sf2`) or SFZ is a zip of real recorded instrument samples — a real piano was sampled at multiple velocities, packed into one file.
- A composition plan (rule-based or from a tiny LM) → MIDI → soundfont renderer (e.g. FluidSynth) → `.wav`.
- A tiny GGUF chat / music LM can output MIDI or ABC notation — it is just text. Same lane.
- **Ship value:** with a decent soundfont this can sound surprisingly legit (film score pads, simple orchestral). Free, fast, totally local.
- **Built-in soundfont (Q1 decided):** **FluidR3_GM.sf2** (~141 MB, MIT, General MIDI). Staged via `npm run stage-fluidr3-gm` — see [`anikai-desktop/assets/soundfonts/fluidr3-gm/STAGING.md`](../../../../../../../../anikai-desktop/assets/soundfonts/fluidr3-gm/STAGING.md) and [`MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md`](./MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md). Users may add their own `.sf2` later; *generating* instrument samples is a future lane (RAVE-class / neural SFZ), kept separate from this one.

### Lane 3 — ONNX SFX one-shot / short loop

- Single `.onnx` per effect-class. Prompt tags or short text → short clip (foley, UI sound, sweep, ambience tile).
- Same engine plumbing as imaging upscalers (ONNX Runtime).
- **Ship value:** small, cheap, slots into game / pipeline / chat-tool use without bringing in heavy music backends.

### Lane 4 — Neural codec-token music models (Stable Audio Open / MusicGen / AudioLDM 2)

This is the lane that needs the most explaining.

- You **cannot** train a transformer on raw 44 100-samples-per-second PCM — context windows blow up. So someone trained a **neural audio codec** that compresses audio into discrete tokens like text. Names you will see: **Encodec** (Meta), **DAC** (Descript), **SoundStream** (Google), or a model-specific autoencoder.
- A huge transformer is then trained to predict the next audio token given a text prompt.
- At inference: prompt → tokens → codec decoder → PCM at 44.1 / 48 kHz.
- Open-weight examples Anikai can route:

| Model | Codec | Length / output | Notes |
|-------|-------|------------------|-------|
| **MusicGen** (Meta) | Encodec | 30 s, instrumental, prompt or melody | Solid, license-permissive |
| **Stable Audio Open** | Custom autoencoder | up to 47 s, instrumental + SFX | Stability AI, commercial-friendly |
| **Stable Audio Open Small** | same | shorter / smaller weights | Runs on more hardware |
| **AudioLDM 2** | VAE + diffusion (same idea, different math) | music + general audio | Diffusers pipeline |

- **Engine on Windows:** Python service (Diffusers / Transformers), same pattern as FLUX / Qwen-Image. No new C++ engine for day one.

### Lane 5 — Singing voice (separate problem, lane gap)

- Singing voice synthesis is its **own** model class, not the same as instrumental music gen.
- Conditioned on **lyrics + melody + voice timbre**.
- Open source has DiffSinger / VITS-singing variants / RVC-class models. Quality is well below proprietary tier today.
- **Anikai stance:** flag this as a known gap. Surface it in the curated Suno-clone pipeline doc with “planned, depends on open singing model” status. Do not silently substitute a TTS model for singing.

---

## What Suno / Udio actually are

Not one model. A pipeline they do not show:

```
1. Lyrics input ─┐
                 ├─→ Lyrics + structure planner (an LLM)
2. Style prompt ─┘   → verse/chorus structure, key, tempo, lyric timing

3. Instrumental codec-token model (Lane-4 family but ~10–50× larger,
   trained on enormous undisclosed datasets)
                     → instrumental audio tokens

4. Vocal model (separate, Lane-5 family)
   conditioned on lyrics + inferred melody + a learned voice timbre
                     → vocal audio tokens

5. Codec decoder + DSP mix
                     → 48 kHz stereo .mp3
```

The “magic” is three things, none of them architectural secrets:

1. **Scale** of the transformer.
2. **Data** — massive scraped commercial music (the subject of active lawsuits).
3. A **separate** vocal model that open source has not matched yet.

This is why Anikai treats Suno-style output as **a curated pipeline of multiple models**, not a single feature.

---

## Anikai promise model (honesty contract)

- The **app** ships and validates **working models and engines**.
- The **user** composes pipelines and supplies the right model files for the lane they want.
- We never label a parametric/MIDI output as “neural music”, never silently swap a TTS engine for a singing model, never imply Suno-tier vocals from a non-singing model.
- A cloud / API lane (Suno API, ElevenLabs, etc.) is **not** in scope for the local-first phase; when it lands later, it must be **explicitly labeled** as cloud — same rule as the Android plan.

---

## Desktop status (Windows x86-64, 2026-05)

| Lane | Desktop status | Chat tool | Notes |
|------|----------------|-----------|-------|
| **1 — Parametric DSP** | **Shipped** | `generate_music_dsp` | `parametric-wav-composer.js` → WAV; Media Magic “Generate DSP sketch”; keyboard record UI remains Lane 1 play-only. |
| **2 — MIDI + soundfont** | **Shipped** (dev) | `generate_music` | FluidSynth + FluidR3; theme GM instruments; JSON/ABC plans; `arranger="gguf"` uses chat slot → JSON → render. **Stage:** `npm run stage-audio-midi` (not in installer yet). |
| **3 — ONNX SFX** | Planned | — | |
| **4 — Neural codec-token** | Planned | — | Stable Audio Open / MusicGen class. |
| **5 — Singing voice** | Planned (gap) | — | Honest pipeline gap. |

Implementation detail: [`MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md`](./MIDI_SOUNDFONT_LANE_IMPLEMENTATION_PLAN.md).

---

## Anikai staging order

1. **Lane 1 + Lane 2** first — parametric + MIDI/soundfont. Zero-download honest baseline. **Desktop: both tool paths shipped; installer bundling deferred.**
2. **Lane 4 (Stable Audio Open)** next — first neural-prompt-to-music model card. Reuses the imaging Python venv.
3. **Lane 3 (ONNX SFX)** in parallel — small, cheap, useful for chat / pipeline tool use.
4. **Lane 5 (singing voice)** later — surfaced as a *pipeline gap* in the Suno-clone doc, not as a shippable feature, until an open model is good enough to label honestly.

---

## Open questions (to resolve before code lands)

| # | Question | Notes |
|---|----------|-------|
| **Q1** | Which built-in soundfont ships with Anikai (size vs coverage)? | **Decided: FluidR3_GM** — staged under `resources/soundfonts/fluidr3-gm/`; manifest in `assets/soundfonts/fluidr3-gm/manifest.json`. |
| **Q2** | MIDI renderer choice — bundle FluidSynth, or wrap an existing native sf2 lib? | Affects installer size and licensing. |
| **Q3** | Parametric composer authoring — JS / Rust module living in-process? | Keep in-process; no extra service for Lane 1. |
| **Q4** | Stable Audio Open routing — extend the imaging Python venv or a sibling `media-audio` venv? | Likely sibling, to keep imaging’s requirements pinned. |
| **Q5** | Where does the SFX `.onnx` catalogue live? | Probably under `models/sfx/<name>/` mirroring image pack folders. |
| **Q6** | Future “generate instrument samples” lane (RAVE-class / neural soundfont) | Out of scope for day one — capture as its own lane doc when explored. |

---

## Cross-links

- About → Generating media → Audio (Quick start, How it actually works).
- About → Pipelines → Curated → Suno-clone (will live at [`../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md`](../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md)).
- About → Engines & families → ONNX (codec models, SFX) and Diffusers (Lane-4 music).
- About → Sentience → Voice (companion speaking / TTS) — **different** role from Lane 5 singing voice; cross-link both ways.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-19 | Initial overview written from the audio-lanes teaching pass; locks in five-lane model, Suno-pipeline shape, honesty contract. |
| 2026-05-20 | Desktop status table: Lane 1 DSP + Lane 2 MIDI/soundfont shipped in app; Lanes 3–5 still planned. |
