# TODO — Motion-sense engines (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Registries (UI):**

- `anikai-desktop/assets/about-guide/motion-sentience-registry.json`
- `anikai-desktop/assets/about-guide/runtime-packs-registry.json`
- `anikai-desktop/assets/about-guide/imaging-registry.json` (ONNX stacks)

**Architecture:** [`../../implementations/generation/motion/MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md`](../../implementations/generation/motion/MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md)

**Strategy:** [`../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md`](../../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md)

**PersonaLive plan:** [`../../android-arm64/implementations/engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../android-arm64/implementations/engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

---

## P0 — PersonaLive (no FOMM)

- [ ] Manifest row `personalive_portrait` matches upstream weight tree
- [ ] `python.personalive` runtime pack stub in RUNTIME_PACKS doc
- [ ] Offline smoke: hero still + stock `driving.mp4` → short clip
- [ ] About Motion-sense: tick family **VERIFIED** when smoke passes

## P0 — Rig + Companion Generate

- [ ] Document link: bio **Generate** → GGUF still (existing stub)
- [ ] Android rig phoneme path documented as **partial** in registry (already)

## P1 — Phoneme driving bridge

- [ ] `PhonemeDriverFrameSynth` spec → implementation
- [ ] PersonaLive online accepts synth stream (not only webcam)

## P2 — ONNX graphs (desktop ORT runner)

- [x] Portrait depth — Media Magic post + `onnx_portrait_depth` stack
- [x] DWPose — two-graph yolox + dw-ll
- [x] x4 post — UltraSharp Get pack + Media Magic upscale
- [x] Inpaint — LaMa image+mask feeds
- [x] Runtime packs registry + Software tab rows (`pack.onnx.imaging`, …)
- [ ] GFPGAN runner
- [ ] Wav2Lip runner

## P3 — Alternates (optional)

- [ ] SadTalker sidecar smoke
- [ ] LivePortrait sidecar smoke

## Explicitly out of scope

- [ ] ~~FOMM~~ — removed from product plan (keep Android code read-only until removed)

---

## Done when

- [ ] Motion-sense About tab shows non-zero **shipped** or **VERIFIED** for PersonaLive
- [ ] `OPERATIONS_INDEX` row updated
