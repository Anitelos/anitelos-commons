# Text generation model role plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

Purpose: define recommended text-generation model roles by use-case (speed, reflex reporting, deep reasoning, surveillance summaries, creative support) so ANIKAI can swap models intentionally instead of one-model-for-everything.

---

## Scope

This file covers:

- role-based text model recommendations (not brand lock-in),
- speed/quality/efficiency trade-off strategy,
- model pipeline combinations for richer output chains,
- integration points with handover orchestrator and companion.

This file does **not** replace runtime-family docs for GGUF/LiteRT/etc.

---

## Role taxonomy for text generation

| Text role | Goal | Typical runtime profile |
|-----------|------|--------------------------|
| **T1 Fast live chat** | low-latency, responsive conversation | compact model, short context, aggressive speed settings |
| **T2 Reflex event summarizer** | transform sensor/specialist packets into concise reports | small-mid model, structured output mode |
| **T3 Deep reasoner** | complex planning/synthesis with longer context | larger model, higher quality profile, slower lane |
| **T4 Surveillance narrative analyst** | summarize detection timelines and anomalies clearly | mid/large model with robust summarization templates |
| **T5 Creative copy/director** | prompts, mood text, narrative/worldbuilding assistance | mid model with style/mood controls |

---

## Recommendation strategy (model-agnostic)

### A) Fast response lane (T1)

- prioritize speed and low memory footprint,
- cap context and decoding complexity,
- keep always available for UI responsiveness.

### B) Reflex/report lane (T2)

- optimize for concise structured summaries,
- consume handover packets from vision/audio specialists,
- return machine+human readable output.

### C) Deep lane (T3/T4/T5)

- activate on-demand when user intent requires richer reasoning,
- allow slower generation but keep clear progress signals,
- hand results back to companion continuity lane.

---

## Multi-model text pipeline patterns

### Pattern 1: Fast -> Deep -> Fast

1. Fast lane acknowledges and structures request quickly.
2. Deep lane runs detailed reasoning/planning.
3. Fast lane delivers interactive follow-up.

### Pattern 2: Specialist packet -> Summarizer -> Companion

1. Non-text specialist returns packet (vision/audio/pipeline).
2. Summarizer lane converts packet to user-facing report.
3. Companion integrates into ongoing context.

### Pattern 3: Mood/context -> Text -> Voice handoff

1. Text lane produces response with mood/context tags.
2. Voice lane consumes text + expression metadata.
3. Output preserves style/emotion intent.

---

## Runtime family mapping hints

| Runtime family | Best-fit text roles |
|----------------|---------------------|
| **GGUF** | T1/T2/T3 depending on model size + device class |
| **LiteRT** | T1/T2 compact lanes on constrained devices |
| **ExecuTorch/MNN (future text-lane trials)** | selective T1/T2/T3 based on proven model quality |

Rule: role assignment is capability/profile based, not hardcoded by model name.

---

## Selection policy inputs

Scheduler should consider:

- target latency,
- required reasoning depth,
- memory/thermal budget,
- user policy preset,
- availability of specialist packet evidence.

---

## Output contract expectations

Each text lane should provide:

- clear role id (`T1`..`T5`),
- source model/runtime metadata,
- confidence or quality hint when applicable,
- handoff-ready structured segment for downstream lanes (voice/report/UI).

---

## Phased implementation

### Phase 0 - role schema

- formalize role IDs and lane metadata.

### Phase 1 - dual-lane baseline

- operationalize T1 fast lane + T2 summarizer lane.

### Phase 2 - deep lane integration

- add T3/T4/T5 on-demand activation via handover orchestrator.

### Phase 3 - adaptive policy

- dynamic role switching by thermal/memory/user policy.

---

## Open decisions

- minimum acceptable quality bar for T1 fast lane,
- first deep-lane role to prioritize (`T3` vs `T4`),
- how aggressive automatic switching should be before asking user.

---

## Linked docs

- `implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`
- `implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`

---

## Linked todo

- `todo/mid-scope/TODO_MODEL_HANDOVER_AND_TEXT_ROLE_ORCHESTRATION.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial text generation role strategy added for multi-model swap and role orchestration planning. |
