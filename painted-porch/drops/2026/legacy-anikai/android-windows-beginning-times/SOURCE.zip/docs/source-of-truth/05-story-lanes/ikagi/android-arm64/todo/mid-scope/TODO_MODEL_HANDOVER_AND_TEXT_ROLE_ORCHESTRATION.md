# TODO — model handover and text role orchestration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation docs

- `implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`
- `implementations/generation/text/TEXT_GENERATION_MODEL_ROLE_PLAN.md`

---

## Intent

- Build a reliable model handover/swap architecture so ANIKAI can route tasks by role instead of keeping all models resident.
- Define text-role specialization for speed, reflex reporting, deep reasoning, and surveillance summaries.
- Keep runtime/model switching explicit, policy-driven, and honest.

---

## Checklist (working)

- [ ] Finalize handover packet schema (task, source model, evidence, confidence, cost).
- [ ] Define role-class scheduler policy (latency/quality/memory/thermal/user policy).
- [ ] Implement baseline chain: reflex trigger -> specialist -> text summarizer -> companion.
- [ ] Implement T1 fast lane + T2 summarizer lane with explicit role metadata.
- [ ] Add on-demand deep lane switching and return-to-fast behavior.
- [ ] Validate degraded labeling and no hidden cloud substitution in local-only mode.

---

## Linked operations

- `todo/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through sentient orchestration maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created shared orchestration todo for handover architecture and text role planning. |
