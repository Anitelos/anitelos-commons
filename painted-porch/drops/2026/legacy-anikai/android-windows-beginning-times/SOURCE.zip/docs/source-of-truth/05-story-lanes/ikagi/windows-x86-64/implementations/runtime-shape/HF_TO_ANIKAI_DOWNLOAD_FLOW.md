# Hugging Face → Anikai download flow (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Phase A complete (Slices 1–2 + coverage table) |
| **Operations** | Slice 1 shipped · Slice 2 shipped |
| **Last reviewed** | 2026-05-19 |

Purpose: define how a click in the About → Model catalogue (and, later, the Models-panel catalogue) fetches model weights from Hugging Face into the user’s `models/` tree **with sidecar de-duplication, persistent progress, and honest "you already have it" prompts** — so users can side-load by clicking, never accidentally re-download a 20 GB encoder, and always know what is happening at the bottom of the screen.

This doc does **not** replace:

- About-guide structure: [`../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)
- Pack layouts: [`../generation/imaging/gguf/GGUF_MODEL_PACK_FAMILIES.md`](../generation/imaging/gguf/GGUF_MODEL_PACK_FAMILIES.md)
- Sidecar override engine: [`../../anikai-desktop/main-process/imaging-sidecar-overrides.js`](../../../../../../../../../anikai-desktop/main-process/imaging-sidecar-overrides.js) (source)

---

## Surface — where the user clicks

About → Generating media → Imaging (and Audio when its lane lands) → **Model catalogue** table.

Per stack row, after the **Capabilities** column, add a **Get pack** cell:

```
[ Verified ✓ ]   [ Light ]   [ Standard ]   [ Full ]
```

- Show the badge only if the row has a `verified` block (status: `verified`).
- Show a tier button only if `downloadPacks.<tier>` exists for the row.
- Tier buttons are disabled with a tooltip explaining why if the model is already fully resident on disk.
- Visual: **Capabilities cell** is tinted **green** when at least one capability is present — same per-capability pill style across rows, so the eye scans the catalogue as "what each model can do".

### Quant tier canon

| Tier | Maps to on HF | Why |
|------|----------------|-----|
| **Light** | Q4_K_S / Q4_K_M / Q5_K_M / Q6_K | Smaller files, runs on more hardware, minor quality loss |
| **Standard** | Q8_0 | Very close to full precision; sweet spot for most users |
| **Full** | FP16 (or BF16) | Native model precision. **FP32 is almost never published**; only used during training |

UI labels use the canon words (**Light / Standard / Full**), not Low / Med / High.

---

## Sidecar de-duplication (the core win)

When a tier is clicked, run a **preflight pass** before any bytes move. Each file from the pack runs through this order:

1. **Already in `models/_shared/<slot>/`** matching expected **SHA-256** → reuse, write override into pack runtime config.
2. **Already in `models/_shared/<slot>/`** matching expected **filename + byte size** (fast path when the hash for that file is too big to verify on the fly) → reuse, write override.
3. **Already in a sibling pack folder** (covers prior side-loads) → reuse, write override.
4. **Not present anywhere known** → download.
   - Default target: `models/_shared/<slot>/` so the *next* pack reuses it automatically.
   - Diffusion `.gguf` always goes to the pack folder, **never** shared (engine assumes it lives next to its config).

This means a user clicking *Light* on **FHDR**, then *Light* on **FLUX.1 Schnell**, then *Standard* on **FLUX.1 Dev** downloads the diffusion `.gguf` three times but **VAE + CLIP-L + T5-XXL only once**.

### "You already have it" dialog

If preflight finds a match, **never silently overwrite**. Show a small dialog summarising every match, with three options per file:

| Choice | Effect | Recommended? |
|--------|--------|--------------|
| **Use existing file** *(default, highlighted)* | Write an override path into the pack runtime config, skip the download. | ✓ (saves disk + bandwidth) |
| **Also download to pack folder** | Treat the pack as standalone; sidecar is duplicated. | Only when isolating a pack for portability. |
| **Replace shared copy** | Re-download to `_shared/`; warns that any pack currently overriding to the old file will switch automatically. | Only when the existing file is suspected corrupt. |

The dialog also shows the **summary line**: *“Downloading FHDR Light · 16.8 GB total · 3 files reused from `_shared/` → saving 12.4 GB”.*

---

## Persistent progress — where it lives

Downloads surface on the **global activity ticker** under the main chat column (full-width strip in `#app`, below `#anikaiAppMain`), driven by `pack-download:status` from main and rendered in [`anikai-desktop/components/chat.js`](../../../../../../anikai-desktop/components/chat.js) (`#chatActivityDockMount` / `#chatActivityDock`, message line + Cancel while `cancelable`).

The ticker already joins multiple status parts with ` · ` (e.g. inference queue + download line). Download progress is **another part** in the same join.

### Progress part shape

```
Downloading FHDR Light · 3.4 / 16.8 GB · 21% · 4 min left
```

- Updates at minimum once per second.
- Compresses when multiple downloads are running: *"Downloading 2 packs · 28% combined".*
- Stays visible across panel switches (it is a global IPC channel, not chat-message bound).
- On completion: ticker briefly shows *"FHDR Light installed · open in Models"* (auto-dismiss after 8 s).
- On cancel/error: ticker shows *"FHDR Light cancelled — partial files cleaned"* / *"FHDR Light failed: <reason> — open download log"*.

---

## What SHA-256 is and why we use it

A SHA-256 is a fixed-length **content fingerprint** — run any file through the SHA-256 function and you get a 64-character string that changes if even one byte of the file changes. Hugging Face publishes this string for every file on its blob storage, so Anikai can:

1. **Confirm an existing file is what we think it is** before reusing it (catches name collisions / silent corruption).
2. **Confirm a finished download is intact** (catches network corruption that a TCP checksum missed).

Why an "optional verify" was in the earlier sketch: hashing a 20 GB T5-XXL takes ~30 seconds on a slow drive. The verification step is still **always on by default** in this final design — the user’s call is whether *post-download verify of files >5 GB* runs synchronously (blocks the "ready" state) or asynchronously (lets you start using the model while verify finishes in the background). Default: **synchronous for ≤5 GB, async for >5 GB**, with a Settings toggle.

---

## Verified-by-Anikai badge

Two states ship in v1, with a third reserved for community endorsement later:

| Badge | Stored as | Surfaced as | Notes |
|-------|-----------|-------------|-------|
| **Verified** | `"verified": { status: "verified", date, notes, tested_tier }` | Green tick in the **Get pack** cell with a tooltip showing date, tier tested, and notes. | The Anikai team has run this stack and got acceptable output. |
| **Untested** *(default)* | absent or `status: "untested"` | No badge. | In the registry but never blessed. |
| **Community** *(reserved)* | `status: "community"` | Outline tick. | Future — once we have a sign-in / endorsement surface. Not implemented in v1. |

The badge is **per-stack**, optionally tied to a tier (you can verify Light without claiming Full works).

---

## Registry schema additions

Extend each entry in `imaging-registry.json` → `stacks[]`:

```json
{
  "id": "fhdr-gguf",
  "...": "existing fields",

  "downloadPacks": {
    "light": {
      "label": "Q4_K_M (≈ 6.4 GB)",
      "totalBytes": 16834567890,
      "files": [
        {
          "role": "diffusion",
          "url": "https://huggingface.co/kpsss34/FHDR_Uncensored/resolve/main/FHDR_ComfyUI-Q4_K_M.gguf",
          "filename": "FHDR_ComfyUI-Q4_K_M.gguf",
          "bytes": 6543210000,
          "sha256": "<hex>",
          "target": "pack"
        },
        {
          "role": "vae",
          "url": "https://huggingface.co/second-state/FLUX.1-schnell-GGUF/resolve/main/ae.safetensors",
          "filename": "ae.safetensors",
          "bytes": 335304388,
          "sha256": "<hex>",
          "target": "shared",
          "sharedSlot": "vae"
        },
        {
          "role": "clipL",
          "url": "https://huggingface.co/second-state/FLUX.1-schnell-GGUF/resolve/main/clip_l.safetensors",
          "filename": "clip_l.safetensors",
          "bytes": 246144152,
          "sha256": "<hex>",
          "target": "shared",
          "sharedSlot": "text-encoders"
        },
        {
          "role": "t5",
          "url": "https://huggingface.co/second-state/FLUX.1-schnell-GGUF/resolve/main/t5xxl_fp16.safetensors",
          "filename": "t5xxl_fp16.safetensors",
          "bytes": 9787841024,
          "sha256": "<hex>",
          "target": "shared",
          "sharedSlot": "text-encoders"
        }
      ]
    },
    "standard": { "label": "Q8_0 (≈ 12 GB)", "files": [ "..." ] },
    "full":     { "label": "FP16 (≈ 24 GB)", "files": [ "..." ] }
  },

  "verified": {
    "status": "verified",
    "date": "2026-05-18",
    "notes": "Verified text-to-image at 1024×1024 with FLUX.1 sidecars.",
    "tested_tier": "light"
  }
}
```

Notes:

- `target: "pack"` → `models/<stack-folder>/`.
- `target: "shared"` → `models/_shared/<sharedSlot>/`.
- `sharedSlot` enum (v1): `vae`, `text-encoders`. New slots get added as new families need them.
- `sha256` is **optional in the registry but recommended**. If absent, Slice 1 preflight falls back to filename + ±15% size tolerance and skips the post-download verify (with a UI hint). Slice 2 raises this to strict SHA-256 when present.
- `aliases: string[]` — additional filenames that count as the same file during preflight matching (covers HF naming variants like `model.fp16.safetensors` vs `model.safetensors`, or split quants like `Q4_K_S` ↔ `Q4_K_M` that the user may already have locally). Optional.
- `gated: true` — repo requires accepting terms / signing in on Hugging Face before download. Surfaces a yellow banner with click-out link; does **not** attempt to bypass the gate.
- `repoUrl` — direct link to the HF repo page, used by the gated banner and the per-file "Open HF repo" link in the preflight modal.
- `bytes` lets the UI display per-file progress accurately without `Content-Length` round-trips.

### SD3 / SD3.5 stacks (repo-first Get pack)

FLUX families still use `target: "shared"` where documented. **SD3 stacks use a different rule:**

| Stack | Get pack installs | Not in Get pack (router secondary) |
|-------|-------------------|-------------------------------------|
| **calcuis/sd3.5-large-gguf** | DiT + `clip_l` + `clip_g` + `t5xxl_fp8_e4m3fn` beside the `.gguf` (`target: "pack"`) | — |
| **calcuis/sd3.5-lite-gguf** | Lite DiT + pig VAE (`diffusion_pytorch_model.safetensors` from calcuis large file URL) | Encoders from calcuis large (separate Get pack) |
| **stduhpf turbo** | Turbo DiT only (not HF-gated) | Encoders from calcuis large |

**Gated model** on calcuis rows = accept **Stability AI Community License** on Hugging Face for that repo before `resolve` downloads work.

At runtime, `probeSd3ClipStackLayout` searches **pack folder first**, then `models/sd35-large-calcuis/` and `models/_shared/text-encoders/` as fallbacks. Catalogue links use each stack’s own HF repo plus explicit file URLs (no duplicate repo-root links that get suppressed).

---

## IPC + main-process flow

**Renderer → main (invoke)**

| IPC | Payload | Returns |
|-----|---------|---------|
| `models:downloadPack.preflight` | `{ stackId, tier }` | `{ ok, stackId?, tier?, decisions? }` — `decisions[]` per file: `role`, `decision` (`reuse` \| `download`), `onDisk`, `matchedAt`, `filename`, `bytes`, `target`, `sharedSlot`, `gated`, `repoUrl`, `sha256`, `matchMode` |
| `models:downloadPack.start` | `{ stackId, tier, choices }` — `choices` maps `role` → `use-existing` \| `to-pack` \| `replace-shared` | `{ ok, jobId? }` |
| `models:downloadPack.cancel` | `jobId` (string) | `{ ok, cancelled }` |

**Main → renderer (broadcast on `pack-download:status`)**

One channel carries progress, completion, errors, and optional readiness. Typical payload fields:

| Field | Meaning |
|-------|---------|
| `line` | Human-readable one-line status for the global activity ticker |
| `jobId` | Correlates with `models:downloadPack.start` |
| `phase` | `progress` \| `done` \| `error` \| `cancelled` |
| `cancelable` | `true` while download in flight (renderer shows **Cancel**) |
| `logPath` | Path under `ANIKAI_HOME/logs/downloads/` for this job |
| `readiness` | On `phase: 'done'`, optional GGUF image readiness snapshot (`ready`, `steps`, `route`, etc.) when the stack resolved to a flat `.gguf` model ref |

There is **no** separate `confirm` / `progress` / `done` IPC pair; the preflight modal commits `choices` and then calls `start`.

Main-process responsibilities:

1. **Preflight** — for every file in the chosen tier, check shared / pack / sibling locations per the dedup order; build the `decisions` summary.
2. **Start** — user choices from the preflight modal are sent with `models:downloadPack.start` (defaults to reuse where preflight found a match).
3. **Download** — stream to `<file>.part` with HTTP **Range** resume when a partial exists and the registry has `bytes`; **429/503** backoff with `Retry-After` when present; atomic rename to final path; verify SHA-256 when `sha256` is set (sync for ≤5 GB, async for larger).
4. **Sidecar override write** — after success, `model-runtime:save` with `imageSidecars` path overrides for `vae` / `clipL` / `t5` plus task types from the stack row.
5. **Readiness** — after overrides are saved, main runs the same GGUF readiness logic as `media:get-readiness` for the new `modelRef` and attaches the result on the final `pack-download:status` (`phase: 'done'`, field `readiness`).
6. **Cleanup on cancel/error** — partial `.part` files removed where possible; sidecar overrides untouched on failure.

---

## Pilot — shipped sequence

1. **FHDR** (`fhdr-gguf`) — first `downloadPacks` + `verified`; preflight modal + Slice 2 downloader + sidecar overrides.
2. **FLUX.1 Schnell (city96)** (`flux1-schnell-city96`) — same shared `vae` / `text-encoders` files as FHDR → cross-pack dedupe without re-downloading encoders.
3. **FLUX.1 Dev (city96)** (`flux1-dev-city96`) — `downloadPacks` for Q4_K_S / Q5_0 / Q8_0 diffusion quants; identical sidecar URLs and slots as Schnell/FHDR.

Further stacks (leejet mirrors, SDXL, Chroma, etc.) are **registry batches**: each needs curated HF `resolve/main/` URLs, `bytes` from the HF API or LFS pointers, optional `sha256`, and a smoke pass before `verified` is set. See **Get-pack registry coverage** below.

---

## Slice plan (status board)

### Slice 1 — preflight, dedupe scan, gated handling · **SHIPPED 2026-05-19**

Commit: `cb0ddc19  feat(anikai-desktop): HF download flow Slice 1 — Get-pack preflight, dedupe, gated repos`.

| Sub-item | What landed |
|----------|-------------|
| FHDR registry block | `downloadPacks.{light,standard,full}` + `verified` for `fhdr-gguf`, real HF URLs + byte sizes + `aliases[]` + `gated`/`repoUrl` per file. |
| Catalogue UI | **Get pack** column on the imaging catalogue; **Verified** badge; tier buttons (Light / Standard / Full); green-tinted capability chips. |
| Preflight IPC | `models:downloadPack.preflight` reads registry, scans `_shared/<slot>/` → pack folder → sibling packs. Without per-file `sha256`: filename + aliases with ±15 % size tolerance. With `sha256`: tight size gate + full-file hash must match for reuse. |
| Preflight modal | "On disk: Yes / No" rows, matched paths, totals, **estimated bytes saved**, yellow gated-repo banner with clickable links; HF links use event delegation so dynamic content stays clickable. |
| Hint copy | Modal hint clarifies that diffusers-style sidecars in a pack folder are auto-detected → standalone files only useful for `_shared/` cross-pack reuse. |
| Diffusers preset row | Intentionally has **no** `downloadPacks` block — "Get pack" stays `—`; Diffusers tree downloads are their own (later) flow. |

### Slice 2 — actual downloader + verify + apply overrides · **SHIPPED 2026-05-19**

| Sub-item | What landed |
|----------|-------------|
| Streaming downloader | HTTP(S) GET with redirects; stream to `<file>.part`; atomic rename; cleanup `.part` on cancel/error. |
| Persistent progress ticker | `pack-download:status` IPC; activity ticker shows download line and **Cancel** while `cancelable`; auto-dismiss success after 8s, errors/cancel after 12s. |
| SHA-256 verification | When `sha256` is present in the registry, preflight reuse requires a matching hash; post-download verify before rename for files ≤5 GB, verify after rename for larger files. `clip_l` + `t5xxl_fp16` in FHDR registry include HF LFS hashes. |
| Apply-overrides step | After success, `model-runtime:save` with `imageSidecars` path overrides for `vae` / `clipL` / `t5` (`flux1_clip_t5`) and `vae` / `llm` (`flux2_llm_vae`), plus task types from the stack row. |
| Range resume + 429/503 backoff | Partial `.part` resumes with `Range` when registry lists `bytes`; retries with backoff and honors `Retry-After` when present. |
| Pack-done readiness | On successful install, main attaches a GGUF readiness snapshot to `pack-download:status` when `phase` is `done` (same logic as `media:get-readiness` for flat `.gguf` refs). |

### Slice 3 — scale + catalogue · **PARTIAL** (Diffusers tree **deferred**)

Non-Diffusers items below stay in scope; **Diffusers "Get tree"** is explicitly **not** priority until GGUF + Get-pack flows are exercised on real hardware.

| Sub-item | Detail |
|----------|--------|
| More `downloadPacks` rows | **Shipped / partial:** `flux2_llm_vae` stacks ship triple-file packs; FLUX.1 city96 + **leejet schnell/dev** + **Shuttle 3.1** + **klein** rows + FHDR share second-state sidecars where applicable. Remaining batches: SDXL city96, ERNIE (needs Ministral GGUF source), etc. |
| SHA-256 from HF | Extend `scripts/build-imaging-registry.mjs` to fetch HF blob hashes per file so the registry maintainer rarely types them by hand. |
| Models-panel catalogue | Hoist the rich filterable catalogue (capability / family / verified / disk-cost / VRAM-class) out of About once verified entries cross ~50 rows. About stays the **teaching surface**; Models becomes the **shopping surface**. |
| Diffusers tree downloads | **Deferred:** a separate "Get tree" action on Diffusers-preset rows that fetches the whole HF repo subtree (`model_index.json` + every required subfolder), not per-file picks. Would reuse the same ticker. |

---

## Get-pack registry coverage (imaging stacks)

Only stacks with a `downloadPacks` object show **Light / Standard / Full** in About → Imaging catalogue. All other GGUF rows show **—** until a pack block is added and (ideally) smoke-verified.

| Stack `id` | Get-pack | Notes |
|------------|----------|--------|
| `fhdr-gguf` | Yes | Verified; diffusion gated on HF — link-out + manual accept, then preflight reuse. |
| `flux1-schnell-city96` | Yes | Shared VAE + CLIP-L + T5 with FHDR. |
| `flux1-dev-city96` | Yes | City96 dev quants; same shared sidecars as Schnell/FHDR. |
| `flux1-schnell-leejet` | Yes | Leejet schnell **q4_k** / **q4_0** / **q8_0** + shared VAE + CLIP-L + T5 (tiers start at q4). |
| `flux1-dev-leejet` | Yes | Leejet dev **q4_k** / **q4_0** / **q8_0** + same sidecars. |
| `shuttle-31` | Yes | Shuttle GGUF Q4_K_S / Q6_K / Q8_0 + same FLUX.1 sidecars. |
| `klein-9b-unsloth` | Yes | Unsloth klein 9B GGUF + kaiyuyue VAE + Unsloth Qwen3-8B GGUF (`light` / `standard` / `full`). |
| `klein-9b-leejet` | Yes | Leejet klein 9B (Q4_0 / Q8_0) + same VAE + Qwen3-8B (`light` / `full`). |
| `flux2-dev-city96` | Yes | City96 `flux2-dev` Q4_K_S + VAE + Qwen3-8B (`light` only — very large DiT). |
| `klein-4b-leejet` | Yes | Leejet 4B Q4_0 / Q8_0 + VAE + Unsloth Qwen3-4B (`light` / `full`). |
| `klein-4b-base-leejet` | Yes | Base 4B variant; same LLM/VAE pairing (`light` / `full`). |
| *All other `stacks[]` rows* | No | Add `downloadPacks` in batches; Diffusers preset rows intentionally omit packs (tree flow later). |

---

## Future — Models-panel catalogue

The About → Model catalogue is the **seed**. When the verified-list crosses ~50 entries, we hoist a richer **Models-panel catalogue** with:

- Filter by **capability** / **family** / **verified status** / **disk-cost band** / **VRAM-class**.
- Click → "Get pack" inline (same IPC).
- Per-row "open run history" once Playground lands.

The About guide stays as the **teaching surface** (How it actually works, families); the Models panel becomes the **shopping surface**.

---

## Open questions

| # | Question | Default if not resolved |
|---|----------|--------------------------|
| **Q1** | Should `_shared/` be the default for **every** sidecar even when the user only owns one pack? | Yes — disk cheap, hygiene wins. Settings toggle exists. |
| **Q2** | How are SHA-256 hashes maintained in the registry? Manual at first or scripted? | Manual for the FHDR pilot. Add `scripts/build-imaging-registry.mjs` extension to fetch hashes from HF later. |
| **Q3** | Mirror hosting (if HF goes down)? | Out of scope for v1. Honest "HF unreachable" error message instead. |
| **Q4** | Authenticated HF models (gated repos)? | **Default path:** user downloads via browser using Get-pack links / table, places files under `models/` per Target column; preflight then reuses them — **no token**. **Optional:** read token in Settings → General for in-app streaming (no browser cookie parity). On 401/403 the app may open the repo page as a nudge. |
| **Q5** | Where do download logs live? | `ANIKAI_HOME/logs/downloads/<stackId>-<tier>-<timestamp>.log`. Linked from the error ticker. |
| **Q6** | Should the preflight modal show "saving N GB" prominently? | Yes — top-line summary. |

---

## Cross-links

- About → Generating media → Imaging → Quick start (overrides + `_shared/` story).
- About → Pipelines (curated pipelines may install multi-stack bundles in future).
- Models panel — runtime drawer (`mrImageSidecars`) — pre-populated by the download flow.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-19 | Initial download-flow doc. Locks in Light / Standard / Full tiers, shared-first dedup, confirm dialog, persistent activity ticker (`#chatActivityDock`), registry schema additions, FHDR pilot. |
| 2026-05-19 | **Slice 1 shipped** (commit `cb0ddc19`). Added schema notes for `aliases[]` (filename variants) and `gated` + `repoUrl` (HF gated repo banner / link-out). Q4 (gated handling) updated to "partially shipped — link-out only, no token auth yet". Slice plan section added: Slice 2 covers streaming downloader, persistent ticker hook with cancel, SHA-256 replacing the ±15 % size tolerance, and the apply-overrides step that writes matched paths into pack runtime config. |
| 2026-05-19 | **Slice 2 shipped**: `models:downloadPack.start` / `.cancel`, `main-process/pack-download.js` (stream to `.part` + rename, SHA-256 when present, logs under `logs/downloads/`), `pack-download:status` → activity ticker + Cancel; preflight uses content hash when registry lists `sha256`; FHDR `clip_l` / `t5xxl_fp16` include HF LFS hashes; `model-runtime:save` applies sidecar path overrides after success. |
| 2026-05-19 | Gated HF UX: **manual download + Target paths** as the default story; optional read token only for in-app streaming (Settings → General). Q4 and in-app copy updated accordingly. |
| 2026-05-19 | Doc pass: fixed ticker references (`#chatActivityDock` / `#chatActivityDockMount`); pilot + Slice 3 aligned with registry; added **Get-pack registry coverage** table. Registry: `downloadPacks` for **`flux1-dev-city96`** (city96 Q4_K_S / Q5_0 / Q8_0 + same shared sidecars as Schnell). |
| 2026-05-19 | **FLUX.2 Get-pack (pilot):** registry `downloadPacks` for `klein-9b-unsloth`, `klein-9b-leejet`, `flux2-dev-city96`, `klein-4b-leejet`, `klein-4b-base-leejet` (HF API–sized `resolve/main` URLs; VAE from `kaiyuyue/FLUX.2-dev-vae`; LLM from Unsloth Qwen3 GGUF). Removed **`klein-9b-bfl`** catalogue row (Diffusers/safetensors baseline, not GGUF). `pack-download.js`: `llm` role maps into `imageSidecars.slots.llm` on success. |
| 2026-05-19 | **FLUX.1 shared sidecars in `downloadPacks`:** VAE + CLIP-L + T5-XXL `resolve/main` URLs now point at [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) (`ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors`); `totalBytes` per tier recomputed from file sums. Letian + comfyanonymous remain documented as alternates in pack-family prose / model sheets. |
