# Community

**Scope:** cross-device and social ideas—where to host, how to host, membership shape, and anything that is more “people and place” than “inference graph.”

**When to open:** you are thinking about discoverability, trust, shared spaces, or multi-user flows—not the JNI layer.

**Promote to:** `docs/source-of-truth/04-community/` (when that tree gains real proposals) or governance docs if it becomes policy.
