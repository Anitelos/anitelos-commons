# CUDA toolkit bin (optional GPU offload)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.cuda` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Detect user NVIDIA toolkit for ggml-cuda and ORT CUDA EP — not bundled full installer.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

Optional future cuda.runtime redistributable slice only.

## Staging path

`Auto-detect Program Files/NVIDIA GPU Computing Toolkit`

## Unlocks (no model weights)

gguf-gpu-layers, ort-cuda-ep

## Verification smoke

Report cudart path; one GPU layer smoke on GGUF.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
