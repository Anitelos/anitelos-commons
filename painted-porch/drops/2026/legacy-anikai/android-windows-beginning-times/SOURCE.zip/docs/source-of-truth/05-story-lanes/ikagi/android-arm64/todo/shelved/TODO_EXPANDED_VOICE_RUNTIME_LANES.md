# TODO — Expanded voice runtime lanes (shelved)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs revisit |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation docs

- `implementations/generation/audio/voice/VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- `implementations/generation/audio/voice/COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- `implementations/generation/audio/voice/XTTS_RUNTIME_IMPLEMENTATION_PLAN.md`
- `implementations/generation/audio/voice/VITS_RUNTIME_IMPLEMENTATION_PLAN.md`
- `implementations/generation/audio/voice/CLOUD_VOICE_PROVIDER_PLAN.md`

---

## Intent

- Keep non-mobile-priority voice lanes tracked without bloating the Game Maker mobile checklist.
- Preserve "Anikai-first" path while explicitly shelving heavier runtime lanes for later cycles.
- Provide a clean resume point when voice quality/perf budget shifts (Windows lane or future device classes).

---

## Checklist (resume when reactivated)

- [ ] Re-validate runtime viability per engine (quality, latency, memory, install size).
- [ ] Define per-engine promote/shelve criteria and acceptance thresholds.
- [ ] Link resumed items to active mid/high-scope todos before implementation starts.
- [ ] Update operations status per lane after each review cycle.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created shelved bridge for expanded voice runtime lanes outside lean mobile Game Maker scope. |
