# Ikagi — Windows (x86-64)

**Scope:** desktop-first ANIKAI: overlay shell, model onboarding, Playgrounds (visual composition), automation/sentience *when documented*, and Windows-specific truth in `os-quirks/`.

**Story anchor (read this first):** [`WHAT_IS_ANIKAI_ON_WINDOWS.md`](./WHAT_IS_ANIKAI_ON_WINDOWS.md) — sovereign workshop; **Media Magic** is the current product center ([`implementations/companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](implementations/companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md)).

**Related lane note:** [`GAME_MAKER_WINDOWS_X64_DIRECTION.md`](./GAME_MAKER_WINDOWS_X64_DIRECTION.md)

---

## Sister lane (Android)

[`../android-arm64/`](../android-arm64/) is a **sibling**, not a shared workbook.

- **Same layout habit:** top-level buckets (`todo`, `implementations`, `complete`, `os-quirks`, `scripts`) and the same *style* of implementation subfolders (engines, generation lanes, pipelines, sentience, etc.) so you always know where a topic *would* live.
- **Separate authored content:** plans, indexes, and todos are **written fresh in this lane**. Do not treat Android markdown as source of truth for Windows work, and vice versa. Cross-links only when you deliberately want them (or later from the app).
- **Why:** keeps taxonomy parallel without coupling delivery or burning out on “invisible plumbing” docs that never ship to something you can see.

---

## Workflow (same buckets as Android)

| Folder | Meaning |
|--------|---------|
| `todo/` | Active thinking with **scope lanes** (`low-` / `mid-` / `high-`) plus `shelved/`. Folders exist; markdown tasks appear when you promote work from conversation. |
| `implementations/` | Stable design parking—schemas, UI contracts, engine notes—**without** mixing checkbox chaos. **Folder shape** matches the Android lane (parallel tree under `implementations/`); **files here are Windows-authored** unless you explicitly link elsewhere. |
| `complete/` | Archived wins—mirror implementation layout when something ships or a design is deliberately frozen. |
| `os-quirks/` | Windows / Electron / GPU / permission oddities and risk log. |
| `scripts/` | Reproducible helpers (build, pack, diagnose) once you add them. |

**When to open:** PC overlay, local model setup, Playground graph UX, and multi-window shell work—before or in parallel with roadmap entries elsewhere.

---

## Quick links

- Vision: [`WHAT_IS_ANIKAI_ON_WINDOWS.md`](./WHAT_IS_ANIKAI_ON_WINDOWS.md)
- OS / desktop truth: [`os-quirks/`](./os-quirks/)
- Work queue (empty scaffolding): [`todo/`](./todo/)
- Stable designs (scaffold + index): [`implementations/`](./implementations/) — [`implementations/README.md`](./implementations/README.md), tighten hub [`implementations/WINDOWS_DESKTOP_INDEX.md`](./implementations/WINDOWS_DESKTOP_INDEX.md).
- Done mirror (empty scaffolding): [`complete/`](./complete/)
