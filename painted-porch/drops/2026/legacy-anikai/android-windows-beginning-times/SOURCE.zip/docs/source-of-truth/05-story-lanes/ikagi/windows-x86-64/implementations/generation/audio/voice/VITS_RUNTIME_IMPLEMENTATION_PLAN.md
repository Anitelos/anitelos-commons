# VITS runtime implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

---

## Current state (code)

- Catalog lane exists under `ExpressiveEngineKind.VITS`.
- Curated VITS model entry exists in `ExpressiveVoiceCatalog`.
- Runtime parity is not yet at the same operational level as Kokoro lane.

Primary references:

- `.../voice/catalog/ExpressiveVoiceCatalog.kt`
- `.../voice/provider_runtimes/VoiceProviderRuntime.kt`
- `.../voice/provider_runtimes/local_runtime/EspeakPhonemizerNative.kt`

---

## Anikai-engine-first policy

- Prefer ANIKAI-local execution path first.
- If local VITS quality/readiness does not meet operational bar now, set **Needs revisit**, shelve, and return later.
- Do not block other engine lanes while VITS is parked.

---

## Operational goals

1. define final phoneme/front-end strategy for VITS lane,
2. verify VITS pack readiness and asset contract,
3. validate synthesis quality and latency on target device classes,
4. align runtime diagnostics and UI status for clear user feedback.

---

## Checklist

- [ ] Finalize front-end strategy (grapheme vs phoneme pipeline).
- [ ] Validate VITS pack asset contract and profile detection.
- [ ] End-to-end synth verification in orchestrator session flow.
- [ ] Performance profiling and thermal behavior check.
- [ ] Final lane status decision: `Operational` or `Needs revisit`.

---

## Dependencies

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Umbrella: `../VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Mixed pipeline relation: `../../../pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial dedicated VITS runtime plan with Anikai-engine-first + shelve/return policy. |
