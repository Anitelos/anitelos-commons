# Whisper chain capability smoke pipeline (integration harness)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-09 |

Purpose: define a **single, repeatable pipeline** that exercises ANIKAI’s **multi-runtime handover**, **load-out / load-in between models**, **per-hop inference timing**, and **pass/fail flagging** across model families—without building every product pipeline first. Informally this is a **“Chinese whispers” / telephone** harness: payload moves along a line of adapters (or the same payload is replayed per adapter).

**Hard link — engine platform (readiness, registry, manifest, handover contract):**  
[`../engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)

**Model family index:**  
[`../engine-inference/model-hub/MODEL_HUB_INDEX.md`](../engine-inference/model-hub/MODEL_HUB_INDEX.md)

---

## Scope

This file covers:

- **Modalities:** text (generation / transform), imaging (single reference in → image or tensor out), camera-backed lanes (e.g. emotion on faces) as **isolated** runs, and **future** short video clips (e.g. ~2 s per model) when video runtimes exist.
- **Two harness modes** (same UI, different semantics): **chain** (each step mutates the payload) vs **relay** (fixed seed input; each adapter runs independently or with full reset between hops for apples-to-apples timing).
- **Observability:** per-hop wall time, optional memory delta, explicit **failure reason** and **readiness state** at exit (aligned with parent doc: `INSTALLED` … `UNAVAILABLE`).
- **Output matrix:** rows keyed by **`runtimeFamily` + `adapterProfileId` + modality + device profile`**, columns for last run status, latency p50/p95 if repeated, notes.

This file does **not** replace:

- per-engine bring-up checklists under [`../engine-inference/model-hub/`](../engine-inference/model-hub/),
- product pipelines such as [`SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](./SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md),
- quality bars in [`../generation/`](../generation/) (harness may use **golden** assets but does not own quality policy).

---

## Why this lives under `pipelines/`

The harness is **choreography**: ordered steps, IO contracts between steps, and user-visible “what ran.” Engine inference docs own **how each family loads, probes, and executes**. This doc owns **the cross-family test story** and stays **hard-linked** to the parent engine plan so manifest/registry/handover rules do not fork.

---

## Harness modes

### Chain (“whisper”)

- **Input:** user seed text (or image bytes for imaging chain).
- **Behavior:** adapter 1 produces output → becomes input for adapter 2 → …  
- **Use:** stress handover, truncation, and **order-dependent** behavior; surfaces drift if earlier hops produce odd tokens.
- **Guardrails:** max characters/tokens per hop, optional JSON envelope for structured fields, truncate policy **documented per profile**.

### Relay (“benchmark”)

- **Input:** same canonical prompt or **golden** image every hop.
- **Behavior:** unload previous session, load next, run one forward path; no accumulation of prior model’s creative output.
- **Use:** compare **latency** and **success rate** across GGUF vs LiteRT vs ONNX (and others) fairly.

---

## Modality lanes (staged)

### 1) Text-capable families (first)

- Participants: any pack declaring **`text_generation`** / **`chat`** (or equivalent) with a known **adapter profile** (see parent plan: same wrapper ≠ same graph; Flux-style multi-graph packs are separate profiles).
- Measures: time to first token (if streaming), time to full completion, handover time between unload/load.
- UI: configurable **order** (e.g. GGUF → LiteRT → ONNX); export row to failure matrix.

### 2) Imaging (shared golden input)

- **Input:** fixed test bitmap (resolution, color space documented) similar in spirit to sprite pipeline tests but **minimal**—prove “tensor in → bitmap out” or tagged failure.
- **Behavior:** relay mode default; optional chain if a later model accepts prior image as edit input.
- **Pass:** output dimensions within tolerance or explicit “non-image output” flagged without crashing.

### 3) Camera / emotion (one-by-one)

- Not interleaved in the same automatic chain as text by default: **permissions**, preview lifecycle, and thread affinity differ.
- Same **matrix** format: one row per model run; failures are **expected** on devices without camera or denied permission.

### 4) Video (future)

- **Input:** short script or fixed clip id; **output:** ~2 s generated clip per selected model (when generation stack exists).
- **Contract:** timeout, max bytes, codec/container; failures are explicit (timeout, OOM, unsupported op).

---

## Failure matrix (minimum fields)

Each run appends or updates a row:

| Field | Description |
|-------|-------------|
| `runId` | UUID or monotonic batch id |
| `modality` | `text` \| `image` \| `camera` \| `video` |
| `mode` | `chain` \| `relay` |
| `runtimeFamily` | e.g. `gguf`, `onnx`, `litert` |
| `adapterProfileId` | disambiguates multi-graph / non-plug-and-play packs |
| `modelPackId` | catalog / manifest id |
| `readinessAtStart` | from parent doc vocabulary |
| `status` | `ok` \| `failed` \| `skipped` |
| `latencyMs` | wall for hop (and optional sub-phases: load, infer, unload) |
| `reason` | user-safe string + optional internal code |

---

## Relationship to Swarm / Sentience / community pipelines

This harness is the **canonical integration spine** for proving that **pipeline steps** can depend on **real adapters** later. User-authored or community pipeline schemas should eventually map to the same **handover + readiness** primitives; this doc does not define schema v1 (see parent plan open decisions).

---

## Open decisions

- Whether chain mode allows **cross-modality** hops (text → image caption) in v1 or stays **single modality per run**.
- Where the matrix is persisted (debug-only JSON vs export share).
- Minimum device set for “green” CI vs on-device manual runs.

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Created whisper-chain / relay capability smoke pipeline plan; hard-linked to engine inference capability platform plan. |
