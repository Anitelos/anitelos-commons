# Complete (archived mirror)

**Scope:** when work graduates out of active drift, **mirror** the same folder names you used under `implementations/` so you can answer “what did we finish?” without opening fifty roadmap files.

**Rule:** paste a one-paragraph capstone + link to the canonical roadmap or PR when you move something here.
