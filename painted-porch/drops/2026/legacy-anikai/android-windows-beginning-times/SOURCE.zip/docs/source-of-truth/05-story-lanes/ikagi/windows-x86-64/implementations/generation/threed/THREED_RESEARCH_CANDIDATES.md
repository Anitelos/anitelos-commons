# 3D research candidates — registry watchlist

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Research / integration planning |
| **Last reviewed** | 2026-06-02 |
| **Registry** | `anikai-desktop/assets/about-guide/threed-registry.json` → `researchCandidates[]` |

**Parent:** [`THREED_GENERATION_INDEX.md`](./THREED_GENERATION_INDEX.md) · [`../../pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md`](../../pipelines/COMPOSABLE_PATHS_AND_EXPERT_MODE_DIRECTION.md)

---

## Why a watchlist (not shipped stacks yet)

These projects are **not** in `testedStacks` until Anikai has a runner, pack, and smoke test. They **are** tracked so About, lane pipelines, and future Playground nodes share one vocabulary.

| Project | URL | Primary job in Anikai story |
|---------|-----|-----------------------------|
| **TriSplat** | [lhmd.top/trisplat](https://lhmd.top/trisplat/) | Sparse views → **triangle mesh** for environments / sets (simulation-ready) |
| **TripoSplat** | [tripo3d.ai/research/triposplat](https://www.tripo3d.ai/research/triposplat) | Single image → **3D Gaussians** with learned density control (DeG); inference LoD budget |
| **PhysX-Omni** | [physx-omni.github.io](https://physx-omni.github.io/) | Unified **simulation-ready** rigid / deformable / articulated assets |
| **CubePart** | [cubepart.github.io](https://cubepart.github.io/) | **Open-vocabulary part schema** → multi-part meshes + engine behaviors |
| **MoCapAnything V2** | [animotionlab.github.io/MoCapAnythingV2](https://animotionlab.github.io/MoCapAnythingV2/) | **Video → motion** for retarget onto a rigged character mesh |

---

## TripoSplat — single-image generative splats

[TripoSplat](https://www.tripo3d.ai/research/triposplat) targets a gap structure-aligned Gaussian generators leave open: **adaptive density** (split/prune analog) inside a generative pipeline via **Density-Sampled Gaussians (DeG)** — centers sampled from an octree-structured density field, trained with a policy-gradient on rendering error.

**Practical wins for Anikai:**

| Property | Why it matters |
|----------|----------------|
| **One RGB still in** | Same desk story as SHARP / LiTo — no sparse-view bundle required (unlike TriSplat). |
| **MIT + ~2k LOC PyTorch** | Low dependency surface; pairs with ComfyUI ecosystem notes on the project page. |
| **Inference-time Gaussian count** | Background prop vs hero asset vs multi-platform LoD without retraining. |
| **Stylized objects** | Strong on illustrated / game-art stills — complements photoreal mesh stacks. |

**Vs shipped/planned stacks:** SHARP ONNX splats today; LiTo for view-dependent appearance; TRELLIS / Pixel3D / Hunyuan for **mesh + UV** hero characters. TripoSplat is the watchlist pick when you want **generative splat quality** with a **budget knob**, not a replacement for environment **triangle** reconstruction (TriSplat) or rig motion (MoCap).

Registry: `researchCandidates[].id === "triposplat-image-gaussians"`.  
Lane row: `image-to-triposplat-gaussians` in `lane-pipelines-registry.json`.

---

## Near-term smoke order (workshop)

Hand-testing sequence aligned with the character production graph (video before MoCap; mesh stacks after cycles exist):

1. **Direction-image cycles → video** — LTX 2.3 variants: distilled BF16, FP8 dev, light dev mix, NVFP4; source = character designer angle batch / direction stills.  
2. **WAN + sprite-action LoRA** — side-view loop from the same identity refs.  
3. **Mesh / splat stacks** — TRELLIS, Pixel3D-class, LiTo (`stage-lito`), then **TripoSplat** for adaptive Gaussian LoD on hero props.  
4. **MoCapAnything V2** — once (2) and a mesh from (3) exist.  
5. **TriSplat / CubePart / PhysX** — environment and mechanical lanes after core smokes.

---

## TriSplat + environment design — panoramic vs multi-view

**TriSplat** is feed-forward **sparse-view scene reconstruction** with **native triangle** primitives (no Gaussian → Poisson post). That fits **“turn my environment concept into game-ready tris.”**

### Good fit

- **Environment designer** outputs clean, low-clutter stills.
- **Character-designer-style angle batch** adapted for **room / street / arena**: 8–24 orbit positions around a fixed point (camera yaw sweep), export as separate PNGs.
- **Video lane**: short **in-place orbit** clip → extract N keyframes (every 15–30°) → TriSplat input set.
- DL3DV-style outdoor sets (see TriSplat demo scenes) when you have walk-around coverage.

### Weak fit (common misconception)

- **Single equirectangular panorama** from “spin camera in place” is **one** synthetic wide view, not the **sparse unposed multi-view** bundle TriSplat is built for. A pano can still be a **reference** for art direction, but for TriSplat prefer **discrete frames** from the orbit.
- **Better pano workflow:** pano for **lighting/mood board** → regenerate **per-direction stills** (or batch angles) → those stills → TriSplat.

### Anikai implementation sketch

1. Media Magic **Environment designer** → hero still.  
2. Optional **tween/orbit** (video tab or future “orbit capture” tool) → keyframe strip.  
3. Playground node **TriSplat reconstruct** → `.obj`/mesh + collision-friendly tris.  
4. Export to Unreal/Unity or in-app preview (TriSplat demo already drives agents on mesh).

---

## CubePart + PhysX-Omni — “super mechanical designer”

Different layers, **composable**:

| Layer | Tool | Output |
|-------|------|--------|
| **Structure + parts** | [CubePart](https://cubepart.github.io/) | Meshes per schema part (wheels, lid, blades, torso…) |
| **Simulation metadata** | [PhysX-Omni](https://physx-omni.github.io/) | Material, scale, affordance, kinematics, function text — **PhysXVerse / PhysX-Bench** mindset |

**Together:** user prompts *“jellyfish race car”* with schema `hull, tentacle_fins, cockpit, thrusters` → CubePart meshes → PhysX-Omni tags which parts are rigid/articulated → **test hinge/spin in Anikai** before Unreal export.

**With existing stacks:** holistic mesh from **Hunyuan3D-2 / LiTo / TripoSR** → CubePart **mesh-conditioned** decomposition when user supplies part names.

---

## MoCapAnything V2 — video → rig (your animation-from-video idea)

Planned chain (character, not environment):

```text
South / mixed refs (character designer)
    → Pixel3D-class / Hunyuan3D-2 / LiTo mesh (same identity)
East-side 2D cycle OR WAN + sprite-action LoRA side-view video
    → MoCapAnything V2 (motion extract)
    → retarget to rig on the 3D mesh
    → loop clip + optional cutscene block (video + audio theme)
```

This is how **2D sprite work** stops being “sprite-only” and becomes **motion reference** for a **3D game character**.

Registry: `researchCandidates[].id === "mocap-anything-v2"` in `threed-registry.json`.  
Lane row: `video-mocap-retarget-3d` in `lane-pipelines-registry.json`.

---

## Full production graph (image → video → 3D → audio → niche designers)

Honest scope: **not one model** — a **curated pipeline** with LoRA fix-up stages. Fits Anikai’s sovereign workshop story.

```text
Concept sketch (optional) + text
    → Character / outfit / environment designers (image)
    → LoRA tweak passes (lighting, detail, inpaint)
    → Video (LTX / WAN / fashion / scene specialists — CogOmni-class scene understanding optional)
    → 3D mesh (Hunyuan / LiTo / TripoSR) + optional CubePart/PhysX
    → MoCap from video loops
    → Music / voice / theme (audio lane)
    → Playground save → chat “run production v3”
```

**AAA / Square Enix–class look** is realistic as **stacked specialists + art direction**, not a single checkpoint — same way AAA uses dozens of tools but **one director**. Anikai’s bet is the **director is the companion** and the **tools are packs**.

### Niche designers (parallel tracks)

| Designer | Feeds |
|----------|--------|
| Character | Mesh refs, angle batches, WAN video |
| Outfit / fashion | Look dev → apply to character |
| Environment | TriSplat sparse views, scene video |
| Vehicle / prop | CubePart schema → PhysX |
| Scene video (CogOmni-class etc.) | Motion / layout for cutscenes — video registry, not 3D |

---

## Integration order (recommended)

1. **Video smokes** — LTX direction cycles, then WAN + sprite LoRA (see **Near-term smoke order** above).  
2. **Mesh / splat smokes** — SHARP (partial), Hunyuan3D-2, TRELLIS, Pixel3D-class, LiTo, TripoSplat.  
3. **MoCapAnything V2** — highest leverage for **cycle → 3D anim** once video + mesh exist.  
4. **TriSplat** — environment SKU; depends on keyframe export UX.  
5. **CubePart + PhysX-Omni** — mechanical / interactive props; heavier integration.

Each promotion from `researchCandidates` → `testedStacks` needs: repo pin, `stage-*` script, Get pack or weights doc, Media Magic or headless IPC, one E2E smoke.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-06-02 | Initial watchlist: TriSplat, PhysX-Omni, CubePart, MoCapAnything V2; pano vs multi-view note; AAA production graph |
| 2026-06-02 | TripoSplat (DeG splats, MIT); near-term smoke order (LTX → WAN → mesh/splat → MoCap) |
