#requires -Version 5.1
<#
.SYNOPSIS
  Writes DOC_PROGRESS_SNAPSHOT.md: doc staging / operations roll-ups and checkbox counts per markdown file.

.DESCRIPTION
  Scans implementations/ and todo/ under android-arm64. Parses | **Doc staging** | and | **Operations** |
  from the standard status table. Counts markdown task items (- [ ] / - [x]) outside fenced code blocks.

.PARAMETER Arm64Root
  Path to .../05-story-lanes/ikagi/android-arm64 (folder that contains implementations/ and todo/).

.PARAMETER NoDrilldown
  Omit the long "Open checkbox drill-down" section (verbatim `- [ ]` lines per file).

.NOTES
  Re-run after doc edits: & scripts/Generate-DocProgressReport.ps1
#>
param(
  [string]$Arm64Root = (Split-Path -Parent $PSScriptRoot),
  [switch]$NoDrilldown
)

$ErrorActionPreference = "Stop"

$implRoot = Join-Path $Arm64Root "implementations"
$todoRoot = Join-Path $Arm64Root "todo"
$outPath  = Join-Path $implRoot "DOC_PROGRESS_SNAPSHOT.md"

if (-not (Test-Path $implRoot)) { throw "implementations not found: $implRoot" }
if (-not (Test-Path $todoRoot)) { throw "todo not found: $todoRoot" }

# Placeholder for missing status-table cells (matches markdown em dash)
$emDash = [string][char]0x2014

function Remove-MarkdownFencedCode {
  param([string]$Text)
  # ```lang ... ``` or ``` ... ```
  return [regex]::Replace($Text, '(?ms)^```[^\r\n]*\r?\n.*?^```\s*', '')
}

function Get-StatusFromTable {
  param([string]$Text, [string]$Label)
  # | **Doc staging** | Started |
  $esc = [regex]::Escape($Label)
  $pattern = "(?m)\|\s*\*\*$esc\*\*\s*\|\s*(.+?)\s*\|"
  $m = [regex]::Match($Text, $pattern)
  if (-not $m.Success) { return $null }
  $v = $m.Groups[1].Value.Trim()
  # strip accidental markdown in cell
  $v = $v -replace '^\*\*|\*\*$', ''
  return $v
}

function Get-CheckboxCounts {
  param([string]$Text)
  $stripped = Remove-MarkdownFencedCode $Text
  $open = 0
  $done = 0
  foreach ($mm in [regex]::Matches($stripped, '(?m)^\s*[-*+]\s+\[(\s|x|X)\]')) {
    $c = $mm.Groups[1].Value
    if ($c -match '^[xX]$') { $done++ } else { $open++ }
  }
  return @{ Open = $open; Done = $done; Total = ($open + $done) }
}

function Get-OpenCheckboxLineTexts {
  param([string]$Text)
  $stripped = Remove-MarkdownFencedCode $Text
  $out = New-Object System.Collections.Generic.List[string]
  foreach ($line in $stripped -split '\r?\n') {
    $m = [regex]::Match($line, '^\s*[-*+]\s+\[(\s|x|X)\]\s*(.*)$')
    if (-not $m.Success) { continue }
    if ($m.Groups[1].Value -match '^[xX]$') { continue }
    [void]$out.Add($m.Groups[2].Value.TrimEnd())
  }
  return $out
}

function Append-DrilldownSection {
  param(
    [System.Text.StringBuilder]$Sb,
    [string]$Title,
    [System.IO.FileInfo[]]$Files,
    [string]$RootDir
  )
  [void]$Sb.AppendLine("## $Title")
  [void]$Sb.AppendLine('')
  [void]$Sb.AppendLine('Each bullet is the text after an open `- [ ]` task item (same scope as counts: outside fenced code blocks).')
  [void]$Sb.AppendLine('')
  $rootResolved = (Resolve-Path $RootDir).Path
  $any = $false
  foreach ($f in ($Files | Sort-Object FullName)) {
    $raw = Get-Content $f.FullName -Raw -Encoding UTF8
    $items = Get-OpenCheckboxLineTexts $raw
    if ($items.Count -eq 0) { continue }
    $any = $true
    $rel = $f.FullName.Substring($rootResolved.Length).TrimStart('\', '/').Replace('\', '/')
    [void]$Sb.AppendLine("### ``$rel``")
    foreach ($t in $items) {
      $display = if ([string]::IsNullOrWhiteSpace($t)) { '_(empty)_' } else { $t }
      [void]$Sb.AppendLine("- $display")
    }
    [void]$Sb.AppendLine('')
  }
  if (-not $any) {
    [void]$Sb.AppendLine('_No open checkboxes in this scope._')
    [void]$Sb.AppendLine('')
  }
  [void]$Sb.AppendLine('---')
  [void]$Sb.AppendLine('')
}

function Collect-Rows {
  param(
    [System.IO.FileInfo[]]$Files,
    [string]$RootDir,
    [string]$KindLabel
  )
  $rows = New-Object System.Collections.Generic.List[object]
  foreach ($f in $Files) {
    $raw = Get-Content $f.FullName -Raw -Encoding UTF8
    $rel = $f.FullName.Substring((Resolve-Path $RootDir).Path.Length).TrimStart('\', '/').Replace('\', '/')
    $staging = Get-StatusFromTable $raw "Doc staging"
    $ops = Get-StatusFromTable $raw "Operations"
    $cb = Get-CheckboxCounts $raw
    [void]$rows.Add([pscustomobject]@{
      Kind = $KindLabel
      Path = $rel
      DocStaging = if ($staging) { $staging } else { $emDash }
      Operations = if ($ops) { $ops } else { $emDash }
      Open = $cb.Open
      Done = $cb.Done
      Total = $cb.Total
    })
  }
  return $rows
}

$implExcludeNames = @(
  "DOC_STATUS_HEADER.md"
)

$implFiles = Get-ChildItem $implRoot -Recurse -Filter "*.md" |
  Where-Object { $implExcludeNames -notcontains $_.Name }

$todoFiles = Get-ChildItem $todoRoot -Recurse -Filter "*.md"

$allRows = @()
$allRows += Collect-Rows $implFiles $implRoot "implementations"
$allRows += Collect-Rows $todoFiles $todoRoot "todo"

$utc = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss") + " UTC"

function Get-StatusRollup($Rows, $Property) {
  $Rows | Group-Object $Property | Sort-Object Name | ForEach-Object {
    [pscustomobject]@{ Name = $_.Name; Count = $_.Count }
  }
}

$byStaging = Get-StatusRollup $allRows DocStaging
$byOps = Get-StatusRollup $allRows Operations

$missingStaging = ($allRows | Where-Object { $_.DocStaging -eq $emDash }).Count
$missingOps = ($allRows | Where-Object { $_.Operations -eq $emDash }).Count

$sb = [System.Text.StringBuilder]::new()
[void]$sb.AppendLine('# Android arm64 - doc progress and checkbox snapshot')
[void]$sb.AppendLine('')
[void]$sb.AppendLine('| Field | Value |')
[void]$sb.AppendLine('|-------|-------|')
[void]$sb.AppendLine('| **Doc staging** | Started |')
[void]$sb.AppendLine('| **Operations** | Operational (generated digest) |')
[void]$sb.AppendLine("| **Last reviewed** | $(([datetime]::UtcNow).ToString('yyyy-MM-dd')) |")
[void]$sb.AppendLine('')
[void]$sb.AppendLine("**Generated:** $utc  ")
$relFromRepo = 'docs/source-of-truth/05-story-lanes/ikagi/android-arm64/scripts/Generate-DocProgressReport.ps1'
[void]$sb.AppendLine("**Regenerate (repo root):** ``powershell -NoProfile -ExecutionPolicy Bypass -File $relFromRepo``")
[void]$sb.AppendLine('**Optional (counts + roll-ups only):** append ``-NoDrilldown`` to skip the verbatim open-checkbox lists.')
[void]$sb.AppendLine('')
[void]$sb.AppendLine('**Scope:** all `*.md` under `implementations/` (except `DOC_STATUS_HEADER.md`) and all `*.md` under `todo/`. Parses the `| Field | Value |` table for **Doc staging** and **Operations**. Task checkboxes are `- [ ]` / `- [x]` lines outside fenced code blocks. **Drill-down** lists each open item''s line text by file (omit with `-NoDrilldown`).')
[void]$sb.AppendLine('')
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Summary")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Metric | Value |")
[void]$sb.AppendLine("|--------|-------|")
[void]$sb.AppendLine("| Implementation markdown files | $($implFiles.Count) |")
[void]$sb.AppendLine("| Todo markdown files | $($todoFiles.Count) |")
[void]$sb.AppendLine("| Files missing **Doc staging** cell | $missingStaging |")
[void]$sb.AppendLine("| Files missing **Operations** cell | $missingOps |")
[void]$sb.AppendLine("| Open checkboxes (total) | $(($allRows | Measure-Object -Property Open -Sum).Sum) |")
[void]$sb.AppendLine("| Done checkboxes (total) | $(($allRows | Measure-Object -Property Done -Sum).Sum) |")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Roll-up: Doc staging")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Doc staging | Files |")
[void]$sb.AppendLine("|-------------|-------|")
foreach ($g in $byStaging) {
  [void]$sb.AppendLine("| $($g.Name) | $($g.Count) |")
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Roll-up: Operations")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Operations | Files |")
[void]$sb.AppendLine("|------------|-------|")
foreach ($g in $byOps) {
  [void]$sb.AppendLine("| $($g.Name) | $($g.Count) |")
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Per file (implementations)")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Path | Doc staging | Operations | Open | Done | Total |")
[void]$sb.AppendLine("|------|-------------|------------|------|------|-------|")
foreach ($r in ($allRows | Where-Object Kind -eq "implementations" | Sort-Object Path)) {
  [void]$sb.AppendLine("| ``$($r.Path)`` | $($r.DocStaging) | $($r.Operations) | $($r.Open) | $($r.Done) | $($r.Total) |")
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Per file (todo)")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Path | Doc staging | Operations | Open | Done | Total |")
[void]$sb.AppendLine("|------|-------------|------------|------|------|-------|")
foreach ($r in ($allRows | Where-Object Kind -eq "todo" | Sort-Object Path)) {
  [void]$sb.AppendLine("| ``$($r.Path)`` | $($r.DocStaging) | $($r.Operations) | $($r.Open) | $($r.Done) | $($r.Total) |")
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## Files missing status cells (needs paste from DOC_STATUS_HEADER)")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Kind | Path | Missing |")
[void]$sb.AppendLine("|------|------|---------|")
foreach ($r in ($allRows | Where-Object { $_.DocStaging -eq $emDash -or $_.Operations -eq $emDash } | Sort-Object Kind, Path)) {
  $miss = @()
  if ($r.DocStaging -eq $emDash) { $miss += 'Doc staging' }
  if ($r.Operations -eq $emDash) { $miss += 'Operations' }
  [void]$sb.AppendLine("| $($r.Kind) | ``$($r.Path)`` | $($miss -join ', ') |")
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("---")
[void]$sb.AppendLine("")
if (-not $NoDrilldown) {
  Append-DrilldownSection $sb 'Open checkbox drill-down (implementations)' $implFiles $implRoot
  Append-DrilldownSection $sb 'Open checkbox drill-down (todo)' $todoFiles $todoRoot
}
[void]$sb.AppendLine("## Changelog (this snapshot)")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("| Date | Note |")
[void]$sb.AppendLine("|------|------|")
[void]$sb.AppendLine("| $(([datetime]::UtcNow).ToString('yyyy-MM-dd')) | Roll-ups, per-file counts, and open-checkbox drill-down (verbatim line text per file). |")

[System.IO.File]::WriteAllText($outPath, $sb.ToString(), [System.Text.UTF8Encoding]::new($true))

Write-Host "Wrote: $outPath"
Write-Host "implementation_md=$($implFiles.Count) todo_md=$($todoFiles.Count) open_total=$(($allRows | Measure-Object -Property Open -Sum).Sum) drilldown=$(-not [bool]$NoDrilldown)"
