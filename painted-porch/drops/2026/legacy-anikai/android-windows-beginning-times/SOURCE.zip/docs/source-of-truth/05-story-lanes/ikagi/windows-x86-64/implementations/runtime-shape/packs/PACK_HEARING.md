# Hearing runtime pack (whisper.cpp)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.hearing` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** ASR / live transcribe via whisper-cli + ggml DLLs.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

whisper.cpp Windows build; align ggml with gguf pack policy.

## Staging path

`desktop-data/runtime-packs/gguf.asr/`

## Unlocks (no model weights)

asr, live-transcribe

## Verification smoke

Transcribe 10s WAV fixture.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
