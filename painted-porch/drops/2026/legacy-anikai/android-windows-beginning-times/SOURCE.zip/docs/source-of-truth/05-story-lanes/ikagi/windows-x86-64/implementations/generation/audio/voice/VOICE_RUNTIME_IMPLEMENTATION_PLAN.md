# Voice runtime implementation plan (Android umbrella)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-06 |

Purpose: top-level voice runtime index. Engine-level planning lives in dedicated docs so each lane can be tested and iterated independently.

---

## Runtime map (current)

| Engine lane | Current status | Detailed plan |
|-------------|----------------|---------------|
| **Kokoro ONNX** | Active lane; needs parity hardening + emotion integration checks | [`KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md`](./engines/KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md) |
| **CosyVoice ONNX** | Adapter path present; needs readiness/synth parity hardening | [`COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md`](./engines/COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md) |
| **XTTS** | UI/runtime lane visible; native adapter integration still WIP | [`XTTS_RUNTIME_IMPLEMENTATION_PLAN.md`](./engines/XTTS_RUNTIME_IMPLEMENTATION_PLAN.md) |
| **KITTEN** | Catalog-present; dedicated bring-up/testing lane required | [`KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md`](./engines/KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md) |
| **VITS** | Catalog-present; front-end + runtime parity still pending | [`VITS_RUNTIME_IMPLEMENTATION_PLAN.md`](./engines/VITS_RUNTIME_IMPLEMENTATION_PLAN.md) |
| **Cloud providers (shared)** | Routing/fallback lane used as explicit optional provider path | [`CLOUD_VOICE_PROVIDER_PLAN.md`](./engines/CLOUD_VOICE_PROVIDER_PLAN.md) |

### References (code)

- `Anikai App/src/main/java/com/anikai/soul/voice/catalog/ExpressiveVoiceCatalog.kt`
- `Anikai App/src/main/java/com/anikai/soul/voice/provider_runtimes/VoiceProviderRuntime.kt`
- `Anikai App/src/main/java/com/anikai/soul/voice/provider_runtimes/local_runtime/LocalVoiceRuntimeInstaller.kt`

---

## Shared status model

Status model used in this workspace:

- `Not started`
- `In progress`
- `Operational`
- `Needs revisit`

`Operational` means production-usable at current bar; future upgrades are expected.

---

## Shared constraints across all engine docs

- each engine must expose explicit readiness diagnostics (no silent fallback claiming success),
- emotion/prosody integration must be validated per engine, not assumed from one lane,
- pack/runtime profile checks must be deterministic before synthesis starts,
- routing labels in UI must match actual executing engine.

## Delivery policy (Anikai first)

- ANIKAI-local engine path is always first target.
- If a lane cannot reach current operational bar, mark **Needs revisit**, shelve, and continue with other lanes.
- Keep shelved lanes documented with explicit return triggers and dated changelog updates.

---

## Cross-dependencies (sideways + parent)

This voice plan is not only a child:

- feeds **Game Maker** showcase operation (dynamic NPC voices),
- depends on runtime packaging/storage contract,
- overlaps with awareness/emotion systems and voice studio UX,
- interacts with mixed pipeline execution in `pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`.

Primary links:

- Parent tracker: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Operations board: `implementations/OPERATIONS_INDEX.md`
- Mixed workflow pipeline: `implementations/pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`
- Global execution context: `02-roadmap/LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial voice runtime plan split from local media mega-log with code-verified current-state summary. |
| 2026-05-06 | Converted to umbrella/index doc; split engine work into Kokoro/Cosy/XTTS dedicated plans. |
| 2026-05-06 | Added dedicated Kitten/VITS/cloud docs and formalized Anikai-first + shelve/return policy. |
