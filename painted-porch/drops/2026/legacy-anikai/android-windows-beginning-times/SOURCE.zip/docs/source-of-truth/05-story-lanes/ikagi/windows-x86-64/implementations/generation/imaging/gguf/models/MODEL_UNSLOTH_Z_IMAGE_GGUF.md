# Model sheet — unsloth / Z-Image-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [unsloth/Z-Image-GGUF](https://huggingface.co/unsloth/Z-Image-GGUF)  
- Turbo sibling: [`MODEL_LEEJET_Z_IMAGE_TURBO_GGUF.md`](./MODEL_LEEJET_Z_IMAGE_TURBO_GGUF.md)  
- **FLUX.1 ae (recommended, Apache-2.0):** [second-state/FLUX.1-schnell-GGUF — ae.safetensors](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/resolve/main/ae.safetensors) (or full sidecar tree [tree/main](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main)).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- LLM: [Qwen/Qwen3-4B](https://huggingface.co/Qwen/Qwen3-4B)  
- sd.cpp: [`z_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/z_image.md)  

## Pack family

`z_image_llm_vae` — FLUX.1 Schnell **ae.sft** VAE + Qwen3-4B LLM.

## Weight layout

```text
models/z-image/
  z_image_bf16-or-quant.gguf
  vae/ae.sft
  text_encoders/Qwen3-4B-Instruct-….gguf
```

## Product

- **Preset id:** `z_image_gguf_unsloth`  
- **Profile (proposal):** `z_image_gguf` — 1024×512 default in upstream example; cfg 5 base / 1 turbo  

## Anikai router

`planned` — `buildZImageSdArgs` + probe.

## Checklist

- [ ] Router + probe  
- [ ] E2E smoke  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
