# Chat turn timeline, Gemma UX, and inference caps (phased plan)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-20 |

**Purpose:** Phased delivery for (1) **Cursor-style turn timeline** in chat, (2) **honest footer caps** vs Persona sliders, (3) **Gemma 4 one-pass channel** stability, and (4) optional **pre-pass classifier** — without blocking current shipping chat.

**Gemma-specific issues and engine flags:** [`models/GEMMA4_E4B_ANIKAI.md`](models/GEMMA4_E4B_ANIKAI.md)

**Code today:** `anikai-desktop/components/chat.js` (`runGgufThoughtTurn`), `shared/gguf-output-templates/gemma4-channels.js`, `shared/companion-text-inference.js`, `shared/thought-segment-tags.js`

**Related:** [`../../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) (E+ `llama-server` before voice/live duplex)

---

## Problem statement (current)

| Symptom | Root cause |
|---------|------------|
| Thought/reply feel like **one blob** | Gemma uses **one unified completion** (`planningIncludesReply`); UI **re-renders one bubble** per chunk |
| Partial `<complexity …` lines while streaming | Tags stripped at **segment end**, not per chunk |
| **Contract / `[User]` echo** in debug (sometimes in bubble) | Full output contract pasted into **raw `-no-cnv` prompt**; model mirrors it |
| Footer **`thought cap 512`** vs Persona **32768** | Footer shows **effective this-turn cap** (adaptive % × plan max, floor **512** `TOKEN_MIN`), not slider max |
| Segments/tools **vanish** in UI | `segments[]` + tool loop exist; display **merges** thought and **replaces** DOM |
| Debug vs chat disagree | Debug = **literal stream**; chat = **parsed/sanitized** — intentional, confusing without labels |

---

## Target experience

```mermaid
flowchart TB
  subgraph ui [User-visible chat bubble]
    T1[Preflight / media notices]
    T2[Thought segment 1]
    TOOL[Tool: get_group_plan ✓]
    T3[Thought segment 2 optional]
    R[Reply streaming]
  end
  subgraph footer [Footer meta]
    F1[Persona max: plan · reply · ctx]
    F2[This turn: thought · reply · temp · unified]
  end
  subgraph debug [Debug only]
    D[Literal full stream + Copy]
  end
  T1 --> T2 --> TOOL --> T3 --> R
  footer --> F1
  footer --> F2
```

- **Normal chat:** no system contract, no `[User]` block, no machine tags in the reply.
- **Timeline:** append-only **events** inside the turn (not full bubble replace).
- **Footer:** two lines — **rails (Persona)** vs **effective (this message)**.
- **Debug:** unchanged role (forensics).

---

## Phase 0 — Document and measure (no UX rewrite)

**Goal:** Shared vocabulary and acceptance checks.

| Task | Done when |
|------|-----------|
| Keep [`GEMMA4_E4B_ANIKAI.md`](models/GEMMA4_E4B_ANIKAI.md) updated with each parser/engine change | Issue ↔ fix ↔ file path |
| Footer glossary in Persona panel: “This turn may use less than your max” | One hint line under inference summary |
| Smoke script: one “hi” turn → save `debugLiteral` + parsed thought/reply JSON | `scripts/` or manual checklist in Gemma doc |

**Exit:** Team agrees footer numbers are **effective caps**, not bugs.

---

## Phase 1 — Footer and Persona clarity (small code)

**Goal:** Stop “512 vs 32768” confusion without changing inference.

| Deliverable | Detail |
|-------------|--------|
| Footer line A | `Max: plan 32768 · reply 8192 · ctx 131072` (from loaded companion policy) |
| Footer line B | `Turn: thought 512 · reply 1802 · temp 0.36 · unified 2314 · task greeting` |
| Optional | Show `decideThought / decideReply / decideTemperature` as `companion decides` when flags true |

**Files:** `chat.js` (`formatInferenceMetaLine`, `mergeTurnInferenceMeta`), `panels.js` (Persona hint)

**Exit:** User can read footer without comparing to sliders incorrectly.

---

## Phase 2 — Stream sanitization during thought (medium)

**Goal:** No growing `<complexity` / `<tool` garbage in the live thought stream.

| Deliverable | Detail |
|-------------|--------|
| Streaming strip | Apply `ThoughtSegmentTags.stripMachineTags` (or partial-tag mask) on **each** `onStreamChunk` before paint |
| Contract echo | If cumulative buffer matches `isLikelyPromptLeak` / contract-only prefix, **hide** until real `<\|channel\|>thought` |
| Reply channel | Once `final` open, route chunks only to **reply** sub-pane |

**Files:** `chat.js`, `gguf-output-templates/utils.js`, `gemma4-channels.js` (`streaming: true` path)

**Exit:** “hi” turn shows readable planning lines, not 40 lines of partial tags.

**Depends on:** Phase 0 acceptance tests.

---

## Phase 3 — Turn timeline UI (larger)

**Goal:** Cursor-like **persistent steps** inside one assistant turn.

| Event type | Example UI row |
|------------|------------------|
| `preflight` | Media scan / compare notice |
| `thought_segment` | Collapsible “Thinking” body (segment N) |
| `tool_start` / `tool_done` | `get_group_plan` + result one-liner |
| `reply` | Main answer (existing `msg-body`) |
| `choices` | Interactive chips (existing) |

| Deliverable | Detail |
|-------------|--------|
| Data model | `messages[].turnEvents[]` persisted with chat session |
| Renderer | Append DOM nodes; **do not** `innerHTML` whole bubble on chunk |
| Segment loop | Push event when segment completes + when each tool returns |
| Scroll | Auto-scroll within turn; preserve expand/collapse state |

**Files:** `chat.js`, `chat.css`, serialize/restore in chat persistence

**Exit:** Tool + second segment visible as separate rows; nothing “disappears” when reply starts.

**Depends on:** Phase 2 (readable segment text).

---

## Phase 4 — Gemma prompt / echo reduction (engine + template)

**Goal:** Less contract regurgitation in the **literal** stream (fixes debug and parser).

| Option | Tradeoff |
|--------|----------|
| **A. Short channel hint** | Replace full `formatGemmaOutputContract()` in **completion** prompt with 3-line channel reminder; keep full contract in docs/training note only |
| **B. `llama-server` + chat template** | E+ session with jinja; may hide thought in stream (see Gemma doc) |
| **C. Negative / stop sequences** | Harder on `-no-cnv`; limited |

**Recommended first:** Option A + stronger `stripEchoedPromptFraming` on prefix before first real channel.

**Files:** `behavior-contract.js`, `gemma4-channels.js`, `gguf-completion.js`

**Exit:** Debug stream for “hi” starts at `<\|channel\|>thought`, not “Format (one pass…”.

**Tracked in:** [`GEMMA4_E4B_ANIKAI.md`](models/GEMMA4_E4B_ANIKAI.md) § Planned changes

---

## Phase 5 — Optional pre-pass classifier (second model)

**Goal:** Set **this-turn** `thoughtPct` / `replyPct` / `temp_bias` / `task` **before** main Gemma run, using model-emitted `<complexity/>` on the **same** turn today (too late).

### Architecture

```mermaid
sequenceDiagram
  participant U as User message
  participant C as Classifier GGUF
  participant G as Gemma 4 E4B
  participant UI as Chat timeline
  U->>C: Short prompt max 64-128 tok out
  C-->>UI: complexity JSON or tag
  UI->>G: Main turn unified cap from tag
  G-->>UI: thought + final channels
```

| Property | Guidance |
|----------|----------|
| **When** | Only if companion policy has `decideThought` / `decideReply` / `decideTemperature` |
| **Cost** | +1 spawn (or server slot) ~50–200 ms on 1B class GPU |
| **Fallback** | Heuristic `classifyTurnDemand` (today) if classifier fails |
| **Output contract** | Single line: `<complexity temp_bias="…" thought_pct="…" reply_pct="…" task="…"/>` only |

### Candidate classifier models (same `llama-completion` stack)

Pick **small instruct** GGUF the user may already have under `models/`. Quant **Q4_K_M or Q8** for speed.

| Model (HF / common GGUF name) | Params | Why consider | Caveat |
|-------------------------------|--------|--------------|--------|
| **SmolLM2-360M-Instruct** | 360M | Very fast; easy “router” | Weaker on nuanced `task` labels |
| **Qwen2.5-0.5B-Instruct** | 0.5B | Good instruction following / JSON-ish | Separate template from Gemma |
| **Llama-3.2-1B-Instruct** | 1B | Solid tiny classifier | Meta license / template |
| **Phi-3.5-mini-instruct** | 3.8B | Strong reasoning for size | Heavier than needed for router |
| **Gemma-2-2B-IT** | 2B | Same family tone as main model | Still not channel-native |
| **Ministral-3B-Instruct** | 3B | Already in ERNIE / encoder paths for some users | VRAM if same GPU as E4B |

**Recommendation:** **[SmolLM2-Rethink-360M](https://huggingface.co/prithivMLmods/SmolLM2-Rethink-360M-GGUF)** as a **Familiar** classifier (not the companion chat weight). See [`models/SMOLLM2_RETHINK_360M_ANIKAI.md`](models/SMOLLM2_RETHINK_360M_ANIKAI.md), [`../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md`](../../../anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md).

| Companion setting (proposed) | Meaning |
|------------------------------|---------|
| `classifierModelRef` | Optional path under `models/` |
| `classifierEnabled` | Off by default until Phase 5 shipped |

**Exit:** Footer `Turn:` line shows `task greeting (classifier)` and caps match `<complexity/>` before generation.

---

## Phase 6 — Ephemeral footer controls (optional polish)

**Goal:** Adjust **next** message caps without opening Persona.

| Control | Behavior |
|---------|----------|
| Mini sliders or steppers | Override **only next send** thought/reply % or temp |
| Reset | Back to Persona + classifier |
| Persist | Session-only, not saved to companion JSON |

**Depends on:** Phase 1 footer clarity (users understand what they’re tweaking).

---

## Other cool things (same timeline / inference stack)

| Idea | What it gives you |
|------|-------------------|
| **Resident `llama-server` (E+)** | Faster turns, real streaming API, classifier + main model hot-swapped by slot |
| **Classifier + main on two slots** | Router on 0.5B GPU stream; Gemma on GPU 0 |
| **Grammar / GBNF on classifier only** | Force valid `<complexity/>` one-liner |
| **Turn replay in debug** | Re-parse saved `debugLiteral` with parser v2 diff |
| **Export turn as markdown** | Timeline + reply for bug reports |
| **Per-event token counts** | “tool 412 tok · reply 1204 tok” in footer |
| **Screen capture → vision handoff** | Already shipping; document in timeline as `attachment` event |
| **Thought stream menu toggle** | Show/hide timeline thought rows without disabling tools |
| **Group vision lead row** | Timeline event “Sight: Companion B scanned image” |

---

## Suggested delivery order

| Order | Phase | Rationale |
|-------|-------|-----------|
| 1 | 0 + 1 | Cheap clarity |
| 2 | 2 | Fixes worst streaming UX before big UI |
| 3 | 4 | Reduces parser load for timeline |
| 4 | 3 | Timeline needs clean segments |
| 5 | 5 | Classifier optional power feature |
| 6 | 6 | Nice-to-have |

**Parallel:** Gemma doc + Phase 4 template work.

---

## Acceptance (full program)

- [ ] “hi” turn: no contract text in **user-visible** thought or reply
- [ ] Tool row visible before reply; second segment visible if loop continues
- [ ] Footer shows **Max** and **Turn** lines; Turn caps explain greeting floor 512 when plan max is high
- [ ] Debug still shows literal stream; Copy works
- [ ] Gemma doc lists each issue as **Open / Mitigated / Fixed** with PR or commit ref

---

## Linked todos

| Todo | Suggestion |
|------|------------|
| GGUF desktop | [`../../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) |
| Group E+ | [`../../../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md`](../../../../todo/mid-scope/TODO_GROUP_CHAT_MATE_NETWORK_DESKTOP.md) |
| Execution agent timeline | [`../../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md) (C2 drafting channel — related UX) |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial phased plan: timeline UI, footer caps, Gemma echo, classifier options, cool ideas |
