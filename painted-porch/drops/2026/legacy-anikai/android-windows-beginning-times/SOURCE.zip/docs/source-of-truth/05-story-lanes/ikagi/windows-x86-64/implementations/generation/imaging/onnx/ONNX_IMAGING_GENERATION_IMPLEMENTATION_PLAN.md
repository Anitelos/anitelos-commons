# ONNX imaging generation (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Partial (ORT runner + IPC; per-model files on disk) |
| **Last reviewed** | 2026-05-20 |

## Purpose

Track **still-image and post-process** targets that run through **ONNX Runtime** on desktop — upscalers, restoration, matting, depth, and other **specialty** graphs that are **not** the primary `sd.exe` txt2img path.

**Engine load, EP policy, and session lifecycle** live in the ONNX **engine** plan, not here.

**Lane index (desktop status, cross-family):** [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)

**ONNX engine (tasks, probes, CUDA/DirectML):** [`../../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

---

## Folder layout (this lane)

| Path | Role |
|------|------|
| `onnx/ONNX_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md` | This file — product rules for imaging ONNX |
| `onnx/models/` | Per-model sheets when a target ships (create on adoption; mirror [`../gguf/models/`](../gguf/models/) pattern) |

Do **not** mix PersonaLive portrait motion here — that is a **Python sidecar** under [`../python/`](../python/).

---

## Relationship to GGUF txt2img

| Role | Owner |
|------|--------|
| Primary decode (FLUX, SD, ERNIE, …) | [`../gguf/`](../gguf/) + `sd.exe` |
| Post-pass after PNG (upscale, face restore, …) | This lane + ONNX engine |
| About guide catalogue | Separate **ONNX** format section in `imaging-registry.json` (planned rows today) |

Hooks from the GGUF product plan: [`../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) (ONNX post section).

---

## Desktop code touchpoints (when wired)

| Area | Code (2026-05-20) |
|------|-------------------|
| Stack catalogue | `anikai-desktop/shared/onnx-imaging-stacks.js` |
| ORT runner | `anikai-desktop/main-process/onnx-imaging-runtime.js` + `onnx-image-io.js` |
| IPC | `imaging:onnx-list-stacks`, `imaging:onnx-probe-stack`, `imaging:onnx-run-stack` in `main.js` |
| Preload | `window.anikai.listOnnxImagingStacks` / `probeOnnxImagingStack` / `runOnnxImagingStack` |
| Smoke | `npm run smoke-onnx-imaging` |
| Deps | `onnxruntime-node`, `pngjs` in `anikai-desktop/package.json` |
| Registry | `assets/about-guide/imaging-registry.json` — `format: "onnx"` stacks |
| Runtime pack | Settings → Device → Software → ONNX format pack (voice.onnx ORT DLLs; imaging uses npm ORT today) |

**Model folders** (under `%ANIKAI_HOME%/models/`):

| Stack id | Folder | Example file |
|----------|--------|----------------|
| `onnx_upscale` | `onnx/upscale/` | `4x-UltraSharp.onnx` |
| `onnx_bg_remove` | `onnx/rembg/` | `u2net.onnx` |
| `onnx_portrait_depth` | `onnx/portrait-depth/` | `depth.onnx` |
| `onnx_inpaint` | `onnx/inpaint/` | `lama.onnx` (+ mask at run) |
| `onnx_pose_dwpose` | `onnx/dwpose/` | `yolox_l.onnx`, `dw-ll_ucoco_384.onnx` |

**Runner status:** upscale, matting, depth, inpaint (image+mask), DWPose (yolox+dw-ll) **shipped in desktop runner**; GFPGAN / Wav2Lip **catalogue only**.

---

## Stack library

Curated ONNX families (sprite post, portrait depth, matting, face restore, pose aux): [`ONNX_IMAGING_STACK_LIBRARY.md`](./ONNX_IMAGING_STACK_LIBRARY.md).

---

## Adoption checklist (per model)

1. Add `onnx/models/MODEL_*.md` with HF id, input resolution, and honest VRAM floor.  
2. Register stack in `build-imaging-registry.mjs` (or sibling builder) with `format: 'onnx'`.  
3. Tick E2E in [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md) only after Media Magic or companion path persists output.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial ONNX imaging lane stub; `models/` reserved; links to engine plan and GGUF index. |
| 2026-05-20 | Desktop v1: `onnx-imaging-runtime.js`, IPC, smoke script; upscale/matting/depth runners. |
| 2026-05-20 | v2: DWPose two-graph, inpaint dual-feed, Media Magic post UI, Get packs, runtime-packs-registry. |
