# XTTS runtime implementation plan (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

---

## Current state (code)

- XTTS lane is visible in runtime selection/UI as WIP (`XTTS (WIP)`).
- `XtTsRuntimePack` currently throws explicit WIP errors for synth/stream paths.
- `LocalVoiceRuntimeInstaller` includes XTTS runtime library staging scaffolding (`libxtts-native.so` flow).

Primary references:

- `.../voice/provider_runtimes/VoiceProviderRuntime.kt` (`XtTsRuntimePack`)
- `.../voice/provider_runtimes/local_runtime/LocalVoiceRuntimeInstaller.kt`
- `.../voice_subtabs/sonus_subtab/VoicePackBrowseSheet.kt`

---

## Operational goals

1. connect staged runtime binaries to real native XTTS synthesis path,
2. replace WIP throw behavior with readiness-gated execution,
3. define pack/profile contract and diagnostics for supported XTTS bundles,
4. align UI labels with actual runtime behavior.

---

## Checklist

- [ ] Confirm runtime binary install/staging path for active ABIs.
- [ ] Implement native adapter bridge in XTTS runtime pack.
- [ ] Add deterministic pack validation before runtime init.
- [ ] Wire synth + streaming state transitions.
- [ ] Document explicit fallback behavior when XTTS is selected but unavailable.

---

## Dependencies

- Parent: `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md`
- Umbrella: `../VOICE_RUNTIME_IMPLEMENTATION_PLAN.md`
- Mixed pipeline relation: `../../../pipelines/VOICE_MUSIC_WORKFORCE_PIPELINE_PLAN.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | Initial dedicated XTTS runtime plan split from umbrella voice doc. |
