# The Terminal — documentation hub

| Field | Value |
|-------|-------|
| **Status** | Living / end-game vision (not shipped as product UI yet) |
| **Code home (future)** | `anikai-desktop/main-process/workshop-log.js`, Workshop Terminal panel in chat |
| **npm catalog (repo)** | [`../../../../../../../anikai-desktop/npm/README.md`](../../../../../../../anikai-desktop/npm/README.md) |
| **Dev checks runbook** | [`npm/README.md`](npm/README.md) |

---

## Start here

| Doc | Who it's for |
|-----|----------------|
| **[`ANIKAI_TERMINAL_LIVING_SPEC.md`](ANIKAI_TERMINAL_LIVING_SPEC.md)** | Everyone — forever spec: workshop log, in-app terminal, PowerShell end-game, Overseer, chat menu entry |
| **[`WSL_TERMINAL_AND_STREAMING_PLAN.md`](WSL_TERMINAL_AND_STREAMING_PLAN.md)** | Windows + LiTo/WSL workflows — how to stream "real terminal-like" run output safely |
| **[`CONTRIBUTING_TO_THIS_FOLDER.md`](CONTRIBUTING_TO_THIS_FOLDER.md)** | Humans + AI — how to add npm scripts, log domains, and UI ideas without bloating the spec |

---

## One-line product vision

**Anikai Terminal** = Android Studio Logcat + an optional PowerShell workshop shell — always recording structured workshop events in the background; full UI and shell backends only when the user opens it from chat (≡ menu), so CUDA inference and companions are never drowned in noise.

---

## Near-term vs end-game

| Horizon | What |
|---------|------|
| **Now** | `npm run dev`, `dev:cluster-debug`, catalogs in `anikai-desktop/npm/` + [`npm/`](npm/README.md) runbook; chat ≡ → **Workshop Terminal (soon)** hint |
| **Next** | Workshop log ring buffer (M0), chat ≡ → full **Workshop Terminal** panel (M1) |
| **End-game** | PowerShell PTY in panel, companion-suggested commands with HITL, multi-backend dropdown (cmake, Ubuntu WSL, …) |

Update **`ANIKAI_TERMINAL_LIVING_SPEC.md`** changelog when you extend scope — do not fork competing terminal plans elsewhere.
