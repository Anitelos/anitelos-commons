# Anikai rig + phoneme driver (built-in)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.rig.anikai` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Face rig policy, PoseIntent schema, canvas phoneme path — no vendor ZIP.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

Ship in app; phoneme synth still in progress.

## Staging path

`app policy + motion-sentience-registry.json`

## Unlocks (no model weights)

rig-deterministic, phoneme-driver

## Verification smoke

Load rig JSON; render test pose intent.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
