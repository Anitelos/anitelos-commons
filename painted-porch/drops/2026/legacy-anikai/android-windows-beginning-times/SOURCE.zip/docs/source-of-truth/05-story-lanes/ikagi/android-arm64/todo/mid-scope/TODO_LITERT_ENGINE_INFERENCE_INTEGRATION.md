# TODO — LiteRT engine inference integration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/litert/LITERT_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Track LiteRT as a formal engine family lane with adapter + manifest discipline.
- Convert helper-task mentions into buildable runtime integration work.
- Keep delegate policy and fallback transparency explicit per device class.

---

## Checklist (working)

- [ ] Define LiteRT adapter ids and manifest schema fields for ANIKAI model hub.
- [ ] Deliver one operational LiteRT helper lane with validated output schema.
- [ ] Implement delegate selection policy and explicit fallback diagnostics.
- [ ] Wire at least one Swarm specialist lane to LiteRT adapter resolution.
- [ ] Validate cancellation/lifecycle reliability under repeated runs.
- [ ] Ensure no silent non-local fallback when LiteRT lane fails.

---

## Linked operations

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through inference maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created LiteRT engine inference integration todo during model-family split pass. |
