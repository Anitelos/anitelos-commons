# Awareness (anima)

Continuity of attention, emotional thread, and learning across sessions/devices—distinct from a single OS quirks doc.
