# Imaging pipeline record & replay

**Status:** Phase 1 shipped (record / replay). **Image weaving** tab scaffold shipped (layers · preview · settings · recent gens). Node canvas + bake export from weaving are next.

**Related UI:** Media Magic **Record / Stop**; **Pipelines** pane (list, source paths, Run).

**Playground (graph editor):** [`PLAYGROUND_NODE_EDITOR_DIRECTION.md`](./PLAYGROUND_NODE_EDITOR_DIRECTION.md) — Rete UI layer, phased 2D → 3D; Record feeds this lane.

## Target flow (from sketch)

```
[prompt alpha mask] ──┐
[media source]      ──┼──► tuned settings ──► gen 1 (Qwen mask)
                      │
                      └──► tuned settings + prompt final + source re-feed ──► gen 2 (Kontext)
                                    │
                                    ▼
                      tuned settings ──► gen 3 (depth ONNX)
                                    │
                                    ▼
                      image mix (blend / layers) ──► bake save
```

Optional branch: after Kontext, **prompt alpha → tune → Qwen gen 4** can feed the image-mix step instead of depth-only output.

## Phase 1 (shipped)

| Piece | Location |
|-------|----------|
| Schema v1 | `anikai-desktop/shared/imaging-pipeline-schema.js` |
| Save/load | `anikai-desktop/main-process/imaging-pipeline-store.js` → `ANIKAI_HOME/runtime/pipeline-schemas/` |
| Replay | `anikai-desktop/main-process/imaging-pipeline-runner.js` → `runtime/pipeline-runs/<id>/` |
| Record UI | Media Magic header **Record** → mask / main / post runs append steps → **Stop** names + saves (auto **bake_save** if missing) |
| Playground | `anikai-desktop/components/pipelines-panel.js` |

**Step types:** `pre` | `main` | `post` | `image_mix` (pass-through until mix tab exists) | `bake_save`.

**Wiring:** `inputs.sourceId`, `maskFromStep`, `inputFromStep` resolve image paths per step during replay.

## Schema (v1)

```json
{
  "version": 1,
  "id": "kontext-depth-abc123",
  "name": "Qwen mask → Kontext → depth → bake",
  "sources": [
    { "id": "src_media_source_0", "slot": "media_source", "label": "Media source", "path": "" }
  ],
  "steps": [
    {
      "id": "step_1",
      "type": "pre",
      "label": "gen (mask) · Qwen mask",
      "modelRef": "pre:qwen-mask",
      "prompt": "main character",
      "inputs": { "sourceId": "src_media_source_0" }
    },
    {
      "id": "step_2",
      "type": "main",
      "label": "gen (main) · diffusers:…",
      "modelRef": "diffusers:…",
      "prompt": "…",
      "inputs": { "sourceId": "src_media_source_0", "maskFromStep": "step_1" },
      "settings": { "styleId": "none", "outputFormat": "png" }
    },
    {
      "id": "step_3",
      "type": "post",
      "label": "gen (post) · depth",
      "modelRef": "onnx:onnx-depth-…",
      "inputs": { "inputFromStep": "step_2" }
    },
    {
      "id": "step_4",
      "type": "bake_save",
      "label": "Bake save",
      "inputs": { "inputFromStep": "step_3" }
    }
  ]
}
```

## Image weaving UI (Phase 2a — scaffold)

Media Magic header mode **Image weaving** (formerly “Image mix”):

| Region | Role |
|--------|------|
| **Layers** (left) | Stack list; **+ Image** upload; drop zone for drag-from-recent |
| **Preview** (center) | Canvas composite of visible layers |
| **Settings** (right) | Opacity, blend mode, visibility, remove layer |
| **Recent generations** (bottom dock) | Shared across Image / Music / Video — **drag** or **double-click** thumb to add a layer (Image weaving) |

Starts empty until the user adds an image. **Bake** (UI): composites visible layers at full resolution → PNG under `generated-media/image-mix/` → appears in Recent generations. Pipeline `image_mix` step still **pass-through** in replay until it references a baked path.

## Phase 2+ (planned)

See [`PLAYGROUND_NODE_EDITOR_DIRECTION.md`](./PLAYGROUND_NODE_EDITOR_DIRECTION.md) for Rete spikes and unified graph schema.

1. **Node canvas** — drag sources, wires, inline value chips, save / save as (Rete Phase 2).
2. **Image weaving bake** — export composite PNG; wire `image_mix` step in runner; alpha burn / overlay sliders.
3. **Mid-pipeline source insert** — re-feed `media_source` + `prompt final` into Kontext step (as in sketch).
4. **Optional Qwen branch** after Kontext into mix input.
5. Export schema JSON for docs/tests.
6. **Companion-authored pipelines** — full capability inventory exposed in chat (see [`../../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../../WHAT_IS_ANIKAI_ON_WINDOWS.md)).
7. **Video weaving + ShaderToy layers** — [`VIDEO_MIX_SHADERTOY_DIRECTION.md`](./VIDEO_MIX_SHADERTOY_DIRECTION.md) (shipped scaffold: preview, groups, generate, chat `generate_shader`).

## Non-goals (v1)

- No pixel-perfect UI replay (window positions, scroll).
- No automatic HF downloads during replay (packs from catalogue **Get pack** first).

See also: [CURATED_PIPELINES_INDEX.md](./CURATED_PIPELINES_INDEX.md).
