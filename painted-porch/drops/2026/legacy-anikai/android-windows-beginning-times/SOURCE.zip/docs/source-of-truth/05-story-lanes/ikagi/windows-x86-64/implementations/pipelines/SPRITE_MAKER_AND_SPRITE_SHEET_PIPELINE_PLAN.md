# Sprite Maker + Sprite Sheet pipeline plan (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Partial (Steps 1–5 shipped; archetype dialog + FOMM lane planned) |
| **Last reviewed** | 2026-05-22 |
| **Platform** | **Windows desktop** (`anikai-desktop` · Media Magic · Games → Sprite sheet). Android lane doc is reference-only: [`../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md`](../../android-arm64/implementations/pipelines/SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE_PLAN.md). |

Purpose: define one end-to-end **local** pipeline from concept intake to approved tidy NESW stills to final sprite-sheet export for Game Maker–class ingest.

**App implementation snapshot (non-authoritative, Windows):** Games → **Sprite sheet** in Media Magic implements **Steps 1–3** in `anikai-desktop/components/media.js` + `media-pane-templates.js`. Step 1 uses **Main model (Kontext)** (`#mediaSpriteModelSelect`): Diffusers `FluxKontextPipeline` when a `preset:…` is selected, else **GGUF Kontext** via `sd.exe` img2img. Step 2: ONNX rembg + fringe color remove + tight crop (`shared/sprite-pixel-cleanup.js`). Step 3: N/E/S/W from **south** via img2img (same model as Step 1; status line `#mediaSpriteStep3ModelHint`). Steps 4+ (sheet compose, animation dialog) remain **planned** per sections below. Authoritative behavior stays in code until this doc is marked operational.

**Offline pixel cleanup tool (optional):** [`../../../../../../tools/pixel-sprite-downscale/index.html`](../../../../../../tools/pixel-sprite-downscale/index.html) — downscale, palette limit, edge flood remove, tight crop before dropping into Step 3 South.

---

## Windows desktop — shipped vs planned (2026-05)

| Step | Product surface | Status | Engine / notes |
|------|-----------------|--------|----------------|
| **1 — Concept still** | Step 1: concept drop, style ref, pixel W/H, Generate | **Shipped** | Kontext txt2img / dual-ref (`multiple_images` on Diffusers); GGUF concept-only on `sd.exe`. Progress + GPU label on generate. |
| **2 — Matte / cleanup** | Step 2: rembg, fringe color, tolerance, pick/remove, tight crop | **Shipped** | ONNX rembg IPC; CPU flood/crop helpers. |
| **3 — NESW facings** | Step 3: South drop / Use Step 1; Generate N/E/W | **Shipped** | img2img from south; `SPRITE_FACING_PROMPTS`; no separate Step 3 model picker. |
| **4 — Approval gate** | Approve / revoke NESW set | **Shipped** | `#mediaSpriteApproveNeswBtn`; clears on facing change. |
| **5 — Sheet export** | Facing mode + 8-frame strip PNG | **Shipped** | `#mediaSpriteExportSheetBtn`; `SpriteSheetCompose` + `.meta.json` sidecar. |
| **6 — Animation dialog** | Archetype + extended frame plans | **Planned** | See § Post-NESW animation dialog. |
| **7 — FOMM / motion lane** | Higher-fluidity between frames | **Planned** | Lane A optional; v1 offset loop shipped in Step 5. |

**Quality contract:** [`../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`](../generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md) (Windows wording). **Stack roles:** [`./IMAGING_PIPELINE_QUALITY_STACK.md`](./IMAGING_PIPELINE_QUALITY_STACK.md).

---

## Scope

This file covers:

- Sprite Maker intake and tidy character still generation,
- route selection across prompt-only, reference+prompt, and reference+vision-assist+prompt,
- Flux primary plus ONNX x4 post flow,
- animation-variation planning and sprite-sheet build flow from approved stills,
- UI clarity policy (disable states so users are not shown invalid controls).

This file does **not** replace:

- sprite visual quality contract in `generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`,
- model-family generation planning in `generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md` and `generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md`,
- low-level runtime internals in `engine-inference/model-hub/*`.

---

## Product endgame (single truth)

The project target is:

1. User can provide prompt-only or concept image + prompt.
2. App produces tidy NESW still outputs with consistent identity.
3. User approves still outputs.
4. App builds a sprite sheet via a second pipeline using motion archetypes and character profile context.
5. Final artifacts are exported with explicit metadata trail.

---

## Pipeline DAG

| Stage | Job | Typical owner |
|-------|-----|----------------|
| **P0 - Character intake** | Normalize prompt, optional concept refs, character profile (background/identity/mission), and desired style tags. | app layer |
| **P1 - Route select** | Choose generation route: prompt-only, ref+prompt, or ref+vision-assist+prompt. | app orchestration |
| **P2 - Prompt scaffold** | Build structured generation brief (identity lock, silhouette constraints, facing goals, quality preset). | text scaffold helper + app templates |
| **P3 - Tidy still generation (NESW)** | Generate N/E/S/W master stills using Flux primary lane (img2img or txt2img as selected). | local image runtime primary adapter |
| **P4 - Post quality pass** | Run ONNX x4 UltraSharp stage post where enabled and valid for preset/device. | ONNX image runtime |
| **P5 - Approval gate** | User review/approve NESW outputs; rejected outputs re-enter P2/P3 with variation controls. | Sprite Maker surface |
| **P6 - Motion archetype mapping** | Map approved character to animation archetype (manual preset or profile-driven auto-pick). | sprite-sheet orchestrator |
| **P7 - Sprite-sheet compose** | Generate frame sets and compose final sheet(s), preserving identity and silhouette across frames. | Sprite Sheet Maker pipeline |
| **P8 - Export + metadata** | Save sheet, preview strips, and metadata (route, model ids, preset, archetype, stage timings). | Creations export |

---

## Route and model policy

### Supported routes

- `Prompt only` (txt2img primary),
- `Reference + prompt` (img2img primary),
- `Reference + vision assist + prompt` (image understanding stage feeds scaffold, then img2img/txt2img).

### Model profile policy (Windows)

- **FLUX Kontext (Diffusers preset)** = preferred primary for concept + reference + N/E/W consistency (`FluxKontextPipeline`, `media-diffusers-image.py`).
- **FLUX Kontext (GGUF / `sd.exe`)** = operational fallback; concept-only on Step 1; south-driven img2img on Step 3.
- **Flux.2** = experimental when assigned (same Media Magic model picker family).
- **ONNX rembg** = Step 2 matte (required for clean south before NESW).
- **ONNX x4 UltraSharp** = canonical post lane for quality uplift (Media Magic post row / future sprite preset).

Rule: keep route selection and model profile selection as separate controls. **Step 3 does not duplicate the model picker** — it reads Step 1’s Kontext selection.

### Windows route mapping (Media Magic today)

| Legacy route name (schema) | Windows UI today |
|----------------------------|------------------|
| `PROMPT_ONLY` | Step 1 generate with concept only (no ref) |
| `REF_PROMPT` | Step 1 concept + style reference |
| `REF_VISION_PROMPT` | **Planned** — vision-assist scaffold before img2img (companion / VLM lane) |

---

## UI clarity contract (disable states)

To avoid user confusion, controls must disable when prerequisites are missing:

- disable `Reference + prompt` and `Reference + vision assist + prompt` routes when no reference image is attached,
- disable `Flux.2` profile when no assigned Flux.2-capable lane is available,
- disable `Generate` when selected route has no assigned compatible model lane,
- disable sprite-sheet generation until NESW approval gate passes,
- disable archetype auto mode when character profile context is empty and no fallback rule is configured.

Each disabled control must show a short reason string (e.g., "Attach a reference image first").

---

## UI toggle matrix (enable/disable truth table)

### Route selector (Sprite Maker)

| Route option | Enabled when | Disabled reason copy |
|-------------|--------------|----------------------|
| `Prompt only` | text-to-image lane is assigned and ready | `Assign a text-to-image model first.` |
| `Reference + prompt` | reference image is attached **and** image-to-image lane is assigned and ready | `Attach a reference image and assign an image-to-image model.` |
| `Reference + vision assist + prompt` | reference image is attached **and** vision-assist lane available **and** primary generation lane available | `Needs reference image, vision assist lane, and a primary generation model.` |

### Model profile selector

| Model option | Enabled when | Disabled reason copy |
|-------------|--------------|----------------------|
| `Flux.1 (default)` | at least one Flux.1-compatible primary lane is assigned | `Assign a Flux.1 primary lane under User Access -> Models.` |
| `Flux.2 (experimental)` | Flux.2 lane is assigned and device policy allows this profile | `Flux.2 lane unavailable or blocked by current device policy.` |
| `ONNX x4 post` (quality toggle) | ONNX post graph is assigned and compatible with selected output shape/preset | `Assign a compatible ONNX x4 post model to enable this quality pass.` |

### Primary actions

| Action | Enabled when | Disabled reason copy |
|--------|--------------|----------------------|
| `Generate NESW` | selected route + selected model profile are valid and required inputs exist | `Current route/model selection is incomplete.` |
| `Approve NESW set` | all required facings are present and pass minimum quality checks | `Complete all required NESW outputs before approval.` |
| `Generate sprite sheet` | NESW set is approved and archetype selection resolved (manual or auto) | `Approve NESW and choose/resolve animation archetype first.` |

### Archetype controls (Sprite Sheet Maker)

| Control | Enabled when | Disabled reason copy |
|---------|--------------|----------------------|
| `Auto archetype` | character profile fields exist (`identity`, `mission`, or equivalent) and auto rules are loaded | `Add character profile context to use auto archetype.` |
| `Manual archetype list` | archetype catalog is loaded | `Archetype catalog not loaded.` |
| `Archetype override` | auto archetype produced a result or manual was pre-selected | `No archetype result available to override yet.` |

Implementation note: when disabled, keep controls visible but dimmed and include reason text directly below the control to prevent "hidden feature" confusion.

---

## Model readiness chips (planned UX)

**Status:** not implemented yet; design contract for a future Creations / Sprite Maker strip so users see what is **on-device and usable** without opening Swarm settings.

### Goals

- One glance: **Flux.1**, **Flux.2**, **ONNX x4 (UltraSharp)**, **FOMM v2 bundle** each show `missing` / `downloaded` / `ready` (or equivalent).
- **Ready** means more than “file exists”: e.g. Flux GGUF is loadable size; zip bundles are unpacked and required subgraph files are present; ONNX post matches expected naming where the scanner expects it.

### Flux 1 vs Flux 2

- Ship **two curated downloads** (when Flux.2 lane is productized): distinct `CuratedModelEntry` ids and **distinct on-disk `fileName`s** (e.g. two different `.gguf` names).
- **Primary scan id:** Swarm lane assignment / catalog id the user binds for img2img or txt2img.
- **Secondary verification id (optional but recommended):** derive a stable token from the resolved **filename** (or a manifest sidecar) so readiness logic can ask “does this disk artifact match Flux.1 vs Flux.2?” without ambiguous single-path assumptions.
- UI chips should key off **resolved primary lane + filename family**, not only a single generic “flux” flag.

### ONNX: x4 UltraSharp vs FOMM

| Chip | Artifact | Ready means (conceptual) |
|------|-----------|---------------------------|
| **x4 post** | Assigned ONNX sharpen/upscale graph | Model file present under Swarm (or assigned path), extension/name matches runtime resolver, compatible with output shape policy. |
| **FOMM v2** | Qualcomm FOMM zip → unpacked folder | Zip present **and** extracted ONNX files found matching required tokens (`detector`, `generator`) under the predictable unpack root. |

### Interaction with disable matrix

- Chips are **informational**; the existing toggle matrix remains the authority for what actions are enabled.
- When a chip shows `missing`, adjacent copy can deep-link to **Assign model → Swarm** or the pipeline catalog.

---

## Animation variety system (non-uniform characters)

Use a motion-archetype library (5-10 presets) to prevent same-animation output across all characters.

Recommended initial archetypes:

- stoic_guardian,
- agile_rogue,
- heavy_brute,
- arcane_caster,
- beast_feral,
- gunner_tactical,
- spear_dancer,
- floating_mystic.

Selection policy:

- user-selected archetype wins,
- if not selected, auto-pick from character profile (background/identity/mission text),
- always allow user override before P7 compose.

---

## Character profile payload (for sheet intelligence)

Minimum schema fields to feed Sprite Sheet Maker:

- `identity_summary`,
- `mission_role`,
- `temperament_tags`,
- `combat_style_tags`,
- `silhouette_notes`,
- `equipment_props`,
- `preferred_archetype` (optional),
- `route_used`,
- `model_profile_used`.

This payload should be created in P0/P2 and carried through P8 export metadata.

---

## Schema contract (v1 draft)

Use one shared run contract so Sprite Maker and Sprite Sheet Maker can pass state without hidden assumptions.

### `CharacterProfile`

| Field | Type | Required | Notes |
|------|------|----------|-------|
| `characterId` | `String` | yes | Stable id across reruns. |
| `displayName` | `String` | yes | Human-readable character name. |
| `identitySummary` | `String` | yes | Core identity/persona sentence(s). |
| `missionRole` | `String` | no | Goal/mission text used for archetype hints. |
| `temperamentTags` | `List<String>` | no | Example: `disciplined`, `reckless`, `mystic`. |
| `combatStyleTags` | `List<String>` | no | Example: `melee`, `ranged`, `caster`. |
| `silhouetteNotes` | `String` | no | Shape/readability constraints. |
| `equipmentProps` | `List<String>` | no | Persistent visual props. |
| `preferredArchetype` | `String?` | no | Optional user-selected default. |

### `SpritePipelineRunSpec`

| Field | Type | Required | Notes |
|------|------|----------|-------|
| `runId` | `String` | yes | Unique pipeline run id. |
| `characterProfile` | `CharacterProfile` | yes | Bound character profile snapshot. |
| `routeMode` | `enum` | yes | `PROMPT_ONLY`, `REF_PROMPT`, `REF_VISION_PROMPT`. |
| `modelProfile` | `enum` | yes | `FLUX1_DEFAULT`, `FLUX2_EXPERIMENTAL`. |
| `qualityPreset` | `enum` | yes | `FAST`, `BALANCED`, `QUALITY`. |
| `enableOnnxPostX4` | `Boolean` | yes | Canonical ONNX stage-post toggle. |
| `referenceImageUri` | `String?` | conditional | Required for reference routes. |
| `directionRefUri` | `String?` | no | Optional mood/direction reference. |
| `promptText` | `String` | yes | User prompt + scaffold output. |
| `targetCellPx` | `Int` | yes | Output side per facing. |
| `targetBodyPx` | `Int` | yes | Character body height target. |
| `laneAssignments` | `Map<String, String>` | yes | Active model paths per lane at run start. |

### `NeswArtifactSet`

| Field | Type | Required | Notes |
|------|------|----------|-------|
| `setId` | `String` | yes | Group id for NESW render set. |
| `runSpecId` | `String` | yes | Back-reference to run spec. |
| `northUri` | `String?` | yes | Nullable until generated. |
| `eastUri` | `String?` | yes | Nullable until generated. |
| `southUri` | `String?` | yes | Nullable until generated. |
| `westUri` | `String?` | yes | Nullable until generated. |
| `approved` | `Boolean` | yes | NESW approval gate flag. |
| `approvalNotes` | `String?` | no | Optional user notes before sheet step. |

### `SpriteSheetComposeSpec`

| Field | Type | Required | Notes |
|------|------|----------|-------|
| `composeId` | `String` | yes | Unique compose request id. |
| `neswSetId` | `String` | yes | Approved NESW set input id. |
| `targetFacingMode` | `enum` | yes | `NORTH`, `EAST`, `SOUTH`, `WEST`, `ALL`. |
| `archetypeMode` | `enum` | yes | `MANUAL`, `AUTO_FROM_PROFILE`. |
| `selectedArchetype` | `String?` | conditional | Required when manual mode selected. |
| `framePlanId` | `String` | yes | Idle/walk/attack frame layout profile id. |
| `outputSheetLayout` | `String` | yes | Row/column/cell ordering contract id. |
| `emitPreviewAnimation` | `Boolean` | yes | Enables in-place preview playback after sheet output. |

---

## Post-NESW animation dialog flow

After NESW generation completes, show a dedicated animation dialog (separate from still generation controls).

### Dialog controls

- facing target selector: `North`, `East`, `South`, `West`, `All`,
- archetype selector: manual preset list or auto-from-profile,
- frame plan selector (basic vs extended),
- run button: `Generate sheet animation`.

### Facing mode behavior

- single-facing modes generate sheet frames for that facing only,
- `All` mode executes one facing at a time in fixed order (`N -> E -> S -> W`), back-to-back,
- each facing run writes intermediate progress and preview availability state.

### Disable-state rules (dialog)

- disable dialog open action until NESW set is complete,
- disable `Generate sheet animation` until NESW set is approved,
- disable `All` mode when any required facing source image is missing,
- disable auto-archetype when profile context required for mapping is absent.

---

## Progress and in-place preview contract

### Generation progress

- show stage label + numeric percent (0-100%) during sheet generation,
- for `All` mode, show nested progress:
  - overall progress across all facings,
  - current-facing progress (e.g. `EAST 45%`).

### Preview behavior

- when one facing sheet is complete, enable in-place loop preview for that facing immediately,
- when `All` mode finishes, provide facing tabs and `Play all` loop preview,
- keep preview local and deterministic (no remote player dependency),
- preserve a "still fallback preview" if animation frames fail for any facing.

### Suggested progress model

- `0-15%`: input validate + frame-plan build,
- `16-70%`: frame generation/composition,
- `71-90%`: post cleanup + sheet encode,
- `91-100%`: metadata write + preview-ready index.

---

## Models needed (practical starting set)

### Required for first operational release

1. **Primary generation model (Flux.1 GGUF)**  
   - Role: P3 tidy NESW still generation (txt2img/img2img route dependent).  
   - Count: **1 required** for operational baseline.

2. **Post model (ONNX x4 UltraSharp)**  
   - Role: P4 quality uplift/sharpen stage.  
   - Count: **1 required** for quality path.

### Optional for expansion

3. **Flux.2 primary lane (experimental)**  
   - Role: alternate primary profile for devices that can afford it.  
   - Count: 0 required for baseline; enable when available.

4. **Vision-assist model lane**  
   - Role: route `Reference + vision assist + prompt` (image understanding that improves prompt scaffold).  
   - Count: 0 required for baseline; needed only if this route is offered.

5. **Motion model lane (FOMM family) for animation compose assist**  
   - Role: P7 frame animation/sheet compose assist after approved NESW stills.  
   - Candidate: Qualcomm First-Order-Motion-Model ONNX pack (`detector` + `generator`) for Snapdragon/NPU-friendly devices.
   - Count: 0 required for baseline; enable when runtime/device gate passes.

---

## Do we need a different model type?

Short answer: **not for v1 baseline**, but **yes for higher-fluidity animation expansion**.

- v1 can ship with existing model families already in plan: Flux primary + ONNX post.
- sprite-sheet variation should begin as a **pipeline/orchestration layer** (archetype rules, frame planning, compose logic), not a brand-new model family requirement.
- for advanced animation smoothness, add a motion model lane (FOMM-class) behind strict capability gates while preserving a universal fallback path.

---

## Dual-lane animation strategy (v1 + v2)

**Windows default:** start with **Lane B** only; add **Lane A** when a motion pack is probed ready on desktop (CUDA/ONNX), same *idea* as Android but **no Snapdragon gate**.

### Lane A — motion sheet pipeline (optional, ONNX / future pack)

- Runtime: FOMM-class ONNX (`detector` + `generator`) or successor motion graph when shipped under `ANIKAI/Models` + pack probes.
- Target: GPUs with headroom after still generation; user opt-in.
- Use: higher-fluidity in-between frame synthesis before final sheet pack.
- **Reference:** Android FOMM notes in [`../../android-arm64/implementations/engine-inference/model-hub/fomm/`](../../android-arm64/implementations/engine-inference/model-hub/fomm/) — not a Windows requirement for v1.

### Lane B — v1 motion sheet pipeline (Windows baseline)

- Runtime: archetype frame plan + deterministic per-frame offset loop (+ optional lightweight ONNX cleanup).
- Target: all supported Windows GPUs / CPU fallback.
- Use: guaranteed compatibility and predictable output.

### v1 strip — frames per facing row (current contract)

- **Implemented:** **8 frames per facing row**, fixed (no user-facing config yet). Each row is one facing; cells are the same NESW source still with a **subtle per-frame pixel-offset loop** (idle-style motion) to aim for smoother motion than a shorter strip before full FOMM inference exists.
- **Single facing:** one row × 8 frames → **8** cells wide (`cellPx × 8`).
- **All facings:** up to four rows (N → E → S → W) × 8 frames → **32** cells max on one PNG.
- **Future (after baseline validates):** optional UI/settings for frames-per-row, alternate offset loops, and archetype-driven **for-loop variations** (see Sprite todo).

### Lane selection policy

1. Probe Qualcomm lane capability at run start (both detector and generator session readiness).
2. If ready and user allows optimized lane, use Lane A.
3. Otherwise use Lane B.
4. Always label active lane in UI/progress metadata (`animationLane=v2_motion_sheet_pipeline` or `animationLane=v1_motion_sheet_pipeline`).

Rule: never silently failover without lane label update; progress UI must show which lane is active.

---

## FOMM integration notes (initial constraints)

- treat FOMM as an **animation-stage model**, not replacement for Flux still generation,
- keep input normalization strict (resolution/profile contract such as 256-class crops where required),
- persist detector/generator model ids in compose metadata,
- gate by device capability and memory budget before allocation,
- expose user toggle to force fallback lane when they prefer deterministic/stable output,
- after zip download, treat **unpack + ONNX token check** as part of “usable” readiness (not zip-only).

---

## Appendix: FOMM vs “talking companion” avatar (out of Sprite Maker scope)

This appendix records **intent only**; companion-facing animation is a separate pipeline doc when prioritized.

### What FOMM-class models are

First-order motion approaches are **motion transfer**: a **source appearance** (e.g. one character image) is driven by a **motion signal** from elsewhere—classically a **driving video** of a person (or another sequence) so that pose and expression trajectories come from real motion. They are **not** a complete “audio in → lifelike talking avatar out” system by themselves.

### If the goal is “character talks + mouth/eyes/body match”

You typically combine **layers**:

1. **Audio → face / mouth** — viseme prediction, audio-driven talking-head models, or traditional lip-sync (often a dedicated small model or blend-shape rig), because **lip sync is not uniquely solved by FOMM alone**.
2. **Idle / situational body motion** — canned idle loops, seated poses (“park bench”), or light procedural sway so the body does not stay frozen.
3. **Optional driving video** — webcam or a reference clip feeding **pose/expression** into motion transfer (FOMM-style) onto your rendered character, when you want full-frame coherence without hand-rigging every joint.

### Live vs offline

- **Live:** feasible as a pipeline (mic → ASR/TTS timing → mouth model + optional camera driving video → composite onto avatar). Latency and thermal budget dominate on phone.
- **No reference video:** still workable if you substitute **synthetic motion** (audio-conditioned head pose, canned animation curves, or a lightweight puppet rig) instead of a real driving clip—but that is **different machinery** than “drop in FOMM only.”

### “Smart” composite (practical)

Use the **cheapest model for each band**: rigid or blend-shape **mouth** driven by audio timings; **small head motion** from audio or prosody; **larger body motion** from presets or rare video-driven transfer. Reserve heavy motion transfer for moments that need it.

---

## Process to get this into app (implementation order)

### Phase A - Character-profile driven NESW

1. Add/extend character profile intake in Sprite Maker (`background`, `identity`, `mission`, style traits).  
2. Inject profile data into P2 prompt scaffold and metadata.  
3. Run P3 + P4 with current Flux+ONNX stack and preserve route/model profile in output metadata.  
4. Enforce route/model disable matrix in UI.

### Phase B - Approval and handoff

1. Add explicit NESW approval gate object/state.  
2. Block sprite-sheet actions until approval passes.  
3. Persist approved still set as canonical handoff artifact for sheet generation.

### Phase C - Sprite-sheet generator

1. Add motion archetype selector + auto-pick from character profile.  
2. Build frame plan per archetype (idle/walk/attack style signatures).  
3. Compose sheet from approved stills + frame plan (dual-lane: Qualcomm FOMM if available, universal fallback otherwise).  
4. Export sheet + metadata trail.

### Phase D - Expansion lanes

1. Enable Flux.2 profile where assigned and device policy allows.  
2. Enable vision-assist route only when lane is present; keep disabled with reason otherwise.

---

## Validation gates (before operational claim)

- one route from each class (prompt-only, ref+prompt) successfully generates tidy NESW stills on-device,
- ONNX post pass runs deterministically in quality preset on at least one supported device class,
- disable-state UX prevents invalid actions and shows clear reason copy,
- animation dialog supports `N/E/S/W/ALL` targeting with correct gating and ordered `ALL` execution,
- sheet generation shows percent progress and enables in-place preview playback on completion,
- dual-lane animation selection works as declared (Qualcomm FOMM lane when eligible, universal fallback otherwise) with explicit lane labeling,
- sprite-sheet compose produces at least two distinct archetype outputs from different character profiles,
- exported metadata includes route, model profile, archetype, and stage timing trace.

---

## Linked docs

- [`../generation/WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md`](../generation/WINDOWS_EMERGING_MEDIA_VISION_BACKLOG.md) — video/3D/vision models to evaluate later (Marlin, LiTo, Lance, etc.)
- `implementations/generation/imaging/sprite-quality-floor/SPRITE_QUALITY_FLOOR.md`
- `implementations/generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md`
- `implementations/engine-inference/model-hub/fomm/FOMM_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`
- `implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`

---

## Linked todo

- `todo/mid-scope/TODO_SPRITE_MAKER_AND_SPRITE_SHEET_PIPELINE.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-22 | **Steps 4–5 shipped:** NESW approval gate + sprite sheet export (8 frames/row, meta.json). |
| 2026-05-22 | **Windows lane authority:** retitled from Android; added shipped Steps 1–3 table (Media Magic Games sprite), Kontext/Diffusers vs GGUF policy, Step 3 model = Step 1, pixel tool link; dual-lane wording desktop-first. |
| 2026-05-06 | Documented **v1 sheet strip contract**: 8 frames per facing row (fixed), subtle offset loop, max 32 cells when `All` facings; future configurable frames and archetype-driven loop variants. |
| 2026-05-06 | Linked **FOMM engine inference** implementation plan (`engine-inference/model-hub/fomm`). |
| 2026-05-06 | Added planned **model readiness chips** contract (Flux.1 / Flux.2 dual identity + ONNX x4 + FOMM unpack/readiness); app snapshot note for FOMM zip unpack; appendix clarifying FOMM as motion transfer vs future talking-companion stacks. |
| 2026-05-06 | Added dual-lane animation strategy: Qualcomm FOMM optimized lane + universal fallback lane, with capability gating and explicit lane labeling. |
| 2026-05-06 | Added v1 schema contract (`CharacterProfile`, `SpritePipelineRunSpec`, `NeswArtifactSet`, `SpriteSheetComposeSpec`) plus post-NESW animation dialog and progress/preview behavior contract. |
| 2026-05-06 | Added concrete model requirements, model-type decision rule, and app implementation order (character profile -> NESW approval -> sprite-sheet compose). |
| 2026-05-06 | Added explicit UI toggle matrix (route/model/actions/archetype controls) with enable gates and disabled reason copy contract. |
| 2026-05-06 | Initial combined Sprite Maker + Sprite Sheet pipeline plan with route/model policy, disable-state UX contract, and archetype-based animation variation strategy. |
