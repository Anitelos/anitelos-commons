# TODO — MediaPipe engine inference integration (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-06 |

---

## Source implementation doc

- `implementations/engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`

---

## Intent

- Turn MediaPipe from "mentioned helper lane" into a real ANIKAI inference engine path.
- Track packaging/runtime decisions, JNI/native checklist completion, and app routing.
- Keep MediaPipe in engine-inference scope (not mixed into generation contracts).

---

## Checklist (working)

- [ ] Decide first ship path: MediaPipe Tasks AAR first or custom JNI graph first.
- [ ] Implement adapter registration + manifest schema for MediaPipe capability packs.
- [ ] Deliver one operational task end-to-end (recommended: segmentation).
- [ ] Bind at least one Swarm/task lane to MediaPipe adapter with explicit fail states.
- [ ] Add artifact schema validation (mask/landmark JSON) and storage contract notes.
- [ ] Add device/thermal gating policy for continuous or heavy tasks.
- [ ] Verify lifecycle and cancellation stability for repeated task runs.

---

## Linked operations

- `todo/mid-scope/TODO_LOCAL_MEDIA_IMAGING_PIPELINE.md`
- `todo/high-scope/TODO_GAME_MAKER_SHOWPIECE.md` (indirect dependency through imaging/vision maturity)

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created dedicated MediaPipe inference integration todo from local media split effort. |
