# Resona Unification Plan

**Purpose:** Canonical inventory for Resona collaboration (policy, presence, local replay, rollout, workspace routes) plus **DEFERRED** follow-ups for platform-scale work.

**Status (2026-05-02):** **Resona v1 completion gate** is treated as **met** for shipped collaboration scope (see [Completion gate](#completion-gate-when-to-close-this-roadmap)). Open checkbox backlog was **cleared**; remaining engineering lives only in **DEFERRED** sections below. Reopen [TODO](#todo-open-work) when you pull an item back into active delivery.

**How to maintain this doc**

1. **Single active backlog:** Use [TODO (open work)](#todo-open-work) **only** while items are in-flight (checkboxes). When work is parked, move bullets to **DEFERRED — platform & v2** and remove checkboxes from TODO.
2. When you **finish** something: add a short **“In place”** bullet under the right [Category](#categories-in-place-vs-scope); if it was listed under DEFERRED, trim or annotate there.
3. Do **not** reintroduce parallel “Wave / Phase” ladders for the same topic; this file is organized **by category**, not by release wave.

**Status words:** `DONE` = shipped and validated in app or tests. `DEFERRED` = explicitly postponed (say where). `MET` = completion gate satisfied for the declared scope.

---

## TODO (open work)

_No open checkboxes as of **2026-05-02**._ Add new `- [ ]` lines here when restarting a deferred item.

---

## DEFERRED — platform & v2 engineering (2026-05-02)

Former Resona TODO backlog. Items are **not** v1 collaboration blockers at current rollout; prioritize when resourcing multi-device / hybrid sync / artifact model work.

- **Invite policy — folder / project-asset hooks:** extend `setupPolicyJson` + apply path once project artifacts + SAF contract exist (today: room + member execution flags only; see `LobbyInvitePolicyContract` KDoc).
- **Hybrid sync — product-level:** CRDT-style chat/presence merge + host-authoritative files/tasks beyond current local replay/ingress (see **Sync & replay** for shipped local-first stack).
- **Cross-device presence + reassignment dispatch:** local broker + gating shipped; remote propagation + dispatch still open.
- **Two-device replay convergence:** automated pairing tests (diagnostics matrix remains deterministic / local — `runLobbyReplayConvergenceMatrix` in `AnikaiRepository` + Resona settings UI).
- **Project inbox → first-class artifacts:** `WorkspaceDrop` / sync model keyed as project artifacts, not only `Project inbox:` title + `source` hints.
- **Capability routing matrix:** install/runtime gating for brokered delegated tasks across members.
- **Legacy thread pathways — further cleanup:** optional follow-up to remove `workspace` shim entirely or narrow automation catalog strings. **Partial (2026-05-02):** `AnikaiSettings.resonaLegacyWorkspaceRouteUsesNamingShim` + migration 85→86; `workspace` route read-compat remains, redirecting to either `naming_manage` or `deferred_workspace` per flag (`AnikaiNavGraph`, Resona → Settings).
- **Migration diagnostics — full panel:** human-readable upgraded/skipped rows + fallback paths beyond JSON copy. **Partial (2026-05-02):** `ResonaRolloutDiagnostics.roomSchemaVersion` (SQLite `PRAGMA user_version`) surfaced in Resona settings UI + copied diagnostics JSON (`AnikaiRepository.getResonaRolloutDiagnostics`, `DropBoxFilesTab` / `DropBoxScreenConnector`).
- **Chat selection v1 polish:** long-press multi-select + soft-delete redact shipped; optional UX follow-ups only if product asks.

---

## DEFERRED — memory / Meridian (ex–Bond Store refresh)

**2026-05-02:** The old “Bond Store refresh” / solo memory IA item is **out of the Resona collaboration gate**. Bond Store **UI** is retired; thread + storage + checklist backlog lives in **`BOND_STORE_ISSUES_AND_FIXES_PLAN.md`** (historical filename) and **`STORAGE_CONTRACT_V1.md`**, with primary surfaces under **Soul Meridian** (Memories, metrics) and **User Access**. Reopen here only if Resona **project artifact** or nav work must explicitly align with that backlog.

---

## Outside Resona “core gate” (optional backlog)

_Track here or in product notes; not blocking the completion gate._

- [ ] **Post-Resona:** Soul Meridian / memory IA, User Access consolidation, `!` + About deep links, trace metadata normalization, Gemma4 UNK, vocal layering (see historical bullets in git if you remove detail from here).

---

## Completion gate (when to close this roadmap)

**v1 status (2026-05-02): MET** for shipped Resona collaboration scope (local-first policy, presence lease gating, replay ingress + convergence probe, workspace shell, diagnostics + rollback).

The checklist below is the **definition** of the gate; use it when reopening the roadmap after regressions or a new major phase.

Close **`RESONA_UNIFICATION_PLAN.md`** as “complete” for a given phase when:

1. **TODO** has no remaining **blocking** items for collaboration correctness you care to ship (you may move items to **DEFERRED — platform & v2** with one-line rationale).
2. **Memory / Meridian backlog** (ex–Bond Store refresh) is tracked outside this gate — see **DEFERRED — memory / Meridian** with cross-refs; do not block closing this file on that solo-memory work.
3. “No rugsweeping”: routing and execution failures stay **conversation-visible** with blocker reasons (`CompanionController` / policy resolvers).

After gate: cosmetic copy, tab labels, and deep links are **product notes**, not reopeners of this roadmap unless regressions force it.

---

## Mental model (one roof)

| Layer | Role | Primary code / route |
| --- | --- | --- |
| **Resona workspace** | **Projects** (solo + shared / collab entry), **Contacts** (lobby contacts), **Settings** (folder refs + rollout toggles + diagnostics lane). | `deferred_workspace` → `DropBoxScreenConnector` |
| **Lobby social** | Room list, invites, **per-room chat** (not the workspace shell). | `local_lobby`, `local_lobby_room/{roomId}` |
| **Companion** | Solo + lobby threads, quick controls, attachments. | `companion_conversation` |
| **Policy + diagnostics** | JSON policy maps, kill switches, diagnostics JSON, audit rollback. | `AnikaiSettings`, `LobbyInvitePolicyContract`, `ResonaSettingsScreenConnector`, Audit diagnostics |

**Workspace intake:** project-scoped **Inbox drop** (note + file) → `WorkspaceDrop` + tagged `source` → `WorkspaceInboxCoordinator` + roaming. No legacy global inbox tab; dialog **`!`** explains when roaming runs the queue.

---

## Categories (in place vs scope)

### 1 — Resona workspace & navigation

**In place**

- Shell tabs **Projects | Contacts | Settings** (`DropBoxTab`, `DropBoxScreenConnector`).
- Shared collab + lobby chat entry from **Projects**; contact CRUD on **Contacts**; Resona rollout + folder lane on **Settings** (`DropBoxFilesTab`).
- Home / shortcuts: Co-lab / DropBox routes fold into same shell where applicable (`AnikaiNavGraph`).
- Legacy **global DropBox inbox** tab + **Prepare now** removed; per-project inbox + roaming replaces it.

**Scope / pointers**

- Optional copy: “Check files” → “Open folder”, deep links, Contacts depth (non-blocking).

**Routes (canonical)**

| Area | Route | Surface |
| --- | --- | --- |
| Workspace | `deferred_workspace` | `DropBoxScreenConnector` |
| Resona settings deep link | `resona_settings?focus=` | `ResonaSettingsScreenConnector` |
| Lobby list | `local_lobby` | `ResonaLobbyScreenConnector` |
| Lobby room chat | `local_lobby_room/{roomId}` | `LocalLobbyRoomScreen` |
| Co-lab route | `resona_colab` | `ResonaCoLabScreenConnector` (often returns to workspace) |
| Companion | `companion_conversation` | `CompanionConversationScreen` |
| Legacy | `workspace` | compat only; prefer `deferred_workspace` |

---

### 2 — Lobby policy & invite contract

**In place**

- Canonical JSON: `lobbyRoomPoliciesJson`, `lobbyMemberPoliciesJson` on `AnikaiSettings`.
- Legacy `LOBBY_POLICY::…` lines in `aiDynamicMemory` migrated on load (`LobbyPolicyJsonMigration`, `LobbyPolicyJsonMigrationTest`).
- Invite `setupPolicyJson` **build + apply** centralized in **`LobbyInvitePolicyContract`** + **`LobbyInvitePolicyContractTest`** (partial apply, roundtrip resolvers; self `autoCatchUp` no longer inherits unrelated room at **build** time).
- Invite UI defaults: `TeamScreen` send dialog (room + invitee toggles) → `createLobbyInvite`.
- Accept path: `acceptLobbyInvite` → `applySetupPolicyPayload` when `resonaInviteSetupPolicyEnabled`.
- Kill switch: `resonaInviteSetupPolicyEnabled`.
- **KDoc schema:** invite JSON keys, settings map layout, resolver names — see `LobbyInvitePolicyContract.kt` file-level documentation.

**Deferred** — see **DEFERRED — platform & v2** (invite folder / project-asset hooks).

- Folder / SAF **project-asset** fields on invite payload (waits on artifact schema); room + member flags already in `LobbyInvitePolicyContract`.

---

### 3 — Presence, lease & delegated routing

**In place**

- Member fields: `ACTIVE` / `AWAY_RUNNING` / `OFFLINE`, lease metadata, `allowFinishActiveAfterLeave` on `LobbyRoomMemberEntity`.
- Queue gating: new delegated assignment requires eligible presence (`SpecialistTaskQueueCoordinator` / repository broker paths).
- Default away lease (~30m) + self presence controls surfaced in UI where wired.
- **Local** reassignment broker when assignee ineligible (telemetry).

**Open** — **DEFERRED — platform & v2**

- Cross-device presence + reassignment **dispatch**; richer diagnostics counters (lease reject reasons, reassignment counts) where not yet surfaced.

---

### 4 — Sync & replay

**In place (local-first)**

- Join snapshot + replay bundle: `LobbyJoinSnapshot`, `LobbyReplayBundle`, `buildLobbyJoinSnapshot`, visible-only / redaction-aware paths.
- Soul event types for replay hygiene: e.g. `RESONA_MESSAGE_REDACTED`, code-task lock acquire/release/revert.
- Lobby **one coding task at a time**: `ResonaLobbyCodeTaskLockCoordinator` + queue lifecycle in `SpecialistTaskQueueCoordinator`.
- Replay state: `lobbyReplayStateJson`; apply + ingress: `applyLobbyReplayBundle`, `ingestLobbyReplayBundle`.
- Transport hook + telemetry: `pushLobbyReplayBundleToCortex` path; `LobbyReplayTransportCodec`; audit diagnostics **convergence matrix** (`runLobbyReplayConvergenceMatrix`) for idempotent dedupe checks.

**Open** — **DEFERRED — platform & v2**

- Full **hybrid** product semantics (CRDT chat/presence + host-authoritative files/tasks) and **two-device** automated convergence tests.

---

### 5 — Rollout, diagnostics & kill switches

**In place**

- Flags: `resonaInviteSetupPolicyEnabled`, `resonaPresenceLeaseEnforcementEnabled`, `resonaReplayIngressEnabled`.
- Resona diagnostics JSON + rollout stage / drift / rollback hints in settings UI.
- Staged profiles **SAFE / BALANCED / FULL** (apply bundles + telemetry).
- Audit: emergency rollback to SAFE, confirmation + session bypass badge, runbook snippets.

**Open** — **DEFERRED — platform & v2**

- Migration diagnostics **panel** (human-readable summary). **Partial:** schema version in Resona diagnostics (see DEFERRED list).

---

### 6 — Projects, inbox & workspace pipeline

**In place**

- Solo + shared project cards, templates, folder open, inbox drop dialog + roaming kick, linked rooms (`ResonaCoLabOrchestrator` / `linkedRoomId` patterns as implemented).
- `WorkspaceInboxCoordinator` + roaming worker paths for deferred strategy / project-tagged drops.

**Open** — **DEFERRED — platform & v2**

- First-class **project artifact** model and sync.

---

### 7 — Chat, composer & consent

**In place**

- Attachments: drop file, take picture; storage hardened (URI-first, camera path).
- `.md` plan **consent-first** gate in chat (detect → discuss → explicit consent before execute); blocker surfacing when routing cannot run.
- Lobby change-summary v1, catch-up cursors, project file sync toggle affecting routing posture.
- Session title hints: `SessionTitleHint`, `AiManager.suggestSessionTitle`, thread snapshot context.
- GGUF **singleton mutex** for load+stream; `NonCancellable` inference gate where wired.

**Open** — **DEFERRED — platform & v2**

- Selection UX polish only if needed.

---

### 8 — Cleanup & compatibility

**In place**

- Many legacy entry labels removed from primary chat entry; compatibility shims in nav where listed above.
- **`workspace` route flag (2026-05-02):** `resonaLegacyWorkspaceRouteUsesNamingShim` (default **on** for upgrades) preserves legacy redirect to naming; turn **off** in Resona → Settings to send old `workspace` opens to canonical `deferred_workspace`.

**Open** — **DEFERRED — platform & v2**

- Further flag-gated removal of other superseded **thread** / automation entry labels; preserved read paths for old records.

---

## AI fix handoff (debugging signal)

When investigating a Resona bug, capture: symptom, expected behavior, solo vs lobby room, rollout flags on/off, and **paste diagnostics JSON** from Resona settings. That separates policy, presence, replay ingress, and model-layer issues.

---

## Decision notes

- Resona collaboration core before solo **memory / Meridian** backlog (`BOND_STORE_ISSUES_AND_FIXES_PLAN.md`); that backlog is **deferred** from this gate (see **DEFERRED** above).
- Persona-authored uncertainty beats silent skip; avoid app-authored yes/no where conversational consent fits.
- **Lobby vs solo bond:** bond delta clamped in lobby thread context (`lobbyBondIsolated` in `CompanionController.saveAssistantReply` metadata) while other signals still learn from collaboration.
