# Anima (bridge — soul across devices)

**Scope:** ANIKAI + soul continuity across hardware: roaming pairs, awareness pairs, **combo** ideas that belong neither only to Ikagi nor only to one runtime doc.

**Subthemes (from your note):** roaming ([`roaming/`](./roaming/)), awareness ([`awareness/`](./awareness/)), “todos + completes + separate combos” living together when the story is inherently cross-device.

**When to open:** the insight starts with “if we pick up on the other machine…”

**Pair with:** `ANIKAI_LIVE_RUNTIME_OPERATING_SPEC.md` for enforceable rules once a note matures.
