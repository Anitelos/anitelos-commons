# Model sheet — ponpoke / flux2-klein-9b-uncensored-text-encoder (optional encoder swap)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-19 |

> **Desktop catalogue:** this is **documentation only**. It is **not** a separate `testedStacks` row in `imaging-registry.json`. FLUX.2 Klein / dev rows describe the optional swap in the **Encoders** column and a **hover tooltip** (gated repo + how to replace files / sidecar override).

## HF

- Encoder repo: [ponpoke/flux2-klein-9b-uncensored-text-encoder](https://huggingface.co/ponpoke/flux2-klein-9b-uncensored-text-encoder)  
- Base image model (DiT weights): [black-forest-labs/FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B)  
- VAE (ungated): [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae)  

## What it is

This repo is the **text encoder only** (Qwen3-derived, safetensors + GGUF quant options). It **does not** generate pixels alone. HF instructions: place weights in Comfy **`models/clip`** (or GGUF clip nodes) **paired** with the official **FLUX.2-klein** DiT, or swap `AutoModel` in a **Diffusers** pipeline.

**Gated** on Hugging Face (safety acknowledgment).

## Sequencing (product)

1. Ship **full** [FLUX.2-klein-9B](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B) baseline — see [`MODEL_BFL_FLUX2_KLEIN_9B.md`](./MODEL_BFL_FLUX2_KLEIN_9B.md).  
2. **Then** add optional preset to replace the default text encoder with this repo (same DiT weights).

## Intended inference family (Windows desktop)

- **Diffusers / PyTorch sidecar** with a **two-part preset**: DiT from BFL + encoder checkpoint from ponpoke.  
- **Not** a single-file `sd.exe -m` target.

## Product notes

- **Preset id (future):** `flux2_klein_uncensored_stack` (proposal; Diffusers two-weight preset — **not** the same as a single GGUF catalogue row).  
- **Manifest:** must list **two** HF ids or two local paths (encoder + DiT) plus tokenizer paths as required by the loader.

## Implementation checklist (Anikai Desktop)

- [ ] Loader recipe written (transformers/diffusers swap per HF “For Developers” section).  
- [ ] Legal / gating flow documented for both repos.  
- [ ] End-to-end image smoke with swapped encoder vs official baseline (optional comparison shot).  
- [ ] Lane index checkbox updated when green.  

## Links

- Lane index: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  
- Diffusers family stub: [`../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../diffusers/DIFFUSERS_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-14 | Sequencing: full FLUX2 first, encoder swap phase 2. |
| 2026-05-19 | Clarified doc-only role vs desktop `imaging-registry` testedStacks; klein rows carry Encoders column + tooltip. |
