# Windows desktop — documentation index

| Field | Value |
|-------|-------|
| **Purpose** | One link hub when tightening docs — avoid re-explaining **manager**, **familiars**, **project tree**, or **magnets** in every plan. |
| **Workshop status** | [`anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md`](anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md) |
| **Ops ↔ todos** | [`operations/OPERATIONS_INDEX.md`](operations/OPERATIONS_INDEX.md) |

---

## Shell and workspace

| Topic | Canonical doc | Todo |
|-------|---------------|------|
| **What is Anikai (story)** | [`../WHAT_IS_ANIKAI_ON_WINDOWS.md`](../WHAT_IS_ANIKAI_ON_WINDOWS.md) | — |
| **Media Magic (build center)** | [`companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md`](companion-surface/MEDIA_MAGIC_PRODUCT_VISION.md) | imaging / audio / video lane todos |
| **Workshop overview** | [`anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md`](anikai-agent-workflows/DESKTOP_WORKSHOP_STATE.md) | — |
| **Anikai Terminal (creators, later)** | [`the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md`](the-terminal/ANIKAI_TERMINAL_LIVING_SPEC.md) · npm [`anikai-desktop/npm/README.md`](../../../../../../anikai-desktop/npm/README.md) | M0–M1 planned |
| **Project tree (M0 shipped)** | [`companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md`](companion-surface/desktop-overlay-and-panels/PROJECT_WORKSPACE_TREE.md) | [`../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md`](../todo/mid-scope/TODO_MAGNET_PANELS_WORKSPACE_DESKTOP.md) (tree section) |
| **Drag-magnet panels (M0 shipped)** | [`companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md`](companion-surface/desktop-overlay-and-panels/MAGNET_PANELS_WORKSPACE_OVERVIEW.md) | same todo (M1+ polish) |
| **Chat + segment loop** | [`anikai-agent-workflows/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](anikai-agent-workflows/THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) | [`../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) |

---

## Who does what (roles)

| Topic | Canonical doc |
|-------|---------------|
| **Index (start here)** | [`anikai-agent-workflows/execution-agent/ROLES_INDEX.md`](anikai-agent-workflows/execution-agent/ROLES_INDEX.md) |
| **Companion specialty / craft + session role + manager** | [`anikai-agent-workflows/execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](anikai-agent-workflows/execution-agent/Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) |
| **Familiar reflex system (F1–F7)** | [`anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md`](anikai-agent-workflows/execution-agent/Familiars/FAMILIARS_REFLEX_SYSTEM.md) |
| **Familiar Assign roles** (guard, classifier, time, …) | [`anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md`](anikai-agent-workflows/execution-agent/Familiars/FAMILIAR_ROLES.md) |
| **Workforce / automation / capability map** | [`anikai-agent-workflows/execution-agent/WORKFORCE_AND_ORCHESTRATION_VISION.md`](anikai-agent-workflows/execution-agent/WORKFORCE_AND_ORCHESTRATION_VISION.md) |
| **Group chat + Lead-last** | [`anikai-agent-workflows/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](anikai-agent-workflows/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) |

**Manager in one line:** companion **specialty** `manager` = orchestration / automation lead — **not** familiar guard, **not** group **Lead** (session role). See Specialists doc.

---

## Execution agent (workspace tools)

| Topic | Canonical doc |
|-------|---------------|
| **Architecture overview** | [`anikai-agent-workflows/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](anikai-agent-workflows/execution-agent/COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md) |
| **Sandbox + HITL** | [`anikai-agent-workflows/execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md`](anikai-agent-workflows/execution-agent/COMPANION_SANDBOX_AND_SECURITY_ARCHITECTURE.md) |
| **Team blackboard** | [`anikai-agent-workflows/execution-agent/TEAM_BLACKBOARD_ORCHESTRATION.md`](anikai-agent-workflows/execution-agent/TEAM_BLACKBOARD_ORCHESTRATION.md) |
| **Screen copilot** | [`anikai-agent-workflows/execution-agent/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](anikai-agent-workflows/execution-agent/DESKTOP_COPILOT_AND_SCREEN_AGENT.md) |

Project tree supplies the **workspace root** for Track A; blackboard/manager UI is later.

---

## Motion-sense, ONNX imaging, runtime packs

| Topic | Canonical doc | Desktop registry |
|-------|---------------|------------------|
| **Architecture (pose vs phoneme rig)** | [`generation/motion/MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md`](generation/motion/MOTION_SENTIENCE_AND_IMAGING_RUNTIME_ARCHITECTURE.md) | — |
| **PoseIntent + rig JSON schema** | [`generation/motion/RIG_AND_POSE_INTENT_SCHEMA.md`](generation/motion/RIG_AND_POSE_INTENT_SCHEMA.md) | — |
| **Runtime pack catalogue** | [`runtime-shape/RUNTIME_PACKS_CATALOGUE.md`](runtime-shape/RUNTIME_PACKS_CATALOGUE.md) · [`runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md`](runtime-shape/RUNTIME_PACKS_AND_INSTALLER.md) · per-pack [`runtime-shape/packs/`](runtime-shape/packs/) | `anikai-desktop/assets/about-guide/runtime-packs-registry.json` |
| **ONNX imaging stacks** | [`generation/imaging/onnx/ONNX_IMAGING_STACK_LIBRARY.md`](generation/imaging/onnx/ONNX_IMAGING_STACK_LIBRARY.md) | `imaging-registry.json` (build script) |
| **Motion-sense families** | Android [`PORTRAIT_RIG_MOTION_STRATEGY.md`](../android-arm64/implementations/pipelines/PORTRAIT_RIG_MOTION_STRATEGY.md) | `motion-sentience-registry.json` |
| **PersonaLive** | [`engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](engine-inference/model-hub/personalive/PERSONALIVE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) | `pack.personalive` on Software tab |

**Software tab:** Settings → Device → Software → **Check runtimes** reads the same pack ids as the About **Runtime packs** table.

---

## Text / familiars models

| Topic | Canonical doc |
|-------|---------------|
| **Turn timeline (classifier phases)** | [`generation/text/gguf/CHAT_TURN_TIMELINE_PHASED_PLAN.md`](generation/text/gguf/CHAT_TURN_TIMELINE_PHASED_PLAN.md) |
| **SmolLM2 familiar classifier** | [`generation/text/gguf/models/SMOLLM2_RETHINK_360M_ANIKAI.md`](generation/text/gguf/models/SMOLLM2_RETHINK_360M_ANIKAI.md) |
| **GGUF model notes index** | [`generation/text/gguf/models/README.md`](generation/text/gguf/models/README.md) |

---

## Doc hygiene rules

1. **Do not** duplicate Manager, specialty tables, or familiar reflex flow — link **Specialists** or **FAMILIAR_ROLES**.
2. **Do not** duplicate project tree data model — link **PROJECT_WORKSPACE_TREE**.
3. **Tree M0 shipped** ≠ **drag-magnet M0** — say which you mean.
4. Edit **Familiars** under `execution-agent/Familiars/` only (`companion-surface/FAMILIARS_REFLEX_SYSTEM.md` is a redirect).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Initial tighten index after Familiars F1–F7 + project tree M0 |
| 2026-05-20 | Drag-magnet M0 shipped (panel → chat, follow on move, detach on drag). |
