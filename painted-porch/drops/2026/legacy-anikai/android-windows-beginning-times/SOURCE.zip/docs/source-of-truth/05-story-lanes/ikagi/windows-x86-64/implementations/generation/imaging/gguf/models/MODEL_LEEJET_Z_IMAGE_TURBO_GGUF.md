# Model sheet — leejet / Z-Image-Turbo-GGUF

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [leejet/Z-Image-Turbo-GGUF](https://huggingface.co/leejet/Z-Image-Turbo-GGUF)  
- **FLUX.1 ae (recommended, Apache-2.0):** [second-state/FLUX.1-schnell-GGUF — ae.safetensors](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/resolve/main/ae.safetensors) (or [tree/main](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main)).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- LLM: [Qwen/Qwen3-4B](https://huggingface.co/Qwen/Qwen3-4B)  
- sd.cpp: [`z_image.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/z_image.md) § Z-Image-Turbo  

## Pack family

`z_image_llm_vae`

## Product

- **Preset id:** `z_image_turbo_gguf_leejet`  
- **Profile (proposal):** `z_image_turbo_gguf` — cfg 1, fast steps  

## Links

- [`MODEL_UNSLOTH_Z_IMAGE_GGUF.md`](./MODEL_UNSLOTH_Z_IMAGE_GGUF.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
