# GGUF imaging generation (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

**Lane index (what works, per model, other inference families):** [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)

**Per-repo / per-stack model sheets:** [`./models/`](./models/)

Purpose: **imaging generation** product lane when the **native decode path** is a **GGUF-bound diffusion** (or hybrid) adapter—not “any `.gguf` file implies pixels.” This doc owns **user-facing modes**, **output contracts** (bytes, resolution, alpha), and **relation to ONNX** post-passes. **Load, probe, and `diffusion_decode` task truth** live in the GGUF **engine** plan.

**Plug-and-play:** [`GGUF_MODEL_PACK_FAMILIES.md`](./GGUF_MODEL_PACK_FAMILIES.md) defines **`pack_family_id`** routers (probe + CLI builder + profile). Per-HF-repo detail stays in [`./models/`](./models/). **Lane index** E2E ticks: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md).

**Roadmap:** txt2img GGUF breadth first (SD1.5, SDXL, FLUX, Qwen-Image, Z-Image, SD3) → img2img / edit → vision → **music / video** as separate lanes.

**GGUF engine (tasks + JNI/FFI):** [`../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Android GGUF engine (diffusion lane context):** [`../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**ONNX engine (post / alternate primary on Windows):** [`../../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../engine-inference/model-hub/onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Model paths / import:** [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)

---

## Scope

- GGUF adapter paths that emit **image bytes** (PNG / raw RGBA) per manifest.
- **Primary vs post:** when GGUF is primary vs when **ONNX** post graph runs after GGUF primary (quality stack).
- Desktop **UX hooks**: where the user picks preset, resolution cap, and sees honest “not available” states.

Out of scope here: sprite sheet packaging contracts (add sibling docs under `generation/imaging/` when promoted).

---

## Model type id

| id | Meaning |
|----|---------|
| `gguf_diffusion_decode` | GGUF container + native adapter that implements the engine’s `diffusion_decode` task with a validated decode contract |

---

## Capabilities (product slices)

| capability_id | User-visible meaning | Engine / pipeline prerequisite |
|---------------|----------------------|--------------------------------|
| `image_txt2img` | Text + latent → image | `diffusion_decode` + validated graph; manifest lane `image_primary` |
| `image_img2img` | Image + strength → image | Same + input image contract |
| `image_post_onnx_chain` | Upscale / refine after GGUF | ONNX `image_post` adapters registered in pipeline metadata |

---

## Verification gates

- Successful **persisted** image artifact on disk + visible in UI (or explicit failure string).
- No claim when engine probe says `diffusion_decode: false`.
- If ONNX post is declared, chain fails closed with reason when ORT session fails.

---

## Desktop implementation slice (stable-diffusion.cpp, 2026-05-17)

Product path today is **`sd.exe`** via `runImageGenerationMain` — not the future `diffusion_decode` JNI task id.

| Concern | Behavior |
|---------|----------|
| **Flux 1.x GGUF** | Requires `vae/`, `text_encoder/`, `text_encoder_2/` beside the `.gguf` (**FLUX.1 split-pack**). Readiness warns if missing. |
| **Flux 2 klein GGUF** | Requires **flux2 pack**: `--diffusion-model` + `--vae` (flux2_ae) + `--llm` (Qwen3 8B) — see [`../models/MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md`](../models/MODEL_UNSLOTH_FLUX2_KLEIN_9B_GGUF.md) and `vendor/stable-diffusion.cpp/docs/flux2.md`. **Do not** use FLUX.1 split-pack probe for klein. |
| **Sharded T5** | Merged to OS temp file **on each Generate**; deleted after `sd.exe` exits. Needs bundled media-python (`dist:full`). |
| **Caps / sampler / seed** | `shared/sd-gguf-image-profiles.js` per model name; overridable in Media Magic UI. |
| **Prompt styles** | `shared/image-style-presets.js` appends tags; **None** = user text only. |
| **Output path** | `<ANIKAI_HOME>/generated-media/<prompt-slug>-<timestamp>.png` |
| **Honest failures** | stderr surfaced; `single -m` logged when split-pack unavailable |

Per-repo E2E status: [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md) and [`../models/`](../models/).

---

## Linked todos

| Todo | Path |
|------|------|
| GGUF imaging desktop | [`../../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md`](../../../../todo/mid-scope/TODO_GGUF_IMAGING_DESKTOP.md) |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-10 | Initial GGUF imaging generation plan for Windows; ties engine diffusion task to product capabilities and ONNX post role. |
| 2026-05-14 | Point to `IMAGING_GENERATION_INDEX.md` + `models/` for per-target truth; keep this file for cross-cutting GGUF imaging rules only. |
| 2026-05-17 | Document desktop sd.exe slice: split-pack, profiles, styles, dist:full media-python, prompt filenames. |
| 2026-05-18 | Link pack-family registry; plug-and-play router waves; ~25 model sheets in index. |
