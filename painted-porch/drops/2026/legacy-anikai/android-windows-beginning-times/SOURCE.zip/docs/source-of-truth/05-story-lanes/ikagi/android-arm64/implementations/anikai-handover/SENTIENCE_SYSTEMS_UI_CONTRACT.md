# Sentience Systems UI contract (Android)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-08 |

Purpose: define the user-facing contract for Sentience Systems so model assignment, capability readiness, fallback behavior, and role ownership are consistent across User Access and handover orchestration.

---

## Scope

This file covers:

- Sentience Systems surface structure in User Access,
- role cards and assignment behavior (`eyes`, `ears`, `turn`, `touch`, `emotion`),
- readiness/degraded labeling rules tied to runtime capability probes,
- relationship to Swarm and Soul surfaces.

This file does **not** define:

- runtime adapter internals (engine-inference docs own that),
- pipeline choreography (Swarm docs own that),
- voice persona authoring (Meridian docs own that).

---

## Why this exists

Reflex behavior currently feels too narrow for the intended architecture. Sentience Systems is the broader perception/interaction control surface where users decide what the app can sense and how it reacts, using models from the same shared capability pool as Swarm.

This prevents:

- placeholder controls disconnected from runtime reality,
- duplicated model registration between Sentience and Swarm,
- unclear ownership of "who is sensing what" in the app.

---

## Service-plane positioning

- **Sentience Systems:** always-on or event-driven perception/interaction services.
- **Swarm:** workflow pipelines and task automations.
- **Soul/Companion:** reasoning, memory policy, and final conversational behavior.
- **Meridian voice:** custom voice/persona shaping and expressive render setup.

Rule: Sentience and Swarm stay separate in UX, but both pull from one model pool and capability registry.

---

## Information architecture (User Access)

### A) Section shell

- Tab label: `Sentience Systems` (with optional compatibility subtitle "Reflex-compatible").
- Top summary strip:
  - overall sentience status (`Operational`, `Partial`, `Disabled`),
  - active role count,
  - degraded role count,
  - quick entry to diagnostics.

### B) Core role cards

Required cards:

1. **Eyes** (`sentience.eyes.primary`)
   - examples: face/emotion/screen analyst/visual context.
2. **Ears (ASR)** (`sentience.ears.asr`)
   - speech-to-text front-end and optional phoneme features.
3. **Turn Monitor** (`sentience.turn.monitor`)
   - interruption/start-stop turn boundaries.
4. **Touch/Context** (`sentience.touch.context`)
   - app interaction and state-context sensing.
5. **Emotion Classifier** (`sentience.emotion.classifier`)
   - audio/visual affect extraction used by Soul policy.

Each card includes:

- assigned primary model,
- fallback model,
- runtime family badge,
- readiness state badge,
- enable/disable switch,
- info action with capability and missing-artifact detail.

### C) Optional cards (phase-gated)

- Ambient awareness helper,
- scene/surveillance analyzer,
- advanced multimodal packer.

These remain hidden unless readiness gates are met.

---

## Assignment and fallback contract

For each sentience role:

- user can set `Primary`, `Fallback`, or `Disabled`,
- assignment picker only lists `SUPPORTED` or better candidates,
- `LOADABLE`/`VERIFIED` states are highlighted as preferred,
- missing sidecar requirements (for example `mmproj`) block assignment with explicit reason,
- fallback activation shows visible degraded badge and reason text.

### Role ID contract

Sentience role IDs must remain stable for orchestration calls:

- `sentience.eyes.primary`
- `sentience.ears.asr`
- `sentience.turn.monitor`
- `sentience.touch.context`
- `sentience.emotion.classifier`

Optional extension IDs should follow the same prefix.

---

## Readiness and honesty rules

Sentience cards must use shared readiness states from the capability platform:

- `INSTALLED`
- `SUPPORTED`
- `LOADABLE`
- `VERIFIED`
- `DEGRADED`
- `UNAVAILABLE`

Rules:

- no "active" visual state when readiness is below `LOADABLE`,
- no silent fallback; every downgrade must show explicit reason,
- controls that require runtime support are disabled with inline explanation (not hidden failure).

---

## Diagnostics and audit

Each role exposes a compact diagnostics drawer:

- selected model id and runtime family,
- adapter id and provider/backend info,
- latest readiness result and timestamp,
- last failure reason,
- last latency sample (when available),
- fallback chain state.

Global Sentience diagnostics should be exportable to the same audit lane used by Swarm/Soul operation traces.

---

## Interaction with Swarm and Soul

- Sentience outputs are published as modality packets for Soul and optionally as signals for Swarm triggers.
- Swarm can consume sentience outputs but does not own sentience role assignments.
- Soul policy decides how strongly to trust sentience outputs (confidence thresholds and policy presets).
- Same model can be assigned to Sentience and Swarm only if concurrency and lifecycle guards pass.

---

## First implementation slice

1. Add `Sentience Systems` section shell and status strip.
2. Implement two cards first: `Ears (ASR)` + `Turn Monitor`.
3. Wire assignment picker to shared capability registry filtering.
4. Add explicit degraded badge and fallback reason rendering.
5. Emit role diagnostics fields into handover packet metadata.

---

## Verification gates

- Users can assign primary/fallback models for at least `ears` and `turn` roles.
- Assignment list only shows capability-eligible models.
- Role card status reflects real readiness state from probe/session outcomes.
- Fallback transitions are visible and logged.
- Sentience role IDs are callable from orchestration without hardcoded model names.

---

## Linked docs

- `implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`
- `implementations/anikai-handover/SENTIENCE_FEATURE_SLOT_SCHEMA_V1.md`
- `implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`
- `todo/high-scope/TODO_ENGINE_INFERENCE_CAPABILITY_PLATFORM.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-08 | Created Sentience Systems UI contract with role cards, readiness rules, and shared model-pool integration constraints. |
| 2026-05-08 | Linked v1 Sentience feature-slot schema for assignment payload and slot-key contract. |
