# Model sheet — leejet / FLUX.1-dev-gguf

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [leejet/FLUX.1-dev-gguf](https://huggingface.co/leejet/FLUX.1-dev-gguf)  
- **FP16 sidecars (Apache-2.0, one repo):** [second-state/FLUX.1-schnell-GGUF](https://huggingface.co/second-state/FLUX.1-schnell-GGUF/tree/main) — `ae.safetensors`, `clip_l.safetensors`, `t5xxl_fp16.safetensors` beside the diffusion `.gguf` (matches Anikai `downloadPacks`).  
- VAE mirror (alternate): https://huggingface.co/Letian2003/black-forest-labs_FLUX.1-dev_vae (plain URL; not auto-indexed into desktop catalogue hf[])  
- Base / encoders (alternate, gated): [black-forest-labs/FLUX.1-dev](https://huggingface.co/black-forest-labs/FLUX.1-dev)  
- sd.cpp: [`flux.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/flux.md)  

## Pack family

`flux1_clip_t5`

## Weight layout

Same as [`MODEL_CITY96_FLUX1_DEV_GGUF.md`](./MODEL_CITY96_FLUX1_DEV_GGUF.md).

## Product

- **Preset id:** `flux1_dev_gguf_leejet`  
- **Profile:** `flux_dev_gguf`  

## Notes

Reference quant quality table in upstream `flux.md`. License: FLUX.1-dev non-commercial unless BFL commercial terms obtained.

## Checklist

- [ ] Split-pack E2E  
- [ ] Lane index tick  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
