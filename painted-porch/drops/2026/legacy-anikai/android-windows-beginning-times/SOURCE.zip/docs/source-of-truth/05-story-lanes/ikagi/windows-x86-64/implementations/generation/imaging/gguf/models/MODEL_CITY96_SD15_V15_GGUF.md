# Model sheet — city96 / stable-diffusion-v1-5-gguf

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [city96/stable-diffusion-v1-5-gguf](https://huggingface.co/city96/stable-diffusion-v1-5-gguf)  
- Base: [runwayml/stable-diffusion-v1-5](https://huggingface.co/runwayml/stable-diffusion-v1-5)  

## Pack family

`sd_single_m` — [`MODEL_GGUF_FAMILY_SD15_SINGLE_FILE.md`](./MODEL_GGUF_FAMILY_SD15_SINGLE_FILE.md)

## Intended inference (Windows)

| Path | Fit |
|------|-----|
| **Native `sd.exe`** | **Primary** — single `-m` |
| Diffusers | Optional sidecar if user has full snapshot |

## Product

- **Preset id (proposal):** `sd15_v15_gguf_city96`  
- **Profile:** `sd15_gguf` — 512², 28 steps, cfg 7  

## Checklist

- [ ] Router: `sd_single_m` before flux fallbacks  
- [ ] E2E Media Magic smoke  
- [ ] Lane index tick  

## Links

- [`../IMAGING_GENERATION_INDEX.md`](../IMAGING_GENERATION_INDEX.md)  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
