# WSL terminal and streaming plan

| Field | Value |
|-------|-------|
| **Scope** | WSL-specific extension of `ANIKAI_TERMINAL_LIVING_SPEC.md` |
| **Status** | Proposed design (aligned with M0-M6 phases) |
| **Primary goal** | Make in-app console feel like a real terminal without destabilizing inference paths |

---

## Why this doc exists

`ANIKAI_TERMINAL_LIVING_SPEC.md` defines the north star for Workshop Log + Terminal.  
This document zooms into one backend and one UX request:

1. **Backend:** Ubuntu WSL as a first-class terminal backend on Windows.
2. **UX:** "Show me what the terminal is doing right now" during setup/generation.

---

## Product intent (plain language)

For most users, Anikai should feel like:

- "Click run, see live lines, know what stage it's on."
- No need to manually open Ubuntu unless they choose to.
- Same terminal surface for LiTo, ONNX, packs, and future tasks.

For power users, optional "raw terminal" behavior can be enabled later.

---

## Two console modes

### Mode A — Pipeline Console (default)

Shows structured run output from managed tasks:

- LiTo WSL setup
- LiTo infer
- Pack download
- ONNX / Python lanes
- `npm run` jobs launched by Terminal UI

Each line carries metadata: `runId`, `source`, `stream`, `level`, `ts`.

Benefits:

- Safer
- Easier filtering/search
- Works well with companions and snapshots
- Better beginner experience

### Mode B — Raw WSL Terminal (advanced)

Optional PTY-backed shell session (end-game):

- true interactive shell
- direct command entry
- backend selector includes `wsl`

Risks/cost:

- input focus complexity
- escape sequence rendering
- stronger security + HITL requirements
- higher risk of user confusion

Decision: keep **Mode A first**; add Mode B only after M1/M2 stability.

---

## WSL backend requirements

## 1) Distro resolution

- Detect installed distros via `wsl -l -v`.
- Accept names like `Ubuntu`, `Ubuntu-22.04`, etc.
- Prefer first `Ubuntu*`; fallback to default distro.
- If no distro installed, show one-line install guidance and stop.

## 2) Run envelope

Every WSL task run should emit lifecycle events:

- `run.start`
- `stage` updates (if available)
- `stdout` / `stderr` lines
- `run.finish` with exit code and elapsed ms

## 3) Stage marker convention

Use a shared marker in scripts/tools:

```text
ANIKAI_STAGE:4/6 · Latent sampling
```

Terminal UI interprets this into a highlighted stage line and optional status pill.

---

## Unified event shape (WSL + non-WSL)

```json
{
  "runId": "run_01J...",
  "source": "lito.setup",
  "backend": "wsl",
  "stream": "stdout",
  "level": "info",
  "message": "Resolving dependencies...",
  "stage": "4/6 · pixi install",
  "ts": "2026-05-28T11:54:10.882Z"
}
```

Notes:

- `backend` examples: `wsl`, `powershell`, `python`, `onnx`, `npm`.
- `stage` may be omitted for normal lines.
- Terminal filters should operate on `source`, `backend`, `level`.

---

## Suggested UI controls

For Workshop Terminal panel:

- **View switch:** `Pipeline Console | Raw Terminal` (Raw hidden until M5+)
- **Source chips:** `All`, `LiTo`, `Packs`, `ONNX`, `Voice`, `npm`
- **Backend chip:** `Any`, `WSL`, `PowerShell`, `Python`, `ONNX`
- **Run picker:** current run + recent runs
- **Follow toggle:** auto-scroll on/off
- **Attach snippet button:** send selected lines to chat

---

## Safety boundaries

- Do not auto-stream full terminal tails into companion prompts.
- Companions read snapshots only unless user explicitly attaches lines.
- WSL command execution remains HITL for arbitrary commands.
- Managed in-app jobs (setup/infer/download) are allowed without raw shell access.

---

## Phase mapping to living spec

| Living spec phase | WSL implication |
|---|---|
| **M0** | WSL runs emit normalized Workshop Log events |
| **M1** | Workshop Terminal displays WSL task streams with filters |
| **M1b** | `npm` Run actions stream into same console model |
| **M2** | Snapshot API can filter `backend=wsl` + `source=lito.*` |
| **M5** | Optional PTY-based Raw WSL Terminal behind explicit user action |
| **M6** | Backend dropdown exposes WSL alongside PowerShell/cmake |

---

## Open questions

| # | Question |
|---|---|
| WSL-Q1 | Should Pipeline Console collapse noisy package-manager lines by default? |
| WSL-Q2 | Should Terminal remember preferred distro per project? |
| WSL-Q3 | Should stage markers be required for all first-party scripts? |
| WSL-Q4 | Do we need "Beginner mode" copy text whenever backend is WSL? |

---

## Implementation hints (non-binding)

- Reuse existing `media:lito-log` style event flow as a reference path.
- Introduce a shared log emitter utility for all subprocess backends.
- Keep terminal rendering append-only + bounded ring to avoid UI jank.
- Do not block inference threads with per-line heavy processing.

---

## Implementation checklist (current codebase)

Use this as a practical build list for the next pass.

### A) Normalize event payloads (main/preload/renderer)

- [ ] Add a shared event shape for terminal lines (`runId`, `source`, `backend`, `stream`, `level`, `message`, `ts`, optional `stage`).
- [ ] Emit that shape from main process for LiTo routes in `anikai-desktop/main.js` (currently `media:lito-log` sends `{ level, message }`).
- [ ] Update preload bridge in `anikai-desktop/preload.js` to expose unified terminal events (keep backward compatibility during migration).
- [ ] Update renderer consumer in `anikai-desktop/components/media.js` to parse unified payload first, fallback to legacy payload.

### B) Run lifecycle + stage semantics

- [ ] Generate `runId` per task invocation (LiTo setup, LiTo infer, pack jobs, npm jobs).
- [ ] Emit lifecycle markers: `run.start`, `run.finish` (include `exitCode`, `elapsedMs`, and `ok`).
- [ ] Keep `ANIKAI_STAGE:` line convention in scripts and Python tools; parse into highlighted stage rows in UI.
- [ ] Preserve raw stderr lines for debugging (do not hide failures behind stage-only summaries).

### C) UI controls (Pipeline Console first)

- [ ] Add source filter chips in console UI (`All`, `LiTo`, `Packs`, `ONNX`, `Voice`, `npm`).
- [ ] Add backend filter chip (`Any`, `WSL`, `PowerShell`, `Python`, `ONNX`).
- [ ] Add a run picker (`current run`, recent runs).
- [ ] Add follow toggle (`auto-scroll on/off`) and persist preference.
- [ ] Add "attach selected lines to chat" action with bounded line count.

### D) Performance + safety

- [ ] Enforce bounded ring buffer per run and global cap (avoid unbounded DOM growth).
- [ ] Truncate extremely long lines and expose expandable detail.
- [ ] Keep companion ingestion snapshot-only by default; no full live tail injection.
- [ ] Ensure in-flight inference paths avoid expensive per-line parsing work.

### E) WSL-specific reliability

- [ ] Keep flexible distro detection (`Ubuntu*`, default distro fallback).
- [ ] Improve no-distro error to one beginner action path (Store link + `wsl --install` hint).
- [ ] Expose detected distro in UI status line.
- [ ] Optional later: user override selector for distro in app settings.

### F) Raw Terminal mode (deferred)

- [ ] Gate behind feature flag until M5.
- [ ] Require explicit user opt-in + clear "advanced" label.
- [ ] Add HITL guardrails for arbitrary command execution.
- [ ] Keep Pipeline Console as default even after Raw mode ships.

