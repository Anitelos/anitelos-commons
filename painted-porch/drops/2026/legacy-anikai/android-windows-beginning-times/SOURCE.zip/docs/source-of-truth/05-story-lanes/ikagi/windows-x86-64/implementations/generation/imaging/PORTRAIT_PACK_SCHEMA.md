# Portrait Pack Schema (v1)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

This schema defines the generated asset pack that `PortraitPresenceActor` can load at runtime.

**Related:** [`PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`](./PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md), [`../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`](../../pipelines/IMAGING_PIPELINE_QUALITY_STACK.md), [`../../pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md`](../../pipelines/CREATIONS_PERSONA_RIG_TEST_PIPELINE_PLAN.md), [`../../OPERATIONS_INDEX.md`](../../OPERATIONS_INDEX.md).

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-07 | Added cross-link to Persona Rig test pipeline plan (consumer of pack scenes + motion hints). |
| 2026-05-06 | Added staging header + cross-links. |

## Active pack location

Runtime loader checks:

- `ANIKAI/Profiles/portrait-packs/active/manifest.json`

All relative paths in the manifest are resolved from `ANIKAI/Profiles/`.

## Folder example

```text
ANIKAI/Profiles/
  portrait-packs/
    active/
      manifest.json
  portrait-assets/
    desk/
      base.png
      eyes_open.png
      eyes_closed.png
      brows_calm.png
      brows_focus.png
      brows_warm.png
      brows_alert.png
      mouth_rest.png
      mouth_a.png
      mouth_e.png
      mouth_o.png
      mouth_m.png
```

## Manifest JSON

```json
{
  "version": 1,
  "packId": "netrunner_female_pack_v1",
  "scenes": {
    "desk_cam": {
      "base": "portrait-assets/desk/base.png",
      "eyesOpen": "portrait-assets/desk/eyes_open.png",
      "eyesClosed": "portrait-assets/desk/eyes_closed.png",
      "browsCalm": "portrait-assets/desk/brows_calm.png",
      "browsFocus": "portrait-assets/desk/brows_focus.png",
      "browsWarm": "portrait-assets/desk/brows_warm.png",
      "browsAlert": "portrait-assets/desk/brows_alert.png",
      "mouthRest": "portrait-assets/desk/mouth_rest.png",
      "mouthA": "portrait-assets/desk/mouth_a.png",
      "mouthE": "portrait-assets/desk/mouth_e.png",
      "mouthO": "portrait-assets/desk/mouth_o.png",
      "mouthM": "portrait-assets/desk/mouth_m.png"
    },
    "phone_closeup": {},
    "chair_side": {}
  }
}
```

## Notes

- Scene keys must match:
  - `desk_cam`
  - `phone_closeup`
  - `chair_side`
- You can provide only `base` at first and add layer files incrementally.
- If no active pack is found, runtime falls back to the existing profile bitmap + procedural overlays.
- 4-shot auto-generation + redo-one-shot planner contract lives in:
  - `docs/source-of-truth/02-roadmap/PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`

## Optional v2: subtle body / idle motion (shot-driven)

When onboarding / 4-shot planning is wired, it is reasonable to **derive micro-motion from the shot**, not random wiggle: e.g. bench + relaxed pose → slight **ankle / calf** shift or **forearm** rest motion; desk + hands_active → small **wrist / finger** idle on keys; standing hero → **weight shift** only. Keep it **sub-2D** (mesh warp, parallax, or tiny masked cycles) so phone budgets stay honest.

**Planner / pack author** can attach hints per scene (or inherit from the shot slot that maps to that scene). Per-shot source of truth in the planner output: optional `idleMotionHints` on each shot in `PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md`; pack build copies into `idleMotion` here and sets `drivingShotSlot` to the originating slot.

| Field | Purpose |
| --- | --- |
| `idleMotion.mode` | e.g. `off`, `subtle_2d`, `masked_cycle` |
| `idleMotion.regions` | Same region ids as planner `idleMotionHints.regions` (see autogen contract v2 starter set) |
| `idleMotion.intensity` | `0.0`–`1.0` cap for amplitude / rate |
| `idleMotion.drivingShotSlot` | Which 4-shot slot informed this (`ambient_presence`, `focus_work`, …) for traceability |

Example fragment (optional keys; v1 loaders ignore unknown fields):

```json
"desk_cam": {
  "base": "portrait-assets/desk/base.png",
  "mouthRest": "portrait-assets/desk/mouth_rest.png",
  "idleMotion": {
    "mode": "subtle_2d",
    "regions": ["forearm_left", "hand_rest"],
    "intensity": 0.35,
    "drivingShotSlot": "focus_work"
  }
}
```
