# GGUF engine inference implementation plan (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned (desktop first engine) |
| **Last reviewed** | 2026-05-10 |

Purpose: define the **first** desktop inference engine family for ANIKAI on Windows: **GGUF** containers executed through a **llama.cpp–class** runtime stack. This document is the **engine** contract (wrapper, capabilities per task, verification). It pairs with generation-side docs under `implementations/generation/text/`.

**Android parity (layout + concepts, not identical UX):** [`../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md)

**Desktop model paths / import UX:** [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md)

---

## Scope

This file covers **GGUF on Windows x86-64** for:

- **Wrapper / runtime family:** GGUF file + compatible native backend (llama.cpp-style loader, CPU and optional GPU offload where supported).
- **Capability matrix** by **task** (what the engine may legally claim after probe + manifest + successful init).
- **Lane boundaries:** companion chat, optional multimodal **understanding** (projector sidecars), and explicit separation from **generation/text** product contracts (see linked generation doc).

This file does **not** fully own:

- per–model-type narrative and role taxonomy (see [`generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md) and [`generation/text/TEXT_GENERATION_LANE_INDEX.md`](../../../generation/text/TEXT_GENERATION_LANE_INDEX.md)),
- imaging / video generation engines,
- sentience / sensory stacks (for example MediaPipe on other platforms; Windows sentience docs will link **in** when a family shares probes or delegates).

---

## What GGUF is (on Windows, in ANIKAI terms)

**GGUF** is a single-file (or primary-file + optional sidecars) **container** format commonly produced for **llama.cpp** compatible runtimes. A filename such as `…-Q4_K_M.gguf` implies **quantization** and a **decode profile**; it does **not** prove a given build can load the tensor layout or run at target latency.

**Rule:** presence of a `.gguf` under `models/` is **inventory**, not **capability**. Execution requires: adapter + manifest row + session init + successful output contract for the **task** being claimed.

---

## Wrapper / family / task matrix (authoritative for GGUF engine)

| Task id | Description | GGUF engine must declare | Notes |
|---------|-------------|---------------------------|--------|
| `text_decode` | Autoregressive token generation from prompt | `text_generation` | Core desktop companion path. |
| `text_embed` | Text embeddings for retrieval / tools (if enabled) | `text_embedding` | Optional; only if runtime exposes stable embed API. |
| `vision_understand` | Image → conditioning → text (no pixel synthesis) | `vision_understanding` + required sidecars (e.g. `mmproj`) | Same honesty rule as Android: no sidecar → no claim. |
| `audio_understand` | Audio → text (if enabled) | `audio_understanding` | Only when native path exists and is probed. |
| `diffusion_decode` | Native diffusion in GGUF (rare / specialized) | `diffusion_decode` | Separate adapter path; do not infer from chat weights. |

**Family id:** `gguf`  
**Wrapper id (example):** `llamacpp_win_x64` (final name should match whatever single native bridge ships first).

---

## Role model (ownership)

| Lane | Owner doc | GGUF engine responsibility |
|------|-----------|----------------------------|
| Companion **chat** brain | [`TEXT_GENERATION_LANE_INDEX.md`](../../../generation/text/TEXT_GENERATION_LANE_INDEX.md) + runtime selector | Load, stream, stop, thermal-aware settings; expose probe result to UI. |
| **Multimodal understanding** | engine-inference (here) + future sentience cross-links | Enforce sidecar + capability flags before enabling attach/analyze UI. |
| **Text roles** (T1–T5 style) | [`generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md) | Engine reports **profile** (size, quant, context); scheduler assigns role. |
| **Sentience / sensory** | `implementations/sentience/*` (stubs) | GGUF does not subsume camera/mic; may **consume** fused features if another module provides them. |

---

## Windows implementation plan (runtime + native)

### 1) Session / process ownership

- One **authoritative** load config (threads, context length, batching, mmap, mlock, GPU layers if any).
- **Single-writer** session lifecycle from the process that owns the companion (Electron main or dedicated worker; avoid silent duplicate loads).
- Cancellation: window hide, panel close, user stop, and shutdown must **tear down** native state without dangling mmap.

### 2) Native / FFI checklist

- [ ] Single **x86-64** artifact (or CPU + optional CUDA/DirectML/Vulkan variant) with explicit build matrix in repo docs.
- [ ] FFI boundary: prompt in → token stream / full completion out; structured errors (no “fake success”).
- [ ] Optional: streaming callback into renderer with backpressure.
- [ ] Capability **probe** on load: arch mismatch, missing ops, OOM → surfaced to UI and manifest row.

### 3) Capability manifest contract (per bundle)

Each catalog row for a GGUF bundle should include:

| Field | Example |
|-------|---------|
| `model_id` | stable id |
| `adapter_id` | `llamacpp_win_x64` |
| `files` | primary `.gguf` + optional `mmproj` paths |
| `capabilities` | `{ "text_generation": true, "vision_understanding": false, … }` |
| `profile` | `{ "quant": "Q4_K_M", "vram_mb_est": …, "ctx_default": … }` |
| `lanes` | `["companion_primary", …]` |

---

## App integration map (desktop)

### A) Electron + companion

- GGUF is the **default first** local brain when manifest + probe pass.
- Desktop **models** folder and import flow: see [`MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md).

### B) Multimodal understanding

- Same rule as Android: **no** vision claim without working projector + test pass.
- Output is **text / tool plan**, not generated pixels.

### C) Swarm / pipelines (future)

- Specialist steps bind **only** when capability + adapter id match; failures are explicit degraded states.

---

## Desktop trajectory (ordered next steps)

**Today (Phase 0 bridge):** Electron **main** spawns upstream **`llama-completion`** once per user message (`-no-cnv`, fixed `-n`), via [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md) (build + env vars) and `anikai-desktop/main-process/gguf-completion.js`. Chat reads **`modelSlots.chat`** for the active companion; models must resolve under **`MODELS_DIR`**.

| Step | What | Why |
|------|------|-----|
| 1 | **Streaming tokens** to the chat bubble (IPC chunk events + renderer append) | Matches product expectation; avoids long silent waits. |
| 2 | **Cancel / companion switch** — kill or signal child; ignore late stdout | Prevents runaway CPU and wrong-thread replies. |
| 3 | **Warm session** — keep one `llama-completion` or small native helper **alive** between turns (same model) | Amortize load; align with “single-writer session” above. |
| 4 | **Optional `llama-server`** — long-lived HTTP / OpenAI-shaped local port; Electron is client | Better concurrency, tool calling later, shared GPU context. |
| 5 | **Probe + manifest row** in UI (not filename inference) | Same honesty rule as Android; enables mmproj / capability warnings. |
| 6 | **Native FFI** (optional) — link `llama` directly instead of subprocess | Smaller latency surface; higher packaging cost. |

---

## Verification gates (before “operational” claims)

- Chat: stable start/stop, no leak across companion switches.
- Vision: one on-device success path **or** feature hidden.
- Manifest: flags match probe; no inference from filename alone.

---

## Linked docs

| Topic | Path |
|-------|------|
| Text generation (lane index) | [`../../../generation/text/TEXT_GENERATION_LANE_INDEX.md`](../../../generation/text/TEXT_GENERATION_LANE_INDEX.md) |
| GGUF text generation (type plan) | [`../../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md`](../../../generation/text/gguf/GGUF_TEXT_GENERATION_IMPLEMENTATION_PLAN.md) |
| ONNX engine (Windows) | [`../onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../onnx/ONNX_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |
| GGUF imaging generation (Windows) | Lane index [`../../../generation/imaging/IMAGING_GENERATION_INDEX.md`](../../../generation/imaging/IMAGING_GENERATION_INDEX.md); product rules [`../../../generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md`](../../../generation/imaging/gguf/GGUF_IMAGING_GENERATION_IMPLEMENTATION_PLAN.md) |
| GGUF music generation (Windows) | [`../../../generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md`](../../../generation/audio/music-sfx/gguf/GGUF_MUSIC_GENERATION_IMPLEMENTATION_PLAN.md) |
| Model hub index (Windows) | [`../MODEL_HUB_INDEX.md`](../MODEL_HUB_INDEX.md) |
| Model download + local GGUF bridge (desktop) | [`../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md`](../../../companion-surface/desktop-overlay-and-panels/MODEL_DOWNLOAD_DATA_ROOT_AND_PANEL.md) |
| Android GGUF engine plan | [`../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../../../../android-arm64/implementations/engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md) |

---

## Linked todos (Windows)

| Todo | Path |
|------|------|
| GGUF text on desktop | [`../../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md`](../../../../todo/mid-scope/TODO_GGUF_TEXT_GENERATION_DESKTOP.md) |
| Windows text roles | [`../../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md`](../../../../todo/mid-scope/TODO_WINDOWS_TEXT_ROLE_ORCHESTRATION.md) |

**Android tracking (parity reading, not Windows work items):** [`../../../../../android-arm64/todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md`](../../../../../android-arm64/todo/mid-scope/TODO_GGUF_ENGINE_INFERENCE_RUNTIME.md)

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial Windows x86-64 GGUF engine-inference plan: first desktop engine, task matrix, manifest contract, links to generation/text and Android parity doc. |
| 2026-05-09 | Generation/text split: lane index + GGUF type plan + desktop todos; table links updated. |
| 2026-05-10 | Linked ONNX + GGUF imaging/music generation plans; model download doc path → `companion-surface/…`. |
| 2026-05-10 | Desktop trajectory table (spawn → stream → session → server → probe → FFI); Phase 0 bridge called out with code/doc pointers. |
