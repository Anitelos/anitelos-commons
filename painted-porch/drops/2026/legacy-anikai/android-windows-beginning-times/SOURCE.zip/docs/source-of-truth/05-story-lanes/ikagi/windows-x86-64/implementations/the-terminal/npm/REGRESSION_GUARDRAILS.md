# Regression guardrails — prevent one-line chaos

Real incidents on this codebase — **one line** caused full-day UI failure. These guardrails exist so we never rely on luck again.

---

## Known failure modes (learned the hard way)

| Symptom | Likely one-line class | Detection |
|---------|----------------------|-----------|
| Dock pill becomes huge; chat flies off-screen; negative dock X | Remeasuring dock HWND width from `getBounds()` in a sync loop (`refreshDockWindowOuterWidth`) | `npm run dev:cluster-debug` — watch width explode in logs |
| Dock vanishes when dragging chat | OS `-webkit-app-region: drag` on dock without frozen size | Manual drag + cluster debug |
| Workspace trees grow taller/wider on every layout pass | Re-enabled live tree sync instead of frozen `__anikaiWorkspaceFrozenW/H` | Visual + cluster debug |
| Buttons dead app-wide | Bad panels tab / menu entry wiring (shared handler or overlay) | Click smoke across dock + chat + panels after any menu/tab edit |
| Startup crash | Wrong export on main-process module (`stateDir is not a function`) | `npm run dev` immediately after IPC/state changes |

---

## Pre-merge checklist (shell / layout PRs)

- [ ] Diff touches `main.js`, dock, chat, or panels? → **`dev:cluster-debug`** manual pass (drag dock, collapse chat, open two panels).
- [ ] Diff touches magnet registry or panel bounds? → **`npm run smoke-magnet-panels`**.
- [ ] Diff adds/changes chat ≡ menu item? → Click every other menu item still works.
- [ ] No new `getBounds()` → setBounds feedback loops without frozen layout constants.
- [ ] Document the lesson: one sentence in this file or runbook changelog if new class found.

---

## Code review red flags

1. **Measuring what you just set** — sync handler reads window size then resizes again in the same tick.
2. **Removing “frozen” layout fields** without replacing invariant — trees and dock had explicit frozen dimensions for a reason.
3. **Global CSS on `.chat-header-menu-item` or panel tabs** — prefer scoped classes; past tab change broke unrelated buttons.
4. **Silent `console.log` only** — prefer future `workshopLog.emit({ domain: 'shell', ... })` (M0); until then use `ANIKAI_CLUSTER_DEBUG`.

---

## UX checks (human, 2 minutes)

1. **Dock led drag** — chat cluster moves; dock does not resize to full screen.
2. **Panels dock toggle** — from chat ≡ menu; panel strip still clickable.
3. **Thought stream / toggles** — checkmarks still toggle; no dead overlay.
4. **Restart app** — from menu; app recovers layout.

---

## When to extend this doc

Any regression that took **>30 minutes** to diagnose and traced to **≤3 lines** changed → add a row to **Known failure modes** and a runbook command if a new npm smoke is warranted.

---

## Changelog

| Date | Change |
|------|--------|
| 2026-05-22 | Initial guardrails from dock width feedback-loop incident + prior panels-tab incident |
