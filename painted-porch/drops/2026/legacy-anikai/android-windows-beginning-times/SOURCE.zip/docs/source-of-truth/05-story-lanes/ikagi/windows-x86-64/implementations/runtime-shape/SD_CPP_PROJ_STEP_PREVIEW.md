# SD.cpp `proj` step preview (Media Magic)

**Status:** Implemented in desktop Media Magic for native **GGUF + sd.exe** runs.

## Behavior

During denoise, stable-diffusion.cpp writes a low-cost preview PNG using **latent RGB projection** (`--preview proj`). Anikai:

1. Passes preview CLI flags when spawning `sd.exe` / `sd-cli`.
2. Emits `previewPath` on `sd-image:progress` when the file updates.
3. Shows that frame in the Media Magic **Result** panel (with step overlay).
4. Deletes `*.anikai-preview.png` after the run; final quality still comes from full **VAE** decode to `-o`.

## Staging checklist (no extra weights for `proj`)

| Item | Staged? | Notes |
|------|---------|--------|
| `sd.exe` / `sd-cli.exe` with `--preview` | Via **`gguf.imaging`** | Install / repair local AI engine |
| Preview PNG path | Runtime temp beside output | `resolveProjPreviewPath()` in `anikai-desktop/main-process/sd-proj-preview.js` |
| TAESD | **Not used** | `tae` / `vae` preview modes are optional future work |
| Vendor CLI docs | `vendor/stable-diffusion.cpp/examples/cli/README.md` | Source of truth for flags |
| App manifest | `anikai-desktop/assets/sd-cpp-preview/STAGING.md` | Human-readable staging table |

## CLI reference (upstream)

```text
--preview proj
--preview-path <absolute-path.png>
--preview-interval 1
```

Other modes (`tae`, `vae`) need extra decode cost or `--taesd` weights; **`proj` is the default Anikai choice** because it adds minimal hassle.

## Final image quality

Preview mode does **not** change the saved image unless you also pass `--taesd` **without** `--taesd-preview-only`. Anikai does not pass those flags.

## Code map

| Layer | File |
|-------|------|
| CLI args + file stat | `anikai-desktop/main-process/sd-proj-preview.js` |
| Spawn + progress IPC | `anikai-desktop/main-process/gguf-completion.js` |
| Result panel refresh | `anikai-desktop/components/media.js` |
| IPC channel | `sd-image:progress` (preload `onSdImageProgress`) |

## Unsupported models

If sd.cpp has no latent RGB table for a family, previews may be absent while sampling still succeeds. Check sd.exe stderr for `No latent to RGB projection known`.
