# Agentic control loop & persistent memory (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Overview:** [`COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](./COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md)

**Builds on:** [`THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md`](../THOUGHT_REPLY_SEGMENT_PIPELINE_PLAN.md) (segment loop today is **not** yet a full agentic controller)

**Todo:** [`../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md) (Track B)

---

## Goal

Evolve from **chat loop** (user → one infer block → stop) to **agentic control loop** (orchestrator decides: another segment, update background state, compress context, or surface final reply).

Target feel: IDE agents (Cursor-class) — **continuous rolling execution** with honest local boundaries.

---

## Chat loop vs agentic loop

| | Chat loop (today) | Agentic loop (target) |
|--|-------------------|------------------------|
| **Stop condition** | Model emits final / `<done/>` | Controller + model tags |
| **Memory** | Transcript append-only | Scratchpad + TODO + optional journal |
| **Visible UI** | Thought panel + reply bubbles | Processing state + **only** final channel in user bubble |
| **Context limit** | Truncation / quality cliff | Sliding compression + pinned state |

```mermaid
flowchart LR
  User[User message] --> Ctrl[Turn controller]
  Ctrl --> Seg[Segment infer]
  Seg --> Parse[Parse channels + tags]
  Parse --> Ctrl
  Ctrl -->|more work| Seg
  Ctrl -->|compress| Roll[Context roller]
  Ctrl -->|show user| Final[Final bubble]
  Roll --> Ctrl
  State[(Scratchpad + TODO)] --> Seg
```

**Key idea:** The LLM talks to the **controller** through structured tags; the controller owns when the user sees text.

---

## Memory architecture

```text
[Context window]
    ├─► [Sliding horizon compression] ──► [Micro-summaries] (pinned)
    ├─► [Active scratchpad]     (mutate in place, never evicted)
    ├─► [Active TODO list]      (mutate in place, never evicted)
    └─► [Journal entries]       (async writes, cross-thread recall)
```

### A. Sliding context & micro-summaries

**Trigger:** Context fill ≥ **80%** of effective `-c` (from `gguf-metadata` + Persona cap).

**Action (background, invisible in user bubble):**

1. Take oldest ~**30%** of **evictable** transcript tokens.
2. Run a **compression pass** (same or smaller model) → dense micro-summary paragraph.
3. Remove raw tokens; pin summary at top of history block.
4. Re-inject scratchpad + TODO unchanged.

**Non-goals v1:** Vector DB for full chat; cloud summarization API.

### B. Active scratchpad & mutable TODO

| Object | Content | Update mechanism |
|--------|---------|------------------|
| **Scratchpad** | Working assumptions, plan, open questions | Structured tool or tags overwrite sections — not append-only chat spam |
| **TODO list** | done / doing / next | Same; visible in UI as live task list (not chat prose) |

**On rollover:** Scratchpad + TODO copied verbatim into next system prompt assembly.

**Storage:** `%ANIKAI_HOME%/desktop-data/companions/<id>/agent-state.json` (sketch).

### C. Companion journal (notebook)

| Property | Value |
|----------|-------|
| **Purpose** | Long-horizon memory across threads |
| **Writer** | Background pass after major task or pre-rollover |
| **Format** | Markdown files under `journal/<companionId>/` (aligns with workforce §8) |
| **Reader** | Injected summary block with **anti-fabrication** rules (only cited journal facts) |
| **Indexing** | P4+: optional local embeddings; P2: filename + recency only |

Example entry: *“2026-05-20: User wants strict Gemma channel enforcement; dislikes thought leak in bubble.”*

---

## UX: strict UI isolation (thought spillage)

**Problem:** Planning text appears in user-visible bubble.

**Rules:**

| Surface | Shows |
|---------|--------|
| **Thought panel** | `<\|channel\|>thought` / `<thought>` content, tools, tags |
| **Task / status rail** | Spinner, segment index, TODO mutations, indexing blocks |
| **User reply bubble** | Only validated **final** channel text |

**Parser contract (extend today):**

- Drop tokens before first valid final marker when family requires it (`gemma4-channels.js`).
- Never stream thought chars into `appendAssistantMessage` path.
- Async tools: show **“Working…”** card, not intermediate model monologue.

Cross-check: [`CONVERSATION_PATHS_AND_THOUGHT_ROUTING.md`](../../runtime-shape/CONVERSATION_PATHS_AND_THOUGHT_ROUTING.md).

---

## Controller integration with segment loop

Today `runGgufThoughtTurn` runs segments until `<done/>` / clarify / tool exhaustion.

**Extensions (Track B):**

| Controller hook | Behavior |
|-----------------|----------|
| `beforeSegment` | Inject scratchpad + TODO + compression summaries |
| `afterSegment` | Apply scratchpad/TODO mutations from tags |
| `shouldContinue` | Beyond max segments: only if TODO open items and user opted “keep going” |
| `onContextPressure` | Schedule roller job; pause user-visible stream with status only |

**Do not** fork a second infer stack — extend the same segment orchestrator.

---

## Implementation slices (Track B)

| Slice | Deliverable |
|-------|-------------|
| **B0** | `agent-state.json` + scratchpad/TODO tags + UI task rail |
| **B1** | Context roller at 80% + micro-summary pin |
| **B2** | Journal writer pass + cross-thread inject |
| **B3** | User-visible “agent session” mode toggle (power user) |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Captured Antigravity agentic-loop thread; aligned with existing segment + workforce journal docs. |
