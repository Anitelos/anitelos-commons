# Team blackboard orchestration (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-20 |

**Overview:** [`COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md`](./COMPANION_EXECUTION_ARCHITECTURE_OVERVIEW.md)

**Prerequisites:** Track B0 (controller state), **E+** multi-resident or multiple `llama-server` ports ([`GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`](../../engine-inference/model-hub/gguf/GGUF_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md))

**Related:** [`GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md), [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](../WORKFORCE_AND_ORCHESTRATION_VISION.md)

**Todo:** [`../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md`](../../../todo/mid-scope/TODO_COMPANION_EXECUTION_AGENT_DESKTOP.md) (Track C)

---

## Goal

Use **several small local models** (Gemma, Qwen, Phi, etc.) as a **planning team** that works **in parallel** on a shared **blackboard** — then **Freeze & Approve** before execution — instead of round-robin “Agent 1 talks, then Agent 2 talks.”

This is **orchestration for power users** and large tasks; solo chat remains the default product.

---

## Why not round-robin chat

| Round-robin | Blackboard |
|-------------|------------|
| Serial context pollution | Each agent reads/writes **structured state** |
| “Telephone game” drift | Cross-review passes on **drafts**, not chat history |
| One model dominates | Roles (architect, security, QA) stay separated |

```mermaid
flowchart TB
  subgraph main [Electron main process]
    BB[Blackboard state object]
  end

  BB --> A1[Gemma - Architect]
  BB --> A2[Qwen - Quality]
  BB --> A3[Phi - Security]
  A1 --> BB
  A2 --> BB
  A3 --> BB
```

Agents do **not** DM each other; they read/write **fields** on the blackboard.

---

## Blackboard schema (v1 sketch)

```json
{
  "globalGoal": "Build secure registry table in Electron.",
  "proposedPlan": [],
  "agentStatuses": {
    "architect": { "status": "thinking", "currentFocus": "Schema" },
    "quality": { "status": "idle", "currentFocus": "Waiting for draft" }
  },
  "drafts": {},
  "reviews": [],
  "conflicts": [],
  "phase": "planning"
}
```

| Field | Role |
|-------|------|
| `globalGoal` | User request + controller edits |
| `proposedPlan` | Unified steps after convergence |
| `agentStatuses` | UI avatars / spinners |
| `drafts` | Per-agent initial proposals |
| `reviews` | Cross-review entries |
| `conflicts` | Unresolved objections for Freeze UI |
| `phase` | `planning` \| `frozen` \| `executing` \| `done` |

**Storage:** in-memory + optional snapshot under `%ANIKAI_HOME%/desktop-data/teams/<sessionId>.json`.

---

## Phase 1 — Parallel brainstorming & debate

### Step A — Independent drafting (parallel)

- Main process fires **N workers** (see below) with same goal, different **role prompts**.
- Each writes to `drafts[roleId]` — hidden from user chat.

### Step B — Cross-review

Orchestrator re-prompts each agent with **another agent’s draft**:

- Architect reviews timeline / dependencies.
- Security reviews file paths / injection / sandbox violations.

Output → `reviews[]` as structured lines, not free chat.

### Step C — Drafting channel UI

Unified **“Planning thread”** surface (new panel or Playground sub-tab):

```text
[Gemma · Architect]: Path A — single registry module…
[Phi · Security]: Path A leaks cwd — isolate worker process…
```

Not raw JSON; not the main companion bubble.

### Convergence

Stop debate when:

- All agents emit `<ready_for_review/>`, or
- **3 rounds** max (configurable).

---

## Freeze & approve (human gate)

Before **Go**:

| UI block | Content |
|----------|---------|
| **Master plan** | Merged step list |
| **Role assignments** | Which model runs which step |
| **Dissent log** | Unresolved warnings (e.g. “Qwen: step 4 may exceed 2B context”) |

User may edit plan, reassign, override dissent → **Approve** sets `phase = executing`.

**Non-goal:** Autonomous Go without explicit click (Manager autonomous mode is separate — [`Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md`](Specialists/COMPANION_SPECIALTIES_AND_SESSION_ROLES.md) § Manager, [`WORKFORCE_AND_ORCHESTRATION_VISION.md`](WORKFORCE_AND_ORCHESTRATION_VISION.md) §9).

---

## Phase 2 — Execution via task DAG

```text
[Task 1: UI schema] → Gemma 4B → complete
        ↓
[Task 2: Parsers]  → Qwen 2B  ─┐ parallel after Task 1
[Task 3: Tests]    → Phi 3    ─┘
```

| Mechanism | Behavior |
|-----------|----------|
| **DAG** | Orchestrator builds acyclic graph from approved plan |
| **Ready queue** | Tasks whose deps are `complete` |
| **Blackboard update** | Agent sets `tasks[id].status`; main wakes dependents |
| **Per-agent scratchpad** | From Track B — avoids cross-task context pollution |

**Execution uses Track A:** patches and shell go through sandbox + HITL.

---

## Worker model (Electron)

Antigravity sketch used `worker_threads` + `agentWorker.js`:

| Piece | Responsibility |
|-------|----------------|
| `TeamOrchestrator` (main) | Phase machine, blackboard, DAG scheduler |
| `agentWorker.js` | HTTP to assigned `llama-server` port, role prompt, return JSON |
| Renderer | Planning thread + Freeze UI + execution progress |

**Do not** block UI thread on infer — same rule as `gguf-completion` today.

### Multi-model infrastructure options

| Option | When |
|--------|------|
| **E+ multi-resident** | Preferred — one desktop, N hot models |
| **N llama-server ports** | Manual power-user setup |
| **Sequential fake parallel** | Dev only — not product |

---

## Distinction from group chat mate network

| | Group chat | Team blackboard |
|--|------------|-----------------|
| **Audience** | User talks to companions | User approves **plan** then execution |
| **Output** | Conversational bubbles | Structured plan + DAG |
| **Models** | Usually one active speaker | Many models in **planning** phase |
| **Doc** | GROUP_CHAT plan | This doc |

They can share **roster + hub** metadata from workforce vision.

---

## Implementation slices (Track C)

| Slice | Deliverable |
|-------|-------------|
| **C0** | Blackboard schema + `TeamOrchestrator` planning phase only |
| **C1** | Parallel draft + cross-review workers |
| **C2** | Drafting channel UI + Freeze & Approve |
| **C3** | DAG executor + per-task scratchpads |
| **C4** | Link approved plan → pipeline panel export (workforce §11) |

---

## Open questions

1. **Personality vs role-only UI** — Avatars per agent slot vs functional badges only?
2. **VRAM budget** — Max parallel drafts = f(resident policy)?
3. **Single workspace** — One blackboard per workspace root?

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Captured Antigravity multi-agent / blackboard thread; scoped after sandbox + agentic loop. |
