# Voice Weaving — Media Magic (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Phase 1 partial — Voice Weaving tab + preset manifests; LongCat + Kokoro TTS in Compose |
| **Last reviewed** | 2026-05-24 |
| **Parent pipeline** | [`../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md`](../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md) — S3 speaking / singing and Compose **Voice** stage |
| **Related registries** | `anikai-desktop/assets/about-guide/voice-registry.json`, `articulations-registry.json` |
| **Runtime plans** | [`./KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md`](./KOKORO_RUNTIME_IMPLEMENTATION_PLAN.md), [`./XTTS_RUNTIME_IMPLEMENTATION_PLAN.md`](./XTTS_RUNTIME_IMPLEMENTATION_PLAN.md), [`./COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md`](./COSYVOICE_RUNTIME_IMPLEMENTATION_PLAN.md), [`./KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md`](./KITTEN_RUNTIME_IMPLEMENTATION_PLAN.md) |

Purpose: define how Anikai **separates voice engines from voice presets**, where users **author** clones and custom voices, and how the **Suno-clone Compose** desk **consumes** those voices without locking to a single cloner (LongCat is first, not last).

This doc does **not** replace:

- **Sentience → Voice** — companion *speaking* replies (chat TTS), not song production.
- **Articulations** catalogue — **singing** models (S3 / Lane 5) used from Compose **Lyrics** when rendering sung vocals.
- Per-engine implementation plans under this folder.

---

## Why engines and voices must be separate

| Layer | What it is | Example |
|-------|------------|---------|
| **Engine** | Runtime + weight layout that *can* render audio | LongCat-AudioDiT, Kokoro ONNX, XTTS v2, CosyVoice, DiffSinger |
| **Voice preset** | A named choice *on* that engine | “My narrator clone”, Kokoro `af_bella`, XTTS ref `chapter1.wav` |
| **Role / capability** | What Compose asks for | `text-to-speech`, `voice-clone`, `singing-voice` |

A single engine can expose **many** presets. A preset must not be confused with “the model picker” in Compose — that picker is **`engine → presets`**, not a flat list of weight folders.

**Product rule:** Voice **authoring** lives in **Voice Weaving**. Compose **selects** a preset and renders a line or lyric pass — it does not host multi-step clone wizards (Kokoro voice maker, LongCat ref+transcript training UI, etc.).

---

## Relationship to the Suno-clone pipeline

```mermaid
flowchart TB
  subgraph suno [Suno-clone DAG]
    S1[S1 Lyrics + structure]
    S2[S2 Instrumental Lane 4]
    S3[S3 Singing voice]
    S4[S4 Mix / DSP]
  end
  subgraph mm [Media Magic Audio]
    CW[Compose — consumer]
    VW[Voice Weaving — author]
    ASM[Assembly]
  end
  subgraph reg [Catalogues]
    AR[articulations-registry — singing]
    VR[voice-registry — speaking / clone]
    UP[user presets manifest]
  end
  VW --> UP
  VR --> VW
  AR --> S1
  UP --> CW
  VR --> CW
  CW --> S3
  CW --> S2
  CW --> ASM
  S4 --> ASM
```

| Suno stage | Media Magic surface | Voice / articulation source |
|------------|---------------------|-----------------------------|
| **S1** | Compose → **Lyrics** | Chat GGUF + optional image/audio sources; **singing articulation** picker (planned) from `articulations-registry` (`singing-voice` capability) |
| **S2** | Compose → **Instrumental** | Lane 4 backends (`music-audio-registry`) |
| **S3 (speak line today)** | Compose → **Voice** | **Voice preset** from Voice Weaving (`voice-registry` + user presets) |
| **S3 (sing lyrics — gap)** | Compose → **Lyrics** + future **Sing** action | **Articulation** entries (DiffSinger, VITS singing, Cantio, …) — not the same list as speaking presets |
| **S4–S5** | **Assembly** + export | Stem paths, ffmpeg analysis, amix |

Full pipeline runner: **Pipelines → Run Suno-clone** (linear Phase 0). **Compose** + **Generate full song** are the interactive desk — see [`../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md`](../../pipelines/CURATED_SUNO_CLONE_PIPELINE.md).

---

## Media Magic Audio tabs (target)

| Sub-tab | Role |
|---------|------|
| **Synth / MIDI** | Lanes 1–2 |
| **Compose** | Suno desk: Lyrics → Voice → Instrumental (Assembly is its own tab) |
| **Voice Weaving** | **Author** presets: clone, import pack, name, readiness, pack-missing hints |
| **Assembly** | Layer stems, analyze, export mix |
| **SFX** | Lane 3 one-shots |
| **Games** | Sprite sheet / game tools |

**Today (desktop):** **Voice Weaving** tab ships for LongCat — save clone presets under `voices/presets/`. **Compose → Voice** uses a grouped **Voice preset** dropdown (`voice:list-presets`, `audio:render-voice-preset`). **Kokoro** TTS ships via `kokoro-onnx` + `npm run stage-kokoro-voice` (preset `af_heart`). XTTS / CosyVoice use the same manifest when wired.

---

## Voice Weaving — responsibilities

| In scope | Out of scope (other surfaces) |
|----------|-------------------------------|
| Record / pick reference audio for clone engines | Companion chat reply voice (Sentience) |
| Run engine-specific clone or preset creation | Lane 4 instrumental generation |
| Name preset, tag capabilities, link pack files | Lyrics GGUF planning (Compose Lyrics) |
| Show **missing pack** with path hint (greyed in Compose) | Full singing score pipeline (future Playground graph) |
| Import Kokoro `.bin` / Android-exported preset manifests | |
| Long-term: **Kokoro voice maker** wizard (multi-step, style tokens) | |

### Preset manifest (planned contract)

User presets live under Anikai home, e.g. `voices/presets/<presetId>.json`:

```json
{
  "id": "my-warm-narrator",
  "displayName": "Warm narrator",
  "engineId": "kokoro_onnx",
  "capabilities": ["text-to-speech", "voice-affect"],
  "packRefs": {
    "modelOnnx": "models/voices/kokoro/kokoro-v1_0.onnx",
    "voiceBin": "models/voices/kokoro/voices/my-warm.bin"
  },
  "createdAt": "2026-05-24T00:00:00.000Z"
}
```

Desktop resolves `packRefs` against `ANIKAI_HOME/models/` (and registry layout assets). If a file is missing, the preset is **listed but disabled** with: *“This pack is missing from your kokoro folder”* (same UX pattern as Android Kokoro presets).

IPC target (planned): `audio:render-voice-preset` with `{ presetId, text, durationSec, … }` dispatching to per-engine adapters (`longcat`, `xtts`, `cosyvoice`, `kokoro`, …).

---

## Compose — Voice stage (consumer UX)

### Grouped dropdown (target)

```
▼ Voice
  ── Prioritized engines ──
  LongCat-AudioDiT
    ○ Default TTS (1B)
    ○ My narrator clone
    ○ Studio (3.5B)          [disabled] Weights missing — Get pack
  Kokoro
    ○ af_bella
    ○ My warm narrator       [disabled] Pack missing: voices/my-warm.bin
  XTTS v2
    ○ Reference: chapter1.wav
  ── More engines ──
  CosyVoice · Piper · …
  ── Any speaking voice ──
  Kitten · companion_default · novelty TTS …
```

Rules:

1. **Curated clone/TTS engines first** (order from `voice-registry.json` `packFamilies` + product priority).
2. **Presets nested under engine** (`<optgroup label="LongCat">`).
3. **Do not lock the list** — users may want a song line read in Kitten, Kokoro, or a deliberately “basic” voice; filter by **capability**, not brand.
4. **Missing dependency = visible, disabled**, never silent fallback to another engine.

### Today (shipped partial)

| Piece | Status |
|-------|--------|
| LongCat TTS via Diffusers `LongCatAudioDiTPipeline` | Shipped — `npm run stage-longcat-voice` |
| LongCat clone presets (ref wav + transcript) | Shipped — author on Voice Weaving; `audiodit` optional |
| Grouped preset picker in Compose | Shipped — `voice:list-presets` + `<optgroup>` |
| Voice Weaving tab | Shipped — save/delete user presets |
| Kokoro TTS (`kokoro-onnx`, `media-kokoro-voice.js`) | Shipped — `npm run stage-kokoro-voice`; Get pack `voice-pack-registry` |
| XTTS v2 (`coqui-tts`, clone presets) | Shipped — `npm run stage-xtts-voice` |
| CosyVoice-300M (zero-shot clone) | Partial — `npm run stage-cosyvoice-voice` + Get pack; heavy upstream |
| Voice Get packs (`voice-pack-registry.json`) | Shipped in Media Magic **!** menus — imaging-style download |
| Android Kokoro `voices/*.bin` import | Planned — desktop uses kokoro-onnx combined `voices-v1.0.bin` today |

---

## Compose — Lyrics stage and singing articulations

**Speaking** presets (Voice Weaving) and **singing** models (Articulations) are different roles in the Suno DAG.

| UI | Registry | Filter |
|----|----------|--------|
| Compose → Lyrics → **Singing model** (planned) | `articulations-registry.json` | `capabilities` includes `singing-voice` |
| Compose → Voice | `voice-registry.json` + user presets | `text-to-speech`, `voice-clone`, etc. |

Examples already catalogued: DiffSinger, VITS singing, So-VITS-SVC, ANIKAI Cantio (S3 pick), LongCat where tagged. Lane 5 honest gap remains in the Suno doc until a default S3 backend ships.

---

## Engine catalogue (voice-registry — speaking / clone)

Prioritized for Weaving UI and Compose optgroups (not exhaustive):

| Engine family | Clone? | Notes |
|---------------|--------|-------|
| **LongCat-AudioDiT** | Yes (native + Diffusers TTS) | First desktop wire-up; Compose today |
| **XTTS v2** | Yes | Reference wav → speaker latents |
| **CosyVoice** | Yes | Zero-shot + instruct |
| **Kokoro ONNX** | Preset / style bins | Android preset parity; voice maker = Weaving wizard |
| **Kitten ONNX** | Preset | Compact companion lane |
| **Piper** | Per-voice onnx pair | Lightweight TTS |
| **eSpeak** | — | System / novelty lane |

Singing stacks (DiffSinger, VITS, RVC-class) stay under **Articulations**, not Voice Weaving, unless an engine serves both roles (then tag both capability sets explicitly).

---

## Staging (Media Python)

| Script | Purpose |
|--------|---------|
| `npm run stage-media-python` | Base venv |
| `npm run stage-longcat-voice` | Diffusers + optional `audiodit` clone from cloned LongCat-AudioDiT repo |
| `npm run stage-kokoro-voice` | `kokoro-onnx` in Media Python — weights: `models/voices/kokoro/kokoro-v1.0.onnx` + `voices-v1.0.bin` |
| `npm run stage-xtts-voice` | `coqui-tts` — XTTS weights on first synthesis |
| `npm run stage-cosyvoice-voice` | `cosyvoice` pip — pair with Get pack CosyVoice-300M |

### eSpeak — what needs it?

| Engine | eSpeak role on desktop |
|--------|-------------------------|
| **Kokoro** | **Bundled via `kokoro-onnx` pip** (`espeakng-loader` / `phonemizer-fork`) — you do **not** need `voice.espeak` runtime pack for Kokoro alone. |
| **Piper / some native ONNX** | **`voice.espeak` runtime pack** (`espeak-ng.exe` + `espeak-ng-data/`) — same as Android staging. |
| **XTTS (Coqui)** | Coqui stack manages phonemes internally for XTTS; Android also stages espeak data beside native libs. |
| **LongCat** | Text-in → waveform; no espeak. |
| **CosyVoice** | Reference-audio conditioning; no espeak for basic zero-shot. |

Run `npm run stage-voice-espeak` to bundle `espeak-ng.exe` + `espeak-ng-data/`. A copy under `%ANIKAI_HOME%/desktop-data/runtime-packs/voice.espeak/` overrides the installer bundle.
| `npm run stage-compose-tools` | Whisper ASR for Compose lyrics/instrumental sources |

Voice Weaving engines add their own stage scripts as each adapter ships (mirror Android `stage-*` plans).

---

## Implementation phases

| Phase | Deliverable |
|-------|-------------|
| **0** | This doc; Suno doc cross-links; registries as source of truth |
| **1** (partial) | Voice Weaving tab; preset manifest; Compose `<optgroup>`; `audio:render-voice-preset` (LongCat) |
| **2** | Missing-pack grey state polish; more engine adapters |
| **3** | XTTS + CosyVoice adapters; Kokoro preset import from Android layout |
| **4** | Compose Lyrics **singing articulation** picker; wire S3 runner step when Lane 5 chosen |
| **5** | Kokoro voice maker wizard; Playground graph nodes mirroring Suno DAG |

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-24 | Phase 1 UI: Voice Weaving tab, `voice-preset-store.js`, grouped Compose picker, IPC. |
| 2026-05-24 | Initial Voice Weaving architecture — engine vs preset, Weaving tab, Compose consumer, Suno S1/S3 split, registries, phased plan. |
