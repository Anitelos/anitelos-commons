# Inference attention core (flash-attn)

| Field | Value |
|-------|-------|
| **Scope** | Python transformer stacks (Lance today; future Diffusers specialists) |
| **Parallels** | GGUF `ggml-cuda.dll` + CUDA runtime — optional GPU path with a tested matrix |

## What it is

**flash-attn** is treated as **inference core** for specialist Python runtimes, not an optional pip extra users install at first Generate.

- **Lance** (`lance.runtime.win`, `lance.runtime.wsl`): pack must include torch CUDA + `flash-attn==2.8.3` (pinned in staging).
- **LiTo**: uses Apple **pixi** env in WSL (no flash-attn requirement); same pack discipline (prebuilt in `npm run stage-lito`).

## Maintainer staging

| Pack | Command | WSL prebuild |
|------|---------|----------------|
| Lance | `npm run stage-lance` | `scripts/stage-lance-wsl.cjs` → `wsl-setup-lance.sh` |
| LiTo | `npm run stage-lito` | `scripts/stage-lito-wsl.cjs` → `wsl-setup-lito.sh` |

Skip WSL prebuild on machines without WSL: `ANIKAI_SKIP_WSL_STAGE=1`. CI release builds should set `ANIKAI_STAGE_WSL_REQUIRED=1`.

## Code

- Probe: `anikai-desktop/main-process/inference-attn-core.js`
- Manifest flag: `inferenceCore: "flash-attn"` in `pack.manifest.json`

## End users

No **WSL setup** buttons in Media Magic. Flow: **Runtime pack** (Settings → Media section) + **model pack** (Get pack) → lane unlocks.
