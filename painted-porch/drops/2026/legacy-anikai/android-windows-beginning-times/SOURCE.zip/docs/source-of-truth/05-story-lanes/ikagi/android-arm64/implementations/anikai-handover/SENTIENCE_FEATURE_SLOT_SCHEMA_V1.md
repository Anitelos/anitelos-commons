# Sentience feature slot schema v1

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Not started |
| **Last reviewed** | 2026-05-08 |

Purpose: define a stable assignment schema for Sentience Systems so features bind models by feature-slot contract (not by ad-hoc secondary ids), while staying compatible with shared model pool and Swarm-style routing.

---

## Scope

This file defines:

- Sentience feature and slot identifier format,
- assignment object shape (primary/fallback/disabled),
- readiness and fallback behavior at slot level,
- example payloads for live conversational and surveillance-style features.

This file does **not** define runtime internals, model formats, or UI visuals.

---

## Core principle

Do not add a second model identity system.

Use one model id from the shared capability pool, and bind it through:

`service + feature_id + slot_id -> model_id`

For Sentience:

`sentience.<feature_id>.<slot_path>`

For Swarm (parity target):

`swarm.<pipeline_id>.<step_id>`

---

## Identifier contract

### Service plane

- Sentience plane id: `sentience`

### Feature id

- snake_case, stable, no display text in id.
- examples:
  - `live_face_time`
  - `cctv_watch`
  - `voice_chat`
  - `ambient_awareness`

### Slot id / slot path

- dot-separated capability role path.
- examples:
  - `eyes.face_emotion`
  - `eyes.object_tracker`
  - `ears.asr`
  - `turn.monitor`
  - `emotion.fusion`
  - `touch.context`

### Fully-qualified slot key

`sentience.<feature_id>.<slot_path>`

Example:

`sentience.live_face_time.eyes.face_emotion`

---

## Slot definition schema (conceptual)

Each feature declares required and optional slots:

- `slot_key`: fully-qualified key
- `required`: boolean
- `accepted_capabilities`: list of capability flags from model manifest
- `accepted_runtime_families`: optional runtime whitelist
- `primary_assignment`: model assignment object or null
- `fallback_assignment`: model assignment object or null
- `status`: `UNASSIGNED | ASSIGNED | DEGRADED | DISABLED`
- `last_reason`: optional human-readable failure/degraded reason

### Assignment object

- `model_id`
- `runtime_family`
- `adapter_id`
- `readiness_at_bind` (`SUPPORTED | LOADABLE | VERIFIED`)
- `bound_at_ms`

---

## Suggested JSON shape (v1)

```json
{
  "service": "sentience",
  "feature_id": "live_face_time",
  "enabled": true,
  "slots": [
    {
      "slot_key": "sentience.live_face_time.eyes.face_emotion",
      "required": true,
      "accepted_capabilities": ["face_emotion_detection", "vision_understanding"],
      "primary_assignment": {
        "model_id": "hf:elenaryumina-face-emotion-v2",
        "runtime_family": "onnx",
        "adapter_id": "onnx.vision.face_emotion",
        "readiness_at_bind": "VERIFIED",
        "bound_at_ms": 1762556800000
      },
      "fallback_assignment": {
        "model_id": "mp:face-landmark-lite",
        "runtime_family": "mediapipe",
        "adapter_id": "mediapipe.face.affect_heuristic",
        "readiness_at_bind": "LOADABLE",
        "bound_at_ms": 1762556815000
      },
      "status": "ASSIGNED",
      "last_reason": null
    },
    {
      "slot_key": "sentience.live_face_time.ears.asr",
      "required": true,
      "accepted_capabilities": ["asr_realtime"],
      "primary_assignment": null,
      "fallback_assignment": null,
      "status": "UNASSIGNED",
      "last_reason": "No compatible VERIFIED candidate installed."
    }
  ]
}
```

---

## Readiness and assignment rules

1. Assignment picker should list only capability-compatible candidates.
2. Binding requires at least `SUPPORTED`; prefer `LOADABLE` or `VERIFIED`.
3. A required slot with no primary/fallback keeps feature in degraded state.
4. If primary fails at runtime, role switches to fallback and logs degraded reason.
5. If both primary and fallback fail, slot status becomes `DEGRADED` or `UNASSIGNED`.
6. Disabling a required slot marks feature as `DISABLED` or `PARTIAL`, never silently "healthy."

---

## Feature health aggregation

Per-feature health:

- `OPERATIONAL`: all required slots assigned and runtime-healthy.
- `PARTIAL`: at least one required slot degraded/unassigned but feature still runnable in reduced mode.
- `DEGRADED`: required sensing quality missing for core behavior.
- `DISABLED`: feature toggled off by user or policy.

Sentience section health should aggregate all feature health states.

---

## Logging and handover fields

Every sentience call should include:

- `service_plane`: `sentience`
- `feature_id`
- `slot_key`
- `model_id`
- `runtime_family`
- `adapter_id`
- `execution_state`: `ok | fallback | failed`
- `reason`
- `latency_ms`

This keeps audit parity with Swarm and avoids hidden fallback behavior.

---

## Swarm parity note

This schema intentionally mirrors Swarm step binding shape so both planes can share:

- model pool,
- capability registry,
- readiness states,
- audit pipeline.

Only ownership differs: Swarm owns automation flows; Sentience owns perception/interaction feature slots.

---

## First implementation slice (schema)

Start with two sentience features:

1. `voice_chat`
   - `sentience.voice_chat.ears.asr`
   - `sentience.voice_chat.turn.monitor`

2. `live_face_time`
   - `sentience.live_face_time.eyes.face_emotion`
   - `sentience.live_face_time.ears.asr`
   - `sentience.live_face_time.turn.monitor`

Ship schema support before adding many optional slots.

---

## Linked docs

- `implementations/anikai-handover/SENTIENCE_SYSTEMS_UI_CONTRACT.md`
- `implementations/anikai-handover/ANIKAI_MODEL_HANDOVER_AND_SWAP_ORCHESTRATION_PLAN.md`
- `implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`
- `todo/high-scope/TODO_ENGINE_INFERENCE_CAPABILITY_PLATFORM.md`

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-08 | Created v1 Sentience feature-slot schema with slot keys, assignment shape, and fallback/readiness rules. |
