# TODO — local media / imaging pipeline (mid scope)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |

**Rename freely** as this category splits (e.g. separate todos for GGUF decode vs ONNX post only).

---

## Intent

- Keep **`LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`** as the **single execution registry** (adapters, JNI, honest snapshots).
- Keep **contracts** under `implementations/generation/imaging/` (sprite floor, portrait autogen, pack schema).
- Keep **pipeline stage roles + engines** under `implementations/pipelines/IMAGING_PIPELINE_QUALITY_STACK.md`.
- Keep **ONNX lane ownership and stage plan** under `implementations/engine-inference/model-hub/onnx/ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`.
- Keep **ONNX generation outcome planning** under `implementations/generation/imaging/ONNX_GENERATION_IMPLEMENTATION_PLAN.md`.
- Keep **MediaPipe engine implementation details** under `implementations/engine-inference/model-hub/mediapipe/MEDIAPIPE_ENGINE_INFERENCE_IMPLEMENTATION_PLAN.md`.
- Keep **FLUX generation outcome planning** under `implementations/generation/imaging/FLUX_GENERATION_IMPLEMENTATION_PLAN.md`.
- Use **`OPERATIONS_INDEX.md`** to see all links in one place.

---

## Checklist (working)

- [ ] Split oversized sections out of `LOCAL_MEDIA…` into focused docs; leave the log as index + anti-drift only.
- [ ] ONNX split phase 1: keep only summary in `LOCAL_MEDIA…`; maintain detailed ONNX plan in `ONNX_IMAGE_RUNTIME_AND_PIPELINE_PLAN.md`.
- [ ] Align native diffusion handoff (GGUF JNI) with **S1** in `IMAGING_PIPELINE_QUALITY_STACK.md` once PNG path is canonical.
- [ ] Register at least one **S3** ONNX post graph for QUALITY preset (opset/shape validated).
- [ ] ONNX generation split phase 1: complete ONNX primary/post generation checklist in `TODO_ONNX_GENERATION_IMAGING_PLAN.md`.
- [ ] Portrait path: ensure **S5/S6** handoff matches `PORTRAIT_AUTOGEN_4SHOT_CONTRACT.md` (still → pack → frame animation).
- [ ] MediaPipe split phase 1: define first operational helper task and complete adapter + manifest + lane wiring checklist in `TODO_MEDIAPIPE_ENGINE_INFERENCE_INTEGRATION.md`.
- [ ] FLUX split phase 1: complete Flux 1 baseline + Flux 2 experimental lane planning checklist in `TODO_FLUX_GENERATION_IMAGING_PLAN.md`.

---

## Changelog (this todo)

| Date | Note |
|------|------|
| 2026-05-06 | Created: bridges operations index, pipeline stack, local media split effort. |
| 2026-05-06 | Added ONNX split tracking and explicit ONNX plan doc link. |
| 2026-05-06 | Added MediaPipe split tracking and dedicated engine-inference plan/todo links. |
| 2026-05-06 | Added FLUX generation split tracking and dedicated generation-plan/todo links. |
| 2026-05-06 | Added ONNX generation split tracking and dedicated generation-plan/todo links. |
