# MIDI + soundfont lane — implementation plan (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-20 |

**Read first:** [`AUDIO_GENERATION_LANES_OVERVIEW.md`](./AUDIO_GENERATION_LANES_OVERVIEW.md) (Lane 2 mental model).

**Soundfont staging:** [`anikai-desktop/assets/soundfonts/fluidr3-gm/STAGING.md`](../../../../../../../../anikai-desktop/assets/soundfonts/fluidr3-gm/STAGING.md) — `npm run stage-fluidr3-gm`.

---

## Goal

Turn a **composition plan** (rule-based, companion `<tool>`, or ABC/MIDI JSON) into a **local `.wav`** via:

```
plan → MIDI bytes → FluidSynth (or equivalent) + FluidR3_GM.sf2 → PCM WAV
```

Honest labeling: this is **symbolic rendering**, not neural musicgen.

---

## Staged assets (day one)

| Artifact | Status | Notes |
|----------|--------|-------|
| `FluidR3_GM.sf2` | **Staged** via `stage-fluidr3-gm.cjs` | MIT, ~141 MiB; manifest in `assets/soundfonts/fluidr3-gm/manifest.json` |
| FluidSynth / `fluidsynth.exe` | **Staged** via `stage-fluidsynth.cjs` | v2.5.4 win64 glib → `resources/audio-midi-bin/` |
| `generate_music` chat tool | **Done** (Slice B) | Intake uses `<choices>` chips; tool emits MIDI + render |

---

## Implementation slices

### Slice A — Render smoke test

- [x] Bundle or probe `fluidsynth` CLI on Windows (`-F` wav, `-ni`, soundfont + `.mid` args).
- [x] IPC: `audio:render-midi` with `{ midiPath, soundfontPath?, outWavPath, gain?, sampleRate? }`.
- [x] Default soundfont resolver → `resources/soundfonts/fluidr3-gm/FluidR3_GM.sf2` when present.
- [x] `audio:get-midi-readiness` + `npm run smoke-midi-render` CLI smoke test.
- [x] Main module: `anikai-desktop/main-process/audio-midi-render.js`.

### Slice B — Media Magic + chat tool

- [x] `generate_music` thought-segment tool in chat (`executeGenerateMusicTool`; preview = 8 bars, full = up to 48 bars).
- [x] Write `.mid` + `.wav` under `ANIKAI_HOME/generated-media/audio/midi-symbolic/`.
- [x] Media Magic Music tab: MIDI file list + “Render MIDI to WAV” when Lane 2 is ready.
- [x] IPC: `audio:generate-music`, `media:list-midi-files`; `npm run smoke-generate-music`.

### Slice C — Composition planner

- [x] Companion `planJson` / `composition` JSON → multi-track MIDI (roles, GM programs, optional note list).
- [x] Minimal ABC body (`K:`, `Q:`, note letters + `|` bars) → melody + themed backing.
- [x] Theme keyword → GM instrument pick (jazz / electronic / orchestral / rock / ambient / …) on prompt-only path.
- [x] Multi-channel render: melody, harmony, bass, drums (ch 9) via `midi-gm-instruments.js`.
- [x] GGUF arranger (`gguf-music-arranger.js`): companion chat slot → composition JSON → Lane 2 render (`arranger="gguf"` on `generate_music`).
- [ ] MusicXML subset (later).

### Slice D — Installer

- [ ] `extraResources` entry for `resources/soundfonts/fluidr3-gm/` (like `llama-bin`).
- [ ] `dist:full` runs `stage-fluidr3-gm` before pack (or document manual step).

---

## Open questions

| ID | Question | Notes |
|----|----------|-------|
| Q2 | FluidSynth vs alternative sf2 renderer | Size, LGPL, static link |
| Q3 | Default soundfont path in ANIKAI_HOME vs only in installer resources | Resolver order |
| Q4 | Max MIDI length / polyphony caps for UI honesty | Prevent multi-minute accidental renders |

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-20 | Created plan; FluidR3 GM staging script + manifest. |
| 2026-05-20 | Slice A: FluidSynth staging, `audio:render-midi` IPC, smoke script. |
| 2026-05-20 | Slice B: `generate_music` tool, rule-based `midi-composer`, Media Magic MIDI render UI. |
| 2026-05-20 | Slice C: JSON/ABC composition parser, theme-based GM instruments, multi-channel MIDI. |
