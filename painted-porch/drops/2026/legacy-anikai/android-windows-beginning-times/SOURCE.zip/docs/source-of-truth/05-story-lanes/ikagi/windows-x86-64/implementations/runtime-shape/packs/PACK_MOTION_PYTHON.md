# Motion Python sidecars

| Field | Value |
|-------|-------|
| **Pack id** | `pack.motion.python` |
| **Tier** | active |
| **Doc staging** | Planned |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-22 |

**Purpose:** SadTalker / LivePortrait venvs when promoted; PersonaLive stays separate pack.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md) · **Contract:** [`RUNTIME_PACKS_AND_INSTALLER.md`](../RUNTIME_PACKS_AND_INSTALLER.md)

---

## Vendoring target

Separate venv per family; heavy — download cards not thin installer.

## Staging path

`desktop-data/runtime-packs/motion.python.*`

## Unlocks (no model weights)

sadtalker, liveportrait

## Verification smoke

Import smoke per venv plan.

## Pipeline wiring (when staged)

1. Add probe in `main-process/runtime-pack-probes.js` (or sentience probe).
2. Register row in `assets/about-guide/runtime-packs-registry.json`.
3. Wire IPC from Media Magic / chat tool / pipeline runner step type.
4. Flip About + Software card from **in the works** → **OK** after smoke.

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | Initial pack plan |
