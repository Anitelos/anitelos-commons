# Runtime packs & installer (Windows x86-64)

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planning |
| **Last reviewed** | 2026-05-18 |

**Per-pack plans (tiers A / B / promote-later):** [`RUNTIME_PACKS_CATALOGUE.md`](./RUNTIME_PACKS_CATALOGUE.md) · [`packs/`](./packs/)

**Purpose:** Define how **ANIKAI Desktop** ships as a **bare shell** plus **optional runtime packs** (native binaries, Python venvs, voice data trees) — **not** Hugging Face weights or “model packs” from repos. Settings → **Runtime** becomes the pack **installer / updater / health** surface, aligned with Android’s [`ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../../android-arm64/implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md) and [`MODEL_HUB_INDEX.md`](../engine-inference/model-hub/MODEL_HUB_INDEX.md).

**Code today (interim):** Monolithic staging — `npm run stage-runtimes` → `dist:full` bundles `llama-bin` + `media-python-runtime` via `electron-builder` `extraResources`. See [`../../../../../../anikai-desktop/resources/llama-bin/README.txt`](../../../../../../anikai-desktop/resources/llama-bin/README.txt). This doc is the **target** contract before E+.2+ and before splitting the installer.

### Build strategy (now → endgame)

| Phase | Packaging |
|-------|-----------|
| **Now through endgame** | **Stage and ship everything** in dev/CI (`dist:full`, full `llama-bin`, `media-python`, etc.) so features stay testable without fighting partial installs. |
| **Endgame split** | Peel binaries out of “core ANIKAI” into **extensions**: downloadable **runtime packs** (CDN manifest) and/or **git-linked** build profiles for contributors. App becomes thin; packs become optional cards in Settings → Runtime. |

Until the split lands, treat this doc as the **catalog and rules** for what will become extensions — not a mandate to stop bundling today.

---

## 1. Core idea (your direction — endorsed)

| Layer | What it is | Shipped how |
|-------|------------|-------------|
| **ANIKAI app** | Electron UI, IPC, companion surface, policies, catalogs (JSON in `assets/`) | Installer / store build — **small** |
| **Runtime pack** | Executables + DLLs + fixed data trees (espeak-ng-data, ffmpeg, venv) | User picks packs in **Runtime**; download or side-load |
| **Model pack** | `.gguf`, `.onnx`, LoRAs, Piper voices from HF/etc. | **Never** in runtime packs — **Models** panel + `ANIKAI_HOME/models` only |

**Platform rule (from Android, applies here):** *Model presence is not capability.* A runtime pack must reach **`INSTALLED` → `SUPPORTED` → `LOADABLE` → `VERIFIED`** before UI enables a lane.

**End state:** Desktop mirrors Android’s **model-hub families** — each family gets a **runtime pack** (or pack group) when a Windows adapter exists. GGUF is first; ONNX, MediaPipe, OpenCV DNN, etc. follow as separate packs so the base app stays thin.

---

## 2. Runtime pack vs model pack (hard boundary)

### 2.1 Runtime pack **includes**

- `llama-completion`, `llama-server`, `llama-mtmd-cli`, `ggml-*.dll`, `sd.exe`
- `whisper.cpp` / `whisper-cli` (ASR binary only)
- `ffmpeg`, `ffprobe` (static build)
- `media-python` venv (torch, diffusers, safetensors — **libraries**, not checkpoints)
- `espeak-ng` + **`espeak-ng-data`** tree (phoneme / language data)
- ONNX Runtime DLLs + optional EP providers (CUDA/DirectML) — **runtime**, not `.onnx` weights
- Future: per-hub JNI/FFI bridges as Windows DLLs

### 2.2 Runtime pack **never includes**

- Chat / mmproj / image / music **GGUF weights**
- HF **model repos**, **preset bundles**, or **portrait packs**
- Kokoro / Piper / XTTS **voice model** `.onnx` / `.bin` (those are **model packs** under voice catalog)
- **Optional future `cuda.runtime` pack** — curated `cudart` / redistributable slice ANIKAI tested against a given `gguf.core` build (see §4)
- Full CUDA Toolkit installer (NVIDIA) — still **not** embedded; app **detects** `CUDA_PATH` / Program Files and links user to NVIDIA or “use our pack”
- NVIDIA drivers — OS-level only

### 2.3 Why split matters

- **Legal/size:** Runtime packs are rebuildable from your CI; model packs are user-licensed downloads.
- **Updates:** Hotfix `gguf.core` v1.0.3 without touching a 12 GB Flux GGUF.
- **Honesty:** Companion can say “install **GGUF Core** pack” vs “download **chat model** in Models panel.”

---

## 3. Pack catalog (v1 target)

Packs are **logical products**. Several may **share one on-disk folder** (e.g. all llama.cpp binaries live under `packs/gguf-core/`).

### 3.1 GGUF / llama.cpp family (highest priority)

**CPU vs CUDA builds:** Default pack ships **CPU** (`ggml-cpu.dll`, CPU-only or CPU-primary binaries). **CUDA offload** uses `ggml-cuda.dll` next to the exe **plus** a working `cudart` on the machine (user toolkit, PATH, or future **`cuda.runtime`** pack). See §4.

**Vision / mmproj path in core (tentative):** Gemma 4 **E4B / E2B**-class multimodal chat is a primary target. Plan to include **`llama-mtmd-cli`** (and server multimodal when E+.4 lands) inside **`gguf.core`** so text + mmproj vision work out of the box — **not** a separate download for typical users. **Not final:** if installer size is too large, split back to optional **`gguf.vision`**; manifest health still reports `mtmd` separately.

| Pack id | Display name | Binaries / artifacts | Unlocks (no weights) |
|---------|--------------|----------------------|-------------------------|
| **`gguf.core`** | GGUF Core (text + server + **vision**) | `llama-completion`, `llama-server`, **`llama-mtmd-cli`**, `ggml-cpu.dll` (+ optional `ggml-cuda.dll` in CUDA flavor) | Solo/group chat, **E+**, residency, **mmproj** preflight / attach (Gemma-class multimodal) |
| **`gguf.core.cuda`** | GGUF Core (CUDA flavor) | Same as core with CUDA-built `ggml-cuda.dll` | GPU layers when `cudart` matches tested matrix |
| **`gguf.vision`** | GGUF Vision (optional split) | `llama-mtmd-cli` only | Fallback if core is slimmed; same folder as core when merged |
| **`gguf.imaging`** | GGUF Imaging (native) | `sd.exe` (stable-diffusion.cpp) | Media Magic `.gguf` image generation; step previews use `--preview proj` ([`SD_CPP_PROJ_STEP_PREVIEW.md`](./SD_CPP_PROJ_STEP_PREVIEW.md)) — no extra weights |
| **`gguf.asr`** | GGUF / Whisper ASR | `whisper-cli` or `whisper.cpp` main + ggml dlls | Audio library transcription; video dialogue extract |
| **`gguf.media-tools`** | Media tools | `ffmpeg`, `ffprobe` | Video poster frames, duration, future audio strip for ASR |

**Merge rule (endgame):** **`gguf.core`** (with vision) + **`gguf.media-tools`** as default extension set; **`gguf.imaging`** + dependent Python as Creator bundle. Sub-pack ids remain for health (“mtmd missing”, “ffmpeg missing”).

**`gguf.media-suite` bundle:** `gguf.core` + `gguf.media-tools` + `gguf.asr` (+ optional `gguf.imaging`) — one installer card, atomic ids underneath.

**Coding / general tasks:** No separate binary pack — **model roles** + prompt policy. Optional future **`gguf.embed`** if you add an embedding CLI.

### 3.2 Python sidecar (shared dependency)

| Pack id | Display name | Contents | Unlocks |
|---------|--------------|----------|---------|
| **`python.media`** | Media Python (Diffusers) | `media-python-runtime/venv` | FHDR / Diffusers presets, sharded T5 merge |

**Bundling rule:** Any pack that needs Diffusers declares `"requires": ["python.media"]` in its manifest. The **ZIP for `gguf.imaging` diffusers path** (or a **Creator bundle**) may **embed** a copy of `python.media` for offline install, but on disk there is **one** canonical venv path: `%ANIKAI_HOME%/desktop-data/runtime-packs/python.media/`.

**Media runtime folder target** (python + wsl subtrees, separate pip envs per specialist): [`MEDIA_RUNTIME_LAYOUT.md`](./MEDIA_RUNTIME_LAYOUT.md).

**Dedup on install (save bandwidth):**

1. Before download, compare remote **`contentHash`** / version to installed `python.media/pack.manifest.json`.
2. If **hash matches** → skip download; mark dependent pack as satisfied.
3. If **version newer** → prompt: **Update shared Python** vs **Skip** (dependent pack may fail verify).
4. If **corrupt** → offer **Repair** (re-verify venv `import torch`) or **Overwrite** full venv.
5. Optional: scan common paths (previous profile install, old `resources/media-python-runtime`) and offer **Import existing venv** instead of re-downloading.

Same pattern applies to any future shared pack (e.g. **`engine.onnx`** shared by multiple ONNX lanes).

### 3.3 Voice (generation lane — not GGUF)

| Pack id | Display name | Contents | Notes |
|---------|--------------|----------|--------|
| **`voice.espeak`** | eSpeak-NG (fallback TTS) | `espeak-ng` exe/lib + **full `espeak-ng-data`** | **Reuse Android’s known-good data tree** ([`ExpressiveVoiceInstaller.kt`](../../../../../../Anikai App/src/main/java/com/anikai/soul/voice/catalog/ExpressiveVoiceInstaller.kt) reference). Small, always local. |
| **`voice.onnx`** | ONNX voice runtimes | ORT + provider DLLs | Host for Kokoro / Cosy / etc. — **weights still model packs** |
| **`voice.piper`** | Piper runtime (future) | `piper` exe + optional deps | Optional pack; may **override** espeak data path (see §6) |

**Semi-duplex voice (live roadmap):** Needs **`gguf.core`** (server) + **`gguf.asr`** + **`voice.*`** — staged as separate packs, composed at runtime by orchestrator.

### 3.4 Engine-hub packs (PC parity with Android tree)

When a Windows adapter lands, add a **runtime pack** row — **not** bundled in the thin app.

| Model-hub family | Planned runtime pack id | Typical contents |
|------------------|---------------------------|------------------|
| **onnx** | `pack.onnx` | ONNX Runtime DLLs (neural TTS + shared EP) |
| **onnx imaging** | `pack.onnx.imaging` | `onnxruntime-node` + desktop imaging runner (depth, DWPose, upscale, inpaint, rembg) |
| **personalive** | `pack.personalive` | Python venv + PersonaLive engine under `resources/personalive-runtime/` |
| **motion python** | `pack.motion.python` | SadTalker / LivePortrait sidecars (planned) |
| **rig (app)** | `pack.rig.anikai` | Phoneme rig + PoseIntent — no vendor ZIP |
| **opencv_dnn** | `engine.opencv` | OpenCV + dnn module build |
| **mediapipe** | `engine.mediapipe` | Tasks C API / prebuilt graphs |
| **ncnn** | `engine.ncnn` | ncnn + vulkan optional |
| **executorch** | `engine.executorch` | Edge runner (if desktop story exists) |
| **mnn**, **tengine**, **apache_tvm**, … | `engine.<id>` | Per plan doc when promoted |
| **litert**, **qnn**, **neuropilot**, … | *N/A on Windows* | Android-only stubs stay Android-only |

Index: [`../engine-inference/model-hub/MODEL_HUB_INDEX.md`](../engine-inference/model-hub/MODEL_HUB_INDEX.md).

---

## 4. CPU default, CUDA opt-in, and Device-tab honesty

### 4.1 What we package

| Variant | Shipped in | Notes |
|---------|------------|--------|
| **`gguf.core` (CPU)** | Default extension / endgame thin installer | Always available; no `cudart` required. |
| **`gguf.core.cuda`** | Optional checkbox at install **or** Runtime download | Same binaries + **CUDA-built** `ggml-cuda.dll`; still needs `cudart` at runtime. |
| **`cuda.runtime`** *(future)* | Optional pack | ANIKAI-tested `cudart` redistributable slice paired to a manifest `testedCudaMajor` — alternative to “find toolkit yourself.” |

We do **not** ship the full NVIDIA CUDA Toolkit inside the app installer.

### 4.2 Installer / first-run CUDA choices

NSIS (or first-run wizard) options:

- [ ] **Use GPU for GGUF** (enables CUDA offload in settings when hardware + runtime ready)
- [ ] **Use ANIKAI CUDA runtime pack** *(when available)* — install tested `cudart` beside packs
- [ ] **Use CUDA Toolkit already on this PC** — browse / auto-detect `CUDA_PATH`, `Program Files\NVIDIA GPU Computing Toolkit\CUDA\v*\\bin`
- Link: **Download CUDA Toolkit** (NVIDIA) and **NVIDIA drivers** (existing Device tab buttons)

**Duplicate avoidance:** Before copying DLLs or suggesting toolkit install, scan:

- Installed **`gguf.core`** / profile `llama-runtime` (same version → skip re-copy)
- **`cudart64_*.dll`** already on PATH or next to staged `ggml-cuda.dll`
- Existing **`runtime-packs/`** tree

Offer **“Already present — skip”** or **“Verify integrity only”** instead of blind overwrite.

### 4.3 Device tab cautions (Settings → Device)

Extend compatibility strip beyond “cudart readable”:

| Signal | UX |
|--------|-----|
| **GPU detected, CPU-only pack** | Hint: install **GGUF Core (CUDA)** or enable CPU-only. |
| **`cudart` found but version ≠ pack `testedCudaMajor`** | **Caution:** “This CUDA runtime was not used to build your ANIKAI engine. GPU offload may fail or be unstable. Update NVIDIA drivers and CUDA Toolkit, or install the **ANIKAI CUDA runtime pack** when available.” |
| **CUDA pack + toolkit both present, versions clash** | Recommend one source (prefer ANIKAI pack **or** user toolkit, not both mixed on PATH). |
| **Driver very old** | Link to driver download; do not claim GPU support. |

Record in telemetry/logs: `cudaSource: anikai-pack | toolkit-path | none`, `cudartVersion`, `ggufPackBuildId` — for support, not silent failure.

---

## 5. Delivery tiers (endgame target)

| Tier | Who | Contents |
|------|-----|----------|
| **T0 — Bare** | Power users | App shell only; all packs via Runtime / git-linked dev staging |
| **T1 — Recommended** | Default retail | `gguf.core` (**incl. mtmd**) CPU + `gguf.media-tools` |
| **T2 — Creator** | Optional flavor | T1 + `gguf.imaging` + `python.media` (deduped shared venv) |
| **T3 — On-demand** | Runtime cards | `gguf.core.cuda`, `gguf.asr`, `voice.*`, `engine.*`, future `cuda.runtime` |

**Now:** `dist:full` = **full endgame staging** (everything bundled for development). **Later:** same bits, repackaged as T0–T3 extensions without rewriting inference code.

**Extension delivery channels:**

| Channel | Use |
|---------|-----|
| **CDN ZIP + manifest** | End-user pack install / update (`anikai.runtimePacksManifestUrl`) |
| **Git / monorepo staging** | Contributors: `npm run stage-runtimes`, vendor builds, CI artifacts |
| **Optional git submodule / LFS** | Large binaries for forks that cannot use CDN (documented separately) |

---

## 6. eSpeak strategy

| Topic | Decision |
|-------|----------|
| **Source of truth** | Same **`espeak-ng-data`** revision as Anikai Android (document hash in pack manifest). |
| **Pack layout** | `packs/voice.espeak/espeak-ng.exe` + `packs/voice.espeak/espeak-ng-data/` |
| **Override** | Settings → Runtime → **Advanced:** `espeakDataDir` optional path for Piper/Kokoro mods that ship alternate phoneme assets. |
| **Piper / Kokoro** | Separate **`voice.piper`** / model packs; they call ORT + optional espeak front-end — do not fork espeak pack per voice vendor unless manifest declares `requires: voice.espeak`. |

---

## 7. Settings → Runtime UX (pack installer)

### 7.1 Pack card (each row)

- **Name / blurb** / disk size  
- **State:** Not installed · Downloading · Installed · Update available · Corrupt  
- **Actions:** Install · Update · Uninstall · Open folder · Verify  
- **Health:** sub-checks (e.g. `llama-server` present, `ggml-cuda.dll`, ffmpeg on PATH override)

### 7.2 Downloader behavior

- Manifest URL: `package.json` → `anikai.runtimePacksManifestUrl` (parallel to existing `llamaRuntimeUpdateManifestUrl`).  
- **ZIP** per pack → verify SHA256 → extract under `%ANIKAI_HOME%/desktop-data/runtime-packs/<packId>/`.  
- **Dependencies:** e.g. `gguf.imaging` + Diffusers path may require `python.media` — install shared dep first or skip download if hash matches (§3.2).  
- **Integrity-first:** If installed pack version matches manifest and `verify` passes → **no re-download**; optional “Force reinstall”.  
- **Overwrite policy:** User chooses **Repair** (re-verify) vs **Replace** (delete folder + extract) when versions differ.  
- **No models** in ZIP; post-install copy is only binaries + espeak data + venv.

### 7.3a Check / Repair surface (v1 — Settings → General)

**Today (monolithic staging — already shipping):** Settings → General exposes a single pair of buttons:

| Button | What it does |
|--------|--------------|
| **Check runtimes** | Probes a fixed list of logical slots: `gguf.core` (llama-completion + ggml DLLs), `gguf.imaging` (sd.exe alongside llama-bin), `python.media` (bundled Diffusers venv at `resources/media-python-runtime/venv/`), and the **CUDA bin path** (settings, not a pack). Per slot reports `ok`, `severity` (`required` / `optional`), `repairable`, plain detail, and hints. |
| **Repair** | Iterates only the **non-ok + repairable** items from the last Check (runs Check first if none stored). Per item, calls the existing repair primitive: copy bundled / vendor engine into the profile (`gguf.core`, `gguf.imaging`), auto-fill CUDA bin from `CUDA_PATH` / Program Files (`cuda.runtime`). Does **not** auto-stage `python.media` — that ships in the installer; dev-from-source surfaces a hint to run `npm run stage-media-python`. |

**Why this shape:** users should never need to think about Python venvs, sd.exe, or DLLs. Check answers “is everything where it should be?” and Repair answers “fix what is fixable from inside the app.” The Uninstall affordance moves under **Advanced** in the same panel.

**Endgame (pack-aware — this section is the contract):** when `runtime-packs/<packId>/` directories and per-pack `pack.manifest.json` (§8) exist, the same two buttons must:

1. Read **`runtime-packs/manifest.json`** (the installer index) → enumerate **only the packs the user has installed** (`gguf.core`, `gguf.media-tools`, `voice.espeak`, etc.).
2. For each installed pack, run its **`verify.commands`** (§8) → produce one report row per pack (replacing the static four-slot list above).
3. **Never** report rows for packs the user did not install (so the surface scales: Tier T1 users do not see `gguf.imaging` red just because they did not opt in).
4. Repair invokes the pack’s own `verify` → `install` / `update` paths from §7.2 (re-download from CDN, re-extract, integrity-check) instead of the monolithic copy primitive.

**Migration order (no UI rewrite needed):**

| Phase | Check loop input |
|-------|------------------|
| P0 (today, shipping) | Hardcoded list: `gguf.core`, `gguf.imaging`, `python.media`, `cuda.runtime` |
| P1 | Same list, but each entry first asks `runtime-packs/<packId>/pack.manifest.json` if present, falls back to today’s probe if not — coexistence period |
| P2+ | Pure pack-manifest enumeration; legacy probes deleted |

This way the **buttons, IPC names (`runtimes:check`, `runtimes:repair`), and report shape** stay stable across phases — only the source-of-truth for "what to scan" changes.

### 7.3 Resolution order (runtime lookup)

Extend today’s [`runtime-manifest.json`](../../../../../../anikai-desktop/runtime-manifest.json):

```json
{
  "schemaVersion": 3,
  "packs": [
    { "id": "gguf.core", "installDir": "runtime-packs/gguf-core", "provides": ["llama-completion", "llama-server"] },
    { "id": "gguf.vision", "installDir": "runtime-packs/gguf-core", "provides": ["llama-mtmd-cli"], "mergedInto": "gguf.core" }
  ],
  "resolutionOrder": ["gguf.core", "bundled-llama-bin", "legacy-llama-runtime"]
}
```

App code resolves executables by **scanning installed packs** in order, then bundled `resources`, then profile `llama-runtime/`.

---

## 8. Runtime pack manifest (sketch)

Each pack ships `pack.manifest.json`:

```json
{
  "packId": "gguf.core",
  "version": "2026.05.18",
  "platform": "win-x64",
  "buildFlavor": "cpu",
  "testedCudaMajor": null,
  "contentHash": "sha256:…",
  "license": "MIT",
  "provides": {
    "executables": ["llama-completion.exe", "llama-server.exe", "llama-mtmd-cli.exe"],
    "libraries": ["ggml-cpu.dll"]
  },
  "requires": [],
  "capabilities": ["text_generation", "chat", "vision_understanding"],
  "verify": {
    "commands": [
      { "exe": "llama-completion.exe", "args": ["--version"], "exitMax": 0 }
    ]
  },
  "espeakDataHash": null
}
```

**Model packs** (future, separate system) use a different schema (`modelId`, `files[]`, `mmproj`, HF revision) — do not merge into this file.

---

## 9. Staging & CI (build machine)

All commands run from **`anikai-desktop/`** unless noted. They populate `resources/` (or `desktop-data/runtime-packs/`) for dev runs and **`electron-builder` `extraResources`** for installers.

### 9.1 npm `stage-*` scripts (authoritative list)

| npm script | What it stages | Typical output / pack |
|------------|----------------|------------------------|
| **`stage-llama-runtime`** | `llama-completion.exe`, `llama-server`, mtmd DLLs, imaging CLI helpers | `resources/llama-bin/` → **`gguf.core`**, **`gguf.imaging`** |
| **`stage-media-python`** | Python venv: torch, diffusers, transformers, scipy, soundfile (see `media-python/requirements.txt`) | `resources/media-python-runtime/venv/` → **`python.media`** |
| **`stage-media-tools`** | ffmpeg + ffprobe binaries | `resources/media-tools-bin/` or `desktop-data/runtime-packs/media.tools/` → **`gguf.media-tools`** |
| **`stage-personalive`** | PersonaLive engine + Python venv | `resources/personalive-runtime/` |
| **`stage-fluidsynth`** | FluidSynth executable | `resources/audio-midi-bin/` |
| **`stage-fluidr3-gm`** | FluidR3 General MIDI soundfont (~141 MB) | `resources/soundfonts/fluidr3-gm/` |
| **`stage-audio-midi`** | Shorthand: `stage-fluidsynth` + `stage-fluidr3-gm` | Lane 2 MIDI render |
| **`stage-longcat-voice`** | LongCat extras: upgrades diffusers, installs **`audiodit`** from [LongCat-AudioDiT](https://github.com/meituan-longcat/LongCat-AudioDiT), librosa; writes `stage-longcat-voice.json` on success | Voice **clone** in Media Python (TTS uses Diffusers pipeline) |
| **`stage-compose-tools`** | Whisper (`openai-whisper`) for Compose **From audio** transcribe | `media-python/requirements-compose.txt` |

### 9.2 Bundle shortcuts

| npm script | Includes |
|------------|----------|
| **`stage-runtimes`** | `stage-llama-runtime` + `stage-media-python` + `stage-personalive` + `stage-media-tools` |
| **`dist:full`** | `stage-runtimes` then Windows installer build |

**Recommended for full local music desk (dev):**

```bash
cd anikai-desktop
npm run stage-runtimes
npm run stage-audio-midi
npm run stage-longcat-voice
npm run stage-compose-tools
```

LongCat and Compose tools are **not** in `stage-runtimes` yet — run them when testing **Audio → Compose** voice + **From audio** lyrics.

### 9.3 Planned / doc-only stages

| Script | Target pack |
|--------|-------------|
| `stage-voice-espeak` | `voice.espeak` — espeak-ng.msi 1.52.0 + `third_party/espeak-ng/espeak-ng-data` |
| `stage-whisper` *(planned)* | `gguf.asr` (whisper.cpp CLI + ggml DLLs) |

Release pipeline builds **pack ZIPs** + **app installer**; manifest hosted on CDN.

---

## 10. Mapping to product lanes

| Product lane | Runtime packs (min) | Model packs (user) |
|--------------|---------------------|---------------------|
| Companion chat | `gguf.core` | Chat GGUF |
| Group / E+ | `gguf.core` | Per-companion chat GGUFs |
| Vision / media library | `gguf.core` (mtmd), `gguf.media-tools` | **mmproj** + chat (e.g. Gemma 4 E4B/E2B) |
| Media Magic image | `gguf.imaging` or `python.media` | Image GGUF / Diffusers weights |
| Media Magic dual-ref | `gguf.imaging` (Kontext) or `python.media` | Kontext GGUF/snapshot; optional IP-Adapter weights (model pack) for Flux style blend |
| Sprite sheet maker | Same as Media Magic + `pack.onnx.imaging` (post) | NESW stills, mask inpaint, UltraSharp x4 |
| ASR / “hearing” | `gguf.asr`, `gguf.media-tools` | Whisper GGUF |
| Live voice | `gguf.core`, `gguf.asr`, `voice.espeak` or `voice.onnx` | Voice model packs |
| ONNX portrait / post | `engine.onnx` | ONNX models |
| Solo multi-chat / group E+ | `gguf.core` (+ `.cuda` if GPU) | Multiple chat GGUFs; see group plan §7 |
| **Remote compute node** *(future)* | `compute.node-agent` *(planned)* | Thin agent + `llama-server` on LAN; desktop orchestrator forwards HTTP — [`../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md`](../companion-surface/WORKFORCE_AND_ORCHESTRATION_VISION.md) §12 |

**Compute federation:** runtime packs ship **binaries** on each machine; **model weights** stay on the Models panel per host. The desktop app does not bundle remote GPUs — it registers **node URLs** and routes jobs. Optional future pack: **`compute.node-agent`** (health, auth token, model path registry) separate from `gguf.core`.

---

## 11. Relationship to Android

| Android concept | Windows pack equivalent |
|-----------------|-------------------------|
| `LocalVoiceRuntimeInstaller` | `voice.*` pack ZIP + verify |
| Model-hub family adapter | `engine.<family>` pack |
| GGUF JNI / native bridge | `gguf.*` packs |
| HF model download UI | **Unchanged** — Models panel |
| Capability probe | Per-pack `verify` + `inference:get-status` extensions |

Parent: [`../../../android-arm64/implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../../android-arm64/implementations/engine-inference/ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md).

---

## 12. Implementation phasing (suggested)

| Phase | Scope |
|-------|--------|
| **P0** (now) | This doc + full `dist:full` staging; Device tab CUDA cautions (§4.3); `version.json` capability flags |
| **P1** | `runtime-packs/<id>/` on disk; pack-aware resolver; **integrity skip** for `python.media` |
| **P2** | CDN manifest + Runtime installer; NSIS CUDA checkbox; duplicate-file detection |
| **P3** | `gguf.media-tools`, `voice.espeak`, `gguf.asr`; optional **`cuda.runtime`** pack |
| **P4** | **Endgame split:** thin app + extensions; per-hub `engine.*` packs |
| **P5** | Re-evaluate **`gguf.vision`** split if core+mtmd installer too large |

**E+.2** should target **pack-aware** server lifecycle (`gguf.core` install dir), not a new monolith folder.

---

## 13. Author notes (design feedback)

**What works well in your plan**

- **Bare app + optional inference** matches Android’s capability platform and avoids 5 GB installers for chat-only users.
- **GGUF split** (core / vision / imaging / asr / media-tools) matches how binaries are actually built — one CMake tree, many targets.
- **Excluding all repo models** keeps licensing and update cadence sane.
- **eSpeak from Android** avoids data drift; optional override is the right escape hatch for Piper/Kokoro mods.

**Cautions**

1. **Too many tiny packs** frustrate users — offer **bundles** (GGUF Desktop, Media Suite, Voice Starter) atop atomic ids.  
2. **`python.media` is huge** — keep it T2/T3, not T1, unless you accept installer size.  
3. **CUDA** — CPU default; **`gguf.core.cuda`** + installer checkbox + Device cautions for untested toolkit versions; future **`cuda.runtime`** pack.  
4. **Don’t conflate “coding pack” with runtime** — coding is a **model + policy**; only add a runtime pack if you ship a separate binary (e.g. embed CLI).  
5. **Engine-hub packs** (ONNX, MediaPipe, …) should wait until a Windows **adapter** exists; stubs in `model-hub/` are docs-only until then.

**Single rule for the team:** If it runs without a `.gguf` / `.onnx` **weight file**, it’s a **runtime pack**. If it’s downloaded from HF and assigned in Models, it’s a **model pack**.

---

## 14. Related docs

| Doc | Topic |
|-----|--------|
| [`OPERATIONS_INDEX.md`](OPERATIONS_INDEX.md) | Ops checklist |
| [`../engine-inference/model-hub/MODEL_HUB_INDEX.md`](../engine-inference/model-hub/MODEL_HUB_INDEX.md) | Engine families |
| [`../companion-surface/COMPANION_MEDIA_LIBRARY.md`](../companion-surface/COMPANION_MEDIA_LIBRARY.md) | ffmpeg / ASR / mtmd requirements |
| [`../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md`](../companion-surface/group-chat-mate-network/GROUP_CHAT_MATE_NETWORK_IMPLEMENTATION_PLAN.md) | Phase E+ |
| [`../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md`](../companion-surface/LIVE_CONVERSATION_ENGINE_AND_ROADMAP.md) | Voice after E+ |
| [`../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md`](../companion-surface/DESKTOP_COPILOT_AND_SCREEN_AGENT.md) | Screen copilot J1–J4; GUI VLM / control packs |
| [`../../../../../../anikai-desktop/resources/llama-bin/README.txt`](../../../../../../anikai-desktop/resources/llama-bin/README.txt) | Today’s staging |

---

## 11. Backup, restore, and integrity (planned)

**Not shipped yet** — captured here so runtime, pipeline, and companion work share one contract.

| Capability | Intent |
|------------|--------|
| **Workshop backup** | Snapshot `ANIKAI_HOME` (models registry pointers, pipeline schemas, generated media index, companion state, UI defaults) + installed **runtime pack** versions. User can **refresh** a broken install or move machines without hand-copying folders. |
| **Restore tiers** | *Soft* — re-run Check runtimes / repair manifests; *Hard* — replace stock app files from signed pack; *User creations* — optional include/exclude for `runtime/` outputs and mods. |
| **ANIKAI Modders scan** (separate app, later) | External verifier: walk install + home trees; compare **size, count, name, and deep content fingerprint** (stronger than a single SHA-256 file pass where needed); report **missing / changed / unexpected** files; offer **repair** (restore stock, remove bad mods) and **backup modded / user-created** files before repair. |

**Related:** [`../pipelines/IMAGING_PIPELINE_RECORD_PLAYGROUND.md`](../pipelines/IMAGING_PIPELINE_RECORD_PLAYGROUND.md) (bake save + pipeline outputs live under `runtime/`).

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-17 | Initial runtime packs plan: bare app, GGUF/voice/engine pack catalog, espeak strategy, manifest sketch, phasing. |
| 2026-05-18 | Endgame staging strategy; `python.media` dedup; CPU default + CUDA opt-in + Device cautions; mtmd in `gguf.core` (tentative); extension channels. |
| 2026-05-18 | §10: solo multi-chat / E+ residency mapping; future `compute.node-agent` + link to workforce compute federation. |
| 2026-05-18 | Related doc: desktop copilot; planned `gguf.gui-vlm` / `agent.control-continuous` pack slots. |
| 2026-05-22 | Media Magic dual-reference: Kontext multi-ref (`gguf.imaging` / `python.media`) and IP-Adapter style conditioning (Diffusers + model pack); sprite sheet lane mapping. |
| 2026-05-22 | §11 backup/restore + Modders-scan direction (planned). |

### 3.5 Media Magic dual-reference (desktop)

| Path | Runtime pack | Model pack | Behavior |
|------|--------------|------------|----------|
| **Kontext GGUF** | `gguf.imaging` (`sd.exe`) | `flux1-kontext-dev-*.gguf` + sidecars | Two `-r` refs + `--increase-ref-index` when source and style are set |
| **Kontext Diffusers** | `python.media` | `FLUX.1-Kontext-dev` snapshot under `models/kontext/` | `multiple_images=[(source, style)]` when `dualRefMode=kontext_multi` |
| **Kontext inpaint + style** | `python.media` | Kontext Inpaint preset | `image` + `mask_image` + optional `image_reference` (style) |
| **IP-Adapter style** | `python.media` | Flux base + **IP-Adapter weights** (user-assigned path) | `ip_adapter_image` + scale from style strength slider |

Planner: `anikai-desktop/main-process/media-dual-ref.js`. UI passes `sourceImagePath`, `styleImagePath`, and strength sliders from Media Magic reference column.

**Not in runtime packs:** IP-Adapter / Kontext **weights** remain model packs only. Upgrading `python.media` may be required for `multiple_images` on older Diffusers builds.
