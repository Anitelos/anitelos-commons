# Model sheet — city96 / FLUX.2-dev-gguf

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Planned |
| **Last reviewed** | 2026-05-18 |

## HF

- Repo: [city96/FLUX.2-dev-gguf](https://huggingface.co/city96/FLUX.2-dev-gguf)  
- DiT / full safetensors upstream: [black-forest-labs/FLUX.2-dev](https://huggingface.co/black-forest-labs/FLUX.2-dev) (gated bundle)  
- **VAE weights (ungated mirror):** [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae) → `diffusion_pytorch_model.safetensors` as `vae/flux2_ae.safetensors`  
- sd.cpp: [`flux2.md`](../../../../../../../vendor/stable-diffusion.cpp/docs/flux2.md) § Flux.2-dev  

## Pack family

`flux2_llm_vae` — **Mistral-Small-3.2-24B** LLM (heavy).

## Weight layout

```text
models/flux2-dev/
  flux2-dev-Q4_K_S.gguf
  vae/flux2_ae.safetensors
  text_encoders/Mistral-Small-3.2-24B-Instruct-….gguf
```

## Product

- **Preset id:** `flux2_dev_gguf_city96`  
- **Profile (proposal):** `flux2_dev_gguf` — 1024², cfg 1, euler; VRAM warning in UI  

## Notes

Img2img / edit via `-r` in upstream. Optional small decoder VAE documented in `flux2.md`.

## Anikai router

`planned` — flux2 pack with 24B LLM candidate paths.

## Checklist

- [ ] Readiness warns VRAM / RAM  
- [ ] E2E on high-end GPU only  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-18 | Initial sheet. |
