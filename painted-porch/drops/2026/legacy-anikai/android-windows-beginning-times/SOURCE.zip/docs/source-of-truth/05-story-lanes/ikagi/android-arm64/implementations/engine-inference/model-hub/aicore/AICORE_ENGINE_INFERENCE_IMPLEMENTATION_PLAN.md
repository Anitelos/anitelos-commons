# Android AICore / Gemini Nano engine inference implementation plan

| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Stub only |
| **Last reviewed** | 2026-05-09 |

Purpose: define how ANIKAI could integrate **Google Android AICore** (system-level on-device inference service, including paths toward **Gemini Nano**-class models on supported Android versions). This is an OS integration lane, not a bundled `.onnx`/`.gguf` pack in the traditional sense.

---

## Scope

This file covers AICore for:

- system-mediated model availability and update channels,
- capability probes (`FEATURE_AI_*`, service availability, OS version),
- policy alignment with User Access (what the user allows cloud vs on-device),
- future Sentience/Swarm triggers that consume system-provided inference.

This file does **not** replace LiteRT/ONNX/GGUF local packs; it complements them where the OS exposes a managed stack.

---

## Role model (single truth)

| AICore lane | Ownership |
|-------------|-----------|
| Always-on OS-managed helper | Candidate for lightweight tasks when allowed by policy. |
| Replacement for local GGUF brain | No default assumption. |
| Privacy-sensitive Sentience | Requires explicit user consent + capability disclosure. |

---

## Android implementation plan (stub checklist)

- [ ] Map AICore / GenAI Feature APIs relevant to target `minSdk` / OEM availability.
- [ ] Define probe: service present, model downloadable, thermal/state constraints.
- [ ] Adapter id `aicore` with strict gating in registry.
- [ ] Handover packet fields for “system inference” provenance.
- [ ] Degraded UX when feature absent on device or disabled by policy.

---

## Open decisions

- minimum Android version and Pixel vs broad OEM behavior,
- coexistence with cloud routing and local-only strict mode,
- which tasks are allowed to call AICore vs always-local engines.

---

## Linked docs

- [`../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md`](../../ENGINE_INFERENCE_CAPABILITY_PLATFORM_PLAN.md)
- User Access / policy docs (when consolidated).

---

## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-09 | Initial stub plan for Android AICore / system on-device inference lane. |
