# Document status block (convention)

**Use:** paste the table **immediately under the document’s `# Title`**, before the first narrative section. One block per file so staging stays visible in Git and in editors.

**Fields**

| Field | Meaning |
|-------|--------|
| **Doc staging** | Where the *writing/design* is: `Not started` · `Started` · `Complete` (Complete = story frozen enough to build from; code can still lag). |
| **Operations** | Where *execution* is: `Not started` · `Started` · `Complete` **or** `Needs work` when the doc is sound but the product still misses the bar. |
| **Last reviewed** | Date of last meaningful pass (not trivial typo-only edits). |

**Copy-paste template**

```markdown
| Field | Value |
|-------|-------|
| **Doc staging** | Started |
| **Operations** | Needs work |
| **Last reviewed** | 2026-05-06 |
```

**Changelog (per doc)** — add a small table at the bottom of each contract (or after the status block for tiny docs):

```markdown
## Changelog (this document)

| Date | Note |
|------|------|
| 2026-05-06 | … |
```

Promote the same date into any **global** log (for example `LOCAL_MEDIA_AND_VISION_RUNTIME_LOG.md`) only when the **contract** change is execution-relevant.

**Automation:** After batches of edits, regenerate [`DOC_PROGRESS_SNAPSHOT.md`](./DOC_PROGRESS_SNAPSHOT.md) from repo root:  
`powershell -NoProfile -ExecutionPolicy Bypass -File docs/source-of-truth/05-story-lanes/ikagi/android-arm64/scripts/Generate-DocProgressReport.ps1`  
That roll-up reads **Doc staging** / **Operations** from each file’s status table and counts open vs done markdown checkboxes (excluding fenced code blocks). It also emits an **open-checkbox drill-down** (verbatim line text per file); pass `-NoDrilldown` to the script for a shorter snapshot.
