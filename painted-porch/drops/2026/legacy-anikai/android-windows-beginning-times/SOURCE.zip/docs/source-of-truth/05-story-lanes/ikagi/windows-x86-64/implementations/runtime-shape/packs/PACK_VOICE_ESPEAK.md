# Voice.espeak runtime pack (eSpeak-NG + data)

| Field | Value |
|-------|-------|
| **Pack id** | `pack.voice.espeak` |
| **Parent** | [`pack.voice`](./PACK_VOICE_RUNTIME.md) |
| **Tier** | active |
| **Doc staging** | Started |
| **Operations** | In progress |
| **Last reviewed** | 2026-05-22 |

**Purpose:** Ship **espeak-ng.exe** and the full **espeak-ng-data** tree so Piper, XTTS, and other native G2P paths work offline. Kokoro uses its own phoneme loader via pip but can honor `ESPEAK_DATA_PATH` when this pack is staged.

**Parent index:** [`RUNTIME_PACKS_CATALOGUE.md`](../RUNTIME_PACKS_CATALOGUE.md)

---

## Layout

```
runtime-packs/voice.espeak/          (user sideload — wins over bundle)
  espeak-ng.exe
  *.dll
  espeak-ng-data/
    lang/
    voices/
    ...

resources/voice-espeak-bin/         (installer extraResources → voice-espeak-bin/)
```

Data source when staging: `third_party/espeak-ng/espeak-ng-data` (same revision as Android assets).

Windows exe source: [espeak-ng 1.52.0 MSI](https://github.com/espeak-ng/espeak-ng/releases/tag/1.52.0).

---

## Stage & verify

```bash
cd anikai-desktop
npm run stage-voice-espeak
npm run smoke-voice-espeak
```

Settings → Device → Software → **Check runtimes** — `voice.espeak` should report OK.

---

## Override rule

If `%ANIKAI_HOME%/desktop-data/runtime-packs/voice.espeak/` exists, probes and `voice-espeak.js` resolve it **before** the bundled `resources/voice-espeak-bin/` copy.

Optional env when staging elsewhere:

- `ANIKAI_ESPEAK_STAGE_DIR` — folder with `espeak-ng.exe` + DLLs  
- `ANIKAI_ESPEAK_DATA_DIR` — alternate `espeak-ng-data` tree  
- `ANIKAI_ESPEAK_MSI_URL` — alternate MSI download URL  

---

## Changelog

| Date | Note |
|------|------|
| 2026-05-22 | `npm run stage-voice-espeak` — MSI + third_party data; mirror to runtime-packs |
