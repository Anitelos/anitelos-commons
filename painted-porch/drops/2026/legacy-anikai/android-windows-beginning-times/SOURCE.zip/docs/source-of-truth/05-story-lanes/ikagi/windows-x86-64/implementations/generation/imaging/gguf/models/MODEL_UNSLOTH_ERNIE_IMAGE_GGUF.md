# Model sheet — unsloth / ERNIE-Image-GGUF

| Field | Value |
|-------|-------|
| **Pack family** | `flux2_llm_vae` |
| **HF DiT** | [unsloth/ERNIE-Image-GGUF](https://huggingface.co/unsloth/ERNIE-Image-GGUF) |
| **LLM (sd.exe)** | [Comfy-Org/ERNIE-Image `text_encoders/ministral-3-3b.safetensors`](https://huggingface.co/Comfy-Org/ERNIE-Image/tree/main/text_encoders) |
| **VAE** | [kaiyuyue/FLUX.2-dev-vae](https://huggingface.co/kaiyuyue/FLUX.2-dev-vae) |

Turbo variant: [`MODEL_UNSLOTH_ERNIE_IMAGE_TURBO_GGUF.md`](./MODEL_UNSLOTH_ERNIE_IMAGE_TURBO_GGUF.md).

Baidu `text_encoder/model.safetensors` is for Diffusers workflows only — **not** `--llm` for sd.exe.
